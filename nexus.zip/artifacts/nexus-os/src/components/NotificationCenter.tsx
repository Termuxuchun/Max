import { useState, useEffect, useRef } from "react";
import { ref, onValue, update, remove, push } from "firebase/database";
import { db } from "../firebase";
import { Bell, X, CheckCheck, MessageSquare, Star, BarChart2, Zap, Users, Trash2, Settings } from "lucide-react";

export interface NexusNotification {
  id: string;
  type: "message" | "star" | "poll" | "mention" | "system" | "call";
  title: string;
  body: string;
  ts: number;
  read: boolean;
  from?: string;
  tab?: string;
}

interface NotificationCenterProps {
  username: string;
  accentColor: string;
  onNavigate: (tab: string) => void;
  onOpenChat?: (peer: string) => void;
}

function typeConfig(type: string) {
  switch (type) {
    case "message":  return { icon: <MessageSquare className="w-4 h-4" />, color: "#22d3ee",  bg: "#0e7490" };
    case "star":     return { icon: <Star className="w-4 h-4" />,          color: "#f59e0b",  bg: "#92400e" };
    case "poll":     return { icon: <BarChart2 className="w-4 h-4" />,     color: "#22c55e",  bg: "#166534" };
    case "mention":  return { icon: <Users className="w-4 h-4" />,         color: "#a855f7",  bg: "#6b21a8" };
    case "call":     return { icon: <Zap className="w-4 h-4" />,           color: "#4ade80",  bg: "#166534" };
    case "system":   return { icon: <Settings className="w-4 h-4" />,      color: "#f97316",  bg: "#7c2d12" };
    default:         return { icon: <Bell className="w-4 h-4" />,          color: "#64748b",  bg: "#1e293b" };
  }
}

function timeSince(ts: number) {
  const d = Date.now() - ts;
  if (d < 60000) return "hozir";
  if (d < 3600000) return `${Math.floor(d / 60000)}d`;
  if (d < 86400000) return `${Math.floor(d / 3600000)}s`;
  return `${Math.floor(d / 86400000)}kun`;
}

export default function NotificationCenter({ username, accentColor, onNavigate, onOpenChat }: NotificationCenterProps) {
  const [open, setOpen] = useState(false);
  const [notifs, setNotifs] = useState<NexusNotification[]>([]);
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const panelRef = useRef<HTMLDivElement>(null);
  const prevCountRef = useRef(0);

  useEffect(() => {
    return onValue(ref(db, `notifications/${username}`), snap => {
      if (!snap.exists()) { setNotifs([]); return; }
      const list: NexusNotification[] = [];
      snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => b.ts - a.ts);

      const newUnread = list.filter(n => !n.read).length;
      const prevUnread = prevCountRef.current;

      if (newUnread > prevUnread && prevUnread >= 0 && Notification.permission === "granted") {
        const newest = list.find(n => !n.read);
        if (newest) {
          try {
            new Notification(`NEXUS_OS — ${newest.title}`, {
              body: newest.body,
              icon: "/favicon.svg",
              tag: newest.id,
              silent: false,
            });
          } catch {}
        }
      }
      prevCountRef.current = newUnread;
      setNotifs(list);
    });
  }, [username]);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) setOpen(false);
    }
    if (open) document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  useEffect(() => {
    const key = `nexus_notif_seeded_${username}`;
    if (localStorage.getItem(key)) return;
    localStorage.setItem(key, "1");
    push(ref(db, `notifications/${username}`), {
      type: "system",
      title: "NEXUS_OS ga xush kelibsiz! 🚀",
      body: "Yangi funksiyalar: Analitika, Holatlar, Musiqa, Hamyon va ko'proq!",
      ts: Date.now(),
      read: false,
    });
  }, [username]);

  const unread = notifs.filter(n => !n.read).length;

  function markAll() {
    const updates: Record<string, boolean> = {};
    notifs.filter(n => !n.read).forEach(n => { updates[`notifications/${username}/${n.id}/read`] = true; });
    if (Object.keys(updates).length) update(ref(db), updates);
  }

  function markRead(id: string) {
    update(ref(db, `notifications/${username}/${id}`), { read: true });
  }

  function deleteNotif(id: string) {
    remove(ref(db, `notifications/${username}/${id}`));
  }

  function clearAll() {
    remove(ref(db, `notifications/${username}`));
  }

  function handleClick(n: NexusNotification) {
    markRead(n.id);
    if (n.tab) onNavigate(n.tab);
    else if (n.type === "message" && n.from && onOpenChat) onOpenChat(n.from);
    setOpen(false);
  }

  async function requestPushPermission() {
    if (Notification.permission === "default") {
      await Notification.requestPermission();
    }
  }

  const filters = ["all", "message", "mention", "call", "system"] as const;
  const filterLabels: Record<string, string> = {
    all: "Hammasi", message: "💬", mention: "👥", call: "📞", system: "⚙️"
  };

  const filtered = activeFilter === "all"
    ? notifs
    : notifs.filter(n => n.type === activeFilter);

  return (
    <div className="relative" ref={panelRef}>
      {/* Bell button */}
      <button
        onClick={() => { setOpen(o => !o); requestPushPermission(); }}
        className="relative w-9 h-9 rounded-xl flex items-center justify-center transition hover:bg-slate-800"
        style={{ color: open ? accentColor : "#94a3b8" }}
      >
        <Bell className={`w-5 h-5 ${unread > 0 ? "bell-shake" : ""}`} />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full flex items-center justify-center text-[9px] font-black text-white shadow-lg"
            style={{ background: `linear-gradient(135deg, #ef4444, #f97316)` }}>
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {/* Notification Panel */}
      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 rounded-2xl border border-slate-800/70 shadow-2xl z-50 overflow-hidden"
          style={{ background: "rgba(5,10,24,0.98)", backdropFilter: "blur(20px)", boxShadow: `0 20px 60px rgba(0,0,0,0.8), 0 0 30px ${accentColor}11` }}>

          {/* Panel header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/60">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4" style={{ color: accentColor }} />
              <span className="font-black text-sm text-white">Bildirishnomalar</span>
              {unread > 0 && (
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full"
                  style={{ background: accentColor + "22", color: accentColor }}>
                  {unread} yangi
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              {Notification.permission !== "granted" && (
                <button
                  onClick={requestPushPermission}
                  title="Push bildirishnomalarni yoqish"
                  className="w-7 h-7 rounded-lg hover:bg-amber-950/40 flex items-center justify-center transition text-amber-500 hover:text-amber-400"
                >
                  <Bell className="w-3.5 h-3.5" />
                </button>
              )}
              {unread > 0 && (
                <button onClick={markAll} title="Barchasini o'qildi"
                  className="w-7 h-7 rounded-lg hover:bg-slate-800 flex items-center justify-center transition" style={{ color: accentColor }}>
                  <CheckCheck className="w-4 h-4" />
                </button>
              )}
              {notifs.length > 0 && (
                <button onClick={clearAll} title="Tozalash"
                  className="w-7 h-7 rounded-lg hover:bg-rose-950/40 flex items-center justify-center transition text-slate-600 hover:text-rose-400">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
              <button onClick={() => setOpen(false)}
                className="w-7 h-7 rounded-lg hover:bg-slate-800 flex items-center justify-center transition text-slate-500">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Filter tabs */}
          <div className="flex gap-1 px-3 py-2 border-b border-slate-800/40 overflow-x-auto">
            {filters.map(f => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`flex-shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                  activeFilter === f
                    ? "text-white"
                    : "text-slate-500 hover:text-slate-300"
                }`}
                style={activeFilter === f ? { background: accentColor + "30", color: accentColor } : {}}
              >
                {filterLabels[f]}
              </button>
            ))}
          </div>

          {/* List */}
          <div className="overflow-y-auto max-h-[380px]">
            {filtered.length === 0 && (
              <div className="flex flex-col items-center justify-center py-10 gap-3 text-center px-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-800/60 flex items-center justify-center text-2xl">🔔</div>
                <p className="text-slate-500 text-sm">Hozircha bildirishnoma yo'q</p>
              </div>
            )}

            {filtered.map((n, i) => {
              const cfg = typeConfig(n.type);
              return (
                <div key={n.id}
                  className="group relative border-b border-slate-800/30 last:border-0 transition cursor-pointer hover:bg-slate-800/20"
                  style={{ background: n.read ? "transparent" : accentColor + "08" }}
                  onClick={() => handleClick(n)}>
                  <div className="flex items-start gap-3 px-4 py-3">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ background: cfg.bg + "88", color: cfg.color }}>
                      {cfg.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-1">
                        <p className={`text-sm font-bold leading-snug ${n.read ? "text-slate-400" : "text-white"}`}>{n.title}</p>
                        <span className="text-[9px] text-slate-600 flex-shrink-0 mt-0.5">{timeSince(n.ts)}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed line-clamp-2">{n.body}</p>
                    </div>
                    {!n.read && (
                      <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5" style={{ background: accentColor }} />
                    )}
                  </div>
                  <button onClick={e => { e.stopPropagation(); deleteNotif(n.id); }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 rounded-md bg-rose-950/60 flex items-center justify-center text-rose-400 opacity-0 group-hover:opacity-100 transition">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Footer */}
          {Notification.permission === "granted" && (
            <div className="px-4 py-2 border-t border-slate-800/40 flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
              <span className="text-[10px] text-slate-600 font-mono">Push bildirishnomalar yoqilgan</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export async function pushNotification(username: string, notif: Omit<NexusNotification, "id">) {
  await push(ref(db, `notifications/${username}`), notif);
}
