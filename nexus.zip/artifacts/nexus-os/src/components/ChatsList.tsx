import { useMemo, useState } from "react";
import { Search, X, MessageSquarePlus, Image, Mic, Video, FileText, CheckCheck, Check } from "lucide-react";

interface LastMsg {
  text: string;
  ts: number;
  fromMe: boolean;
  type: string;
  deleted?: boolean;
  edited?: boolean;
}

interface ChatsListProps {
  username: string;
  accentColor: string;
  allUsers: string[];
  unreadMap: Record<string, number>;
  lastMessageMap: Record<string, LastMsg>;
  onlineSet: Set<string>;
  onOpenChat: (u: string) => void;
  backupPeers?: Set<string>;
}

function fmtTime(ts: number) {
  if (!ts) return "";
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString())
    return d.toLocaleTimeString("uz-UZ", { hour: "2-digit", minute: "2-digit" });
  const diff = (now.getTime() - ts) / 86400000;
  if (diff < 7) return d.toLocaleDateString("uz-UZ", { weekday: "short" });
  return d.toLocaleDateString("uz-UZ", { day: "2-digit", month: "2-digit" });
}

function msgPreview(last: LastMsg | undefined) {
  if (!last) return { icon: null, text: "..." };
  if (last.deleted) return { icon: null, text: "🗑️ O'chirildi" };
  const label = last.type === "image"  ? "📷 Rasm"
               : last.type === "audio"  ? "🎵 Ovoz"
               : last.type === "video"  ? "🎬 Video"
               : last.type === "file"   ? "📎 Fayl"
               : null;
  const icon = last.type === "image"  ? <Image   className="w-3 h-3 flex-shrink-0 opacity-60" />
              : last.type === "audio"  ? <Mic     className="w-3 h-3 flex-shrink-0 opacity-60" />
              : last.type === "video"  ? <Video   className="w-3 h-3 flex-shrink-0 opacity-60" />
              : last.type === "file"   ? <FileText className="w-3 h-3 flex-shrink-0 opacity-60" />
              : null;
  return { icon, text: label || (last.edited ? `✏️ ${last.text || "..."}` : last.text || "...") };
}

const GRAD_PAIRS: [string,string][] = [
  ["#22d3ee","#6366f1"], ["#a855f7","#ec4899"], ["#22c55e","#14b8a6"],
  ["#f59e0b","#ef4444"], ["#38bdf8","#818cf8"], ["#84cc16","#22c55e"],
  ["#f97316","#f43f5e"], ["#8b5cf6","#6366f1"], ["#10b981","#0891b2"],
];

function avatarGrad(name: string): [string,string] {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffffffff;
  return GRAD_PAIRS[Math.abs(h) % GRAD_PAIRS.length];
}

type FilterTab = "all" | "unread" | "online";

export default function ChatsList({
  username, accentColor, allUsers, unreadMap, lastMessageMap, onlineSet, onOpenChat, backupPeers,
}: ChatsListProps) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterTab>("all");
  const ghostMode = localStorage.getItem("nx_ghost_mode") === "on";

  const conversations = useMemo(() => {
    return allUsers
      .filter(u => lastMessageMap[u] || unreadMap[u])
      .map(u => ({ peer: u, last: lastMessageMap[u], unread: unreadMap[u] || 0 }))
      .sort((a, b) => (b.last?.ts || 0) - (a.last?.ts || 0));
  }, [allUsers, unreadMap, lastMessageMap]);

  const filtered = useMemo(() => {
    let list = conversations;
    if (query.trim()) {
      const q = query.toLowerCase().replace(/^@/, "");
      list = list.filter(c => c.peer.toLowerCase().includes(q));
    }
    if (filter === "unread")  list = list.filter(c => c.unread > 0);
    if (filter === "online")  list = list.filter(c => onlineSet.has(c.peer));
    return list;
  }, [conversations, query, filter, onlineSet]);

  const totalUnread = conversations.reduce((n, c) => n + c.unread, 0);
  const onlineCount = conversations.filter(c => onlineSet.has(c.peer)).length;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* ===== header ===== */}
      <div className="px-4 pt-4 pb-3 flex-shrink-0 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-mono flex items-center gap-1.5">
              Suhbatlar
              {ghostMode && <span className="text-slate-500 text-sm animate-bounce" title="Arvoq rejimi">👻</span>}
            </p>
            <div className="flex items-center gap-2 mt-0.5">
              <p className="text-lg font-black text-white">Chats</p>
              {ghostMode && (
                <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                  Arvoq rejimi
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {totalUnread > 0 && (
              <span className="text-[10px] font-black px-2.5 py-1 rounded-full text-white shadow-lg"
                style={{ background: accentColor, boxShadow: `0 0 14px ${accentColor}66` }}>
                {totalUnread} yangi
              </span>
            )}
            <button
              onClick={() => {}}
              title="Yangi chat"
              className="w-8 h-8 rounded-xl flex items-center justify-center transition hover:scale-105 active:scale-95"
              style={{ background: `${accentColor}18`, border: `1px solid ${accentColor}30`, color: accentColor }}
            >
              <MessageSquarePlus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Qidirish..."
            className="w-full pl-9 pr-9 py-2.5 rounded-xl text-sm text-white outline-none transition-all duration-200"
            style={{
              background:"rgba(15,23,42,0.7)",
              border:`1px solid ${query ? accentColor + "44" : "rgba(255,255,255,0.07)"}`,
              boxShadow: query ? `0 0 0 2px ${accentColor}15` : "none",
            }}
          />
          {query && (
            <button onClick={() => setQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* filter tabs */}
        <div className="flex gap-1">
          {([
            { key: "all",    label: `Hammasi`, count: conversations.length },
            { key: "unread", label: "O'qilmagan", count: totalUnread },
            { key: "online", label: "Online",     count: onlineCount },
          ] as { key: FilterTab; label: string; count: number }[]).map(tab => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all duration-200 flex-shrink-0"
              style={filter === tab.key
                ? { background: `${accentColor}20`, color: accentColor, border: `1px solid ${accentColor}35` }
                : { background:"transparent", color:"#64748b", border:"1px solid transparent" }
              }
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="min-w-[16px] h-4 flex items-center justify-center rounded-full text-[9px] font-black px-1"
                  style={filter === tab.key
                    ? { background: accentColor, color:"white" }
                    : { background:"#1e293b", color:"#64748b" }
                  }>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ===== list ===== */}
      <div className="flex-1 overflow-y-auto">
        {/* empty state */}
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center px-8 py-16 space-y-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
                style={{ background: `${accentColor}10`, border: `1px solid ${accentColor}20` }}>
                {query ? "🔍" : filter === "unread" ? "✅" : filter === "online" ? "🟢" : "💬"}
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-[#030712]"
                style={{ background: accentColor }} />
            </div>
            <div>
              <p className="text-slate-300 font-bold">
                {query ? `"${query}" topilmadi` : filter === "unread" ? "O'qilmagan xabar yo'q" : filter === "online" ? "Hech kim online emas" : "Suhbatlar yo'q"}
              </p>
              <p className="text-xs text-slate-600 mt-1">
                {query ? "Boshqa nom kiriting" : filter !== "all" ? "Filtrni o'zgartiring" : "Birovga xabar yozing — bu yerda paydo bo'ladi"}
              </p>
            </div>
          </div>
        )}

        <ul>
          {filtered.map(({ peer, last, unread }, idx) => {
            const online    = onlineSet.has(peer);
            const hasUnread = unread > 0;
            const isBackup  = backupPeers?.has(peer) || backupPeers?.has([username, peer].sort().join("_"));
            const [g1, g2]  = avatarGrad(peer);
            const { icon: typeIcon, text: previewText } = msgPreview(last);

            return (
              <li key={peer} className="relative group">
                <button
                  onClick={() => onOpenChat(peer)}
                  className="w-full flex items-center gap-3.5 px-4 py-3 transition-all duration-150 text-left relative overflow-hidden"
                  style={{
                    background: hasUnread
                      ? `linear-gradient(90deg, ${accentColor}06, transparent)`
                      : "transparent",
                  }}
                >
                  {/* hover bg */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-150 pointer-events-none"
                    style={{ background:"rgba(255,255,255,0.025)" }} />

                  {/* unread left border */}
                  {hasUnread && (
                    <div className="absolute left-0 top-2 bottom-2 w-0.5 rounded-full"
                      style={{ background: accentColor }} />
                  )}

                  {/* avatar */}
                  <div className="relative flex-shrink-0">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-base font-black text-white shadow-md"
                      style={{
                        background: `linear-gradient(135deg, ${g1}, ${g2})`,
                        boxShadow: online ? `0 0 0 2px #030712, 0 0 0 3px ${g1}88` : `0 4px 12px ${g1}22`,
                      }}
                    >
                      {peer[0]?.toUpperCase()}
                    </div>
                    {online && (
                      <div className="absolute -bottom-0.5 -right-0.5">
                        <div className="w-3.5 h-3.5 rounded-full bg-green-400 border-2 border-[#030712]" />
                        <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-40" />
                      </div>
                    )}
                    {!online && isBackup && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500/80 border-2 border-[#030712] flex items-center justify-center text-[6px]">
                        ↩
                      </div>
                    )}
                  </div>

                  {/* content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-0.5">
                      <p className={`truncate text-sm ${hasUnread ? "font-black text-white" : "font-semibold text-slate-200"}`}>
                        @{peer}
                      </p>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {last?.fromMe && !hasUnread && (
                          <CheckCheck className="w-3.5 h-3.5 text-slate-600" />
                        )}
                        <span className={`text-[10px] font-mono ${hasUnread ? "" : "text-slate-600"}`}
                          style={hasUnread ? { color: accentColor } : undefined}>
                          {fmtTime(last?.ts || 0)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <p className={`truncate text-xs flex items-center gap-1 min-w-0 ${hasUnread ? "text-slate-300" : "text-slate-500"}`}>
                        {last?.fromMe && (
                          <span className="text-slate-600 flex-shrink-0 text-[10px]">Siz:</span>
                        )}
                        {typeIcon}
                        <span className="truncate">{previewText}</span>
                      </p>
                      {hasUnread && (
                        <span
                          className="flex-shrink-0 min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-black flex items-center justify-center text-white"
                          style={{ background: accentColor, boxShadow: `0 0 10px ${accentColor}66` }}
                        >
                          {unread > 99 ? "99+" : unread}
                        </span>
                      )}
                    </div>

                    {/* tags */}
                    {isBackup && (
                      <div className="flex gap-1 mt-1">
                        <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-emerald-950/40 border border-emerald-800/60 text-emerald-500 font-bold">
                          ↩️ Zaxira
                        </span>
                      </div>
                    )}
                  </div>
                </button>

                {/* divider */}
                {idx < filtered.length - 1 && (
                  <div className="mx-[72px] h-px bg-slate-900/80" />
                )}
              </li>
            );
          })}
        </ul>

        {/* bottom padding */}
        <div className="h-4" />
      </div>
    </div>
  );
}
