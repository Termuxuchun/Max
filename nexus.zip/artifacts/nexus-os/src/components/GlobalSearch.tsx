import { useState, useEffect, useRef } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";
import { Search, X, MessageSquare, Users, Radio, BarChart2, CheckSquare, Clock, ArrowRight, Hash, Zap } from "lucide-react";

interface Result {
  type: "user" | "channel" | "group" | "poll" | "todo";
  id: string;
  title: string;
  subtitle?: string;
  emoji?: string;
  color?: string;
}

interface GlobalSearchProps {
  username: string;
  accentColor: string;
  allUsers: string[];
  onClose: () => void;
  onOpenChat: (id: string, isGroup?: boolean) => void;
  onGoTo: (tab: string) => void;
}

const RECENT_KEY = (u: string) => `nexus_search_recent_${u}`;

export default function GlobalSearch({ username, accentColor, allUsers, onClose, onOpenChat, onGoTo }: GlobalSearchProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [channels, setChannels] = useState<{ id: string; name: string; emoji?: string }[]>([]);
  const [polls, setPolls] = useState<{ id: string; question: string }[]>([]);
  const [recent, setRecent] = useState<Result[]>(() => {
    try { return JSON.parse(localStorage.getItem(RECENT_KEY(username)) || "[]"); } catch { return []; }
  });
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    const u1 = onValue(ref(db, "channels"), snap => {
      if (!snap.exists()) return;
      const list: { id: string; name: string }[] = [];
      snap.forEach(c => { const d = c.val(); list.push({ id: c.key!, name: d.name || c.key! }); });
      setChannels(list);
    });
    const u2 = onValue(ref(db, "polls"), snap => {
      if (!snap.exists()) return;
      const list: { id: string; question: string }[] = [];
      snap.forEach(c => { const d = c.val(); list.push({ id: c.key!, question: d.question || "" }); });
      setPolls(list);
    });
    return () => { u1(); u2(); };
  }, []);

  useEffect(() => {
    if (!query.trim()) { setResults([]); setSelected(0); return; }
    const q = query.toLowerCase();
    const res: Result[] = [];

    allUsers.filter(u => u.toLowerCase().includes(q)).slice(0, 4).forEach(u => {
      res.push({ type: "user", id: u, title: "@" + u, subtitle: "Foydalanuvchi", emoji: "👤", color: accentColor });
    });

    channels.filter(c => c.name.toLowerCase().includes(q)).slice(0, 3).forEach(c => {
      res.push({ type: "channel", id: c.id, title: c.name, subtitle: "Kanal", emoji: "📡", color: "#8b5cf6" });
    });

    polls.filter(p => p.question.toLowerCase().includes(q)).slice(0, 3).forEach(p => {
      res.push({ type: "poll", id: p.id, title: p.question, subtitle: "So'rovnoma", emoji: "📊", color: "#22c55e" });
    });

    setResults(res);
    setSelected(0);
  }, [query, allUsers, channels, polls]);

  function saveRecent(item: Result) {
    const filtered = recent.filter(r => r.id !== item.id).slice(0, 7);
    const next = [item, ...filtered];
    setRecent(next);
    localStorage.setItem(RECENT_KEY(username), JSON.stringify(next));
  }

  function pick(item: Result) {
    saveRecent(item);
    if (item.type === "user") { onOpenChat(item.id); }
    else if (item.type === "channel") { onGoTo("channels"); }
    else if (item.type === "poll") { onGoTo("polls"); }
    else if (item.type === "todo") { onGoTo("todo"); }
    onClose();
  }

  const display = query.trim() ? results : recent;

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowDown") setSelected(s => Math.min(s + 1, display.length - 1));
      if (e.key === "ArrowUp") setSelected(s => Math.max(s - 1, 0));
      if (e.key === "Enter" && display[selected]) pick(display[selected]);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [display, selected]);

  const typeIcon = (type: string) => {
    if (type === "user") return <Users className="w-3.5 h-3.5" />;
    if (type === "channel") return <Radio className="w-3.5 h-3.5" />;
    if (type === "group") return <Hash className="w-3.5 h-3.5" />;
    if (type === "poll") return <BarChart2 className="w-3.5 h-3.5" />;
    if (type === "todo") return <CheckSquare className="w-3.5 h-3.5" />;
    return <MessageSquare className="w-3.5 h-3.5" />;
  };

  const QUICK_ACTIONS = [
    { label: "Chatlar",        tab: "chats",    emoji: "💬", color: accentColor },
    { label: "Holatlar",       tab: "status",   emoji: "📡", color: "#8b5cf6" },
    { label: "Musiqa",         tab: "music",    emoji: "🎵", color: "#ec4899" },
    { label: "Hamyon",         tab: "wallet",   emoji: "⭐", color: "#f59e0b" },
    { label: "So'rovnomalar",  tab: "polls",    emoji: "📊", color: "#22c55e" },
    { label: "Vazifalar",      tab: "todo",     emoji: "✅", color: "#14b8a6" },
    { label: "O'yinlar",       tab: "games",    emoji: "🎮", color: "#6366f1" },
    { label: "Sozlamalar",     tab: "settings", emoji: "⚙️", color: "#64748b" },
  ];

  return (
    <div className="fixed inset-0 z-[95] flex items-start justify-center pt-[10vh] px-4"
      style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(24px)" }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>

      <div className="w-full max-w-lg drop-in">
        {/* Search input */}
        <div className="relative flex items-center bg-slate-900 border rounded-2xl overflow-hidden shadow-2xl"
          style={{ borderColor: accentColor + "55", boxShadow: `0 0 40px ${accentColor}22` }}>
          <Search className="absolute left-4 w-5 h-5 text-slate-500 pointer-events-none" />
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Foydalanuvchi, kanal, so'rovnoma qidirish..."
            className="w-full bg-transparent pl-12 pr-12 py-4 text-white text-base outline-none placeholder-slate-600"
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-4 w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition">
              <X className="w-4 h-4 text-slate-400" />
            </button>
          )}
        </div>

        {/* Shortcut hint */}
        <div className="flex items-center justify-between px-1 mt-2 mb-3">
          <span className="text-[10px] text-slate-700 flex items-center gap-1">
            <Zap className="w-3 h-3" /> Tezkor izlash
          </span>
          <div className="flex items-center gap-2 text-[10px] text-slate-700">
            <span className="bg-slate-800 px-1.5 py-0.5 rounded">↑↓</span> navigatsiya
            <span className="bg-slate-800 px-1.5 py-0.5 rounded">Enter</span> tanlash
            <span className="bg-slate-800 px-1.5 py-0.5 rounded">Esc</span> yopish
          </div>
        </div>

        {/* Quick actions (shown when no query) */}
        {!query.trim() && (
          <div className="mb-3">
            <p className="text-[10px] uppercase tracking-widest text-slate-700 mb-2 px-1 font-bold">Tezkor o'tish</p>
            <div className="grid grid-cols-4 gap-2">
              {QUICK_ACTIONS.map(a => (
                <button key={a.tab} onClick={() => { onGoTo(a.tab); onClose(); }}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl border transition active:scale-95 hover:border-opacity-60"
                  style={{ background: a.color + "11", borderColor: a.color + "33" }}>
                  <span className="text-xl">{a.emoji}</span>
                  <span className="text-[10px] font-bold text-slate-400">{a.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results */}
        {display.length > 0 && (
          <div className="bg-slate-900 border border-slate-800/60 rounded-2xl overflow-hidden shadow-2xl">
            {!query.trim() && recent.length > 0 && (
              <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/60">
                <span className="text-[10px] uppercase tracking-widest text-slate-600 font-bold flex items-center gap-1">
                  <Clock className="w-3 h-3" /> So'nggi qidiruvlar
                </span>
                <button onClick={() => { setRecent([]); localStorage.removeItem(RECENT_KEY(username)); }}
                  className="text-[10px] text-slate-700 hover:text-slate-400 transition">Tozalash</button>
              </div>
            )}
            {display.map((item, i) => (
              <button key={item.id + item.type} onClick={() => pick(item)}
                className="w-full flex items-center gap-3 px-4 py-3 transition border-b border-slate-800/40 last:border-0"
                style={selected === i ? { background: accentColor + "15" } : { background: "transparent" }}
                onMouseEnter={() => setSelected(i)}>
                <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base flex-shrink-0"
                  style={{ background: (item.color || accentColor) + "22", border: `1px solid ${item.color || accentColor}33` }}>
                  {item.emoji}
                </div>
                <div className="flex-1 text-left min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{item.title}</p>
                  <div className="flex items-center gap-1 text-[10px] text-slate-500">
                    {typeIcon(item.type)}
                    <span>{item.subtitle}</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 flex-shrink-0" style={{ color: selected === i ? accentColor : "#334155" }} />
              </button>
            ))}
          </div>
        )}

        {query.trim() && results.length === 0 && (
          <div className="bg-slate-900 border border-slate-800/60 rounded-2xl px-4 py-8 text-center">
            <div className="text-4xl mb-3">🔍</div>
            <p className="text-slate-400 text-sm font-medium">"{query}" bo'yicha hech narsa topilmadi</p>
            <p className="text-slate-600 text-xs mt-1">Boshqacha so'z bilan urinib ko'ring</p>
          </div>
        )}
      </div>
    </div>
  );
}
