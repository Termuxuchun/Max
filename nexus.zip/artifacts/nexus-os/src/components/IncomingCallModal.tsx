import { useEffect, useRef } from "react";
import { Phone, PhoneOff, Video } from "lucide-react";

interface IncomingCallModalProps {
  caller: string;
  callType: "audio" | "video";
  onAccept: () => void;
  onReject: () => void;
}

function getAvatarGradient(name: string): [string, string] {
  const gs: [string, string][] = [
    ["#22d3ee", "#3b82f6"],
    ["#8b5cf6", "#ec4899"],
    ["#10b981", "#22d3ee"],
    ["#f59e0b", "#ef4444"],
    ["#6366f1", "#8b5cf6"],
    ["#14b8a6", "#3b82f6"],
  ];
  return gs[(name.charCodeAt(0) || 0) % gs.length];
}

export default function IncomingCallModal({ caller, callType, onAccept, onReject }: IncomingCallModalProps) {
  const [c1, c2] = getAvatarGradient(caller);
  const containerRef = useRef<HTMLDivElement>(null);

  // Vibrate device if supported
  useEffect(() => {
    if (navigator.vibrate) {
      const pattern = [400, 200, 400, 200, 400];
      navigator.vibrate(pattern);
      const interval = setInterval(() => navigator.vibrate(pattern), 2500);
      return () => { clearInterval(interval); navigator.vibrate(0); };
    }
  }, []);

  // Slide in from top animation
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.style.transform = "translateY(-100%)";
      containerRef.current.style.opacity = "0";
      requestAnimationFrame(() => {
        setTimeout(() => {
          if (containerRef.current) {
            containerRef.current.style.transition = "transform 0.5s cubic-bezier(0.34,1.2,0.64,1), opacity 0.3s ease";
            containerRef.current.style.transform = "translateY(0)";
            containerRef.current.style.opacity = "1";
          }
        }, 20);
      });
    }
  }, []);

  return (
    <div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-start pt-0 overflow-hidden"
      style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(24px)" }}
    >
      {/* Ambient background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute w-96 h-96 rounded-full opacity-20 blur-3xl"
          style={{
            background: `radial-gradient(circle, ${c1}, transparent)`,
            top: "5%", left: "20%",
            animation: "float-orb 8s ease-in-out infinite",
          }}
        />
        <div
          className="absolute w-72 h-72 rounded-full opacity-15 blur-3xl"
          style={{
            background: `radial-gradient(circle, ${c2}, transparent)`,
            bottom: "15%", right: "15%",
            animation: "float-orb 11s ease-in-out infinite 2s",
          }}
        />
      </div>

      {/* Main card — slides in from top */}
      <div
        ref={containerRef}
        className="relative w-full max-w-sm mx-auto"
        style={{
          background: "linear-gradient(160deg, rgba(10,15,30,0.97), rgba(5,8,18,0.99))",
          border: `1px solid ${c1}30`,
          borderTop: "none",
          borderRadius: "0 0 32px 32px",
          boxShadow: `0 20px 60px rgba(0,0,0,0.8), 0 0 0 1px ${c1}15`,
          padding: "40px 24px 32px",
        }}
      >
        {/* Shimmer top edge */}
        <div
          className="absolute top-0 left-0 right-0 h-0.5"
          style={{ background: `linear-gradient(90deg, transparent, ${c1}, ${c2}, transparent)`, opacity: 0.6 }}
        />

        {/* Call type badge */}
        <div className="flex justify-center mb-6">
          <div
            className="flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-wide"
            style={{
              background: callType === "video" ? "rgba(59,130,246,0.15)" : `${c1}15`,
              border: `1px solid ${callType === "video" ? "rgba(59,130,246,0.3)" : `${c1}30`}`,
              color: callType === "video" ? "#60a5fa" : c1,
              animation: "glow-pulse 2s ease-in-out infinite",
            }}
          >
            {callType === "video"
              ? <><Video className="w-3.5 h-3.5" /> Video qo'ng'iroq</>
              : <><Phone className="w-3.5 h-3.5" /> Ovozli qo'ng'iroq</>
            }
          </div>
        </div>

        {/* Avatar + Ripples */}
        <div className="flex justify-center mb-6">
          <div className="relative flex items-center justify-center">
            {/* Ripple rings */}
            <div
              className="absolute rounded-full call-ripple"
              style={{ width: 140, height: 140, background: `${c1}15` }}
            />
            <div
              className="absolute rounded-full call-ripple-2"
              style={{ width: 140, height: 140, background: `${c1}10` }}
            />
            <div
              className="absolute rounded-full call-ripple-3"
              style={{ width: 140, height: 140, background: `${c1}08` }}
            />

            {/* Phone shake icon */}
            <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center z-10 shadow-lg">
              <Phone className="w-4 h-4 text-white phone-shake" />
            </div>

            {/* Avatar */}
            <div
              className="relative w-28 h-28 rounded-full flex items-center justify-center text-4xl font-black text-white select-none"
              style={{
                background: `linear-gradient(135deg, ${c1}, ${c2})`,
                boxShadow: `0 0 60px ${c1}50, 0 0 20px ${c1}25`,
              }}
            >
              {caller.slice(0, 2).toUpperCase()}
            </div>
          </div>
        </div>

        {/* Name + subtitle */}
        <div className="text-center mb-8">
          <p className="text-2xl font-black text-white tracking-tight mb-1">@{caller}</p>
          <p className="text-sm text-slate-400">
            {callType === "video" ? "Sizni video qo'ng'iroqqa taklif qilmoqda" : "Sizni qo'ng'iroqqa taklif qilmoqda"}
          </p>
          {/* Animated dots */}
          <div className="flex justify-center gap-1.5 mt-3">
            {[0,1,2].map(i => (
              <div
                key={i}
                className="w-1.5 h-1.5 rounded-full typing-dot"
                style={{ background: c1 }}
              />
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-center gap-12">
          {/* Reject */}
          <div className="flex flex-col items-center gap-2">
            <button
              onClick={onReject}
              className="w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 active:scale-90"
              style={{
                background: "rgba(239,68,68,0.15)",
                border: "1px solid rgba(239,68,68,0.4)",
              }}
            >
              <PhoneOff className="w-6 h-6 text-red-400" />
            </button>
            <span className="text-xs text-red-400/80 font-medium">Rad etish</span>
          </div>

          {/* Accept */}
          <div className="flex flex-col items-center gap-2">
            <button
              onClick={onAccept}
              className="w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-all duration-200 active:scale-90"
              style={{
                background: `linear-gradient(135deg, #22c55e, #16a34a)`,
                boxShadow: "0 0 40px rgba(34,197,94,0.5), 0 0 80px rgba(34,197,94,0.2)",
                animation: "glow-green 1.5s ease-in-out infinite",
              }}
            >
              {callType === "video"
                ? <Video className="w-8 h-8 text-white" />
                : <Phone className="w-8 h-8 text-white" />
              }
            </button>
            <span className="text-xs text-green-400/80 font-medium">Qabul qilish</span>
          </div>
        </div>

        {/* Swipe hint */}
        <p className="text-center text-[10px] text-slate-600 mt-6 font-mono">
          Yuqoriga suring — rad etish &nbsp;·&nbsp; Pastga suring — qabul qilish
        </p>
      </div>
    </div>
  );
}
