import { useEffect, useRef, useState } from "react";
import { ref, onValue, set, remove, get } from "firebase/database";
import { db } from "../firebase";

interface Props {
  username: string;
  accentColor: string;
  onOpenProfile: (u: string) => void;
  onOpenChat: (u: string) => void;
  onClose: () => void;
}

interface NearbyUser {
  username: string;
  displayName: string;
  state: string;
  lat?: number;
  lng?: number;
  nearbyAt?: number;
  dist?: number;
}

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function fmtDist(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(1)} km`;
}

export default function NearbyModal({ username, accentColor, onOpenProfile, onOpenChat, onClose }: Props) {
  const [geoState, setGeoState] = useState<"idle" | "requesting" | "active" | "denied" | "unsupported">("idle");
  const [myLat, setMyLat] = useState<number | null>(null);
  const [myLng, setMyLng] = useState<number | null>(null);
  const [nearbyUsers, setNearbyUsers] = useState<NearbyUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [contacts, setContacts] = useState<Set<string>>(new Set());
  const watchRef = useRef<number | null>(null);
  const cleanupRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    get(ref(db, `contacts/${username}`)).then(s => {
      if (s.exists()) {
        const keys = new Set<string>();
        s.forEach(c => { keys.add(c.key!); });
        setContacts(keys);
      }
    });
  }, [username]);

  useEffect(() => {
    return () => {
      if (watchRef.current !== null) navigator.geolocation.clearWatch(watchRef.current);
      cleanupRef.current?.();
    };
  }, []);

  useEffect(() => {
    if (myLat === null || myLng === null) return;

    // Write my location to Firebase
    const statusRef = ref(db, `status/${username}`);
    set(statusRef, {
      state: "online",
      nearbyMode: true,
      nearbyAt: Date.now(),
      lat: myLat,
      lng: myLng,
    }).catch(() => {});

    // Cleanup: remove location when modal closes
    cleanupRef.current = () => {
      set(ref(db, `status/${username}/nearbyMode`), false).catch(() => {});
      remove(ref(db, `status/${username}/lat`)).catch(() => {});
      remove(ref(db, `status/${username}/lng`)).catch(() => {});
    };

    // Listen for nearby users
    setLoading(true);
    const unsub = onValue(ref(db, "status"), snap => {
      if (!snap.exists()) { setNearbyUsers([]); setLoading(false); return; }
      const list: NearbyUser[] = [];
      snap.forEach(child => {
        const u = child.key!;
        if (u === username) return;
        const d = child.val();
        if (d.state !== "online") return;
        const user: NearbyUser = { username: u, displayName: u, state: d.state };
        if (d.lat && d.lng) {
          user.lat = d.lat;
          user.lng = d.lng;
          user.dist = haversineKm(myLat, myLng, d.lat, d.lng);
          if (user.dist > 50) return; // skip users > 50km
        }
        user.nearbyAt = d.nearbyAt;
        list.push(user);
      });

      // Sort: users with location first (by dist), then others
      list.sort((a, b) => {
        if (a.dist !== undefined && b.dist !== undefined) return a.dist - b.dist;
        if (a.dist !== undefined) return -1;
        if (b.dist !== undefined) return 1;
        return 0;
      });

      setNearbyUsers(list);
      setLoading(false);
    });

    return () => unsub();
  }, [myLat, myLng, username]);

  function requestLocation() {
    if (!navigator.geolocation) {
      setGeoState("unsupported");
      return;
    }
    setGeoState("requesting");
    watchRef.current = navigator.geolocation.watchPosition(
      pos => {
        setMyLat(pos.coords.latitude);
        setMyLng(pos.coords.longitude);
        setGeoState("active");
      },
      err => {
        if (err.code === 1) setGeoState("denied");
        else setGeoState("unsupported");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  }

  function skipLocation() {
    // Show online users without distance filtering
    setMyLat(0);
    setMyLng(0);
    setGeoState("active");
    setLoading(true);
    const unsub = onValue(ref(db, "status"), snap => {
      if (!snap.exists()) { setNearbyUsers([]); setLoading(false); return; }
      const list: NearbyUser[] = [];
      snap.forEach(child => {
        const u = child.key!;
        if (u === username) return;
        const d = child.val();
        if (d.state !== "online") return;
        list.push({ username: u, displayName: u, state: "online" });
      });
      setNearbyUsers(list);
      setLoading(false);
    });
    cleanupRef.current = () => unsub();
  }

  async function addContact(u: string) {
    await set(ref(db, `contacts/${username}/${u}`), { name: u, addedAt: Date.now() });
    setContacts(prev => new Set([...prev, u]));
  }

  return (
    <div
      className="fixed inset-0 z-[130] flex items-end sm:items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.9)", backdropFilter: "blur(18px)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl border border-slate-800 overflow-hidden"
        style={{ background: "linear-gradient(180deg,#0f172a,#030712)", maxHeight: "85vh", display: "flex", flexDirection: "column" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-800/60 flex items-center justify-between flex-shrink-0">
          <div>
            <p className="text-base font-black text-white">🌍 Yaqindagi odamlar</p>
            <p className="text-[11px] text-slate-500 font-mono">
              {geoState === "active" && myLat !== 0 ? "Joylashuvingiz asosida" : "Hozir onlayn bo'lganlar"}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 text-sm hover:text-white transition"
          >✕</button>
        </div>

        {/* Body */}
        {geoState === "idle" && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 gap-6 text-center">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl relative"
              style={{ background: `${accentColor}22`, border: `1px solid ${accentColor}44` }}>
              <span className="nearby-pulse" style={{ background: accentColor }} />
              🌍
            </div>
            <div>
              <p className="font-black text-white text-base">Yaqindagi odamlarni ko'ring</p>
              <p className="text-sm text-slate-500 mt-1.5 leading-relaxed">
                Joylashuvingizni yoqing va 50km ichidagi NexusOS foydalanuvchilarini ko'ring
              </p>
            </div>
            <div className="w-full space-y-2.5">
              <button
                onClick={requestLocation}
                className="w-full py-3.5 rounded-2xl font-bold text-sm text-white active:scale-95 transition"
                style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}
              >
                📍 Joylashuvni yoqish
              </button>
              <button
                onClick={skipLocation}
                className="w-full py-3 rounded-2xl font-bold text-sm text-slate-400 bg-slate-800/60 border border-slate-700 hover:border-slate-600 active:scale-95 transition"
              >
                👁️ Faqat onlaynlarni ko'rish
              </button>
            </div>
            <p className="text-[10px] text-slate-600">Joylashuvingiz faqat siz uchun ko'rinadi</p>
          </div>
        )}

        {geoState === "requesting" && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 gap-4 text-center">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl animate-pulse bg-slate-800">📍</div>
            <p className="font-bold text-white">Joylashuvingizga ruxsat so'ralmoqda...</p>
            <p className="text-sm text-slate-500">Brauzerda "Ruxsat berish" ni bosing</p>
          </div>
        )}

        {(geoState === "denied" || geoState === "unsupported") && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 gap-4 text-center">
            <div className="text-4xl">⚠️</div>
            <p className="font-bold text-white">
              {geoState === "denied" ? "Joylashuv ruxsati berilmadi" : "Joylashuv qo'llab-quvvatlanmaydi"}
            </p>
            <p className="text-sm text-slate-500">
              {geoState === "denied" ? "Brauzer sozlamalaridan joylashuvni yoqing" : "Qurilmangiz joylashuvni qo'llab-quvvatlamaydi"}
            </p>
            <button onClick={skipLocation}
              className="px-6 py-2.5 rounded-xl font-bold text-sm text-slate-300 bg-slate-800 border border-slate-700">
              👁️ Onlaynlarni ko'rish
            </button>
          </div>
        )}

        {geoState === "active" && (
          <>
            {/* Status bar */}
            <div className="px-4 py-2 border-b border-slate-800/40 flex-shrink-0 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-[11px] text-slate-400 font-mono">
                {loading ? "Yuklanmoqda..." : `${nearbyUsers.length} kishi topildi`}
              </span>
              {myLat !== 0 && (
                <span className="ml-auto text-[10px] text-slate-600 font-mono">
                  📍 {myLat?.toFixed(3)}, {myLng?.toFixed(3)}
                </span>
              )}
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {loading && (
                <div className="flex items-center justify-center py-10">
                  <div className="w-8 h-8 rounded-full border-2 border-slate-700 border-t-cyan-400 animate-spin" />
                </div>
              )}

              {!loading && nearbyUsers.length === 0 && (
                <div className="flex flex-col items-center justify-center py-12 gap-3 text-center">
                  <div className="text-5xl opacity-20">🌍</div>
                  <p className="text-slate-500 text-sm font-mono">Hozir yaqinda hech kim yo'q</p>
                  <p className="text-slate-600 text-xs">Do'stlaringizni NexusOS'ga taklif qiling!</p>
                </div>
              )}

              {!loading && nearbyUsers.map(u => (
                <div key={u.username} className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-600 transition">
                  {/* Avatar */}
                  <button onClick={() => { onClose(); onOpenProfile(u.username); }} className="flex-shrink-0">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-base relative"
                      style={{ background: `linear-gradient(135deg,${accentColor}44,#4f46e5)` }}>
                      {u.username[0]?.toUpperCase()}
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#030712] bg-green-400" />
                    </div>
                  </button>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-100 truncate">@{u.username}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-green-400 font-mono">● onlayn</span>
                      {u.dist !== undefined && myLat !== 0 && (
                        <span className="text-[10px] text-slate-500 font-mono">
                          📍 {fmtDist(u.dist)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-1.5 flex-shrink-0">
                    <button onClick={() => { onClose(); onOpenChat(u.username); }}
                      className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-sm hover:bg-slate-700 transition active:scale-90">
                      💬
                    </button>
                    {contacts.has(u.username) ? (
                      <div className="w-8 h-8 rounded-lg bg-green-950/30 border border-green-800/40 flex items-center justify-center text-sm">✓</div>
                    ) : (
                      <button onClick={() => addContact(u.username)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-sm hover:opacity-90 transition active:scale-90"
                        style={{ background: accentColor }}>
                        ➕
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
