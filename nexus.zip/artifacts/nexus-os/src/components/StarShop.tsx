import { useState, useEffect } from "react";
import { ref, push, onValue, set, get } from "firebase/database";
import { db } from "../firebase";
import { STAR_PACKAGES, type StarPackage } from "../lib/stars";

interface Props {
  username: string;
  accentColor: string;
  onClose: () => void;
}

interface StarRequest {
  id: string;
  username: string;
  amount: number;
  packageId: string;
  label: string;
  price: string;
  status: "pending" | "approved" | "denied";
  requestedAt: number;
  resolvedAt?: number;
}

export default function StarShop({ username, accentColor, onClose }: Props) {
  const [balance, setBalance] = useState(0);
  const [requests, setRequests] = useState<StarRequest[]>([]);
  const [selected, setSelected] = useState<StarPackage>(STAR_PACKAGES[1]);
  const [sending, setSending] = useState(false);
  const [tab, setTab] = useState<"shop" | "history">("shop");

  useEffect(() => {
    const unsub1 = onValue(ref(db, `stars/${username}`), snap => {
      setBalance(snap.val()?.balance || 0);
    });
    const unsub2 = onValue(ref(db, `star_requests`), snap => {
      const list: StarRequest[] = [];
      snap?.forEach(c => {
        const d = c.val();
        if (d.username === username) list.push({ id: c.key!, ...d });
      });
      list.sort((a, b) => b.requestedAt - a.requestedAt);
      setRequests(list);
    });
    return () => { unsub1(); unsub2(); };
  }, [username]);

  const hasPending = requests.some(r => r.status === "pending");

  async function requestPurchase() {
    if (sending || hasPending) return;
    setSending(true);
    try {
      await push(ref(db, "star_requests"), {
        username,
        amount: selected.amount,
        packageId: selected.id,
        label: selected.label,
        price: selected.price,
        status: "pending",
        requestedAt: Date.now(),
      });
      await push(ref(db, "system_pushes/Max"), {
        msg: `⭐ @${username} ${selected.label} (${selected.price}) sotib olmoqchi!`,
        from: username, type: "msg", ts: Date.now(),
      });
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[160] flex items-end sm:items-center justify-center"
      style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(16px)" }}
      onClick={onClose}>
      <div className="w-full max-w-md max-h-[85vh] overflow-hidden rounded-t-3xl sm:rounded-3xl border border-amber-900/40 flex flex-col animate-[scale-in_0.25s_ease-out]"
        style={{ background: "linear-gradient(180deg,#0f172a,#020617)" }}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="p-5 flex items-center justify-between border-b border-slate-800/60"
          style={{ background: "linear-gradient(135deg,rgba(180,83,9,0.15),transparent)" }}>
          <div>
            <p className="text-lg font-black text-white">⭐ Stars Shop</p>
            <p className="text-xs text-amber-400/70 font-mono">Balans: <span className="font-black text-amber-400">{balance}⭐</span></p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center text-sm">✕</button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800/50">
          {(["shop","history"] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-2.5 text-xs font-bold tracking-wider uppercase transition ${tab === t ? "text-amber-400 border-b-2 border-amber-400" : "text-slate-500 hover:text-slate-300"}`}>
              {t === "shop" ? "🛒 Sotib olish" : "📋 Tarix"}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {tab === "shop" && (
            <>
              {hasPending && (
                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/50 text-center">
                  <p className="text-xs text-amber-400 font-bold">⏳ So'rovingiz ko'rib chiqilmoqda...</p>
                  <p className="text-[10px] text-amber-600 mt-0.5">Admin tasdiqlashini kuting</p>
                </div>
              )}

              {/* Package grid */}
              <div className="grid grid-cols-2 gap-2.5">
                {STAR_PACKAGES.map(pkg => (
                  <button key={pkg.id} onClick={() => setSelected(pkg)}
                    className={`relative rounded-2xl p-3.5 text-left transition ${
                      selected.id === pkg.id
                        ? "ring-2 ring-amber-400 scale-[1.02]"
                        : "hover:scale-[1.01] opacity-90"
                    }`}
                    style={{ background: pkg.gradient }}>
                    {pkg.popular && (
                      <span className="absolute -top-1.5 right-2 text-[8px] font-black bg-white text-amber-600 px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                        🔥 Mashhur
                      </span>
                    )}
                    <div className="text-2xl mb-1">{pkg.icon}</div>
                    <p className="text-sm font-black text-white">{pkg.label}</p>
                    <p className="text-[10px] text-white/70 font-bold mt-0.5">{pkg.price}</p>
                  </button>
                ))}
              </div>

              {/* Selected preview + buy */}
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-800/40 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                    style={{ background: selected.gradient }}>
                    {selected.icon}
                  </div>
                  <div>
                    <p className="font-black text-white">{selected.label}</p>
                    <p className="text-xs text-amber-400 font-mono">{selected.price}</p>
                  </div>
                </div>
                <p className="text-[10px] text-slate-400">
                  So'rov admin (@Max) ga yuboriladi. Tasdiqlangandan so'ng balansingiz yangilanadi.
                </p>
                <button onClick={requestPurchase} disabled={sending || hasPending}
                  className="w-full py-3 rounded-xl font-black text-white text-sm transition disabled:opacity-40"
                  style={{ background: hasPending ? "#374151" : "linear-gradient(135deg,#d97706,#b45309)" }}>
                  {sending ? "Yuborilmoqda..." : hasPending ? "⏳ Kutilmoqda..." : `💳 ${selected.price} — Sotib olish`}
                </button>
              </div>

              <p className="text-[10px] text-slate-600 text-center">
                Stars sovg'alar uchun ishlatiladi · 1⭐ = 1 yulduz
              </p>
            </>
          )}

          {tab === "history" && (
            <div className="space-y-2">
              {requests.length === 0 && (
                <div className="text-center py-10 text-slate-600">
                  <p className="text-3xl mb-2">⭐</p>
                  <p className="text-sm">Hali so'rovlar yo'q</p>
                </div>
              )}
              {requests.map(req => (
                <div key={req.id}
                  className={`p-3 rounded-xl border ${
                    req.status === "pending" ? "bg-amber-950/10 border-amber-900/30"
                    : req.status === "approved" ? "bg-green-950/10 border-green-900/30"
                    : "bg-rose-950/10 border-rose-900/30"
                  }`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-black text-white">{req.label}</p>
                      <p className="text-[10px] text-slate-500 font-mono">{new Date(req.requestedAt).toLocaleString("uz-UZ")}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-amber-400">+{req.amount}⭐</p>
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                        req.status === "pending" ? "bg-amber-900/40 text-amber-400"
                        : req.status === "approved" ? "bg-green-900/40 text-green-400"
                        : "bg-rose-900/40 text-rose-400"
                      }`}>
                        {req.status === "pending" ? "⏳ Kutilmoqda" : req.status === "approved" ? "✅ Tasdiqlandi" : "❌ Rad etildi"}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
