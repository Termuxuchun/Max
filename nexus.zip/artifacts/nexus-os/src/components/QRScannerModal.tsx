import { useEffect, useRef, useState } from "react";

interface Props {
  onResult: (text: string) => void;
  onClose: () => void;
}

export default function QRScannerModal({ onResult, onClose }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState(true);
  const [success, setSuccess] = useState(false);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    let detector: any;

    async function start() {
      if (!("BarcodeDetector" in window)) {
        setError("Brauzeringiz QR skanerlashni qo'llab-quvvatlamaydi.\nChrome (Android 9+) yoki Edge ishlating.");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } },
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        detector = new (window as any).BarcodeDetector({ formats: ["qr_code"] });
        scanLoop();
      } catch {
        setError("Kamera ruxsati rad etildi.\nBrauzer → Sozlamalar → Ruxsatlar → Kamera.");
      }
    }

    function scanLoop() {
      if (!videoRef.current || !detector) return;
      detector
        .detect(videoRef.current)
        .then((barcodes: any[]) => {
          if (barcodes.length > 0) {
            setScanning(false);
            setSuccess(true);
            cleanup();
            setTimeout(() => onResult(barcodes[0].rawValue), 400);
          } else {
            animFrameRef.current = requestAnimationFrame(scanLoop);
          }
        })
        .catch(() => {
          animFrameRef.current = requestAnimationFrame(scanLoop);
        });
    }

    start();
    return cleanup;
  }, []);

  function cleanup() {
    cancelAnimationFrame(animFrameRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
  }

  return (
    <div
      className="fixed inset-0 z-[140] flex flex-col items-center justify-center"
      style={{ background: "rgba(0,0,0,0.97)" }}
      onClick={onClose}
    >
      <p className="text-white font-black text-lg mb-6 tracking-wide">📷 QR Skaner</p>

      <div className="relative" onClick={e => e.stopPropagation()}>
        {/* Outer glow ring */}
        <div className="absolute -inset-1 rounded-2xl opacity-60" style={{ background: "linear-gradient(135deg,#06b6d4,#6366f1)", filter: "blur(8px)" }} />

        <div className="relative w-72 h-72 rounded-2xl overflow-hidden border-2 border-cyan-500">
          <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />

          {scanning && !error && (
            <div className="absolute inset-0 pointer-events-none">
              {/* Sweep line */}
              <div className="qr-scan-line" />
              {/* Corner markers */}
              <div className="absolute top-3 left-3 w-8 h-8 border-t-[3px] border-l-[3px] border-cyan-400 rounded-tl-lg" />
              <div className="absolute top-3 right-3 w-8 h-8 border-t-[3px] border-r-[3px] border-cyan-400 rounded-tr-lg" />
              <div className="absolute bottom-3 left-3 w-8 h-8 border-b-[3px] border-l-[3px] border-cyan-400 rounded-bl-lg" />
              <div className="absolute bottom-3 right-3 w-8 h-8 border-b-[3px] border-r-[3px] border-cyan-400 rounded-br-lg" />
              {/* Dim overlay around corners */}
              <div className="absolute inset-0" style={{ boxShadow: "inset 0 0 60px rgba(0,0,0,0.5)" }} />
            </div>
          )}

          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/85 p-5">
              <div className="text-center space-y-2">
                <span className="text-4xl">⚠️</span>
                <p className="text-red-400 text-xs text-center whitespace-pre-line leading-relaxed">{error}</p>
              </div>
            </div>
          )}

          {success && (
            <div className="absolute inset-0 flex items-center justify-center bg-green-950/85">
              <div className="text-center">
                <span className="text-5xl qr-success-pop">✅</span>
                <p className="text-green-400 text-xs font-bold mt-2">Topildi!</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <p className="text-slate-500 text-xs mt-5 text-center">QR kodni ramka ichiga joylashtiring</p>
      <p className="text-slate-700 text-[10px] mt-1">NexusOS QR kodlari avtomatik aniqlanadi</p>
      <button
        onClick={onClose}
        className="mt-5 px-8 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-sm font-bold hover:bg-slate-700 transition active:scale-95"
      >
        Yopish
      </button>
    </div>
  );
}
