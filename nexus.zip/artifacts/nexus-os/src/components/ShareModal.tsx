import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";

interface Props {
  title: string;
  subtitle: string;
  link: string;
  displayLink: string;
  onClose: () => void;
}

type NfcMode = "idle" | "write-ready" | "writing" | "write-done" | "write-error" |
               "scan-ready" | "scanning" | "scan-done" | "scan-error" | "unsupported";

export default function ShareModal({ title, subtitle, link, displayLink, onClose }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [copied, setCopied] = useState(false);
  const [nfcMode, setNfcMode] = useState<NfcMode>("idle");
  const [scannedText, setScannedText] = useState("");
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, link, {
        width: 220,
        margin: 2,
        color: { dark: "#e2e8f0", light: "#0f172a" },
      }).catch(() => {});
    }
  }, [link]);

  useEffect(() => {
    return () => { abortRef.current?.abort(); };
  }, []);

  function copyLink() {
    const text = displayLink;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    } else {
      fallbackCopy(text);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }

  function fallbackCopy(text: string) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;opacity:0;top:0;left:0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
  }

  function checkNFCSupport(): boolean {
    if (!("NDEFReader" in window)) {
      setNfcMode("unsupported");
      setTimeout(() => setNfcMode("idle"), 4000);
      return false;
    }
    return true;
  }

  async function startNFCWrite() {
    if (!checkNFCSupport()) return;
    abortRef.current?.abort();
    setNfcMode("write-ready");
  }

  async function doNFCWrite() {
    if (!checkNFCSupport()) return;
    try {
      setNfcMode("writing");
      const ndef = new (window as any).NDEFReader();
      abortRef.current = new AbortController();
      await ndef.write(
        { records: [{ recordType: "url", data: link }] },
        { signal: abortRef.current.signal }
      );
      setNfcMode("write-done");
      setTimeout(() => setNfcMode("idle"), 3500);
    } catch (err: any) {
      if (err?.name === "AbortError") { setNfcMode("idle"); return; }
      setNfcMode("write-error");
      setTimeout(() => setNfcMode("idle"), 3500);
    }
  }

  async function startNFCScan() {
    if (!checkNFCSupport()) return;
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    setNfcMode("scanning");
    try {
      const ndef = new (window as any).NDEFReader();
      await ndef.scan({ signal: abortRef.current.signal });
      ndef.addEventListener("reading", ({ message }: any) => {
        for (const record of message.records) {
          let text = "";
          if (record.recordType === "url" || record.recordType === "text") {
            const decoder = new TextDecoder(record.encoding || "utf-8");
            text = decoder.decode(record.data);
          } else if (record.recordType === "mime") {
            const decoder = new TextDecoder("utf-8");
            text = decoder.decode(record.data);
          }
          if (text) {
            setScannedText(text);
            setNfcMode("scan-done");
            abortRef.current?.abort();
            if (text.startsWith("nexus://")) {
              setTimeout(() => {
                onClose();
                if (text.startsWith("nexus://join/")) {
                  window.dispatchEvent(new CustomEvent("nexus-navigate", {
                    detail: { type: "channel", channelId: text.replace("nexus://join/", "") }
                  }));
                } else if (text.startsWith("nexus://user/")) {
                  window.dispatchEvent(new CustomEvent("nexus-navigate", {
                    detail: { type: "user", username: text.replace("nexus://user/", "") }
                  }));
                }
              }, 1200);
            }
            return;
          }
        }
      });
      ndef.addEventListener("readingerror", () => {
        setNfcMode("scan-error");
        setTimeout(() => setNfcMode("idle"), 3000);
      });
    } catch (err: any) {
      if (err?.name === "AbortError") { setNfcMode("idle"); return; }
      setNfcMode("scan-error");
      setTimeout(() => setNfcMode("idle"), 3000);
    }
  }

  function cancelNFC() {
    abortRef.current?.abort();
    setNfcMode("idle");
  }

  const isNFCActive = nfcMode === "writing" || nfcMode === "scanning" || nfcMode === "write-ready";

  return (
    <div
      className="fixed inset-0 z-[130] flex items-end sm:items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.9)", backdropFilter: "blur(18px)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-3xl border border-slate-800 overflow-hidden share-modal-enter"
        style={{ background: "linear-gradient(180deg,#0f172a,#030712)" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 pb-0 flex items-center justify-between">
          <div>
            <p className="text-base font-black text-white">{title}</p>
            <p className="text-[11px] text-slate-500 font-mono">{subtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 text-sm hover:text-white transition"
          >✕</button>
        </div>

        {/* QR Code */}
        <div className="flex flex-col items-center py-5 gap-2">
          <div className="p-3 rounded-2xl border border-slate-700/60 qr-glow" style={{ background: "#0f172a" }}>
            <canvas ref={canvasRef} className="rounded-lg block" />
          </div>
          <p className="text-[10px] text-slate-500 font-mono">QR kodni skaner qiling</p>
        </div>

        {/* Actions */}
        <div className="px-4 pb-6 space-y-2.5">
          {/* Copy link */}
          <button
            onClick={copyLink}
            className="w-full flex items-center gap-3 p-4 rounded-2xl border border-slate-700 bg-slate-900/60 hover:border-slate-500 active:scale-95 transition"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-xl flex-shrink-0">🔗</div>
            <div className="flex-1 text-left min-w-0">
              <p className="text-sm font-bold text-white">Silkani nusxalash</p>
              <p className="text-[10px] text-slate-500 font-mono truncate">{displayLink}</p>
            </div>
            <span className={`text-xs font-bold flex-shrink-0 transition-colors ${copied ? "text-green-400" : "text-slate-500"}`}>
              {copied ? "✓ Nusxa" : "Nusxa"}
            </span>
          </button>

          {/* NFC Write */}
          {(nfcMode === "idle" || nfcMode === "write-ready" || nfcMode === "writing" || nfcMode === "write-done" || nfcMode === "write-error" || nfcMode === "unsupported") && (
            <button
              onClick={() => {
                if (nfcMode === "idle") startNFCWrite();
                else if (nfcMode === "write-ready") doNFCWrite();
                else if (isNFCActive) cancelNFC();
              }}
              disabled={nfcMode === "write-done" || nfcMode === "write-error" || nfcMode === "unsupported"}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl border transition-all active:scale-95 relative overflow-hidden ${
                nfcMode === "writing" ? "border-cyan-500 bg-cyan-950/30" :
                nfcMode === "write-ready" ? "border-blue-500 bg-blue-950/25" :
                nfcMode === "write-done" ? "border-green-500 bg-green-950/20" :
                nfcMode === "write-error" || nfcMode === "unsupported" ? "border-red-800 bg-red-950/20" :
                "border-slate-700 bg-slate-900/60 hover:border-slate-500"
              }`}
            >
              {(nfcMode === "writing" || nfcMode === "write-ready") && (
                <>
                  <div className="nfc-ring nfc-ring-1" />
                  <div className="nfc-ring nfc-ring-2" />
                  <div className="nfc-ring nfc-ring-3" />
                </>
              )}
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0 relative z-10 ${
                nfcMode === "writing" || nfcMode === "write-ready" ? "animate-pulse bg-cyan-900/60" : "bg-slate-800"
              }`}>
                {nfcMode === "write-done" ? "✅" : nfcMode === "write-error" ? "❌" : nfcMode === "unsupported" ? "⚠️" : "📡"}
              </div>
              <div className="flex-1 text-left relative z-10">
                <p className="text-sm font-bold text-white">
                  {nfcMode === "write-ready" ? "Telefonni tag'ga teging" :
                   nfcMode === "writing" ? "NFC yozilmoqda..." :
                   nfcMode === "write-done" ? "NFC tag'ga yozildi!" :
                   nfcMode === "write-error" ? "Xato yuz berdi" :
                   nfcMode === "unsupported" ? "NFC qo'llab-quvvatlanmaydi" :
                   "NFC orqali ulashish"}
                </p>
                <p className="text-[10px] text-slate-400">
                  {nfcMode === "write-ready" ? "NFC tag yoki qurilmani yaqinlashtiring →" :
                   nfcMode === "writing" ? "Kutmoqda..." :
                   nfcMode === "write-done" ? "Muvaffaqiyatli yozildi!" :
                   nfcMode === "write-error" ? "Tag'ni yaqinlashtiring va qayta urining" :
                   nfcMode === "unsupported" ? "Android Chrome kerak" :
                   "Profilingizni NFC tag'ga yozadi"}
                </p>
              </div>
              {(nfcMode === "writing" || nfcMode === "write-ready") && (
                <span className="text-[10px] text-slate-400 relative z-10">Bekor</span>
              )}
            </button>
          )}

          {/* NFC Scan */}
          {(nfcMode === "idle" || nfcMode === "scanning" || nfcMode === "scan-done" || nfcMode === "scan-error") && (
            <button
              onClick={() => {
                if (nfcMode === "idle") startNFCScan();
                else if (nfcMode === "scanning") cancelNFC();
              }}
              disabled={nfcMode === "scan-done" || nfcMode === "scan-error"}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl border transition-all active:scale-95 relative overflow-hidden ${
                nfcMode === "scanning" ? "border-violet-500 bg-violet-950/25" :
                nfcMode === "scan-done" ? "border-green-500 bg-green-950/20" :
                nfcMode === "scan-error" ? "border-orange-800 bg-orange-950/20" :
                "border-slate-700/70 bg-slate-900/40 hover:border-slate-500"
              }`}
            >
              {nfcMode === "scanning" && (
                <>
                  <div className="nfc-ring nfc-ring-1" style={{borderColor: "rgba(139,92,246,0.6)"}} />
                  <div className="nfc-ring nfc-ring-2" style={{borderColor: "rgba(139,92,246,0.4)"}} />
                  <div className="nfc-ring nfc-ring-3" style={{borderColor: "rgba(139,92,246,0.2)"}} />
                </>
              )}
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0 relative z-10 ${
                nfcMode === "scanning" ? "animate-pulse bg-violet-900/60" : "bg-slate-800"
              }`}>
                {nfcMode === "scan-done" ? "✅" : nfcMode === "scan-error" ? "⚠️" : "🔍"}
              </div>
              <div className="flex-1 text-left relative z-10">
                <p className="text-sm font-bold text-white">
                  {nfcMode === "scanning" ? "NFC skanerlanyapti..." :
                   nfcMode === "scan-done" ? `Topildi: ${scannedText.slice(0, 28)}...` :
                   nfcMode === "scan-error" ? "O'qishda xato" :
                   "NFC skanerlash"}
                </p>
                <p className="text-[10px] text-slate-400">
                  {nfcMode === "scanning" ? "NFC tag'ni telefonga teging..." :
                   nfcMode === "scan-done" ? "Muvaffaqiyatli o'qildi!" :
                   nfcMode === "scan-error" ? "Tag'ni yaqinlashtiring va qayta urining" :
                   "Boshqa qurilmaning NFC tag'ini o'qiydi"}
                </p>
              </div>
              {nfcMode === "scanning" && (
                <span className="text-[10px] text-slate-400 relative z-10">Bekor</span>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
