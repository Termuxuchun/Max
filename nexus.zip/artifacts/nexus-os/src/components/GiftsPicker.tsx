import { useState, useEffect, useRef, useMemo } from "react";
import { ref, push, set, get, serverTimestamp, onValue } from "firebase/database";
import { db } from "../firebase";
import { GIFTS, RARITY_STYLES, type GiftDef } from "../lib/gifts";

interface Props { fromUser: string; toUser: string; onClose: () => void; onSent?: (g: GiftDef) => void; }

type Rarity = "all" | "common" | "rare" | "epic" | "legendary" | "mythic";

interface Confetti { id: number; x: number; color: string; delay: number; dur: number; size: number; shape: "circle" | "square" | "triangle"; }

const RARITY_TABS: { id: Rarity; label: string; color: string }[] = [
  { id: "all",       label: "🎁 Barchasi",  color: "#94a3b8" },
  { id: "common",    label: "⚪ Oddiy",      color: "#94a3b8" },
  { id: "rare",      label: "🔵 Kam",        color: "#3b82f6" },
  { id: "epic",      label: "🟣 Epic",       color: "#a855f7" },
  { id: "legendary", label: "👑 Afsonaviy", color: "#f59e0b" },
  { id: "mythic",    label: "🌌 Mythic",    color: "#22d3ee" },
];

function getAccent(g: GiftDef) { return g.gradient.match(/#[0-9a-f]{3,6}/i)?.[0] || "#ec4899"; }

function RarityBadge({ rarity }: { rarity: GiftDef["rarity"] }) {
  const styles: Record<string, string> = {
    common:    "bg-slate-700/60 text-slate-300",
    rare:      "bg-blue-500/25 text-blue-300 border border-blue-500/40",
    epic:      "bg-purple-500/25 text-purple-300 border border-purple-500/40",
    legendary: "bg-gradient-to-r from-amber-500/30 to-rose-500/30 text-amber-200 border border-amber-400/50",
    mythic:    "bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 text-cyan-200 border border-cyan-400/50 holo-border",
  };
  const labels: Record<string, string> = { common: "Oddiy", rare: "Kam", epic: "Epic", legendary: "Afsonaviy", mythic: "Mythic" };
  return (
    <span className={`text-[9px] uppercase font-black tracking-wider px-2 py-0.5 rounded-full ${styles[rarity]}`}>
      {labels[rarity]}
    </span>
  );
}

export default function GiftsPicker({ fromUser, toUser, onClose, onSent }: Props) {
  const [selected, setSelected] = useState<GiftDef>(GIFTS[12]);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [starsBalance, setStarsBalance] = useState(0);
  const [celebrating, setCelebrating] = useState(false);
  const [confetti, setConfetti] = useState<Confetti[]>([]);
  const [filter, setFilter] = useState<Rarity>("all");
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const celebTimeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    const unsub = onValue(ref(db, `stars/${fromUser}`), snap => setStarsBalance(snap.val()?.balance || 0));
    return unsub;
  }, [fromUser]);
  useEffect(() => () => { if (celebTimeout.current) clearTimeout(celebTimeout.current); }, []);

  const canAfford = starsBalance >= selected.price;
  const filteredGifts = useMemo(() =>
    filter === "all" ? GIFTS : GIFTS.filter(g => g.rarity === filter), [filter]);

  function spawnConfetti() {
    const colors = ["#f59e0b","#ec4899","#8b5cf6","#22d3ee","#22c55e","#f43f5e","#fbbf24","#a855f7"];
    const shapes: Array<Confetti["shape"]> = ["circle","square","triangle"];
    const cs: Confetti[] = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      color: colors[Math.floor(Math.random() * colors.length)],
      delay: Math.random() * 0.8,
      dur: 1.8 + Math.random() * 1.4,
      size: 6 + Math.random() * 10,
      shape: shapes[Math.floor(Math.random() * shapes.length)],
    }));
    setConfetti(cs);
  }

  async function send() {
    if (sending) return;
    if (!canAfford) { alert(`Yetarli yulduz yo'q!\nKerak: ${selected.price}⭐ · Mavjud: ${starsBalance}⭐`); return; }
    setSending(true);
    try {
      const snap = await get(ref(db, `stars/${fromUser}`));
      const current = snap.val()?.balance || 0;
      if (current < selected.price) { alert("Yetarli yulduz yo'q!"); setSending(false); return; }
      await set(ref(db, `stars/${fromUser}`), { balance: current - selected.price, updatedAt: Date.now() });
      await push(ref(db, `gifts/${toUser}`), { giftId: selected.id, from: fromUser, message: message.trim() || null, price: selected.price, ts: serverTimestamp() });
      await push(ref(db, `star_transactions/${fromUser}`), { type: "gift_sent", amount: -selected.price, giftId: selected.id, toUser, ts: Date.now() });
      await push(ref(db, `system_pushes/${toUser}`), { msg: `🎁 @${fromUser} sizga "${selected.name}" sovg'a yubordi!`, from: fromUser, type: "msg", ts: Date.now() });
      onSent?.(selected);
      spawnConfetti();
      setCelebrating(true);
      celebTimeout.current = setTimeout(onClose, 3000);
    } finally { setSending(false); }
  }

  const accent = getAccent(selected);

  if (celebrating) {
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center overflow-hidden"
        style={{ background: "rgba(0,0,0,0.95)", backdropFilter: "blur(24px)" }}>

        {/* Confetti */}
        {confetti.map(c => (
          <div key={c.id} className="confetti-particle pointer-events-none absolute"
            style={{
              left: `${c.x}%`, top: "-20px",
              width: c.size, height: c.size,
              backgroundColor: c.shape !== "triangle" ? c.color : "transparent",
              borderRadius: c.shape === "circle" ? "50%" : c.shape === "square" ? "2px" : "0",
              border: c.shape === "triangle" ? `${c.size/2}px solid transparent` : "none",
              borderBottom: c.shape === "triangle" ? `${c.size}px solid ${c.color}` : "none",
              animationDelay: `${c.delay}s`,
              animationDuration: `${c.dur}s`,
            }}
          />
        ))}

        {/* Center reveal */}
        <div className="relative z-10 flex flex-col items-center text-center px-6 send-burst">
          {/* Outer glow ring */}
          <div className="absolute rounded-full mythic-aura opacity-40 -z-10"
            style={{ width: 220, height: 220, background: `conic-gradient(from 0deg, ${accent}, #ec4899, #8b5cf6, ${accent})` }} />

          <div className="w-44 h-44 rounded-[36px] flex items-center justify-center mb-6 relative overflow-hidden shimmer-sweep"
            style={{ background: selected.gradient, fontSize: 88, boxShadow: `0 0 60px ${accent}aa, 0 0 120px ${accent}44` }}>
            {selected.icon}
          </div>

          <div className="spin-scale text-5xl mb-3">🎉</div>
          <p className="text-4xl font-black text-white tracking-tight">{selected.name}</p>
          <p className="text-slate-300 mt-2 text-base">@{toUser} ga muvaffaqiyatli yuborildi!</p>
          <div className="mt-4 px-5 py-2 rounded-2xl bg-amber-950/50 border border-amber-700/40 inline-flex items-center gap-2">
            <span className="text-2xl font-black text-amber-400">⭐ {selected.price}</span>
            <span className="text-slate-400 text-sm">sarflandi</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[150] flex items-end sm:items-center justify-center sm:p-4"
      style={{ background: "rgba(0,0,0,0.88)", backdropFilter: "blur(28px)" }}
      onClick={onClose}>

      <div className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-3xl border border-white/8 overflow-hidden animate-[scale-in_0.28s_ease-out]"
        style={{ background: "linear-gradient(180deg,#0d1117 0%,#060a10 100%)", maxHeight: "92vh", display: "flex", flexDirection: "column" }}
        onClick={e => e.stopPropagation()}>

        {/* Drag handle */}
        <div className="flex justify-center pt-2.5 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Gift preview header */}
        <div className="relative px-5 pt-4 pb-3 flex flex-col items-center text-center overflow-hidden flex-shrink-0">
          {/* Radial background glow */}
          <div className="absolute inset-0 -z-0 transition-all duration-500"
            style={{ background: `radial-gradient(ellipse at 50% 0%, ${accent}28 0%, transparent 70%)` }} />

          <button onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/8 hover:bg-white/15 text-slate-400 hover:text-white transition text-sm z-10 flex items-center justify-center">
            ✕
          </button>

          {/* Gift 3D card */}
          <div className="relative mb-3 gift-card-pop" style={{ perspective: 600 }}>
            {/* Rarity glow for legendary/mythic */}
            {(selected.rarity === "legendary" || selected.rarity === "mythic") && (
              <div className="absolute inset-0 rounded-3xl -z-10 legendary-glow scale-110" style={{ background: selected.gradient }} />
            )}
            <div className="w-28 h-28 rounded-3xl flex items-center justify-center relative overflow-hidden shimmer-sweep"
              style={{
                background: selected.gradient,
                fontSize: 60,
                boxShadow: `0 8px 32px ${accent}66, 0 2px 8px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.2)`,
              }}>
              <span className="gift-float relative z-10">{selected.icon}</span>
            </div>
          </div>

          <p className="text-2xl font-black text-white tracking-tight">{selected.name}</p>
          <div className="flex items-center gap-2 mt-1.5 mb-2">
            <RarityBadge rarity={selected.rarity} />
            <span className="text-sm text-amber-400 font-black">⭐ {selected.price}</span>
          </div>
          <div className={`px-3 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-2 border ${canAfford ? "bg-emerald-950/30 text-emerald-400 border-emerald-900/40" : "bg-rose-950/30 text-rose-400 border-rose-900/40"}`}>
            <span className="text-base">{canAfford ? "✓" : "✗"}</span>
            <span>Balans: {starsBalance}⭐</span>
            {!canAfford && <span className="text-[9px] opacity-80">· Yetarli emas</span>}
          </div>
          <p className="text-[10px] text-slate-600 mt-1">@{fromUser} → @{toUser}</p>
        </div>

        {/* Rarity tabs */}
        <div className="flex gap-1.5 px-3 py-2 overflow-x-auto flex-shrink-0 scrollbar-none">
          {RARITY_TABS.map(r => (
            <button key={r.id} onClick={() => setFilter(r.id)}
              className={`flex-shrink-0 px-3 py-1 rounded-full text-[9px] font-black border transition-all duration-200 ${
                filter === r.id
                  ? "text-white scale-105 shadow-lg"
                  : "border-white/8 text-slate-500 hover:text-slate-300 hover:border-white/15"
              }`}
              style={filter === r.id ? { background: `${r.color}30`, borderColor: `${r.color}60`, color: r.color, boxShadow: `0 0 10px ${r.color}40` } : {}}>
              {r.label}
            </button>
          ))}
        </div>

        {/* Gift grid */}
        <div className="flex-1 overflow-y-auto px-3 pb-2" style={{ minHeight: 0 }}>
          <div className="grid grid-cols-4 gap-2">
            {filteredGifts.map((g, idx) => {
              const affordable = starsBalance >= g.price;
              const isSelected = selected.id === g.id;
              const isHovered = hoveredId === g.id;
              const gAccent = getAccent(g);
              return (
                <button key={g.id} onClick={() => setSelected(g)}
                  onMouseEnter={() => setHoveredId(g.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  style={{
                    background: g.gradient,
                    animationDelay: `${(idx % 8) * 0.04}s`,
                    animationName: "gift-grid-appear",
                    animationDuration: "0.3s",
                    animationFillMode: "both",
                    boxShadow: isSelected
                      ? `0 0 0 2.5px #f59e0b, 0 4px 20px ${gAccent}60`
                      : isHovered
                        ? `0 4px 16px ${gAccent}50`
                        : "0 2px 8px rgba(0,0,0,0.4)",
                    transform: isSelected ? "scale(1.08)" : isHovered ? "scale(1.04)" : "scale(1)",
                    transition: "all 0.2s cubic-bezier(0.34,1.56,0.64,1)",
                  }}
                  className={`rounded-2xl flex flex-col items-center justify-center pt-2.5 pb-1.5 px-1 relative overflow-hidden ${!affordable ? "opacity-40 grayscale" : ""}`}
                  title={`${g.name} · ${g.price}⭐`}>
                  {/* Shimmer on hover */}
                  {isHovered && <div className="shimmer-sweep absolute inset-0" />}
                  <span style={{ fontSize: 28 }} className="relative z-10">{g.icon}</span>
                  <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full leading-none mt-0.5 relative z-10 ${affordable ? "bg-black/60 text-amber-300" : "bg-black/60 text-rose-400"}`}>
                    {g.price}⭐
                  </span>
                  {isSelected && (
                    <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-400 text-black text-[9px] font-black flex items-center justify-center z-20 spin-scale">✓</span>
                  )}
                  {g.rarity === "mythic" && (
                    <span className="absolute bottom-0 inset-x-0 h-0.5 rounded-b-full" style={{ background: "linear-gradient(90deg,transparent,#22d3ee,#ec4899,transparent)" }} />
                  )}
                  {g.rarity === "legendary" && (
                    <span className="absolute bottom-0 inset-x-0 h-0.5 rounded-b-full" style={{ background: "linear-gradient(90deg,transparent,#f59e0b,transparent)" }} />
                  )}
                </button>
              );
            })}
            {filteredGifts.length === 0 && (
              <p className="col-span-4 text-center text-slate-600 text-xs py-6">Bu turkumda sovg'a yo'q</p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 pb-4 pt-2 border-t border-white/6 flex-shrink-0 space-y-2">
          <div className="relative">
            <input value={message} onChange={e => setMessage(e.target.value)} maxLength={80}
              placeholder="💌 Izoh qo'shing (ixtiyoriy)..."
              className="w-full bg-white/5 border border-white/10 focus:border-pink-500/60 p-2.5 rounded-xl text-xs text-white outline-none transition placeholder:text-slate-600" />
            {message && <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[9px] text-slate-600">{message.length}/80</span>}
          </div>
          {!canAfford ? (
            <div className="text-center py-1.5 px-3 rounded-xl bg-rose-950/30 border border-rose-900/30">
              <p className="text-xs text-rose-400 font-bold">⭐ Yetarli yulduz yo'q — {selected.price - starsBalance}⭐ kam</p>
            </div>
          ) : (
            <button onClick={send} disabled={sending}
              className="w-full py-3.5 rounded-2xl font-black text-white text-sm transition active:scale-95 relative overflow-hidden shimmer-sweep"
              style={{
                background: `linear-gradient(135deg, ${accent}, #ec4899, #8b5cf6)`,
                boxShadow: `0 4px 20px ${accent}60`,
                opacity: sending ? 0.6 : 1,
              }}>
              <span className="relative z-10">
                {sending ? "⏳ Yuborilmoqda..." : `🎁 ${selected.name} yuborish · ${selected.price}⭐`}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
