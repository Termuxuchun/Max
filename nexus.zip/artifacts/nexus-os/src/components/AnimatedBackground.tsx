import { useEffect, useRef } from "react";

interface Star { x: number; y: number; r: number; speed: number; opacity: number; color: string; }
interface Nebula { x: number; y: number; r: number; color: string; phase: number; }

const PALETTE = ["#22d3ee","#8b5cf6","#ec4899","#3b82f6","#f59e0b","#22c55e"];

export default function AnimatedBackground({ accentColor = "#22d3ee" }: { accentColor?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef   = useRef<number>(0);
  const starsRef  = useRef<Star[]>([]);
  const nebulasRef = useRef<Nebula[]>([]);
  const timeRef   = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    function resize() {
      if (!canvas) return;
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
      init();
    }

    function init() {
      if (!canvas) return;
      const w = canvas.width, h = canvas.height;
      starsRef.current = Array.from({ length: 120 }, () => ({
        x:       Math.random() * w,
        y:       Math.random() * h,
        r:       0.3 + Math.random() * 1.8,
        speed:   0.05 + Math.random() * 0.15,
        opacity: 0.15 + Math.random() * 0.6,
        color:   PALETTE[Math.floor(Math.random() * PALETTE.length)],
      }));
      nebulasRef.current = Array.from({ length: 5 }, () => ({
        x:     Math.random() * w,
        y:     Math.random() * h,
        r:     100 + Math.random() * 200,
        color: PALETTE[Math.floor(Math.random() * PALETTE.length)],
        phase: Math.random() * Math.PI * 2,
      }));
    }

    function draw() {
      if (!canvas || !ctx) return;
      const w = canvas.width, h = canvas.height;
      timeRef.current += 0.004;
      const t = timeRef.current;

      ctx.clearRect(0, 0, w, h);

      // Nebula blobs
      nebulasRef.current.forEach(n => {
        const pulse = 0.9 + 0.1 * Math.sin(t + n.phase);
        const grad = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r * pulse);
        grad.addColorStop(0, n.color + "18");
        grad.addColorStop(0.5, n.color + "08");
        grad.addColorStop(1, "transparent");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r * pulse, 0, Math.PI * 2);
        ctx.fill();
      });

      // Shooting star (rare)
      if (Math.random() < 0.002) {
        const sx = Math.random() * w;
        const sy = Math.random() * h * 0.5;
        const len = 80 + Math.random() * 120;
        const g = ctx.createLinearGradient(sx, sy, sx + len, sy + len * 0.4);
        g.addColorStop(0, accentColor + "00");
        g.addColorStop(0.5, accentColor + "cc");
        g.addColorStop(1, accentColor + "00");
        ctx.strokeStyle = g;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(sx + len, sy + len * 0.4);
        ctx.stroke();
      }

      // Stars
      starsRef.current.forEach(s => {
        const twinkle = s.opacity * (0.7 + 0.3 * Math.sin(t * 2 + s.x));

        // Glow
        const glow = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, s.r * 3);
        glow.addColorStop(0, s.color + Math.round(twinkle * 80).toString(16).padStart(2,"0"));
        glow.addColorStop(1, "transparent");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r * 3, 0, Math.PI * 2);
        ctx.fill();

        // Core dot
        ctx.fillStyle = s.color + Math.round(twinkle * 255).toString(16).padStart(2,"0");
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();

        // Drift upward
        s.y -= s.speed;
        if (s.y < -5) { s.y = h + 5; s.x = Math.random() * w; }
      });

      // Scanline overlay (subtle)
      ctx.fillStyle = "rgba(0,0,0,0.018)";
      for (let y = 0; y < h; y += 4) {
        ctx.fillRect(0, y, w, 1);
      }

      animRef.current = requestAnimationFrame(draw);
    }

    resize();
    draw();
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener("resize", resize);
    };
  }, [accentColor]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0, opacity: 0.55 }}
    />
  );
}
