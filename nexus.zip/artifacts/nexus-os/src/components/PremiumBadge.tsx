import { useEffect, useState } from "react";
import { ref, onValue, set } from "firebase/database";
import { db } from "../firebase";

export interface BadgeDef {
  id: string; name: string; icon: string; gradient: string;
  animation: string; description: string;
  rarity: "common" | "rare" | "epic" | "legendary";
}

export const BADGES: BadgeDef[] = [
  { id: "crown",     name: "Oltin Toj",      icon: "👑", gradient: "linear-gradient(135deg,#f59e0b,#ef4444)",               animation: "badge-pulse",   description: "Klassik premium",         rarity: "common" },
  { id: "fire",      name: "Olov",           icon: "🔥", gradient: "linear-gradient(135deg,#f97316,#dc2626)",               animation: "badge-flicker", description: "Issiq foydalanuvchi",    rarity: "common" },
  { id: "star",      name: "Yulduz",         icon: "⭐", gradient: "linear-gradient(135deg,#fbbf24,#f59e0b)",               animation: "badge-spin",    description: "Yulduz darajasi",        rarity: "common" },
  { id: "heart",     name: "Yurak",          icon: "💖", gradient: "linear-gradient(135deg,#ec4899,#f43f5e)",               animation: "badge-beat",    description: "Sevimli",                rarity: "common" },
  { id: "sun",       name: "Quyosh",         icon: "☀️", gradient: "linear-gradient(135deg,#fde047,#f59e0b)",               animation: "badge-spin",    description: "Yorqin energiya",        rarity: "common" },
  { id: "music",     name: "Musiqa",         icon: "🎵", gradient: "linear-gradient(135deg,#a855f7,#22d3ee)",               animation: "badge-bounce",  description: "Ritm hissi",             rarity: "common" },
  { id: "leaf",      name: "Yashil Barg",    icon: "🍃", gradient: "linear-gradient(135deg,#15803d,#84cc16)",               animation: "badge-float",   description: "Eko-do'st",              rarity: "common" },
  { id: "cat",       name: "Mushuk",         icon: "🐱", gradient: "linear-gradient(135deg,#f472b6,#fbbf24)",               animation: "badge-bounce",  description: "Muloyim va quvnoq",      rarity: "common" },
  { id: "gaming",    name: "Gamer",          icon: "🎮", gradient: "linear-gradient(135deg,#6366f1,#22d3ee)",               animation: "badge-shake",   description: "O'yin ustasi",           rarity: "common" },
  { id: "diamond",   name: "Olmos",          icon: "💎", gradient: "linear-gradient(135deg,#06b6d4,#3b82f6)",               animation: "badge-shine",   description: "Toza va yorqin",         rarity: "rare" },
  { id: "lightning", name: "Chaqmoq",        icon: "⚡", gradient: "linear-gradient(135deg,#facc15,#06b6d4)",               animation: "badge-flicker", description: "Tezkor",                 rarity: "rare" },
  { id: "rocket",    name: "Raketa",         icon: "🚀", gradient: "linear-gradient(135deg,#8b5cf6,#ec4899)",               animation: "badge-shake",   description: "Yuqoriga uchadi",        rarity: "rare" },
  { id: "ghost",     name: "Arvoh",          icon: "👻", gradient: "linear-gradient(135deg,#6366f1,#1e293b)",               animation: "badge-float",   description: "Sirli",                  rarity: "rare" },
  { id: "shield",    name: "Qalqon",         icon: "🛡️", gradient: "linear-gradient(135deg,#1d4ed8,#0ea5e9)",               animation: "badge-pulse",   description: "Himoyachi",              rarity: "rare" },
  { id: "moon",      name: "Oy",             icon: "🌙", gradient: "linear-gradient(135deg,#1e1b4b,#64748b)",               animation: "badge-float",   description: "Tungi yurish",           rarity: "rare" },
  { id: "neon",      name: "Neon",           icon: "💫", gradient: "linear-gradient(135deg,#22d3ee,#ec4899)",               animation: "badge-neon",    description: "Tungi shahar",           rarity: "rare" },
  { id: "anchor",    name: "Langar",         icon: "⚓", gradient: "linear-gradient(135deg,#0c4a6e,#22d3ee)",               animation: "badge-swing",   description: "Mustahkam",              rarity: "rare" },
  { id: "wolf",      name: "Bo'ri",          icon: "🐺", gradient: "linear-gradient(135deg,#475569,#1e1b4b)",               animation: "badge-pulse",   description: "Yovvoyi ruh",            rarity: "rare" },
  { id: "crystal",   name: "Kristal",        icon: "❄️", gradient: "linear-gradient(135deg,#bfdbfe,#3b82f6,#1e3a8a)",       animation: "badge-shine",   description: "Sof va muzday",          rarity: "rare" },
  { id: "butterfly", name: "Kapalak",        icon: "🦋", gradient: "linear-gradient(135deg,#06b6d4,#8b5cf6)",               animation: "badge-float",   description: "Erkin ruh",              rarity: "rare" },
  { id: "trophy",    name: "Kubok",          icon: "🏆", gradient: "linear-gradient(135deg,#eab308,#a16207)",               animation: "badge-shine",   description: "G'olib",                 rarity: "epic" },
  { id: "alien",     name: "Ajnabiy",        icon: "👽", gradient: "linear-gradient(135deg,#22c55e,#0ea5e9)",               animation: "badge-spin",    description: "Boshqa olamdan",         rarity: "epic" },
  { id: "skull",     name: "Bosh Suyak",     icon: "💀", gradient: "linear-gradient(135deg,#475569,#0f172a)",               animation: "badge-shake",   description: "Qo'rqinchli",            rarity: "epic" },
  { id: "wizard",    name: "Sehrgar",        icon: "🧙", gradient: "linear-gradient(135deg,#7c3aed,#c026d3)",               animation: "badge-pulse",   description: "Sirli kuch",             rarity: "epic" },
  { id: "robot",     name: "Robot",          icon: "🤖", gradient: "linear-gradient(135deg,#0ea5e9,#475569)",               animation: "badge-glitch",  description: "AI darajasida",          rarity: "epic" },
  { id: "ninja",     name: "Ninja",          icon: "🥷", gradient: "linear-gradient(135deg,#0f172a,#7c3aed)",               animation: "badge-glitch",  description: "Yashirin va tezkor",     rarity: "epic" },
  { id: "medal",     name: "Medal",          icon: "🥇", gradient: "linear-gradient(135deg,#fbbf24,#b45309)",               animation: "badge-shine",   description: "Birinchi o'rin",         rarity: "epic" },
  { id: "meteor",    name: "Meteor",         icon: "☄️", gradient: "linear-gradient(135deg,#f59e0b,#7c3aed)",               animation: "badge-zoom",    description: "Tezkor zarba",           rarity: "epic" },
  { id: "gem",       name: "Mistik Tosh",    icon: "🔮", gradient: "linear-gradient(135deg,#a855f7,#6366f1)",               animation: "badge-orbit",   description: "Mistik kuch",            rarity: "epic" },
  { id: "samurai",   name: "Samuray",        icon: "⚔️", gradient: "linear-gradient(135deg,#dc2626,#0f172a)",               animation: "badge-shake",   description: "Jangchi ruh",            rarity: "epic" },
  { id: "vampire",   name: "Vampir",         icon: "🧛", gradient: "linear-gradient(135deg,#7f1d1d,#4c0519)",               animation: "badge-pulse",   description: "Abadiy mavjudot",        rarity: "epic" },
  { id: "devil",     name: "Shayton",        icon: "😈", gradient: "linear-gradient(135deg,#dc2626,#7c3aed)",               animation: "badge-flicker", description: "Qorong'u kuch",          rarity: "epic" },
  { id: "eye",       name: "Kuzatuvchi",     icon: "👁️", gradient: "linear-gradient(135deg,#0c4a6e,#7c3aed)",               animation: "badge-glitch",  description: "Hamma narsani ko'radi",  rarity: "epic" },
  { id: "virus",     name: "Hacker",         icon: "🦠", gradient: "linear-gradient(135deg,#15803d,#22d3ee)",               animation: "badge-glitch",  description: "Digital dunyo",          rarity: "epic" },
  { id: "rainbow",   name: "Kamalak",        icon: "🌈", gradient: "linear-gradient(135deg,#ef4444,#8b5cf6,#06b6d4,#22c55e,#eab308)", animation: "badge-rainbow", description: "Eng noyob", rarity: "legendary" },
  { id: "lotus",     name: "Lotus",          icon: "🪷", gradient: "linear-gradient(135deg,#f472b6,#a855f7)",               animation: "badge-float",   description: "Tinchlik",               rarity: "legendary" },
  { id: "phoenix",   name: "Feniks",         icon: "🦅", gradient: "linear-gradient(135deg,#dc2626,#f59e0b,#fde047)",       animation: "badge-rainbow", description: "Qayta tug'iladi",        rarity: "legendary" },
  { id: "dragon",    name: "Ajdaho",         icon: "🐉", gradient: "linear-gradient(135deg,#15803d,#22d3ee)",               animation: "badge-wobble",  description: "Afsonaviy mavjudot",     rarity: "legendary" },
  { id: "unicorn",   name: "Yagona Shox",    icon: "🦄", gradient: "linear-gradient(135deg,#f472b6,#a78bfa,#38bdf8)",       animation: "badge-rainbow", description: "Sehrli",                 rarity: "legendary" },
  { id: "halo",      name: "Halo",           icon: "😇", gradient: "linear-gradient(135deg,#fde047,#fff,#a5f3fc)",          animation: "badge-spin",    description: "Toza qalb",              rarity: "legendary" },
  { id: "king",      name: "Shoh",           icon: "🤴", gradient: "linear-gradient(135deg,#b45309,#fbbf24,#f59e0b)",       animation: "badge-pulse",   description: "Mutlaq hukmron",         rarity: "legendary" },
  { id: "angel",     name: "Farishta",       icon: "👼", gradient: "linear-gradient(135deg,#e0f2fe,#bfdbfe,#818cf8)",       animation: "badge-float",   description: "Ilohiy himoya",          rarity: "legendary" },
  { id: "atom",      name: "Atom",           icon: "⚛️", gradient: "linear-gradient(135deg,#22d3ee,#06b6d4,#0284c7)",       animation: "badge-spin",    description: "Ilm va texnologiya",     rarity: "legendary" },
  { id: "galaxy",    name: "Galaktika",      icon: "🌌", gradient: "linear-gradient(135deg,#1e1b4b,#4f46e5,#ec4899)",       animation: "badge-orbit",   description: "Kosmik mavjudot",        rarity: "legendary" },
  { id: "infinity",  name: "Cheksizlik",     icon: "♾️", gradient: "linear-gradient(270deg,#f59e0b,#22d3ee,#ec4899,#22c55e,#f59e0b)", animation: "badge-rainbow", description: "Chegarasiz kuch", rarity: "legendary" },
  { id: "nexus",     name: "NEXUS Elite",    icon: "🔷", gradient: "linear-gradient(135deg,#22d3ee,#3b82f6,#6366f1,#8b5cf6)", animation: "badge-neon",  description: "NEXUS ning eng zo'rlari", rarity: "legendary" },
];

export function getBadgeById(id?: string | null): BadgeDef {
  return BADGES.find(b => b.id === id) || BADGES[0];
}

const RARITY_META: Record<BadgeDef["rarity"], { label: string; color: string; border: string; glow: string }> = {
  common:    { label: "Oddiy",      color: "#94a3b8", border: "border-slate-700",   glow: "" },
  rare:      { label: "Kam",        color: "#3b82f6", border: "border-blue-700/60", glow: "0 0 10px #3b82f640" },
  epic:      { label: "Epic",       color: "#a855f7", border: "border-purple-600/60", glow: "0 0 12px #a855f740" },
  legendary: { label: "Afsonaviy", color: "#f59e0b", border: "border-amber-500/60", glow: "0 0 16px #f59e0b50" },
};

interface BadgeProps { badgeId?: string | null; size?: number; onClick?: () => void; className?: string; showAura?: boolean; }

export function PremiumBadge({ badgeId, size = 28, onClick, className = "", showAura = true }: BadgeProps) {
  const b = getBadgeById(badgeId);
  const accent = b.gradient.match(/#[0-9a-f]{3,6}/i)?.[0] || "#f59e0b";
  const isLegendary = b.rarity === "legendary";
  return (
    <button onClick={onClick} type="button"
      className={`relative inline-flex items-center justify-center rounded-2xl transition-all duration-200 ${onClick ? "cursor-pointer hover:scale-110 active:scale-95" : "cursor-default"} ${className}`}
      style={{
        width: size, height: size,
        background: b.gradient,
        fontSize: size * 0.5,
        boxShadow: `0 4px 14px ${accent}66, inset 0 1px 0 rgba(255,255,255,0.25), inset 0 -1px 0 rgba(0,0,0,0.2)`,
        border: "1px solid rgba(255,255,255,0.18)",
      }}
      title={b.name}>
      {showAura && (
        <span className={`absolute inset-0 rounded-2xl opacity-50 blur-lg -z-10 ${isLegendary ? "legendary-glow" : ""}`}
          style={{ background: b.gradient, transform: "scale(1.18)" }} />
      )}
      <span className="absolute inset-x-1 top-0.5 h-1/3 rounded-t-2xl pointer-events-none"
        style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.35), transparent)" }} />
      <span className={`${b.animation} relative z-10`}
        style={{ display: "inline-block", lineHeight: 1, filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.4))" }}>
        {b.icon}
      </span>
    </button>
  );
}

export function PremiumChip({ size = "sm" }: { size?: "xs" | "sm" | "md" }) {
  const sz = size === "xs" ? "text-[8px] px-1.5 py-0.5 gap-0.5" : size === "md" ? "text-[11px] px-2.5 py-1 gap-1" : "text-[9px] px-2 py-0.5 gap-1";
  return (
    <span className={`inline-flex items-center ${sz} rounded-full font-black uppercase tracking-wider text-white shadow-sm shimmer-sweep relative overflow-hidden`}
      style={{ background: "linear-gradient(135deg,#f59e0b 0%,#ec4899 60%,#8b5cf6 100%)", boxShadow: "0 2px 8px rgba(236,72,153,0.35), inset 0 1px 0 rgba(255,255,255,0.3)" }}>
      <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><path d="M5 16 3 5l5.5 4L12 4l3.5 5L21 5l-2 11H5zm14 3H5v-2h14v2z"/></svg>
      Premium
    </span>
  );
}

export function VerifiedTick({ size = 14 }: { size?: number }) {
  return (
    <span className="inline-flex items-center justify-center rounded-full text-white flex-shrink-0"
      style={{ width: size, height: size, background: "linear-gradient(135deg,#3b82f6,#1d4ed8)", boxShadow: "0 0 0 1.5px #0b1220, 0 2px 6px rgba(59,130,246,0.5)" }}>
      <svg width={size * 0.65} height={size * 0.65} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12"/>
      </svg>
    </span>
  );
}

interface PickerProps { username: string; currentBadgeId?: string | null; isOwn: boolean; isPremium: boolean; onClose: () => void; }

type RarityFilter = "all" | BadgeDef["rarity"];
const RARITY_FILTERS: { id: RarityFilter; label: string }[] = [
  { id: "all",       label: "✨ Hammasi" },
  { id: "common",    label: "⚪ Oddiy" },
  { id: "rare",      label: "🔵 Kam" },
  { id: "epic",      label: "🟣 Epic" },
  { id: "legendary", label: "👑 Afsonaviy" },
];

export function BadgeShowcase({ username, currentBadgeId, isOwn, isPremium, onClose }: PickerProps) {
  const [selected, setSelected] = useState(currentBadgeId || "crown");
  const [filter, setFilter] = useState<RarityFilter>("all");
  const [hovered, setHovered] = useState<string | null>(null);

  async function save(id: string) {
    setSelected(id);
    if (isOwn && isPremium) await set(ref(db, `users/${username}/badge`), id);
  }

  const active = getBadgeById(selected);
  const activeMeta = RARITY_META[active.rarity];
  const activeAccent = active.gradient.match(/#[0-9a-f]{3,6}/i)?.[0] || "#f59e0b";

  const filteredBadges = filter === "all" ? BADGES : BADGES.filter(b => b.rarity === filter);

  return (
    <div className="fixed inset-0 z-[140] flex items-end sm:items-center justify-center sm:p-4"
      style={{ background: "rgba(0,0,0,0.92)", backdropFilter: "blur(28px)" }}
      onClick={onClose}>
      <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl border border-white/8 overflow-hidden animate-[scale-in_0.28s_ease-out]"
        style={{ background: "linear-gradient(180deg,#0d1117 0%,#060a10 100%)", maxHeight: "92vh", display: "flex", flexDirection: "column" }}
        onClick={e => e.stopPropagation()}>

        {/* Drag handle mobile */}
        <div className="flex justify-center pt-2.5 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Preview header */}
        <div className="relative px-6 pt-5 pb-4 flex flex-col items-center text-center overflow-hidden flex-shrink-0">
          {/* Ambient glow */}
          <div className="absolute inset-0 -z-0 transition-all duration-700"
            style={{ background: `radial-gradient(ellipse at 50% -10%, ${activeAccent}30 0%, transparent 65%)` }} />
          <button onClick={onClose} type="button"
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/8 hover:bg-white/15 text-slate-400 hover:text-white transition flex items-center justify-center text-sm z-10">
            ✕
          </button>

          {/* Large badge preview with floating rings */}
          <div className="relative mb-4">
            {/* Rotating outer ring for legendary */}
            {active.rarity === "legendary" && (
              <div className="absolute -inset-3 rounded-full opacity-30"
                style={{ background: `conic-gradient(from 0deg, transparent 60%, ${activeAccent})`, animation: "rotate-glow 3s linear infinite" }} />
            )}
            {/* Glow halo */}
            <div className="absolute -inset-2 rounded-3xl opacity-25 blur-xl transition-all duration-500"
              style={{ background: active.gradient }} />
            <div className="badge-zoom-pop">
              <PremiumBadge badgeId={selected} size={100} showAura={false} />
            </div>
          </div>

          <p className="text-2xl font-black text-white tracking-tight">{active.name}</p>
          <p className="text-xs text-slate-500 mt-1 mb-2">{active.description}</p>

          {/* Rarity pill */}
          <span className={`text-[10px] uppercase font-black tracking-wider px-3 py-1 rounded-full border ${activeMeta.border} transition-all duration-300`}
            style={{ color: activeMeta.color, boxShadow: activeMeta.glow }}>
            {active.rarity === "legendary" ? "✨ " : ""}{activeMeta.label}
          </span>

          {isOwn && !isPremium && (
            <p className="text-[11px] text-amber-400/80 mt-2 font-semibold">🔒 Badge tanlash uchun Premium kerak</p>
          )}
        </div>

        {/* Rarity filter tabs */}
        <div className="flex gap-1.5 px-4 pb-2 overflow-x-auto flex-shrink-0 scrollbar-none">
          {RARITY_FILTERS.map(f => {
            const meta = f.id === "all" ? null : RARITY_META[f.id as BadgeDef["rarity"]];
            return (
              <button key={f.id} type="button" onClick={() => setFilter(f.id)}
                className={`flex-shrink-0 px-3 py-1 rounded-full text-[9px] font-black border transition-all duration-200 ${filter === f.id ? "scale-105" : "border-white/8 text-slate-500 hover:text-slate-300"}`}
                style={filter === f.id ? {
                  color: meta?.color || "#e2e8f0",
                  borderColor: `${meta?.color || "#e2e8f0"}50`,
                  background: `${meta?.color || "#e2e8f0"}18`,
                  boxShadow: meta?.glow || "0 0 8px rgba(255,255,255,0.1)",
                } : {}}>
                {f.label}
              </button>
            );
          })}
        </div>

        {/* Badge grid */}
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ minHeight: 0 }}>
          <div className="grid grid-cols-5 gap-3">
            {filteredBadges.map((b, idx) => {
              const isSelected = selected === b.id;
              const isHov = hovered === b.id;
              const bMeta = RARITY_META[b.rarity];
              const bAccent = b.gradient.match(/#[0-9a-f]{3,6}/i)?.[0] || "#f59e0b";
              return (
                <button key={b.id} type="button" onClick={() => save(b.id)}
                  onMouseEnter={() => setHovered(b.id)}
                  onMouseLeave={() => setHovered(null)}
                  className={`aspect-square rounded-2xl flex flex-col items-center justify-center gap-1 relative overflow-hidden transition-all duration-200 ${isOwn && !isPremium ? "grayscale opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                  style={{
                    background: b.gradient,
                    animationDelay: `${(idx % 5) * 0.04}s`,
                    animationName: "gift-grid-appear",
                    animationDuration: "0.3s",
                    animationFillMode: "both",
                    boxShadow: isSelected
                      ? `0 0 0 2.5px ${bMeta.color}, 0 4px 20px ${bAccent}55, ${bMeta.glow}`
                      : isHov
                        ? `0 4px 14px ${bAccent}45`
                        : "0 2px 6px rgba(0,0,0,0.4)",
                    transform: isSelected ? "scale(1.1)" : isHov ? "scale(1.05)" : "scale(1)",
                    border: isSelected ? `1.5px solid ${bMeta.color}80` : "1.5px solid transparent",
                  }}
                  title={b.name}>
                  {isHov && <div className="shimmer-sweep absolute inset-0" />}
                  <span className={`${b.animation} relative z-10`} style={{ fontSize: 22 }}>{b.icon}</span>
                  {isSelected && (
                    <span className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full bg-white text-black text-[8px] font-black flex items-center justify-center z-20 spin-scale">✓</span>
                  )}
                  {/* Rarity bottom bar */}
                  {b.rarity !== "common" && (
                    <span className="absolute bottom-0 inset-x-0 h-0.5"
                      style={{ background: `linear-gradient(90deg, transparent, ${bMeta.color}, transparent)` }} />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="px-5 pb-4 pt-2 border-t border-white/6 flex-shrink-0 text-center">
          <p className="text-[10px] text-slate-600">
            {isOwn && isPremium ? "✅ Avtomatik saqlanadi · Profilingizda ko'rinadi" : "👁️ Ko'rish rejimi"}
          </p>
        </div>
      </div>
    </div>
  );
}

export function useUserBadge(username?: string | null) {
  const [badgeId, setBadgeId] = useState<string | null>(null);
  useEffect(() => {
    if (!username) return;
    const u = onValue(ref(db, `users/${username}/badge`), s => setBadgeId(s.val() || "crown"));
    return () => u();
  }, [username]);
  return badgeId;
}
