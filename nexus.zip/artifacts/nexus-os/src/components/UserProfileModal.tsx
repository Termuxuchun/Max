import { useEffect, useState } from "react";
import { ref, get, onValue, set, remove, serverTimestamp, push } from "firebase/database";
import { db } from "../firebase";
import { PremiumBadge, BadgeShowcase, PremiumChip, VerifiedTick } from "./PremiumBadge";
import GiftsPicker from "./GiftsPicker";
import { getGift } from "../lib/gifts";
import ShareModal from "./ShareModal";

interface Props {
  username: string;          // viewer
  targetUser: string;        // profile being viewed
  onClose: () => void;
  onStartChat?: (peer: string) => void;
  onStartCall?: (peer: string, type: "audio" | "video") => void;
  accentColor: string;
}

interface Story {
  id: string;
  mediaType?: "image" | "video";
  mediaUrl?: string;
  mc?: Record<string, string>;
  mcc?: number;
  text?: string;
  ts: number;
}

/** Chunked base64 birlashtiruvchi (UserProfileModal uchun inline) */
function useAssembledUrl(mediaUrl?: string, mc?: Record<string, string>, mcc?: number) {
  const [url, setUrl] = useState<string | undefined>(mediaUrl);
  useEffect(() => {
    if (mc && mcc) {
      let assembled = "";
      for (let i = 0; i < mcc; i++) assembled += mc[String(i)] || "";
      setUrl(assembled);
    } else {
      setUrl(mediaUrl);
    }
  }, [mediaUrl, mcc]);
  return url;
}

function ActiveStoryOverlay({ story, targetUser, onClose }: { story: Story; targetUser: string; onClose: () => void }) {
  const resolvedUrl = useAssembledUrl(story.mediaUrl, story.mc, story.mcc);
  return (
    <div className="fixed inset-0 z-[130] bg-black flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute top-4 left-4 right-4 h-1 bg-white/20 rounded-full overflow-hidden">
        <div className="h-full bg-white animate-[story-progress_5s_linear]" style={{width:"100%"}} onAnimationEnd={onClose} />
      </div>
      <button onClick={onClose} className="absolute top-6 right-4 z-10 text-white text-3xl">✕</button>
      {resolvedUrl ? (
        story.mediaType === "video" ? (
          <video src={resolvedUrl} autoPlay controls playsInline className="max-w-full max-h-full rounded-2xl" onClick={e => e.stopPropagation()} />
        ) : (
          <img src={resolvedUrl} className="max-w-full max-h-full object-contain rounded-2xl" alt="story" />
        )
      ) : story.mcc ? (
        <div className="text-white/60 text-sm">⏳ Yuklanmoqda...</div>
      ) : (
        <div className="max-w-md w-full aspect-[9/16] rounded-2xl flex items-center justify-center p-8 text-2xl font-bold text-white text-center"
          style={{background: "linear-gradient(135deg,#ec4899,#8b5cf6)"}}>
          {story.text || ""}
        </div>
      )}
      <p className="absolute bottom-6 left-1/2 -translate-x-1/2 text-xs text-white/60 font-mono">
        @{targetUser} · {new Date(story.ts).toLocaleString("uz-UZ")}
      </p>
    </div>
  );
}

export default function UserProfileModal({ username, targetUser, onClose, onStartChat, onStartCall, accentColor }: Props) {
  const [profile, setProfile] = useState<any>(null);
  const [stories, setStories] = useState<Story[]>([]);
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [isOnline, setIsOnline] = useState(false);
  const [lastSeen, setLastSeen] = useState<number | null>(null);
  const [isPremium, setIsPremium] = useState(false);
  const [isContact, setIsContact] = useState(false);
  const [contactCount, setContactCount] = useState(0);
  const [showBadgePicker, setShowBadgePicker] = useState(false);
  const [viewerPremium, setViewerPremium] = useState(false);
  const [gifts, setGifts] = useState<{ id: string; giftId: string; from: string; message?: string | null; ts: number; price: number }[]>([]);
  const [showGiftsPicker, setShowGiftsPicker] = useState(false);
  const [showAllGifts, setShowAllGifts] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [isFriend, setIsFriend] = useState(false);
  const [friendReqSent, setFriendReqSent] = useState(false);
  const [incomingFriendReq, setIncomingFriendReq] = useState(false);

  useEffect(() => {
    get(ref(db, `users/${targetUser}`)).then(s => setProfile(s.val() || {}));
    const u1 = onValue(ref(db, `status/${targetUser}`), s => {
      const d = s.val();
      setIsOnline(d?.state === "online");
      setLastSeen(d?.lastSeen || null);
    });
    const u2 = onValue(ref(db, `premium/${targetUser}`), s => {
      const d = s.val();
      setIsPremium(!!(d && d.expiresAt > Date.now()));
    });
    const u3 = onValue(ref(db, `stories/${targetUser}`), s => {
      if (!s.exists()) { setStories([]); return; }
      const list: Story[] = [];
      const cutoff = Date.now() - 24 * 60 * 60 * 1000;
      s.forEach(c => {
        const d = c.val();
        if (d.ts > cutoff) list.push({ id: c.key!, ...d });
        else remove(ref(db, `stories/${targetUser}/${c.key}`));
      });
      list.sort((a, b) => a.ts - b.ts);
      setStories(list);
    });
    const u4 = onValue(ref(db, `contacts/${username}/${targetUser}`), s => setIsContact(s.exists()));
    const u5 = onValue(ref(db, `contacts/${username}`), s => setContactCount(s.exists() ? Object.keys(s.val()).length : 0));
    const u6 = onValue(ref(db, `premium/${username}`), s => {
      const d = s.val();
      setViewerPremium(!!(d && d.expiresAt > Date.now()));
    });
    const u7 = onValue(ref(db, `gifts/${targetUser}`), s => {
      if (!s.exists()) { setGifts([]); return; }
      const list: any[] = [];
      s.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => (b.ts || 0) - (a.ts || 0));
      setGifts(list);
    });
    const u8 = onValue(ref(db, `friends/${username}/${targetUser}`), s => setIsFriend(s.exists() && !!s.val()?.since));
    const u9 = onValue(ref(db, `friend_requests/${targetUser}/${username}`), s => setFriendReqSent(s.exists()));
    const u10 = onValue(ref(db, `friend_requests/${username}/${targetUser}`), s => setIncomingFriendReq(s.exists()));
    return () => { u1(); u2(); u3(); u4(); u5(); u6(); u7(); u8(); u9(); u10(); };
  }, [targetUser, username]);

  async function sendFriendRequest() {
    await set(ref(db, `friend_requests/${targetUser}/${username}`), { ts: Date.now(), from: username });
    await push(ref(db, `notifications/${targetUser}`), {
      type: "mention", title: `@${username} do'stlik so'rovi yubordi 🤝`,
      body: "Do'stlar bo'limidan qabul qilishingiz mumkin", ts: Date.now(), read: false, from: username, tab: "friends"
    });
  }

  async function acceptFriendRequest() {
    const now = Date.now();
    await Promise.all([
      set(ref(db, `friends/${username}/${targetUser}`), { since: now }),
      set(ref(db, `friends/${targetUser}/${username}`), { since: now }),
      remove(ref(db, `friend_requests/${username}/${targetUser}`)),
    ]);
    await push(ref(db, `notifications/${targetUser}`), {
      type: "mention", title: `@${username} do'stlik so'rovini qabul qildi 🎉`,
      body: "Siz do'stlar ro'yxatiga qo'shildi!", ts: Date.now(), read: false, from: username, tab: "friends"
    });
  }

  async function cancelFriendRequest() {
    await remove(ref(db, `friend_requests/${targetUser}/${username}`));
  }

  async function removeFriend() {
    await Promise.all([
      remove(ref(db, `friends/${username}/${targetUser}`)),
      remove(ref(db, `friends/${targetUser}/${username}`)),
    ]);
  }

  async function addContact() {
    if (isContact) {
      await remove(ref(db, `contacts/${username}/${targetUser}`));
      return;
    }
    // check premium limit
    const meSnap = await get(ref(db, `premium/${username}`));
    const myPremium = meSnap.val() && meSnap.val().expiresAt > Date.now();
    if (!myPremium && contactCount >= 20) {
      alert("🔒 Tekin limit (20 kontakt) tugadi. Premium oling — cheksiz kontaktlar!");
      return;
    }
    const name = prompt(`Kontakt nomi (alias):`, targetUser);
    if (!name?.trim()) return;
    await set(ref(db, `contacts/${username}/${targetUser}`), { name: name.trim(), addedAt: serverTimestamp() });
  }

  const initial = targetUser[0]?.toUpperCase();
  const status = isOnline ? "🟢 Onlayn" : lastSeen ? `Oxirgi: ${new Date(lastSeen).toLocaleString("uz-UZ")}` : "Oflayn";

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4" style={{background:"rgba(0,0,0,0.85)", backdropFilter:"blur(20px)"}} onClick={onClose}>
      <div className="w-full max-w-md rounded-3xl border border-slate-800 overflow-hidden animate-[scale-in_0.2s_ease-out] relative"
        style={{background:"linear-gradient(180deg,#0f172a,#030712)", maxHeight:"90vh", display:"flex", flexDirection:"column"}}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="relative p-6 flex flex-col items-center text-center overflow-hidden"
          style={{background: (isPremium && profile?.profileBg) ? "transparent" : `radial-gradient(circle at top, ${accentColor}22, transparent 70%)`}}>

          {/* PREMIUM ANIMATED BACKGROUND (custom or default aura) */}
          {isPremium && profile?.profileBg ? (
            <div className={`absolute inset-0 ${profile.profileBg}`} style={{zIndex:0}} />
          ) : isPremium && (
            <>
              <div className="absolute inset-0 -z-10 premium-aura-bg" />
              <div className="absolute inset-0 -z-10 premium-aura-orb" />
              <div className="absolute inset-0 -z-10 premium-aura-grain" />
            </>
          )}

          <button onClick={onClose} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-slate-900/80 hover:bg-slate-800 flex items-center justify-center text-slate-400 text-sm" style={{zIndex:10}}>✕</button>

          {/* Avatar */}
          <div className="relative mb-3" style={{zIndex:1}}>
            <div className="absolute inset-0 rounded-full animate-pulse"
              style={{background: isPremium ? "linear-gradient(135deg,#f59e0b,#ec4899,#f59e0b)" : `linear-gradient(135deg,${accentColor},#6366f1)`, transform:"scale(1.1)", filter:"blur(8px)", opacity:0.6}} />
            <div className="relative w-28 h-28 rounded-full overflow-hidden border-4 flex items-center justify-center text-5xl font-black"
              style={{background:profile?.avatar ? "transparent" : `linear-gradient(135deg,${accentColor},#6366f1)`, borderColor: isPremium ? "#f59e0b" : "#1e293b"}}>
              {profile?.avatar ? <img src={profile.avatar} className="w-full h-full object-cover" alt={targetUser} /> : initial}
            </div>
            {isPremium && (
              <div className="absolute -bottom-1 -right-1">
                <PremiumBadge badgeId={profile?.badge} size={36} onClick={() => setShowBadgePicker(true)} />
              </div>
            )}
            {isOnline && !isPremium && (
              <div className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-green-400 border-2 border-slate-950" />
            )}
          </div>

          <div className="flex items-center gap-2 mb-1" style={{zIndex:1,position:"relative"}}>
            <p className="text-2xl font-black text-white">@{targetUser}</p>
            {isPremium && <VerifiedTick size={18} />}
          </div>
          <div style={{zIndex:1,position:"relative"}}>
            {isPremium && <div className="mb-1"><PremiumChip size="sm" /></div>}
            {profile?.displayName && <p className="text-sm text-slate-300">{profile.displayName}</p>}
            {profile?.customStatus && (
              <div className="mt-1 px-3 py-1 rounded-full text-xs font-medium bg-black/30 backdrop-blur-sm border border-white/10 text-slate-200">
                {profile.customStatus}
              </div>
            )}
            <p className="text-xs font-mono mt-1" style={{color: isOnline ? "#4ade80" : "#64748b"}}>{status}</p>
            {profile?.bio && (
              <p className="text-sm text-slate-300 mt-3 italic max-w-xs leading-relaxed bg-black/20 backdrop-blur-sm rounded-xl px-3 py-2">"{profile.bio}"</p>
            )}
          </div>
        </div>

        {/* Stories */}
        {stories.length > 0 && (
          <div className="px-4 py-3 border-t border-slate-800/50">
            <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">📸 Story ({stories.length})</p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {stories.map(s => (
                <button key={s.id} onClick={() => setActiveStory(s)}
                  className="flex-shrink-0 w-16 h-20 rounded-xl overflow-hidden border-2 border-pink-500 hover:scale-105 transition relative">
                  {s.mediaUrl ? (
                    s.mediaType === "video"
                      ? <div className="w-full h-full flex items-center justify-center bg-black text-2xl">▶️</div>
                      : <img src={s.mediaUrl} className="w-full h-full object-cover" alt="story" />
                  ) : s.mcc ? (
                    <div className="w-full h-full flex items-center justify-center bg-black text-2xl">
                      {s.mediaType === "video" ? "▶️" : "🖼️"}
                    </div>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[10px] text-white p-1 text-center"
                      style={{background: "linear-gradient(135deg,#ec4899,#8b5cf6)"}}>
                      {(s.text || "").slice(0, 20)}
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="p-4 border-t border-slate-800/50">
          {targetUser !== username ? (
            <div className="grid grid-cols-3 gap-2 mb-2">
              {[
                { icon: "💬", label: "Yozish",  onClick: () => { onStartChat?.(targetUser); onClose(); } },
                { icon: "📞", label: "Audio",   onClick: () => { onStartCall?.(targetUser, "audio"); onClose(); } },
                { icon: "📹", label: "Video",   onClick: () => { onStartCall?.(targetUser, "video"); onClose(); } },
              ].map((b, i) => (
                <button key={i} onClick={b.onClick}
                  className="flex flex-col items-center gap-1 py-2.5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-600 active:scale-95 transition">
                  <span className="text-lg">{b.icon}</span>
                  <span className="text-[9px] text-slate-300 font-medium leading-tight">{b.label}</span>
                </button>
              ))}
            </div>
          ) : null}
          {targetUser !== username && (
            <div className="mb-2">
              {isFriend ? (
                <button onClick={removeFriend}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl bg-green-950/30 border border-green-900/50 hover:bg-rose-950/30 hover:border-rose-900/50 active:scale-95 transition group">
                  <span className="text-base group-hover:hidden">✅</span>
                  <span className="text-base hidden group-hover:inline">🗑️</span>
                  <span className="text-xs font-bold text-green-400 group-hover:text-rose-400 transition">Do'stlar ro'yxatida · O'chirish</span>
                </button>
              ) : incomingFriendReq ? (
                <div className="flex gap-2">
                  <button onClick={acceptFriendRequest}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-2xl font-bold text-xs active:scale-95 transition"
                    style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}40` }}>
                    ✅ Qabul qilish
                  </button>
                  <button onClick={() => remove(ref(db, `friend_requests/${username}/${targetUser}`))}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-2xl font-bold text-xs text-rose-400 bg-rose-950/20 border border-rose-900/40 active:scale-95 transition">
                    ❌ Rad etish
                  </button>
                </div>
              ) : friendReqSent ? (
                <button onClick={cancelFriendRequest}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl bg-slate-800/60 border border-slate-700 hover:bg-slate-700 active:scale-95 transition">
                  <span className="text-base">⏳</span>
                  <span className="text-xs font-bold text-slate-400">So'rov kutilmoqda · Bekor qilish</span>
                </button>
              ) : (
                <button onClick={sendFriendRequest}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-sm active:scale-95 transition"
                  style={{ background:`${accentColor}18`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                  🤝 Do'st qo'shish
                </button>
              )}
            </div>
          )}
          <div className={`grid gap-2 ${targetUser !== username ? "grid-cols-3" : "grid-cols-1"}`}>
            {targetUser !== username && (
              <>
                <button onClick={() => setShowGiftsPicker(true)}
                  className="flex flex-col items-center gap-1 py-2.5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-600 active:scale-95 transition">
                  <span className="text-lg">🎁</span>
                  <span className="text-[9px] text-slate-300 font-medium">Sovg'a</span>
                </button>
                <button onClick={addContact}
                  className="flex flex-col items-center gap-1 py-2.5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-600 active:scale-95 transition">
                  <span className="text-lg">{isContact ? "❌" : "➕"}</span>
                  <span className="text-[9px] text-slate-300 font-medium">{isContact ? "O'chirish" : "Kontakt"}</span>
                </button>
              </>
            )}
            <button onClick={() => setShowShare(true)}
              className="flex flex-col items-center gap-1 py-2.5 rounded-2xl border border-indigo-800/60 bg-indigo-950/20 hover:border-indigo-600 active:scale-95 transition">
              <span className="text-lg">🔗</span>
              <span className="text-[9px] text-indigo-300 font-medium">Ulashish</span>
            </button>
          </div>
        </div>

        {/* GIFTS section */}
        <div className="px-4 py-3 border-t border-slate-800/50">
          <div className="flex items-center justify-between mb-2">
            <p className="text-[10px] font-bold text-slate-500 uppercase">🎁 Sovg'alar ({gifts.length})</p>
            {gifts.length > 0 && (
              <span className="text-[10px] font-bold text-amber-400">
                ⭐ {gifts.reduce((s, g) => s + (g.price || 0), 0)} jami
              </span>
            )}
          </div>
          {gifts.length === 0 ? (
            <p className="text-xs text-slate-600 text-center py-4 italic">
              {targetUser === username ? "Sizga hali sovg'a yo'q" : "Birinchi sovg'ani siz yuboring! 🎁"}
            </p>
          ) : (
            <>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {gifts.slice(0, showAllGifts ? gifts.length : 8).map(g => {
                  const def = getGift(g.giftId);
                  return (
                    <div key={g.id} title={`${def.name} · @${g.from}${g.message ? ` — "${g.message}"` : ""}`}
                      className="flex-shrink-0 w-14 h-14 rounded-2xl flex items-center justify-center relative gift-pop"
                      style={{ background: def.gradient }}>
                      <span className="gift-float" style={{ fontSize: 26 }}>{def.icon}</span>
                      <span className="absolute -bottom-1 -right-1 text-[8px] font-black bg-black/80 text-amber-300 rounded-full px-1.5 py-0.5">{def.price}</span>
                    </div>
                  );
                })}
              </div>
              {gifts.length > 8 && (
                <button onClick={() => setShowAllGifts(!showAllGifts)}
                  className="w-full mt-1 text-[10px] text-slate-400 hover:text-slate-200">
                  {showAllGifts ? "Yopish" : `Hammasi (${gifts.length})`}
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {showGiftsPicker && (
        <GiftsPicker
          fromUser={username}
          toUser={targetUser}
          onClose={() => setShowGiftsPicker(false)}
        />
      )}

      {showShare && (
        <ShareModal
          title={`@${targetUser}`}
          subtitle="Profil ulashish"
          link={`nexus://user/${targetUser}`}
          displayLink={`nexus://user/${targetUser}`}
          onClose={() => setShowShare(false)}
        />
      )}


      {/* Story viewer */}
      {activeStory && (
        <ActiveStoryOverlay
          story={activeStory}
          targetUser={targetUser}
          onClose={() => setActiveStory(null)}
        />
      )}

      {showBadgePicker && (
        <BadgeShowcase
          username={username}
          currentBadgeId={profile?.badge}
          isOwn={targetUser === username}
          isPremium={targetUser === username ? viewerPremium : isPremium}
          onClose={() => setShowBadgePicker(false)}
        />
      )}
    </div>
  );
}
