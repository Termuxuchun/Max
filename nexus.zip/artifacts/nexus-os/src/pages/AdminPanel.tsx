import { useRef, useState, useEffect, useCallback } from "react";
import { ref, set, push, update, remove, get, onValue, serverTimestamp, query, limitToLast, orderByChild } from "firebase/database";
import { db } from "../firebase";
import { startSiren, stopSiren } from "../sounds";
import { GIFTS, getGift } from "../lib/gifts";

interface AdminPanelProps { username: string; }
type AdminTab =
  | "dashboard" | "users" | "analytics" | "broadcast"
  | "chat_monitor" | "bots" | "premium" | "gifts"
  | "system" | "stars" | "channels" | "reports"
  | "music" | "security" | "activity";

const DEFAULT_TRACKS = [
  { title: "Sunny Morning",   artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-sunny.mp3",          emoji: "☀️", color: "#f59e0b", genre: "Pop" },
  { title: "Creative Minds",  artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-creativeminds.mp3",  emoji: "🎨", color: "#8b5cf6", genre: "Ambient" },
  { title: "Ukulele",         artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-ukulele.mp3",        emoji: "🎸", color: "#f97316", genre: "Acoustic" },
  { title: "Little Idea",     artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-littleidea.mp3",     emoji: "💡", color: "#22d3ee", genre: "Jazz" },
  { title: "Tomorrow",        artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-tomorrow.mp3",       emoji: "🌅", color: "#ec4899", genre: "Cinematic" },
  { title: "Hip Jazz",        artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-hipjazz.mp3",        emoji: "🎷", color: "#10b981", genre: "Jazz" },
  { title: "Epic",            artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-epic.mp3",           emoji: "⚡", color: "#ef4444", genre: "Epic" },
  { title: "Dreams",          artist: "Bensound", url: "https://www.bensound.com/bensound-music/bensound-dreams.mp3",         emoji: "🌙", color: "#6366f1", genre: "Electronic" },
];
const GENRES = ["Pop","Ambient","Acoustic","Jazz","Cinematic","Epic","Electronic","Romantic","Classical","Hip-Hop","Lo-Fi","Rock","EDM","Boshqa"];
const EMOJIS = ["🎵","🎸","🎷","🎺","🎻","🥁","🎹","🎤","🎼","🎧","💿","🎶","⚡","🌅","🌙","🔥","💫","🎨","💡","🌿","❤️","🌸","☀️","🌊","🚀","💎","⭐","🏆"];
const COLORS = ["#f59e0b","#8b5cf6","#f97316","#22d3ee","#ec4899","#10b981","#ef4444","#84cc16","#6366f1","#f43f5e","#e879f9","#0ea5e9","#14b8a6","#a855f7","#22c55e"];

const NAV_ITEMS: { id: AdminTab; icon: string; label: string; color: string; badge?: string }[] = [
  { id: "dashboard",    icon: "📊", label: "Dashboard",    color: "#22d3ee" },
  { id: "users",        icon: "👥", label: "Foydalanuvchi",color: "#4ade80" },
  { id: "analytics",    icon: "📈", label: "Analitika",    color: "#a855f7" },
  { id: "activity",     icon: "⚡", label: "Faollik",      color: "#f59e0b", badge: "LIVE" },
  { id: "broadcast",    icon: "📢", label: "Broadcast",    color: "#3b82f6" },
  { id: "chat_monitor", icon: "👁️", label: "Monitor",     color: "#8b5cf6" },
  { id: "bots",         icon: "🤖", label: "Bot Engine",   color: "#22c55e" },
  { id: "premium",      icon: "👑", label: "Premium",      color: "#f59e0b" },
  { id: "stars",        icon: "⭐", label: "Yulduzlar",    color: "#fbbf24" },
  { id: "gifts",        icon: "🎁", label: "Sovg'alar",   color: "#ec4899" },
  { id: "channels",     icon: "📡", label: "Kanallar",     color: "#0ea5e9" },
  { id: "reports",      icon: "🚨", label: "Shikoyatlar",  color: "#ef4444" },
  { id: "music",        icon: "🎵", label: "Musiqa",       color: "#14b8a6" },
  { id: "security",     icon: "🛡️", label: "Xavfsizlik",  color: "#f43f5e" },
  { id: "system",       icon: "⚙️", label: "Tizim",       color: "#64748b" },
];

function useCountUp(target: number, duration = 900) {
  const [val, setVal] = useState(0);
  const startRef = useRef<number | null>(null);
  const prevRef = useRef(0);
  useEffect(() => {
    if (target === prevRef.current) return;
    const from = prevRef.current;
    prevRef.current = target;
    startRef.current = null;
    const tick = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const pct = Math.min((ts - startRef.current) / duration, 1);
      setVal(Math.round(from + (target - from) * (1 - Math.pow(1 - pct, 3))));
      if (pct < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [target, duration]);
  return val;
}

function StatCard({ icon, label, value, color, sub }: { icon: string; label: string; value: number; color: string; sub?: string }) {
  const counted = useCountUp(value);
  return (
    <div className="relative rounded-2xl p-4 overflow-hidden border"
      style={{ background: `${color}08`, borderColor: `${color}25` }}>
      <div className="absolute top-0 right-0 w-20 h-20 rounded-full blur-2xl pointer-events-none"
        style={{ background: `${color}15`, transform: "translate(30%,-30%)" }} />
      <div className="flex items-start justify-between mb-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
          style={{ background: `${color}18` }}>
          {icon}
        </div>
        <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: color, marginTop: 4 }} />
      </div>
      <p className="text-2xl font-black tabular-nums" style={{ color }}>{counted.toLocaleString()}</p>
      <p className="text-[10px] text-slate-500 mt-0.5">{label}</p>
      {sub && <p className="text-[9px] mt-1 font-mono" style={{ color: `${color}99` }}>{sub}</p>}
    </div>
  );
}

export default function AdminPanel({ username }: AdminPanelProps) {
  const [tab, setTab] = useState<AdminTab>("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  /* ── Data states ── */
  const [allUsers, setAllUsers]       = useState<{ key: string; data: any }[]>([]);
  const [statusMap, setStatusMap]     = useState<Record<string, any>>({});
  const [bannedList, setBannedList]   = useState<string[]>([]);
  const [adminList, setAdminList]     = useState<string[]>([]);
  const [premiumUsers, setPremiumUsers]     = useState<Record<string, any>>({});
  const [premiumRequests, setPremiumRequests] = useState<any[]>([]);
  const [globalMessages, setGlobalMessages]   = useState<any[]>([]);
  const [channels, setChannels]       = useState<{ id: string; data: any }[]>([]);
  const [reports, setReports]         = useState<any[]>([]);
  const [starBalances, setStarBalances] = useState<Record<string, number>>({});
  const [starRequests, setStarRequests] = useState<any[]>([]);
  const [allGifts, setAllGifts]       = useState<any[]>([]);
  const [tracks, setTracks]           = useState<any[]>([]);
  const [activityFeed, setActivityFeed] = useState<any[]>([]);
  const [callLogs, setCallLogs]       = useState<any[]>([]);

  /* ── Form states ── */
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [broadcastType, setBroadcastType] = useState<"channel"|"mass"|"push">("channel");
  const [pushUser, setPushUser]         = useState("");
  const [pushMsg, setPushMsg]           = useState("");
  const [pushEmoji, setPushEmoji]       = useState("📢");
  const [announcement, setAnnouncement] = useState("");
  const [targetUser, setTargetUser]     = useState("");
  const [scheduleMsg, setScheduleMsg]   = useState("");
  const [scheduleDelay, setScheduleDelay] = useState("10");
  const [monitorUser, setMonitorUser]   = useState("");
  const [monitorMsgs, setMonitorMsgs]   = useState<any[]>([]);
  const [botName, setBotName]           = useState("NexusBot");
  const [botMsg, setBotMsg]             = useState("");
  const [botDelay, setBotDelay]         = useState("5");
  const [botRunning, setBotRunning]     = useState(false);
  const [wordFilter, setWordFilter]     = useState(() => localStorage.getItem("nexus_word_filter") || "");
  const [userFilter, setUserFilter]     = useState<"all"|"online"|"banned"|"admin"|"premium">("all");
  const [userSearch, setUserSearch]     = useState("");
  const [replyText, setReplyText]       = useState<Record<string, string>>({});
  const [grantStarUser, setGrantStarUser] = useState("");
  const [grantStarAmount, setGrantStarAmount] = useState("100");
  const [giftTargetUser, setGiftTargetUser] = useState("");
  const [giftSelected, setGiftSelected] = useState(GIFTS[0]?.id || "");
  const [giftMessage, setGiftMessage]   = useState("");
  const [trackForm, setTrackForm]       = useState({ title: "", artist: "", url: "", emoji: "🎵", color: "#8b5cf6", genre: "Pop" });
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [lockdown, setLockdown]         = useState(false);
  const [slowMode, setSlowMode]         = useState(false);
  const [ghost, setGhost]               = useState(false);
  const [redTheme, setRedTheme]         = useState(false);
  const [jammed, setJammed]             = useState(false);
  const [sirenOn, setSirenOn]           = useState(false);
  const [banReason, setBanReason]       = useState("");
  const [banDays, setBanDays]           = useState("0");
  const [quickBanUser, setQuickBanUser] = useState("");
  const [playingId, setPlayingId]       = useState<string|null>(null);
  const [testAudio, setTestAudio]       = useState<HTMLAudioElement|null>(null);

  /* ── Logs ── */
  const [logs, setLogs] = useState<{ msg: string; type: "info"|"err"|"warn"|"ok"; time: string }[]>([
    { msg: `🟢 NEXUS ADMIN v3.0 — @${username}`, type: "ok", time: new Date().toLocaleTimeString() }
  ]);
  const [showLogs, setShowLogs] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);
  const botIntervalRef = useRef<ReturnType<typeof setInterval>|undefined>(undefined);

  const log = useCallback((msg: string, type: "info"|"err"|"warn"|"ok" = "info") => {
    const time = new Date().toLocaleTimeString();
    setLogs(prev => {
      const next = [...prev, { msg, type, time }].slice(-200);
      setTimeout(() => logsEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
      return next;
    });
  }, []);

  /* ── Firebase subscriptions ── */
  useEffect(() => {
    const subs = [
      onValue(ref(db, "users"), snap => {
        const list: { key: string; data: any }[] = [];
        snap?.forEach(c => { list.push({ key: c.key!, data: c.val() }); });
        setAllUsers(list);
      }),
      onValue(ref(db, "status"), snap => {
        const m: Record<string, any> = {};
        snap?.forEach(c => { m[c.key!] = c.val(); });
        setStatusMap(m);
      }),
      onValue(ref(db, "banned"), snap => {
        const l: string[] = [];
        snap?.forEach(c => { if (c.val()) l.push(c.key!); });
        setBannedList(l);
      }),
      onValue(ref(db, "admins"), snap => {
        const l: string[] = [];
        snap?.forEach(c => { if (c.val()) l.push(c.key!); });
        setAdminList(l);
      }),
      onValue(ref(db, "premium"), snap => {
        const m: Record<string, any> = {};
        snap?.forEach(c => { m[c.key!] = c.val(); });
        setPremiumUsers(m);
      }),
      onValue(ref(db, "premium_requests"), snap => {
        const l: any[] = [];
        snap?.forEach(c => { l.push({ id: c.key!, ...c.val() }); });
        l.sort((a, b) => (b.requestedAt || 0) - (a.requestedAt || 0));
        setPremiumRequests(l);
      }),
      onValue(query(ref(db, "messages/global_max"), orderByChild("timestamp"), limitToLast(50)), snap => {
        const l: any[] = [];
        snap?.forEach(c => { l.push({ id: c.key, ...c.val() }); });
        setGlobalMessages(l.reverse());
      }),
      onValue(ref(db, "channels"), snap => {
        const l: { id: string; data: any }[] = [];
        snap?.forEach(c => { l.push({ id: c.key!, data: c.val() }); });
        setChannels(l);
      }),
      onValue(ref(db, "reports"), snap => {
        if (!snap.exists()) { setReports([]); return; }
        const l: any[] = [];
        snap.forEach(c => { l.push({ id: c.key!, ...c.val() }); });
        l.sort((a, b) => (b.ts || 0) - (a.ts || 0));
        setReports(l);
      }),
      onValue(ref(db, "stars"), snap => {
        const m: Record<string, number> = {};
        snap?.forEach(c => { m[c.key!] = c.val()?.balance || 0; });
        setStarBalances(m);
      }),
      onValue(ref(db, "star_requests"), snap => {
        const l: any[] = [];
        snap?.forEach(c => { l.push({ id: c.key!, ...c.val() }); });
        l.sort((a, b) => (b.ts || 0) - (a.ts || 0));
        setStarRequests(l);
      }),
      onValue(ref(db, "music/tracks"), snap => {
        const l: any[] = [];
        snap?.forEach(c => { l.push({ id: c.key!, ...c.val() }); });
        l.sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
        setTracks(l);
      }),
      onValue(query(ref(db, "activity_feed"), orderByChild("ts"), limitToLast(50)), snap => {
        const l: any[] = [];
        snap?.forEach(c => { l.push({ id: c.key!, ...c.val() }); });
        l.sort((a, b) => b.ts - a.ts);
        setActivityFeed(l);
      }),
      onValue(ref(db, "system/maintenance"), snap => setMaintenanceMode(!!snap.val())),
      onValue(ref(db, "system/lockdown"), snap => setLockdown(!!snap.val())),
      onValue(ref(db, "system/slow_mode"), snap => setSlowMode(!!snap.val())),
    ];
    return () => subs.forEach(u => u());
  }, []);

  /* ── Monitor user chat ── */
  useEffect(() => {
    if (!monitorUser) { setMonitorMsgs([]); return; }
    const uClean = monitorUser.replace("@", "").toLowerCase();
    const chatKey = [username, uClean].sort().join("_");
    const u = onValue(query(ref(db, `messages/${chatKey}`), orderByChild("timestamp"), limitToLast(30)), snap => {
      const l: any[] = [];
      snap?.forEach(c => { l.push({ id: c.key, ...c.val() }); });
      setMonitorMsgs(l.reverse());
    });
    return u;
  }, [monitorUser, username]);

  /* ── Computed ── */
  const onlineCount   = Object.values(statusMap).filter(v => v?.state === "online").length;
  const premiumCount  = Object.values(premiumUsers).filter(v => v?.expiresAt > Date.now()).length;
  const pendingPremium = premiumRequests.filter(r => r.status === "pending");
  const pendingReports = reports.filter(r => r.status === "pending");
  const totalStars    = Object.values(starBalances).reduce((s, v) => s + v, 0);

  const filteredUsers = allUsers.filter(({ key, data }) => {
    if (userSearch && !key.toLowerCase().includes(userSearch.toLowerCase())) return false;
    if (userFilter === "online")  return statusMap[key]?.state === "online";
    if (userFilter === "banned")  return bannedList.includes(key);
    if (userFilter === "admin")   return adminList.includes(key);
    if (userFilter === "premium") return premiumUsers[key]?.expiresAt > Date.now();
    return true;
  });

  /* ── Actions ── */
  function getTarget() { return targetUser.trim().replace("@", "").toLowerCase(); }

  async function grantPremium(reqId: string | null, uname: string, months: number, label: string, reply?: string) {
    const expiresAt = Date.now() + months * 30 * 24 * 60 * 60 * 1000;
    await set(ref(db, `premium/${uname}`), { plan: `${months}month`, label, months, expiresAt, grantedBy: username, grantedAt: Date.now() });
    if (reqId) await update(ref(db, `premium_requests/${reqId}`), { status: "approved", adminReply: reply || "", resolvedAt: Date.now() });
    await push(ref(db, `system_pushes/${uname}`), { msg: `🎉 Premium faollashdi! ${months} oy. ${reply || ""}`, from: "Admin", type: "msg", ts: Date.now() });
    log(`👑 @${uname} ga ${months} oy Premium berildi`, "ok");
  }

  async function denyRequest(reqId: string, uname: string, reply: string) {
    await update(ref(db, `premium_requests/${reqId}`), { status: "denied", adminReply: reply, resolvedAt: Date.now() });
    await push(ref(db, `system_pushes/${uname}`), { msg: `❌ Premium so'rovingiz rad etildi. ${reply}`, from: "Admin", type: "msg", ts: Date.now() });
    log(`❌ @${uname} so'rovi rad etildi`, "warn");
  }

  async function revokePremium(uname: string) {
    if (!confirm(`@${uname} Premium bekor qilsin?`)) return;
    await remove(ref(db, `premium/${uname}`));
    log(`🗑️ @${uname} Premium bekor qilindi`, "warn");
  }

  async function banUser(uname: string, reason = "", days = 0) {
    const val = days > 0 ? { until: Date.now() + days * 86400000, reason: reason || "Admin", bannedBy: username } : true;
    await set(ref(db, `banned/${uname}`), val);
    await push(ref(db, `system_pushes/${uname}`), { msg: `⛔ Siz ban qildingiz. ${reason ? `Sabab: ${reason}` : ""} ${days > 0 ? `Muddati: ${days} kun` : "Muddatsiz."}`, from: "System", type: "ban", ts: Date.now() });
    log(`⛔ @${uname} ban qilindi ${days > 0 ? `(${days} kun)` : "(muddatsiz)"}`, "warn");
  }

  async function unbanUser(uname: string) {
    await remove(ref(db, `banned/${uname}`));
    log(`✅ @${uname} ban olib tashlandi`, "ok");
  }

  function startBot() {
    if (botRunning) {
      clearInterval(botIntervalRef.current);
      setBotRunning(false); log("⏹️ Bot to'xtatildi", "warn"); return;
    }
    if (!botMsg.trim()) { log("Bot xabari bo'sh!", "err"); return; }
    const send = () => push(ref(db, "messages/global_max"), { sender: botName, text: botMsg, type: "text", status: "sent", timestamp: serverTimestamp() });
    send();
    botIntervalRef.current = setInterval(send, parseInt(botDelay) * 1000);
    setBotRunning(true);
    log(`▶️ Bot boshlandi: "${botMsg}" — ${botDelay}s`, "ok");
  }

  async function sendBroadcast() {
    if (!broadcastMsg.trim()) return;
    if (broadcastType === "channel") {
      await push(ref(db, "messages/global_max"), { sender: "Admin", text: `📢 ${broadcastMsg}`, type: "text", status: "sent", timestamp: serverTimestamp() });
      log(`📢 Global broadcast: "${broadcastMsg}"`, "ok");
    } else if (broadcastType === "mass") {
      for (const { key } of allUsers) {
        await push(ref(db, `system_pushes/${key}`), { msg: `📢 ${broadcastMsg}`, from: "Admin", type: "msg", ts: Date.now() });
      }
      log(`📡 Mass push (${allUsers.length} ta): "${broadcastMsg}"`, "ok");
    } else {
      const u = pushUser.replace("@", "").toLowerCase();
      if (!u) { log("Username bo'sh!", "err"); return; }
      await push(ref(db, `system_pushes/${u}`), { msg: `${pushEmoji} ${pushMsg || broadcastMsg}`, from: "Admin", type: "msg", ts: Date.now() });
      log(`💉 Push → @${u}: "${pushMsg || broadcastMsg}"`, "ok");
    }
    setBroadcastMsg("");
  }

  async function grantStars(uname: string, amount: number) {
    if (!uname || amount <= 0) return;
    const snap = await get(ref(db, `stars/${uname}`));
    const cur = snap.val()?.balance || 0;
    await update(ref(db, `stars/${uname}`), { balance: cur + amount });
    await push(ref(db, `system_pushes/${uname}`), { msg: `⭐ Sizga ${amount} yulduz berildi! Admin tomonidan.`, from: "Admin", type: "msg", ts: Date.now() });
    log(`⭐ @${uname} ga ${amount} yulduz berildi`, "ok");
  }

  async function sendGift(to: string, giftId: string, msg: string) {
    if (!to) return;
    const gift = getGift(giftId);
    if (!gift) return;
    const cur = (await get(ref(db, `stars/${to}`))).val()?.balance || 0;
    await update(ref(db, `stars/${to}`), { balance: cur + gift.price });
    await push(ref(db, `gifts/${to}`), { giftId, from: "Admin", message: msg, ts: Date.now(), price: gift.price });
    await push(ref(db, `system_pushes/${to}`), { msg: `🎁 Sizga ${gift.name} sovg'a yuborildi! ${msg ? `Izoh: "${msg}"` : ""}`, from: "Admin", type: "gift", ts: Date.now() });
    log(`🎁 @${to} ga ${gift.name} yuborildi`, "ok");
  }

  async function seedTracks() {
    if (!confirm(`${DEFAULT_TRACKS.length} ta standart trek yuklansin?`)) return;
    for (let i = 0; i < DEFAULT_TRACKS.length; i++) {
      await push(ref(db, "music/tracks"), { ...DEFAULT_TRACKS[i], addedAt: Date.now(), order: i });
    }
    log(`🎵 ${DEFAULT_TRACKS.length} ta standart trek yuklandi`, "ok");
  }

  function toggleTrackTest(id: string, url: string) {
    if (playingId === id) { testAudio?.pause(); setTestAudio(null); setPlayingId(null); return; }
    testAudio?.pause();
    const a = new Audio(url);
    a.volume = 0.4;
    a.play().catch(() => log("Audio yuklanmadi", "err"));
    a.onended = () => { setPlayingId(null); setTestAudio(null); };
    setTestAudio(a); setPlayingId(id);
  }

  /* ── Tab badge counts ── */
  function getBadge(id: AdminTab) {
    if (id === "premium") return pendingPremium.length > 0 ? pendingPremium.length : null;
    if (id === "reports") return pendingReports.length > 0 ? pendingReports.length : null;
    return null;
  }

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 overflow-hidden">
      <style>{`
        .admin-nav-btn { transition: all 0.15s ease; }
        .admin-nav-btn:hover { background: rgba(255,255,255,0.04); }
        .admin-nav-btn.active { background: rgba(255,255,255,0.07); }
        .admin-input {
          background: rgba(15,23,42,0.8);
          border: 1px solid rgba(148,163,184,0.15);
          border-radius: 12px;
          padding: 10px 14px;
          color: white;
          font-size: 13px;
          width: 100%;
          outline: none;
          transition: border-color 0.2s;
        }
        .admin-input:focus { border-color: rgba(34,211,238,0.5); }
        .admin-input::placeholder { color: #475569; }
        .admin-card {
          background: rgba(15,23,42,0.6);
          border: 1px solid rgba(148,163,184,0.1);
          border-radius: 16px;
          padding: 16px;
        }
        .admin-btn {
          border-radius: 10px;
          font-weight: 700;
          font-size: 11px;
          padding: 8px 16px;
          transition: all 0.15s;
          cursor: pointer;
          border: 1px solid transparent;
        }
        .admin-btn:active { transform: scale(0.96); }
        .log-info  { color: #94a3b8; }
        .log-warn  { color: #f59e0b; }
        .log-err   { color: #f87171; }
        .log-ok    { color: #4ade80; }
        @keyframes live-dot { 0%,100%{opacity:1;transform:scale(1);}50%{opacity:0.5;transform:scale(1.5);} }
        .live-dot { animation: live-dot 1.2s ease-in-out infinite; }
        @keyframes fade-row { from{opacity:0;transform:translateX(-8px);}to{opacity:1;transform:translateX(0);} }
        .fade-row { animation: fade-row 0.25s ease forwards; }
      `}</style>

      {/* ══ TOP BAR ══ */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b border-slate-800/70"
        style={{ background: "rgba(3,7,18,0.98)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center gap-3">
          <button onClick={() => setSidebarCollapsed(v => !v)}
            className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-800 transition text-slate-500">
            ☰
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center text-sm"
              style={{ background: "linear-gradient(135deg,#ef4444,#7c3aed)" }}>🛡️</div>
            <div>
              <p className="text-xs font-black tracking-widest text-white">NEXUS ADMIN</p>
              <p className="text-[9px] font-mono text-rose-500">GOD MODE · @{username}</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-green-900/40 bg-green-950/20">
            <div className="w-1.5 h-1.5 rounded-full bg-green-400 live-dot" />
            <span className="text-[10px] font-bold text-green-400">{onlineCount} online</span>
          </div>
          {(pendingPremium.length + pendingReports.length) > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-amber-900/40 bg-amber-950/20 animate-pulse">
              <span className="text-[10px] font-bold text-amber-400">⏳ {pendingPremium.length + pendingReports.length} kutmoqda</span>
            </div>
          )}
          {maintenanceMode && (
            <div className="px-3 py-1.5 rounded-xl border border-amber-900 bg-amber-950/30">
              <span className="text-[10px] font-black text-amber-400 animate-pulse">🚧 MAINTENANCE</span>
            </div>
          )}
          <button onClick={() => setShowLogs(v => !v)}
            className="text-[10px] font-bold px-3 py-1.5 rounded-xl border border-slate-800 hover:border-slate-600 text-slate-500 hover:text-slate-300 transition">
            {showLogs ? "▼ Yopish" : "▲ Logs"} ({logs.length})
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">

        {/* ══ SIDEBAR ══ */}
        <aside className={`flex-shrink-0 border-r border-slate-800/70 overflow-y-auto transition-all duration-300 ${sidebarCollapsed ? "w-14" : "w-48"}`}
          style={{ background: "rgba(6,10,22,0.9)" }}>
          <div className="p-1.5 space-y-0.5">
            {NAV_ITEMS.map(item => {
              const badge = getBadge(item.id);
              const active = tab === item.id;
              return (
                <button key={item.id} onClick={() => setTab(item.id)}
                  className={`admin-nav-btn w-full flex items-center gap-2.5 px-2.5 py-2.5 rounded-xl relative ${active ? "active" : ""}`}
                  style={active ? { background: `${item.color}12`, border: `1px solid ${item.color}25` } : { border: "1px solid transparent" }}>
                  <span className="text-base flex-shrink-0">{item.icon}</span>
                  {!sidebarCollapsed && (
                    <>
                      <span className="text-xs font-semibold flex-1 text-left truncate" style={{ color: active ? item.color : "#64748b" }}>
                        {item.label}
                      </span>
                      {item.badge && !badge && (
                        <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full" style={{ background: `${item.color}20`, color: item.color }}>
                          {item.badge}
                        </span>
                      )}
                      {badge && (
                        <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-rose-600 text-white animate-pulse">
                          {badge}
                        </span>
                      )}
                    </>
                  )}
                  {sidebarCollapsed && badge && (
                    <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500" />
                  )}
                </button>
              );
            })}
          </div>
        </aside>

        {/* ══ MAIN CONTENT ══ */}
        <main className="flex-1 overflow-y-auto">
          <div className="p-5 max-w-5xl mx-auto">

            {/* ── DASHBOARD ── */}
            {tab === "dashboard" && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-black text-white">Admin Dashboard</h2>
                    <p className="text-xs text-slate-500 font-mono">
                      {new Date().toLocaleDateString("uz-UZ", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 live-dot" />
                    <span className="text-[10px] font-mono text-green-400">REAL-TIME</span>
                  </div>
                </div>

                {/* Stats grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  <StatCard icon="👥" label="Jami foydalanuvchi" value={allUsers.length} color="#22d3ee" />
                  <StatCard icon="🟢" label="Online hozir" value={onlineCount} color="#4ade80" sub={`${Math.round((onlineCount/Math.max(allUsers.length,1))*100)}% aktiv`} />
                  <StatCard icon="👑" label="Premium" value={premiumCount} color="#a855f7" />
                  <StatCard icon="⭐" label="Jami yulduzlar" value={totalStars} color="#f59e0b" />
                  <StatCard icon="⛔" label="Bloklangan" value={bannedList.length} color="#f43f5e" />
                  <StatCard icon="🛡️" label="Admin" value={adminList.length} color="#6366f1" />
                  <StatCard icon="📡" label="Kanallar" value={channels.length} color="#0ea5e9" />
                  <StatCard icon="🎵" label="Musiqa treklarni" value={tracks.length} color="#14b8a6" />
                </div>

                {/* Kutayotganlar */}
                {(pendingPremium.length > 0 || pendingReports.length > 0) && (
                  <div className="admin-card border-amber-900/40 space-y-3">
                    <p className="text-sm font-bold text-amber-400">⏳ Kutayotgan amallar</p>
                    <div className="grid grid-cols-2 gap-3">
                      {pendingPremium.length > 0 && (
                        <button onClick={() => setTab("premium")}
                          className="flex items-center gap-3 p-3 rounded-xl bg-amber-950/20 border border-amber-900/40 hover:border-amber-700/60 transition">
                          <span className="text-2xl font-black text-amber-400">{pendingPremium.length}</span>
                          <div className="text-left">
                            <p className="text-xs font-bold text-amber-300">Premium so'rovlar</p>
                            <p className="text-[10px] text-amber-600">Ko'rish →</p>
                          </div>
                        </button>
                      )}
                      {pendingReports.length > 0 && (
                        <button onClick={() => setTab("reports")}
                          className="flex items-center gap-3 p-3 rounded-xl bg-rose-950/20 border border-rose-900/40 hover:border-rose-700/60 transition">
                          <span className="text-2xl font-black text-rose-400">{pendingReports.length}</span>
                          <div className="text-left">
                            <p className="text-xs font-bold text-rose-300">Shikoyatlar</p>
                            <p className="text-[10px] text-rose-600">Ko'rish →</p>
                          </div>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* Online users */}
                <div className="admin-card space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-green-400">🟢 Online foydalanuvchilar</p>
                    <span className="text-[10px] text-slate-600 font-mono">{onlineCount} ta</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(statusMap).filter(([,v]) => v?.state === "online").map(([k]) => (
                      <div key={k} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-green-950/30 border border-green-900/40 fade-row">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                        <span className="text-[10px] text-green-300 font-mono">@{k}</span>
                      </div>
                    ))}
                    {onlineCount === 0 && <p className="text-slate-600 text-xs font-mono">Hozir hech kim online emas</p>}
                  </div>
                </div>

                {/* Recent activity */}
                <div className="admin-card space-y-2">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-bold text-slate-300">⚡ So'nggi faollik</p>
                    <button onClick={() => setTab("activity")} className="text-[10px] text-cyan-500 hover:text-cyan-400">Barchasi →</button>
                  </div>
                  {activityFeed.slice(0, 8).map(a => (
                    <div key={a.id} className="flex items-center gap-2.5 py-1.5 border-b border-slate-800/40 last:border-0 fade-row">
                      <span className="text-base w-6 text-center flex-shrink-0">{a.icon || "⚡"}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-slate-300 truncate">{a.text}</p>
                        <p className="text-[9px] text-slate-600 font-mono">{a.ts ? new Date(a.ts).toLocaleTimeString("uz-UZ") : ""}</p>
                      </div>
                    </div>
                  ))}
                  {activityFeed.length === 0 && <p className="text-slate-600 text-xs font-mono text-center py-4">Faollik yo'q</p>}
                </div>

                {/* Quick actions */}
                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-slate-300">⚡ Tezkor amallar</p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { icon: "🚧", label: "Maintenance", active: maintenanceMode, action: () => { set(ref(db, "system/maintenance"), !maintenanceMode); log(`🚧 Maintenance: ${!maintenanceMode}`, "warn"); }, color: "#f59e0b" },
                      { icon: "🔒", label: "Lockdown", active: lockdown, action: () => { set(ref(db, "system/lockdown"), !lockdown); log(`🔒 Lockdown: ${!lockdown}`, "warn"); }, color: "#ef4444" },
                      { icon: "🐢", label: "Slow Mode", active: slowMode, action: () => { set(ref(db, "system/slow_mode"), !slowMode); log(`🐢 Slow mode: ${!slowMode}`); }, color: "#f97316" },
                      { icon: "🔄", label: "Reboot All", active: false, action: async () => { if (!confirm("Barcha foydalanuvchilarni qayta yuklatmoqchimisiz?")) return; await set(ref(db, "system/force_reboot"), Date.now()); log("🔄 Force reboot yuborildi!", "warn"); }, color: "#6366f1" },
                    ].map(a => (
                      <button key={a.label} onClick={a.action}
                        className="flex flex-col items-center gap-2 p-4 rounded-2xl border transition"
                        style={a.active ? { background: `${a.color}15`, borderColor: `${a.color}40`, boxShadow: `0 0 16px ${a.color}20` } : { background: "rgba(15,23,42,0.4)", borderColor: "rgba(148,163,184,0.1)" }}>
                        <span className="text-2xl">{a.icon}</span>
                        <span className="text-[10px] font-bold" style={{ color: a.active ? a.color : "#64748b" }}>
                          {a.label}
                        </span>
                        <div className={`w-8 h-4 rounded-full relative transition-colors ${a.active ? "bg-green-500" : "bg-slate-700"}`}>
                          <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${a.active ? "left-4" : "left-0.5"}`} />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── FOYDALANUVCHILAR ── */}
            {tab === "users" && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-black text-white">👥 Foydalanuvchilar</h2>
                  <span className="text-xs text-slate-500 font-mono">{filteredUsers.length} / {allUsers.length}</span>
                </div>

                {/* Filters */}
                <div className="flex flex-wrap gap-2">
                  <input value={userSearch} onChange={e => setUserSearch(e.target.value)}
                    className="admin-input max-w-xs text-xs" placeholder="🔍 Qidirish @username..." />
                  <div className="flex gap-1 flex-wrap">
                    {(["all","online","banned","admin","premium"] as const).map(f => (
                      <button key={f} onClick={() => setUserFilter(f)}
                        className="admin-btn transition"
                        style={userFilter === f ? { background: "#22d3ee20", color: "#22d3ee", borderColor: "#22d3ee40" } : { background: "rgba(15,23,42,0.5)", color: "#64748b", borderColor: "rgba(148,163,184,0.1)" }}>
                        {f === "all" ? `👥 Hamma` : f === "online" ? `🟢 Online` : f === "banned" ? `⛔ Ban` : f === "admin" ? `🛡️ Admin` : `👑 Premium`}
                        <span className="ml-1 opacity-60">
                          ({f === "all" ? allUsers.length : f === "online" ? onlineCount : f === "banned" ? bannedList.length : f === "admin" ? adminList.length : premiumCount})
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* User list */}
                <div className="space-y-2">
                  {filteredUsers.map(({ key: uKey }) => {
                    const isOnline = statusMap[uKey]?.state === "online";
                    const isBanned = bannedList.includes(uKey);
                    const isAdm    = adminList.includes(uKey);
                    const isPrem   = premiumUsers[uKey]?.expiresAt > Date.now();
                    const premDays = isPrem ? Math.ceil((premiumUsers[uKey].expiresAt - Date.now()) / 86400000) : 0;
                    const stars    = starBalances[uKey] || 0;
                    return (
                      <div key={uKey} className="flex items-center gap-3 p-3 rounded-2xl border transition hover:border-slate-700/60 fade-row"
                        style={{ background: isBanned ? "rgba(239,68,68,0.04)" : isAdm ? "rgba(245,158,11,0.04)" : isPrem ? "rgba(168,85,247,0.04)" : "rgba(15,23,42,0.5)", borderColor: isBanned ? "rgba(239,68,68,0.2)" : isAdm ? "rgba(245,158,11,0.15)" : isPrem ? "rgba(168,85,247,0.15)" : "rgba(148,163,184,0.1)" }}>
                        <div className="relative flex-shrink-0">
                          <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-black text-white"
                            style={{ background: isAdm ? "linear-gradient(135deg,#f59e0b,#ef4444)" : isPrem ? "linear-gradient(135deg,#a855f7,#6366f1)" : "linear-gradient(135deg,#334155,#1e293b)" }}>
                            {uKey[0]?.toUpperCase()}
                          </div>
                          <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#030712] ${isOnline ? "bg-green-400" : "bg-slate-600"}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-sm font-bold text-slate-200">@{uKey}</span>
                            {isAdm    && <span className="text-[8px] bg-amber-950/60 text-amber-400 px-1.5 py-0.5 rounded font-black border border-amber-900/60">ADMIN</span>}
                            {isBanned && <span className="text-[8px] bg-rose-950/60 text-rose-400 px-1.5 py-0.5 rounded font-black border border-rose-900/60">BANNED</span>}
                            {isPrem   && <span className="text-[8px] bg-purple-950/60 text-purple-300 px-1.5 py-0.5 rounded font-black border border-purple-900/60">👑 {premDays}k</span>}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[9px] font-mono" style={{ color: isOnline ? "#4ade80" : "#475569" }}>
                              {isOnline ? "🟢 Online" : "⚫ Offline"}
                            </span>
                            <span className="text-[9px] text-amber-600 font-mono">⭐ {stars}</span>
                          </div>
                        </div>
                        <div className="flex gap-1 flex-wrap justify-end">
                          {!isBanned
                            ? <button onClick={() => banUser(uKey, "", 0)} className="admin-btn bg-rose-950/30 text-rose-400 border-rose-900/50 hover:bg-rose-900/40">⛔ Ban</button>
                            : <button onClick={() => unbanUser(uKey)} className="admin-btn bg-green-950/30 text-green-400 border-green-900/50 hover:bg-green-900/40">✅ Unban</button>
                          }
                          {!isAdm
                            ? <button onClick={() => { set(ref(db, `admins/${uKey}`), true); log(`🛡️ @${uKey} admin qilindi`, "ok"); }} className="admin-btn bg-amber-950/30 text-amber-400 border-amber-900/50 hover:bg-amber-900/30">🛡️ Admin</button>
                            : <button onClick={() => { remove(ref(db, `admins/${uKey}`)); log(`@${uKey} admin olib tashlandi`, "warn"); }} className="admin-btn bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700">Demote</button>
                          }
                          {!isPrem
                            ? <button onClick={() => grantPremium(null, uKey, 1, "1 Oy")} className="admin-btn bg-purple-950/30 text-purple-400 border-purple-900/50 hover:bg-purple-900/30">👑 Premium</button>
                            : <button onClick={() => revokePremium(uKey)} className="admin-btn bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700">Revoke</button>
                          }
                          <button onClick={() => grantStars(uKey, 100)} className="admin-btn bg-amber-950/20 text-amber-500 border-amber-900/40 hover:bg-amber-900/20">⭐+100</button>
                          <button onClick={() => { push(ref(db, `system_pushes/${uKey}`), { type: "glitch", ts: Date.now() }); log(`💥 Glitch → @${uKey}`); }} className="admin-btn bg-purple-950/20 text-purple-400 border-purple-900/40">💥</button>
                        </div>
                      </div>
                    );
                  })}
                  {filteredUsers.length === 0 && (
                    <div className="text-center py-12 text-slate-600">
                      <p className="text-3xl mb-2">🔍</p>
                      <p className="text-sm">Foydalanuvchi topilmadi</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── ANALYTICS ── */}
            {tab === "analytics" && (
              <div className="space-y-5">
                <h2 className="text-lg font-black text-white">📈 Analitika</h2>
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                  {[
                    { label: "Jami foydalanuvchi", val: allUsers.length, icon: "👥", c: "#22d3ee" },
                    { label: "Online hozir", val: onlineCount, icon: "🟢", c: "#4ade80" },
                    { label: "Admin", val: adminList.length, icon: "🛡️", c: "#f59e0b" },
                    { label: "Bloklangan", val: bannedList.length, icon: "⛔", c: "#f43f5e" },
                    { label: "Premium", val: premiumCount, icon: "👑", c: "#a855f7" },
                    { label: "Jami yulduzlar", val: totalStars, icon: "⭐", c: "#fbbf24" },
                    { label: "Kanallar", val: channels.length, icon: "📡", c: "#0ea5e9" },
                    { label: "Global xabarlar", val: globalMessages.length, icon: "💬", c: "#6366f1" },
                    { label: "Musiqa trek", val: tracks.length, icon: "🎵", c: "#14b8a6" },
                  ].map(s => (
                    <div key={s.label} className="admin-card">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-2xl">{s.icon}</span>
                        <span className="text-2xl font-black tabular-nums" style={{ color: s.c }}>{s.val.toLocaleString()}</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{s.label}</p>
                      <div className="mt-2 h-1 rounded-full bg-slate-800/80 overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${Math.min(100, (s.val / Math.max(allUsers.length, 1)) * 100)}%`, background: s.c }} />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-amber-400">🏆 Yulduz reytingi (Top 15)</p>
                  <div className="space-y-1.5">
                    {Object.entries(starBalances).sort((a, b) => b[1] - a[1]).slice(0, 15).map(([u, bal], i) => (
                      <div key={u} className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/40 border border-slate-800/60 fade-row">
                        <span className="text-xs font-black w-5 text-center" style={{ color: i === 0 ? "#fbbf24" : i === 1 ? "#94a3b8" : i === 2 ? "#f97316" : "#475569" }}>
                          {i + 1}
                        </span>
                        <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                          style={{ background: `linear-gradient(135deg,${i === 0 ? "#f59e0b,#ef4444" : i === 1 ? "#94a3b8,#64748b" : i === 2 ? "#f97316,#ef4444" : "#334155,#1e293b"})` }}>
                          {u[0]?.toUpperCase()}
                        </div>
                        <span className="flex-1 text-xs font-semibold text-slate-300">@{u}</span>
                        <div className="flex items-center gap-1.5">
                          <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden w-20 hidden sm:block">
                            <div className="h-full rounded-full bg-amber-400" style={{ width: `${Math.min(100, (bal / (Object.values(starBalances).sort((a, b) => b - a)[0] || 1)) * 100)}%` }} />
                          </div>
                          <span className="text-xs font-bold text-amber-400">⭐ {bal.toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── ACTIVITY FEED ── */}
            {tab === "activity" && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-black text-white">⚡ Real-vaqt Faollik</h2>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 live-dot" />
                    <span className="text-[10px] font-mono text-green-400">LIVE</span>
                  </div>
                </div>
                <div className="space-y-1.5">
                  {activityFeed.map(a => {
                    const icon = a.icon || "⚡";
                    const typeColor: Record<string, string> = { join: "#4ade80", message: "#22d3ee", game: "#f59e0b", star: "#fbbf24", call: "#a855f7" };
                    const color = typeColor[a.type] || "#64748b";
                    return (
                      <div key={a.id} className="flex items-center gap-3 p-3 rounded-xl border border-slate-800/60 bg-slate-900/30 fade-row hover:border-slate-700/60 transition">
                        <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-base"
                          style={{ background: `${color}18` }}>
                          {icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-slate-200">{a.text}</p>
                          <p className="text-[9px] text-slate-600 font-mono mt-0.5">
                            {a.username ? `@${a.username} · ` : ""}
                            {a.ts ? new Date(a.ts).toLocaleString("uz-UZ") : ""}
                          </p>
                        </div>
                        <span className="text-[8px] font-bold px-2 py-0.5 rounded-full flex-shrink-0"
                          style={{ background: `${color}20`, color }}>
                          {a.type || "event"}
                        </span>
                      </div>
                    );
                  })}
                  {activityFeed.length === 0 && (
                    <div className="text-center py-16 text-slate-600">
                      <p className="text-4xl mb-3">⚡</p>
                      <p className="text-sm">Faollik ma'lumotlari yo'q</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── BROADCAST ── */}
            {tab === "broadcast" && (
              <div className="space-y-4 max-w-2xl">
                <h2 className="text-lg font-black text-white">📢 Broadcast</h2>
                <div className="flex gap-2">
                  {(["channel","mass","push"] as const).map(t => (
                    <button key={t} onClick={() => setBroadcastType(t)}
                      className="admin-btn flex-1"
                      style={broadcastType === t ? { background: "#3b82f620", color: "#60a5fa", borderColor: "#3b82f640" } : { background: "rgba(15,23,42,0.5)", color: "#64748b", borderColor: "rgba(148,163,184,0.1)" }}>
                      {t === "channel" ? "📡 Kanal" : t === "mass" ? `📣 Mass (${allUsers.length})` : "💉 Shaxsiy"}
                    </button>
                  ))}
                </div>

                {broadcastType !== "push" && (
                  <div className="admin-card space-y-3">
                    <p className="text-xs font-bold text-blue-400">{broadcastType === "channel" ? "📡 Global kanal xabari" : `📣 Barcha ${allUsers.length} ta foydalanuvchiga push`}</p>
                    <textarea value={broadcastMsg} onChange={e => setBroadcastMsg(e.target.value)} rows={4}
                      className="admin-input resize-none" placeholder="Xabar matni..." />
                    <button onClick={sendBroadcast} disabled={!broadcastMsg.trim()}
                      className="admin-btn w-full py-3 disabled:opacity-40"
                      style={{ background: "linear-gradient(135deg,#3b82f6,#6366f1)", color: "white", border: "none" }}>
                      {broadcastType === "channel" ? "📡 KANAL GA YUBORISH" : `📣 ${allUsers.length} TA FOYDALANUVCHIGA YUBORISH`}
                    </button>
                  </div>
                )}

                {broadcastType === "push" && (
                  <div className="admin-card space-y-3">
                    <p className="text-xs font-bold text-cyan-400">💉 Shaxsiy Push Notification</p>
                    <div className="flex gap-2">
                      <input value={pushUser} onChange={e => setPushUser(e.target.value)}
                        className="admin-input flex-1" placeholder="@username" />
                      <select value={pushEmoji} onChange={e => setPushEmoji(e.target.value)}
                        className="admin-input w-20 text-center">
                        {["📢","⚠️","🔔","🎉","💎","⭐","🚨","💬","🎮","🏆","❤️","🔥"].map(e => <option key={e}>{e}</option>)}
                      </select>
                    </div>
                    <textarea value={pushMsg} onChange={e => setPushMsg(e.target.value)} rows={3}
                      className="admin-input resize-none" placeholder="Shaxsiy xabar..." />
                    <button onClick={() => { const u = pushUser.replace("@","").toLowerCase(); if (!u||!pushMsg.trim()) return; push(ref(db, `system_pushes/${u}`), { msg: `${pushEmoji} ${pushMsg}`, from: "Admin", type: "msg", ts: Date.now() }); log(`💉 → @${u}: "${pushMsg}"`, "ok"); setPushUser(""); setPushMsg(""); }}
                      className="admin-btn w-full py-3" style={{ background: "linear-gradient(135deg,#0ea5e9,#22d3ee)", color: "white", border: "none" }}>
                      💉 YUBORISH
                    </button>
                  </div>
                )}

                <div className="admin-card space-y-3">
                  <p className="text-xs font-bold text-amber-400">⏰ Kechiktirilgan Broadcast</p>
                  <textarea value={scheduleMsg} onChange={e => setScheduleMsg(e.target.value)} rows={2}
                    className="admin-input resize-none" placeholder="Keyin yuboriladigan xabar..." />
                  <div className="flex gap-2 items-center">
                    <input type="number" value={scheduleDelay} onChange={e => setScheduleDelay(e.target.value)} min="1"
                      className="admin-input w-24 text-center" />
                    <span className="text-xs text-slate-400">soniya</span>
                    <button onClick={() => {
                      if (!scheduleMsg.trim()) return;
                      const d = parseInt(scheduleDelay);
                      log(`⏰ ${d}s keyin yuboriladi: "${scheduleMsg}"`, "info");
                      setTimeout(async () => {
                        await push(ref(db, "messages/global_max"), { sender: "Admin", text: `📢 ${scheduleMsg}`, type: "text", status: "sent", timestamp: serverTimestamp() });
                        log(`✅ Kechiktirilgan broadcast yuborildi`, "ok");
                      }, d * 1000);
                      setScheduleMsg("");
                    }} className="admin-btn flex-1 py-2.5" style={{ background: "#78350f50", color: "#f59e0b", borderColor: "#78350f" }}>
                      ⏰ REJALASHTIRISH
                    </button>
                  </div>
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-xs font-bold text-amber-400">📌 Tizim E'loni</p>
                  <div className="flex gap-2">
                    <input value={announcement} onChange={e => setAnnouncement(e.target.value)}
                      className="admin-input flex-1" placeholder="E'lon (bo'sh = o'chirish)" />
                    <button onClick={() => { set(ref(db, "system/announcement"), announcement || null); log(`📌 E'lon: "${announcement || "o'chirildi"}"`, "ok"); }}
                      className="admin-btn px-4 py-2.5" style={{ background: "#78350f40", color: "#f59e0b", borderColor: "#78350f" }}>
                      SET
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ── CHAT MONITOR ── */}
            {tab === "chat_monitor" && (
              <div className="space-y-4 max-w-2xl">
                <h2 className="text-lg font-black text-white">👁️ Chat Monitor</h2>
                <div className="admin-card space-y-3">
                  <p className="text-xs font-bold text-purple-400">👤 Foydalanuvchi suhbatini kuzatish</p>
                  <input value={monitorUser} onChange={e => setMonitorUser(e.target.value)}
                    className="admin-input" placeholder="@username..." />
                </div>
                {monitorUser && (
                  <div className="rounded-2xl overflow-hidden border border-purple-900/40">
                    <div className="px-4 py-2.5 flex items-center gap-2" style={{ background: "rgba(88,28,135,0.15)" }}>
                      <div className="w-2 h-2 rounded-full bg-purple-400 live-dot" />
                      <p className="text-[10px] font-mono font-bold text-purple-400">
                        MONITOR: @{username} ↔ @{monitorUser.replace("@","")}
                      </p>
                    </div>
                    <div className="p-4 space-y-2 max-h-72 overflow-y-auto bg-black/40">
                      {monitorMsgs.length === 0 && <p className="text-slate-600 text-xs font-mono text-center py-6">Xabar yo'q...</p>}
                      {monitorMsgs.map(m => (
                        <div key={m.id} className={`flex gap-2 ${m.sender === username ? "flex-row-reverse" : ""}`}>
                          <div className={`max-w-[75%] px-3 py-2 rounded-xl text-[11px] font-mono ${m.sender === username ? "bg-purple-950/80 text-purple-200" : "bg-slate-900 text-slate-300"}`}>
                            <p className="text-[8px] opacity-50 mb-0.5">@{m.sender}</p>
                            <p>{m.type === "image" ? "📷 [RASM]" : m.type === "voice" ? "🎙️ [AUDIO]" : m.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <div className="admin-card space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-slate-300">💬 Global Kanal (Real-time)</p>
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 live-dot" />
                      <span className="text-[9px] text-cyan-400 font-mono">LIVE</span>
                    </div>
                  </div>
                  <div className="max-h-72 overflow-y-auto space-y-1 pr-1">
                    {globalMessages.length === 0 && <p className="text-slate-600 text-xs text-center py-6">Xabar yo'q</p>}
                    {globalMessages.map(m => (
                      <div key={m.id} className="flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-slate-800/40 transition group fade-row">
                        <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-[11px] font-bold flex-shrink-0">
                          {m.sender?.[0]?.toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] font-bold text-cyan-400">@{m.sender} </span>
                          <span className="text-[10px] text-slate-400 font-mono">{m.timestamp ? new Date(m.timestamp).toLocaleTimeString("uz-UZ") : ""}</span>
                          <p className="text-xs text-slate-300 break-words mt-0.5">
                            {m.type === "image" ? "📷 Rasm" : m.type === "voice" ? "🎙️ Audio" : m.text}
                          </p>
                        </div>
                        <button onClick={() => { if (confirm("O'chirishni tasdiqlaysizmi?")) { remove(ref(db, `messages/global_max/${m.id}`)); log(`🗑️ Global xabar o'chirildi`, "warn"); } }}
                          className="opacity-0 group-hover:opacity-100 text-rose-500 hover:text-rose-400 transition text-xs p-1 rounded">🗑️</button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── BOTS ── */}
            {tab === "bots" && (
              <div className="space-y-4 max-w-2xl">
                <h2 className="text-lg font-black text-white">🤖 Bot Engine</h2>
                <div className="admin-card space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-green-400">Bot boshqaruvi</p>
                    <span className={`text-[9px] font-black px-3 py-1 rounded-full border ${botRunning ? "text-green-400 border-green-600 bg-green-950/30 animate-pulse" : "text-slate-600 border-slate-700"}`}>
                      {botRunning ? "● RUNNING" : "○ STOPPED"}
                    </span>
                  </div>
                  <input value={botName} onChange={e => setBotName(e.target.value)} className="admin-input" placeholder="Bot nomi" />
                  <textarea value={botMsg} onChange={e => setBotMsg(e.target.value)} rows={3}
                    className="admin-input resize-none" placeholder="Bot xabari (har {N} soniyada yuboriladi)..." />
                  <div className="flex items-center gap-3">
                    <label className="text-xs text-slate-400">Interval:</label>
                    <input type="number" value={botDelay} onChange={e => setBotDelay(e.target.value)} min="1"
                      className="admin-input w-24 text-center" />
                    <span className="text-xs text-slate-500">soniya</span>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={startBot}
                      className="admin-btn flex-1 py-3"
                      style={botRunning ? { background: "#7f1d1d50", color: "#fca5a5", borderColor: "#7f1d1d" } : { background: "#14532d50", color: "#86efac", borderColor: "#14532d" }}>
                      {botRunning ? "⏹️ TO'XTATISH" : "▶️ BOSHLASH"}
                    </button>
                    <button onClick={() => { if (!botMsg.trim()) return; push(ref(db, "messages/global_max"), { sender: botName, text: botMsg, type: "text", status: "sent", timestamp: serverTimestamp() }); log(`▶ Bot: bir martalik: "${botMsg}"`, "ok"); }}
                      className="admin-btn px-5 py-3" style={{ background: "rgba(30,41,59,0.8)", color: "#94a3b8", borderColor: "rgba(148,163,184,0.2)" }}>
                      ▶ Hozir
                    </button>
                  </div>
                </div>
                <div className="admin-card space-y-2">
                  <p className="text-xs font-bold text-slate-400">⚡ Tayyor presetlar</p>
                  {[
                    { label: "🔔 Ping", msg: "🔔 PING! Siz Nexus tizimida ekansiz.", delay: "3" },
                    { label: "📢 Reklama", msg: "📢 NEXUS_OS — Eng tez messenger! @Max", delay: "10" },
                    { label: "⚠️ Ogohlantirish", msg: "⚠️ DIQQAT: Tizimda texnik ishlar olib borilmoqda!", delay: "30" },
                    { label: "💪 Motivatsiya", msg: "💪 NEXUS foydalanuvchisi! Bugun ham kuchli bo'l!", delay: "60" },
                    { label: "👑 Premium promo", msg: "👑 PREMIUM obuna bilan ko'proq imtiyozlar olasiz! Hamyon → Premium", delay: "120" },
                    { label: "🎮 O'yin taklifi", msg: "🎮 Yangi o'yinlar qo'shildi! O'yinlar bo'limini ko'ring!", delay: "30" },
                  ].map(p => (
                    <button key={p.label} onClick={() => { setBotMsg(p.msg); setBotDelay(p.delay); }}
                      className="w-full text-left p-3 rounded-xl bg-slate-900/40 border border-slate-800/60 hover:border-slate-700/60 transition group">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-slate-200">{p.label}</p>
                        <span className="text-[9px] text-slate-600 font-mono group-hover:text-slate-400 transition">⏱ {p.delay}s</span>
                      </div>
                      <p className="text-[10px] text-slate-500 truncate mt-0.5">{p.msg}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ── PREMIUM ── */}
            {tab === "premium" && (
              <div className="space-y-5 max-w-2xl">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-black text-white">👑 Premium Boshqaruvi</h2>
                  {pendingPremium.length > 0 && <span className="text-[9px] font-black px-3 py-1.5 rounded-full border border-amber-800 bg-amber-950/30 text-amber-400 animate-pulse">{pendingPremium.length} yangi so'rov</span>}
                </div>

                {/* Pending requests */}
                {pendingPremium.length > 0 && (
                  <div className="space-y-3">
                    <p className="text-sm font-bold text-amber-400">⏳ Kutayotgan so'rovlar</p>
                    {pendingPremium.map(req => (
                      <div key={req.id} className="admin-card border-amber-900/40 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-bold text-slate-200">@{req.username}</p>
                              <span className="text-[8px] bg-amber-950/50 text-amber-400 px-2 py-0.5 rounded font-black border border-amber-900/60 animate-pulse">⏳ PENDING</span>
                            </div>
                            <p className="text-xs text-amber-300 font-bold mt-0.5">{req.label} — {req.priceUSD}</p>
                            <p className="text-[10px] text-slate-500 font-mono mt-0.5">{new Date(req.requestedAt).toLocaleString("uz-UZ")}</p>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className="text-lg font-black text-green-400">{req.priceUSD}</p>
                            <p className="text-[10px] text-slate-500">{req.months} oy</p>
                          </div>
                        </div>
                        {req.paymentNote && (
                          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60">
                            <p className="text-[9px] font-bold text-slate-500 mb-1">TO'LOV:</p>
                            <p className="text-xs text-slate-300">{req.paymentNote}</p>
                          </div>
                        )}
                        <input value={replyText[req.id] || ""} onChange={e => setReplyText(p => ({ ...p, [req.id]: e.target.value }))}
                          className="admin-input text-xs" placeholder="Admin javobi (ixtiyoriy)..." />
                        <div className="flex gap-2">
                          <button onClick={() => grantPremium(req.id, req.username, req.months, req.label, replyText[req.id])}
                            className="admin-btn flex-1 py-2.5" style={{ background: "linear-gradient(135deg,#16a34a,#15803d)", color: "white", border: "none" }}>
                            ✅ TASDIQLASH — {req.months} oy
                          </button>
                          <button onClick={() => denyRequest(req.id, req.username, replyText[req.id] || "")}
                            className="admin-btn flex-1 py-2.5" style={{ background: "#7f1d1d60", color: "#fca5a5", borderColor: "#7f1d1d" }}>
                            ❌ RAD ETISH
                          </button>
                        </div>
                        <div className="flex gap-1 pt-1 border-t border-slate-800/60">
                          <p className="text-[9px] text-slate-600 mr-1">Tezkor:</p>
                          {[1, 3, 6, 12].map(m => (
                            <button key={m} onClick={() => grantPremium(req.id, req.username, m, `${m} Oy`, "")}
                              className="admin-btn py-1 px-2" style={{ background: "#4c1d9520", color: "#c4b5fd", borderColor: "#4c1d95" }}>
                              {m} oy
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Manual grant */}
                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-purple-400">👑 Qo'lda Premium Berish</p>
                  <input value={targetUser} onChange={e => setTargetUser(e.target.value)}
                    className="admin-input" placeholder="@username" />
                  <div className="grid grid-cols-4 gap-2">
                    {[{ m: 1, p: "$3" }, { m: 3, p: "$7.8" }, { m: 6, p: "$14.7" }, { m: 12, p: "$88" }].map(({ m, p }) => (
                      <button key={m} onClick={() => { const u = getTarget(); if (!u) return; grantPremium(null, u, m, `${m} Oy`); }}
                        className="py-3 rounded-xl text-center transition hover:opacity-80"
                        style={{ background: "#4c1d9520", border: "1px solid #4c1d95", color: "#c4b5fd" }}>
                        <p className="text-sm font-black">{m} oy</p>
                        <p className="text-[9px] text-purple-700 mt-0.5">{p}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Active premium users */}
                <div className="admin-card space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-purple-400">💎 Aktiv Premium ({premiumCount})</p>
                  </div>
                  <div className="space-y-2">
                    {Object.entries(premiumUsers).filter(([, v]) => v?.expiresAt > Date.now()).map(([u, v]) => (
                      <div key={u} className="flex items-center gap-3 p-3 rounded-xl bg-purple-950/10 border border-purple-900/30 fade-row">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white"
                          style={{ background: "linear-gradient(135deg,#a855f7,#6366f1)" }}>
                          {u[0]?.toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-slate-200">@{u}</p>
                          <p className="text-[10px] text-purple-400 font-mono">{v.label} · {Math.ceil((v.expiresAt - Date.now()) / 86400000)} kun qoldi</p>
                        </div>
                        <button onClick={() => revokePremium(u)} className="admin-btn bg-slate-800/60 text-slate-400 border-slate-700">Bekor</button>
                      </div>
                    ))}
                    {premiumCount === 0 && <p className="text-slate-600 text-xs text-center py-6 font-mono">Premium foydalanuvchi yo'q</p>}
                  </div>
                </div>

                {/* History */}
                {premiumRequests.filter(r => r.status !== "pending").length > 0 && (
                  <div className="admin-card space-y-2">
                    <p className="text-sm font-bold text-slate-400">📋 Tarix</p>
                    {premiumRequests.filter(r => r.status !== "pending").slice(0, 10).map(req => (
                      <div key={req.id} className={`flex items-center gap-3 p-2.5 rounded-xl border ${req.status === "approved" ? "bg-green-950/10 border-green-900/30" : "bg-rose-950/10 border-rose-900/30"}`}>
                        <div className="flex-1">
                          <p className="text-xs font-bold text-slate-200">@{req.username} — {req.label}</p>
                          <p className="text-[9px] text-slate-600 font-mono">{new Date(req.requestedAt).toLocaleDateString()}</p>
                        </div>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded ${req.status === "approved" ? "bg-green-900/30 text-green-400" : "bg-rose-900/30 text-rose-400"}`}>
                          {req.status === "approved" ? "✅ OK" : "❌ RAD"}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ── STARS ── */}
            {tab === "stars" && (
              <div className="space-y-5 max-w-2xl">
                <h2 className="text-lg font-black text-white">⭐ Yulduz Boshqaruvi</h2>
                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-amber-400">⭐ Yulduz Berish</p>
                  <div className="flex gap-2">
                    <input value={grantStarUser} onChange={e => setGrantStarUser(e.target.value)}
                      className="admin-input flex-1" placeholder="@username" />
                    <input type="number" value={grantStarAmount} onChange={e => setGrantStarAmount(e.target.value)}
                      className="admin-input w-28 text-center" placeholder="Miqdor" />
                    <button onClick={() => { grantStars(grantStarUser.replace("@","").toLowerCase(), parseInt(grantStarAmount)); setGrantStarUser(""); }}
                      className="admin-btn px-4 py-2.5" style={{ background: "linear-gradient(135deg,#f59e0b,#ef4444)", color: "white", border: "none" }}>
                      ⭐ Yuborish
                    </button>
                  </div>
                  <div className="flex gap-2">
                    {[50, 100, 500, 1000, 5000].map(n => (
                      <button key={n} onClick={() => setGrantStarAmount(String(n))}
                        className="admin-btn flex-1 py-2 text-center text-amber-400 border-amber-900/40 bg-amber-950/20">
                        {n}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Star requests */}
                {starRequests.filter(r => r.status === "pending").length > 0 && (
                  <div className="admin-card space-y-3">
                    <p className="text-sm font-bold text-amber-400">⏳ Yulduz So'rovlari ({starRequests.filter(r => r.status === "pending").length})</p>
                    {starRequests.filter(r => r.status === "pending").map(req => (
                      <div key={req.id} className="p-3 rounded-xl bg-amber-950/10 border border-amber-900/40 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-bold text-slate-200">@{req.username}</p>
                            <p className="text-xs text-amber-400">⭐ {req.amount} yulduz so'ralmoqda</p>
                          </div>
                          <div className="flex gap-1.5">
                            <button onClick={async () => {
                              await grantStars(req.username, req.amount);
                              await update(ref(db, `star_requests/${req.id}`), { status: "approved" });
                            }} className="admin-btn bg-green-950/30 text-green-400 border-green-900/50">✅</button>
                            <button onClick={() => update(ref(db, `star_requests/${req.id}`), { status: "denied" })}
                              className="admin-btn bg-rose-950/30 text-rose-400 border-rose-900/50">❌</button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Balances */}
                <div className="admin-card space-y-2">
                  <p className="text-sm font-bold text-slate-400">💰 Yulduz Balanslari</p>
                  <p className="text-[10px] text-slate-600 font-mono">Jami: ⭐ {totalStars.toLocaleString()} yulduz tizimda</p>
                  <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                    {Object.entries(starBalances).sort((a, b) => b[1] - a[1]).map(([u, bal]) => (
                      <div key={u} className="flex items-center gap-2.5 p-2 rounded-lg bg-slate-900/40 hover:bg-slate-800/40 transition fade-row">
                        <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                          style={{ background: "linear-gradient(135deg,#334155,#1e293b)" }}>
                          {u[0]?.toUpperCase()}
                        </div>
                        <span className="flex-1 text-xs text-slate-400 font-mono">@{u}</span>
                        <div className="w-20 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                          <div className="h-full rounded-full bg-amber-400" style={{ width: `${Math.min(100, (bal / (Math.max(...Object.values(starBalances)) || 1)) * 100)}%` }} />
                        </div>
                        <span className="text-xs font-bold text-amber-400 w-16 text-right">⭐ {bal}</span>
                        <button onClick={() => {
                          const amt = parseInt(prompt(`@${u} dan necha yulduz olib qo'yish?`) || "0");
                          if (amt > 0) grantStars(u, -Math.abs(amt));
                        }} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-500 hover:text-rose-400 transition">−</button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── GIFTS ── */}
            {tab === "gifts" && (
              <div className="space-y-4 max-w-2xl">
                <h2 className="text-lg font-black text-white">🎁 Sovg'a Yuborish</h2>
                <div className="admin-card space-y-4">
                  <input value={giftTargetUser} onChange={e => setGiftTargetUser(e.target.value)}
                    className="admin-input" placeholder="@username" />
                  <div className="grid grid-cols-3 gap-2">
                    {GIFTS.map(g => (
                      <button key={g.id} onClick={() => setGiftSelected(g.id)}
                        className="p-3 rounded-xl border text-center transition"
                        style={giftSelected === g.id ? { background: g.gradient + "22", borderColor: "rgba(244,63,94,0.4)" } : { background: "rgba(15,23,42,0.5)", borderColor: "rgba(148,163,184,0.1)" }}>
                        <p className="text-2xl mb-1">{g.icon}</p>
                        <p className="text-[10px] font-bold text-slate-200">{g.name}</p>
                        <p className="text-[9px] text-amber-400 font-mono">⭐ {g.price}</p>
                      </button>
                    ))}
                  </div>
                  <textarea value={giftMessage} onChange={e => setGiftMessage(e.target.value)} rows={2}
                    className="admin-input resize-none" placeholder="Izoh (ixtiyoriy)..." />
                  <button onClick={() => { sendGift(giftTargetUser.replace("@","").toLowerCase(), giftSelected, giftMessage); setGiftTargetUser(""); setGiftMessage(""); }}
                    disabled={!giftTargetUser.trim()}
                    className="admin-btn w-full py-3 disabled:opacity-40"
                    style={{ background: "linear-gradient(135deg,#ec4899,#f43f5e)", color: "white", border: "none" }}>
                    🎁 SOVG'A YUBORISH
                  </button>
                </div>

                {/* Gift history */}
                <div className="admin-card space-y-2">
                  <p className="text-sm font-bold text-slate-400">📋 Sovg'a tarixi</p>
                  {allGifts.length === 0 && <p className="text-slate-600 text-xs text-center py-6 font-mono">Hali sovg'a yuborilmagan</p>}
                  {allGifts.slice(0, 20).map(g => {
                    const gift = getGift(g.giftId);
                    return (
                      <div key={g.id} className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/40 border border-slate-800/60 fade-row">
                        <span className="text-xl">{gift?.icon || "🎁"}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-slate-300">@{g.from} → @{g.user}</p>
                          <p className="text-[9px] text-slate-500 font-mono">{gift?.name} · {new Date(g.ts).toLocaleDateString()}</p>
                        </div>
                        <span className="text-[9px] text-amber-400 font-mono">⭐ {g.price}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── CHANNELS ── */}
            {tab === "channels" && (
              <div className="space-y-4 max-w-2xl">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-black text-white">📡 Kanallar va Guruhlar</h2>
                  <span className="text-xs text-slate-500 font-mono">{channels.length} ta</span>
                </div>
                {channels.length === 0 && (
                  <div className="text-center py-16 text-slate-600">
                    <p className="text-4xl mb-3">📡</p>
                    <p className="text-sm">Kanal yoki guruh yo'q</p>
                  </div>
                )}
                {channels.map(ch => (
                  <div key={ch.id} className="admin-card space-y-3 fade-row">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                        style={{ background: ch.data.type === "channel" ? "rgba(14,165,233,0.12)" : "rgba(99,102,241,0.12)" }}>
                        {ch.data.type === "channel" ? "📡" : "👥"}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-slate-200">{ch.data.name}</p>
                        <p className="text-xs text-slate-500 font-mono">@{ch.id} · {ch.data.type}</p>
                        <p className="text-[10px] text-slate-600">yaratdi: @{ch.data.createdBy || ch.data.owner}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-lg font-black text-slate-300">{Object.keys(ch.data.members || {}).length}</p>
                        <p className="text-[9px] text-slate-600">a'zo</p>
                      </div>
                    </div>
                    {ch.data.description && <p className="text-xs text-slate-500 italic px-1">"{ch.data.description}"</p>}
                    <div className="flex gap-2">
                      <button onClick={async () => {
                        const msg = prompt(`"${ch.data.name}" kanaliga xabar:`);
                        if (!msg?.trim()) return;
                        await push(ref(db, `channelMessages/${ch.id}`), { from: "Admin", text: `📢 ${msg.trim()}`, ts: Date.now() });
                        log(`📢 → ${ch.id}: "${msg}"`, "ok");
                      }} className="admin-btn flex-1 py-2" style={{ background: "rgba(14,165,233,0.1)", color: "#38bdf8", borderColor: "rgba(14,165,233,0.2)" }}>
                        📢 Xabar
                      </button>
                      <button onClick={async () => {
                        if (!confirm(`"${ch.data.name}" kanalini o'chirasizmi?`)) return;
                        await remove(ref(db, `channels/${ch.id}`));
                        await remove(ref(db, `channelMessages/${ch.id}`));
                        log(`🗑️ Kanal o'chirildi: ${ch.id}`, "warn");
                      }} className="admin-btn flex-1 py-2" style={{ background: "rgba(239,68,68,0.08)", color: "#f87171", borderColor: "rgba(239,68,68,0.2)" }}>
                        🗑️ O'chirish
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ── REPORTS ── */}
            {tab === "reports" && (
              <div className="space-y-4 max-w-2xl">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-black text-white">🚨 Shikoyatlar</h2>
                  {pendingReports.length > 0 && <span className="text-[9px] font-black px-3 py-1 rounded-full bg-rose-950/40 border border-rose-900 text-rose-400 animate-pulse">{pendingReports.length} yangi</span>}
                </div>
                {reports.length === 0 && (
                  <div className="text-center py-16 text-slate-600">
                    <p className="text-4xl mb-3">✅</p>
                    <p className="text-sm">Shikoyat yo'q</p>
                  </div>
                )}
                {reports.map(r => (
                  <div key={r.id} className={`admin-card fade-row ${r.status === "resolved" ? "border-green-900/30" : r.status === "dismissed" ? "opacity-50" : "border-rose-900/30"}`}
                    style={{ borderColor: r.status === "pending" ? "rgba(239,68,68,0.25)" : undefined }}>
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-slate-200">@{r.reportedUser}</p>
                          <span className={`text-[8px] font-black px-2 py-0.5 rounded-full border ${r.status === "resolved" ? "border-green-700 text-green-400" : r.status === "dismissed" ? "border-slate-700 text-slate-500" : "border-rose-700 text-rose-400 animate-pulse"}`}>
                            {r.status === "resolved" ? "✅ HAL" : r.status === "dismissed" ? "🚫 BEKOR" : "⏳ PENDING"}
                          </span>
                        </div>
                        <p className="text-xs text-rose-400 mt-1">Sabab: {r.reason}</p>
                        <p className="text-[10px] text-slate-500 font-mono mt-0.5">@{r.reportedBy} · {r.ts ? new Date(r.ts).toLocaleString("uz-UZ") : ""}</p>
                      </div>
                    </div>
                    {r.status === "pending" && (
                      <div className="flex gap-2">
                        <button onClick={async () => { await update(ref(db, `reports/${r.id}`), { status: "resolved" }); log(`✅ Shikoyat hal: @${r.reportedUser}`, "ok"); }}
                          className="admin-btn flex-1 py-2" style={{ background: "rgba(22,163,74,0.12)", color: "#86efac", borderColor: "rgba(22,163,74,0.3)" }}>
                          ✅ Hal qilindi
                        </button>
                        <button onClick={async () => {
                          const days = parseInt(prompt(`@${r.reportedUser} ni necha kun ban? (0=bekor)`) || "0");
                          if (days > 0) { await banUser(r.reportedUser, r.reason, days); await update(ref(db, `reports/${r.id}`), { status: "resolved", action: `ban_${days}d` }); }
                        }} className="admin-btn flex-1 py-2" style={{ background: "rgba(239,68,68,0.1)", color: "#f87171", borderColor: "rgba(239,68,68,0.25)" }}>
                          ⛔ Ban
                        </button>
                        <button onClick={() => update(ref(db, `reports/${r.id}`), { status: "dismissed" })}
                          className="admin-btn px-4 py-2 bg-slate-800/60 text-slate-500 border-slate-700">
                          🚫 Bekor
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* ── MUSIC ── */}
            {tab === "music" && (
              <div className="space-y-4 max-w-2xl">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-black text-white">🎵 Musiqa Kutubxonasi</h2>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-mono">{tracks.length} ta trek</span>
                    <button onClick={seedTracks} className="admin-btn py-1.5" style={{ background: "rgba(20,184,166,0.1)", color: "#2dd4bf", borderColor: "rgba(20,184,166,0.2)" }}>
                      📦 Standart treklarni yuklash
                    </button>
                  </div>
                </div>
                <div className="admin-card space-y-3">
                  <p className="text-xs font-bold text-teal-400">➕ Yangi Trek</p>
                  <div className="grid grid-cols-2 gap-2">
                    <input value={trackForm.title} onChange={e => setTrackForm(f => ({ ...f, title: e.target.value }))}
                      className="admin-input text-xs" placeholder="Sarlavha *" />
                    <input value={trackForm.artist} onChange={e => setTrackForm(f => ({ ...f, artist: e.target.value }))}
                      className="admin-input text-xs" placeholder="Ijrochi" />
                  </div>
                  <input value={trackForm.url} onChange={e => setTrackForm(f => ({ ...f, url: e.target.value }))}
                    className="admin-input text-xs" placeholder="MP3 URL *" />
                  <div className="grid grid-cols-3 gap-2">
                    <select value={trackForm.genre} onChange={e => setTrackForm(f => ({ ...f, genre: e.target.value }))}
                      className="admin-input text-xs">{GENRES.map(g => <option key={g}>{g}</option>)}</select>
                    <select value={trackForm.color} onChange={e => setTrackForm(f => ({ ...f, color: e.target.value }))}
                      className="admin-input text-xs">{COLORS.map(c => <option key={c} value={c}>{c}</option>)}</select>
                    <select value={trackForm.emoji} onChange={e => setTrackForm(f => ({ ...f, emoji: e.target.value }))}
                      className="admin-input text-xs">{EMOJIS.map(e => <option key={e}>{e}</option>)}</select>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: trackForm.color + "33" }}>
                      {trackForm.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-white truncate">{trackForm.title || "Sarlavha..."}</p>
                      <p className="text-[10px] text-slate-500">{trackForm.artist || "Ijrochi"} · {trackForm.genre}</p>
                    </div>
                    <button onClick={async () => {
                      if (!trackForm.title.trim() || !trackForm.url.trim()) return;
                      await push(ref(db, "music/tracks"), { ...trackForm, addedAt: Date.now(), order: tracks.length });
                      log(`🎵 "${trackForm.title}" qo'shildi`, "ok");
                      setTrackForm({ title: "", artist: "", url: "", emoji: "🎵", color: "#8b5cf6", genre: "Pop" });
                    }} disabled={!trackForm.title.trim() || !trackForm.url.trim()}
                      className="admin-btn px-5 py-2.5 disabled:opacity-40"
                      style={{ background: "linear-gradient(135deg,#14b8a6,#0ea5e9)", color: "white", border: "none" }}>
                      ➕ Qo'shish
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  {tracks.map((t, i) => (
                    <div key={t.id} className="flex items-center gap-3 p-3 rounded-2xl border border-slate-800/60 bg-slate-900/40 group fade-row hover:border-slate-700/60 transition">
                      <span className="text-slate-700 text-[10px] w-5 text-center font-mono">{i + 1}</span>
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0" style={{ background: (t.color || "#8b5cf6") + "33" }}>
                        {t.emoji || "🎵"}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-white truncate">{t.title}</p>
                        <p className="text-[10px] truncate"><span className="text-slate-500">{t.artist}</span> · <span style={{ color: t.color }}>{t.genre}</span></p>
                      </div>
                      <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition flex-shrink-0">
                        <button onClick={() => toggleTrackTest(t.id, t.url)}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs transition ${playingId === t.id ? "bg-green-800/60 text-green-300 animate-pulse" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}>
                          {playingId === t.id ? "⏸" : "▶"}
                        </button>
                        <button onClick={() => { if (confirm(`"${t.title}" o'chirilsin?`)) { remove(ref(db, `music/tracks/${t.id}`)); log(`🗑️ "${t.title}" o'chirildi`, "warn"); } }}
                          className="w-7 h-7 rounded-lg bg-rose-950/30 border border-rose-900/50 text-rose-400 flex items-center justify-center text-xs hover:bg-rose-900/40 transition">
                          🗑️
                        </button>
                      </div>
                    </div>
                  ))}
                  {tracks.length === 0 && (
                    <div className="text-center py-12 text-slate-600">
                      <p className="text-4xl mb-2">🎵</p>
                      <p className="text-sm">Trek yo'q. Standart treklarni yuklab boshlang!</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── SECURITY ── */}
            {tab === "security" && (
              <div className="space-y-5 max-w-2xl">
                <h2 className="text-lg font-black text-white">🛡️ Xavfsizlik</h2>
                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-rose-400">⛔ Tezkor Ban</p>
                  <div className="flex gap-2">
                    <input value={quickBanUser} onChange={e => setQuickBanUser(e.target.value)}
                      className="admin-input flex-1" placeholder="@username" />
                    <input value={banReason} onChange={e => setBanReason(e.target.value)}
                      className="admin-input flex-1" placeholder="Sabab..." />
                    <input type="number" value={banDays} onChange={e => setBanDays(e.target.value)}
                      className="admin-input w-20 text-center" placeholder="Kun (0=muddatsiz)" />
                    <button onClick={() => { const u = quickBanUser.replace("@","").toLowerCase(); if (!u) return; banUser(u, banReason, parseInt(banDays)); setQuickBanUser(""); setBanReason(""); }}
                      className="admin-btn px-4 py-2.5" style={{ background: "rgba(239,68,68,0.15)", color: "#f87171", borderColor: "rgba(239,68,68,0.3)" }}>
                      ⛔ Ban
                    </button>
                  </div>
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-orange-400">🚫 So'z filtri (spam bloker)</p>
                  <textarea value={wordFilter} onChange={e => setWordFilter(e.target.value)} rows={3}
                    className="admin-input resize-none" placeholder="Vergul bilan ajrating: spam,reklama,hate..." />
                  <button onClick={() => { localStorage.setItem("nexus_word_filter", wordFilter); log(`🚫 So'z filtri yangilandi`, "ok"); }}
                    className="admin-btn py-2.5" style={{ background: "rgba(249,115,22,0.1)", color: "#fdba74", borderColor: "rgba(249,115,22,0.2)" }}>
                    💾 Saqlash
                  </button>
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-rose-400">🛑 Bloklangan foydalanuvchilar ({bannedList.length})</p>
                  {bannedList.length === 0 && <p className="text-slate-600 text-xs font-mono text-center py-4">Hech kim ban qilinmagan</p>}
                  <div className="space-y-1.5">
                    {bannedList.map(u => {
                      const banData = typeof (statusMap[u] as any)?.ban === "object" ? (statusMap[u] as any).ban : null;
                      return (
                        <div key={u} className="flex items-center gap-2.5 p-2.5 rounded-xl bg-rose-950/10 border border-rose-900/30 fade-row">
                          <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 bg-rose-900/50">
                            {u[0]?.toUpperCase()}
                          </div>
                          <span className="flex-1 text-xs font-semibold text-rose-300">@{u}</span>
                          {banData?.until && <span className="text-[9px] text-rose-500 font-mono">{Math.ceil((banData.until - Date.now()) / 86400000)} kun</span>}
                          <button onClick={() => unbanUser(u)} className="admin-btn py-1 px-2.5 text-green-400 border-green-900/50 bg-green-950/20">✅ Unban</button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-amber-400">🔊 Siren / Ogohlantirish</p>
                  <button onClick={() => { if (sirenOn) { stopSiren(); setSirenOn(false); log("🔕 Siren o'chirildi", "warn"); } else { startSiren(); setSirenOn(true); log("🚨 Siren yoqildi!", "warn"); } }}
                    className={`admin-btn w-full py-3 ${sirenOn ? "animate-pulse" : ""}`}
                    style={sirenOn ? { background: "rgba(239,68,68,0.2)", color: "#f87171", borderColor: "#dc2626" } : { background: "rgba(245,158,11,0.1)", color: "#fbbf24", borderColor: "rgba(245,158,11,0.2)" }}>
                    {sirenOn ? "🔕 Sireni o'chirish" : "🚨 Sireni yoqish"}
                  </button>
                </div>
              </div>
            )}

            {/* ── SYSTEM ── */}
            {tab === "system" && (
              <div className="space-y-5 max-w-2xl">
                <h2 className="text-lg font-black text-white">⚙️ Tizim Boshqaruvi</h2>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: "maintenance", icon: "🚧", label: "Maintenance Mode", desc: "Foydalanuvchilarga texnik ish ekrani", color: "#f59e0b", val: maintenanceMode, set: (v: boolean) => { set(ref(db, "system/maintenance"), v); log(`🚧 Maintenance: ${v}`, "warn"); } },
                    { key: "lockdown", icon: "🔒", label: "Lockdown", desc: "Yangi kirish va yozishni bloklashtirish", color: "#ef4444", val: lockdown, set: (v: boolean) => { set(ref(db, "system/lockdown"), v); log(`🔒 Lockdown: ${v}`, "warn"); } },
                    { key: "slow_mode", icon: "🐢", label: "Slow Mode", desc: "Xabar yuborishni sekinlashtirish", color: "#f97316", val: slowMode, set: (v: boolean) => { set(ref(db, "system/slow_mode"), v); log(`🐢 Slow mode: ${v}`); } },
                    { key: "ghost", icon: "👻", label: "Ghost Mode", desc: "Admin ko'rinmas bo'ladi", color: "#a855f7", val: ghost, set: (v: boolean) => { setGhost(v); log(`👻 Ghost: ${v}`); } },
                    { key: "red", icon: "🔴", label: "Red Alert", desc: "Interfeys qizil rangga o'tadi", color: "#dc2626", val: redTheme, set: (v: boolean) => { setRedTheme(v); if (v) set(ref(db, "system/theme_override"), "red"); else remove(ref(db, "system/theme_override")); log(`🔴 Red alert: ${v}`, "warn"); } },
                    { key: "jam", icon: "📶", label: "Signal Jammer", desc: "Barcha ulanishlarni to'xtatish", color: "#6366f1", val: jammed, set: (v: boolean) => { setJammed(v); set(ref(db, "system/jammed"), v); log(`📶 Jammed: ${v}`, "warn"); } },
                  ].map(s => (
                    <button key={s.key} onClick={() => s.set(!s.val)}
                      className="p-4 rounded-2xl border text-left transition"
                      style={s.val ? { background: `${s.color}10`, borderColor: `${s.color}35`, boxShadow: `0 0 20px ${s.color}15` } : { background: "rgba(15,23,42,0.5)", borderColor: "rgba(148,163,184,0.1)" }}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xl">{s.icon}</span>
                        <div className={`w-10 h-5 rounded-full relative transition-colors ${s.val ? "bg-green-500" : "bg-slate-700"}`}>
                          <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${s.val ? "left-5" : "left-0.5"}`} />
                        </div>
                      </div>
                      <p className="text-xs font-bold" style={{ color: s.val ? s.color : "#cbd5e1" }}>{s.label}</p>
                      <p className="text-[9px] text-slate-600 mt-0.5">{s.desc}</p>
                    </button>
                  ))}
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-rose-400">🔄 Tizim Buyruqlari</p>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={async () => { if (!confirm("Barcha foydalanuvchilarni qayta yuklatmoqchimisiz?")) return; await set(ref(db, "system/force_reboot"), Date.now()); log("🔄 Force reboot yuborildi!", "warn"); }}
                      className="admin-btn py-3" style={{ background: "rgba(99,102,241,0.1)", color: "#a5b4fc", borderColor: "rgba(99,102,241,0.2)" }}>
                      🔄 Force Reboot
                    </button>
                    <button onClick={async () => { if (!confirm("Barcha sessiyalarni o'chirib tizimdan chiqarmoqchimisiz?")) return; await set(ref(db, "system/force_logout"), Date.now()); log("🚪 Force logout!", "warn"); }}
                      className="admin-btn py-3" style={{ background: "rgba(245,158,11,0.1)", color: "#fbbf24", borderColor: "rgba(245,158,11,0.2)" }}>
                      🚪 Force Logout
                    </button>
                    <button onClick={() => { set(ref(db, "system/wipe_activity"), Date.now()); log("🧹 Faollik temi tozalandi", "warn"); }}
                      className="admin-btn py-3" style={{ background: "rgba(148,163,184,0.06)", color: "#94a3b8", borderColor: "rgba(148,163,184,0.12)" }}>
                      🧹 Faollik Tozalash
                    </button>
                    <button onClick={() => { if (!confirm("Barcha kalit ma'lumotlarni reset qilmoqchimisiz?")) return; set(ref(db, "system/emergency_reset"), Date.now()); log("🚨 Emergency reset!", "err"); }}
                      className="admin-btn py-3" style={{ background: "rgba(239,68,68,0.08)", color: "#fca5a5", borderColor: "rgba(239,68,68,0.15)" }}>
                      🚨 Emergency Reset
                    </button>
                  </div>
                </div>

                <div className="admin-card space-y-3">
                  <p className="text-sm font-bold text-slate-400">📊 Tizim holati</p>
                  {[
                    { label: "Maintenance",    val: maintenanceMode, color: "#f59e0b" },
                    { label: "Lockdown",       val: lockdown,        color: "#ef4444" },
                    { label: "Slow Mode",      val: slowMode,        color: "#f97316" },
                    { label: "Ghost Mode",     val: ghost,           color: "#a855f7" },
                    { label: "Red Alert",      val: redTheme,        color: "#dc2626" },
                    { label: "Signal Jammed",  val: jammed,          color: "#6366f1" },
                    { label: "Siren",          val: sirenOn,         color: "#ef4444" },
                  ].map(s => (
                    <div key={s.label} className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full flex-shrink-0 ${s.val ? "animate-pulse" : ""}`} style={{ background: s.val ? s.color : "#334155" }} />
                      <span className="text-xs text-slate-400 flex-1">{s.label}</span>
                      <span className="text-[10px] font-bold font-mono" style={{ color: s.val ? s.color : "#475569" }}>
                        {s.val ? "ACTIVE" : "OFF"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* ══ LOGS PANEL ══ */}
      {showLogs && (
        <div className="flex-shrink-0 border-t border-slate-800/70 h-44 flex flex-col"
          style={{ background: "#020408" }}>
          <div className="flex items-center justify-between px-3 py-1.5 border-b border-slate-800/60 flex-shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 live-dot" />
              <p className="text-[9px] font-mono font-bold text-green-400">NEXUS ADMIN LOGS — LIVE</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setLogs([{ msg: `[CLEAR] Tozalandi — @${username}`, type: "ok", time: new Date().toLocaleTimeString() }])}
                className="text-[9px] text-slate-600 hover:text-slate-400 transition font-mono">CLEAR</button>
              <button onClick={() => setShowLogs(false)} className="text-[9px] text-slate-600 hover:text-slate-400 transition">✕</button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5 font-mono text-[10px]">
            {logs.map((l, i) => (
              <div key={i} className={`flex gap-2 items-start ${l.type === "err" ? "log-err" : l.type === "warn" ? "log-warn" : l.type === "ok" ? "log-ok" : "log-info"}`}>
                <span className="opacity-40 flex-shrink-0">{l.time}</span>
                <span>{l.msg}</span>
              </div>
            ))}
            <div ref={logsEndRef} />
          </div>
        </div>
      )}
    </div>
  );
}
