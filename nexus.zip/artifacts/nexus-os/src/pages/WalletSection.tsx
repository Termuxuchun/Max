import { useState, useEffect } from "react";
import { ref, set, get, push, onValue, increment, update } from "firebase/database";
import { db } from "../firebase";
import { useLang } from "../lib/LangContext";
import { Star, Send, Gift, TrendingUp, ArrowUpRight, ArrowDownLeft, Zap, Crown, Award, CheckCircle2, Target, CreditCard, Eye, EyeOff, Plus, Minus, RefreshCw, Lock, Wifi, Copy, Check, Sparkles, ShieldCheck, ChevronRight, X } from "lucide-react";

const DAILY_MISSIONS = [
  { id: "send_msg",    icon: "💬", label: "3 ta xabar yuboring",         desc: "Chat bo'limida xabar yuboring",        reward: 5  },
  { id: "post_story",  icon: "📸", label: "Hikoya qo'shing",              desc: "Holatlar bo'limida hikoya qo'shing",   reward: 10 },
  { id: "make_call",   icon: "📞", label: "Qo'ng'iroq qiling",            desc: "Audio yoki video qo'ng'iroq qiling",   reward: 8  },
  { id: "play_game",   icon: "🎮", label: "O'yin o'ynang",                desc: "O'yinlar bo'limida o'yin o'ynang",     reward: 7  },
  { id: "add_contact", icon: "👤", label: "Kontakt qo'shing",             desc: "Kontaktlar ro'yxatiga qo'shing",       reward: 5  },
  { id: "like_post",   icon: "❤️", label: "5 ta postga layk qo'ying",    desc: "Lenta yoki Holatlar bo'limida",        reward: 6  },
  { id: "send_stars",  icon: "⭐", label: "Kimgadir yulduz yuboring",     desc: "Hamyon → Yuborish bo'limidan",         reward: 12 },
];

interface Transaction {
  type: "send" | "receive" | "bonus" | "purchase";
  amount: number;
  from?: string;
  to?: string;
  note?: string;
  ts: number;
}

interface WalletSectionProps {
  username: string;
  accentColor: string;
  starsBalance: number;
}

const BONUS_AMOUNTS = [10, 15, 20, 25, 30, 50];
const DAILY_BONUS = 15;

// ── Virtual card helpers ─────────────────────────────────────────────────────
function seedRng(seed: number) {
  let s = seed;
  return () => { s = (s * 1664525 + 1013904223) & 0xffffffff; return (s >>> 0) / 0xffffffff; };
}

function genCardNumber(username: string): string {
  const rng = seedRng(username.split("").reduce((a, c) => a + c.charCodeAt(0), 0));
  return [0,1,2,3].map(() => String(Math.floor(rng() * 9000 + 1000))).join(" ");
}

function genCvv(username: string): string {
  const rng = seedRng(username.split("").reduce((a, c) => a * 31 + c.charCodeAt(0), 7));
  return String(Math.floor(rng() * 900 + 100));
}

function genExpiry(username: string): string {
  const rng = seedRng(username.split("").reduce((a, c) => a ^ c.charCodeAt(0), 42));
  const month = String(Math.floor(rng() * 12) + 1).padStart(2, "0");
  const year = String(2026 + Math.floor(rng() * 4));
  return `${month}/${year.slice(2)}`;
}

const CARD_GRADIENTS = [
  "linear-gradient(135deg,#1a1a2e 0%,#16213e 40%,#0f3460 100%)",
  "linear-gradient(135deg,#0d0d0d 0%,#1a0533 50%,#3d0066 100%)",
  "linear-gradient(135deg,#003049 0%,#023e8a 50%,#0077b6 100%)",
  "linear-gradient(135deg,#1b1b2f 0%,#162447 50%,#1f4068 100%)",
  "linear-gradient(135deg,#0a0a0a 0%,#1a1a1a 50%,#2d2d2d 100%)",
];

interface VirtualCard {
  id: string;
  label: string;
  balance: number;
  currency: string;
  gradientIdx: number;
  frozen: boolean;
  createdAt: number;
  transactions: CardTx[];
}

interface CardTx {
  id: string;
  type: "topup" | "withdraw" | "transfer";
  amount: number;
  note: string;
  ts: number;
}

// ── Component ────────────────────────────────────────────────────────────────
export default function WalletSection({ username, accentColor, starsBalance }: WalletSectionProps) {
  const { lang } = useLang();
  const [transactions, setTransactions] = useState<(Transaction & { id: string })[]>([]);
  const [sendTarget, setSendTarget] = useState("");
  const [sendAmount, setSendAmount] = useState("10");
  const [sendNote, setSendNote] = useState("");
  const [allUsers, setAllUsers] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState("");
  const [sendSuccess, setSendSuccess] = useState("");
  const [canBonus, setCanBonus] = useState(false);
  const [bonusCooldown, setBonusCooldown] = useState("");
  const [claiming, setClaiming] = useState(false);
  const [tab, setTab] = useState<"overview" | "send" | "history" | "leaderboard" | "missions" | "card">("overview");
  const [leaderboard, setLeaderboard] = useState<{ username: string; balance: number }[]>([]);
  const [bonusStreak, setBonusStreak] = useState(0);
  const [completedMissions, setCompletedMissions] = useState<Record<string, boolean>>({});
  const [claimingMission, setClaimingMission] = useState<string | null>(null);

  // ── Virtual card state ────────────────────────────────────────────────────
  const [cards, setCards] = useState<VirtualCard[]>([]);
  const [activeCardIdx, setActiveCardIdx] = useState(0);
  const [showCvv, setShowCvv] = useState(false);
  const [showCardNum, setShowCardNum] = useState(false);
  const [copied, setCopied] = useState<"num" | "cvv" | null>(null);
  const [cardAction, setCardAction] = useState<"topup" | "withdraw" | null>(null);
  const [cardAmount, setCardAmount] = useState("");
  const [cardNote, setCardNote] = useState("");
  const [cardActionLoading, setCardActionLoading] = useState(false);
  const [cardToast, setCardToast] = useState("");
  const [showNewCard, setShowNewCard] = useState(false);
  const [newCardLabel, setNewCardLabel] = useState("");
  const [newCardGrad, setNewCardGrad] = useState(0);
  const [creatingCard, setCreatingCard] = useState(false);

  const todayKey = new Date().toISOString().slice(0, 10);

  // ── Load cards from Firebase ──────────────────────────────────────────────
  useEffect(() => {
    return onValue(ref(db, `vcards/${username}`), snap => {
      if (!snap.exists()) { setCards([]); return; }
      const list: VirtualCard[] = [];
      snap.forEach(c => {
        const d = c.val();
        const txList: CardTx[] = [];
        if (d.transactions) {
          Object.entries(d.transactions as Record<string, CardTx>).forEach(([k, v]) => {
            txList.push({ ...v, id: k });
          });
          txList.sort((a, b) => b.ts - a.ts);
        }
        list.push({ id: c.key!, label: d.label, balance: d.balance || 0, currency: d.currency || "UZS", gradientIdx: d.gradientIdx || 0, frozen: !!d.frozen, createdAt: d.createdAt, transactions: txList });
      });
      list.sort((a, b) => a.createdAt - b.createdAt);
      setCards(list);
    });
  }, [username]);

  function showCardToast(msg: string) {
    setCardToast(msg);
    setTimeout(() => setCardToast(""), 2800);
  }

  function copyToClipboard(text: string, type: "num" | "cvv") {
    navigator.clipboard.writeText(text.replace(/\s/g, "")).catch(() => {});
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  }

  async function createCard() {
    if (!newCardLabel.trim()) return;
    if (cards.length >= 3) { showCardToast("⚠️ Maksimal 3 ta karta"); return; }
    setCreatingCard(true);
    const cardRef = await push(ref(db, `vcards/${username}`), {
      label: newCardLabel.trim(),
      balance: 0,
      currency: "UZS",
      gradientIdx: newCardGrad,
      frozen: false,
      createdAt: Date.now(),
      transactions: {},
    });
    setCreatingCard(false);
    setShowNewCard(false);
    setNewCardLabel("");
    setActiveCardIdx(cards.length);
    showCardToast("✅ Virtual karta yaratildi!");
  }

  async function doCardAction() {
    const card = cards[activeCardIdx];
    if (!card || card.frozen) { showCardToast("🔒 Karta muzlatilgan"); return; }
    const amt = parseFloat(cardAmount.replace(",", "."));
    if (!amt || isNaN(amt) || amt <= 0) { showCardToast("⚠️ Miqdorni kiriting"); return; }
    if (cardAction === "withdraw" && amt > card.balance) { showCardToast("⚠️ Balansda yetarli mablag' yo'q"); return; }
    setCardActionLoading(true);
    const delta = cardAction === "topup" ? amt : -amt;
    const txType = cardAction === "topup" ? "topup" : "withdraw";
    await update(ref(db, `vcards/${username}/${card.id}`), { balance: card.balance + delta });
    await push(ref(db, `vcards/${username}/${card.id}/transactions`), {
      type: txType,
      amount: delta,
      note: cardNote.trim() || (cardAction === "topup" ? "Hisob to'ldirish" : "Pul chiqarish"),
      ts: Date.now(),
    });
    setCardActionLoading(false);
    setCardAction(null);
    setCardAmount("");
    setCardNote("");
    showCardToast(cardAction === "topup" ? `✅ +${amt.toLocaleString()} UZS qo'shildi` : `✅ -${amt.toLocaleString()} UZS chiqarildi`);
  }

  async function toggleFreeze() {
    const card = cards[activeCardIdx];
    if (!card) return;
    await update(ref(db, `vcards/${username}/${card.id}`), { frozen: !card.frozen });
    showCardToast(card.frozen ? "✅ Karta faollashtirildi" : "🔒 Karta muzlatildi");
  }

  async function deleteCard() {
    const card = cards[activeCardIdx];
    if (!card) return;
    if (!confirm(`"${card.label}" kartani o'chirishni tasdiqlaysizmi?`)) return;
    await update(ref(db, `vcards/${username}/${card.id}`), null as any);
    setActiveCardIdx(Math.max(0, activeCardIdx - 1));
    showCardToast("🗑️ Karta o'chirildi");
  }

  useEffect(() => {
    return onValue(ref(db, `missions/${username}/${todayKey}`), snap => {
      if (!snap.exists()) { setCompletedMissions({}); return; }
      setCompletedMissions(snap.val());
    });
  }, [username, todayKey]);

  async function claimMission(id: string, reward: number) {
    if (completedMissions[id] || claimingMission) return;
    setClaimingMission(id);
    const snap = await get(ref(db, `stars/${username}`));
    const bal = snap.val()?.balance || 0;
    await update(ref(db, `stars/${username}`), { balance: bal + reward });
    await push(ref(db, `stars_log/${username}`), { type: "bonus", amount: reward, note: `Kunlik vazifa: ${DAILY_MISSIONS.find(m => m.id === id)?.label}`, ts: Date.now() });
    await set(ref(db, `missions/${username}/${todayKey}/${id}`), true);
    setClaimingMission(null);
  }

  useEffect(() => {
    return onValue(ref(db, `stars_log/${username}`), snap => {
      if (!snap.exists()) { setTransactions([]); return; }
      const list: (Transaction & { id: string })[] = [];
      snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => b.ts - a.ts);
      setTransactions(list);
    });
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, "users"), snap => {
      if (!snap.exists()) return;
      const list: string[] = [];
      snap.forEach(c => { if (c.key !== username) list.push(c.key!); });
      setAllUsers(list);
    });
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, "stars"), snap => {
      if (!snap.exists()) return;
      const list: { username: string; balance: number }[] = [];
      snap.forEach(c => { const d = c.val(); if (d?.balance > 0) list.push({ username: c.key!, balance: d.balance }); });
      list.sort((a, b) => b.balance - a.balance);
      setLeaderboard(list.slice(0, 10));
    });
  }, []);

  useEffect(() => {
    checkBonus();
  }, [username]);

  async function checkBonus() {
    const snap = await get(ref(db, `stars/${username}`));
    const data = snap.val();
    const last = data?.lastBonus || 0;
    const streak = data?.streak || 0;
    setBonusStreak(streak);
    const elapsed = Date.now() - last;
    if (elapsed >= 24 * 60 * 60 * 1000) {
      setCanBonus(true);
    } else {
      setCanBonus(false);
      const rem = 24 * 60 * 60 * 1000 - elapsed;
      const h = Math.floor(rem / 3600000);
      const m = Math.floor((rem % 3600000) / 60000);
      setBonusCooldown(`${h}s ${m}d`);
    }
  }

  async function claimBonus() {
    if (!canBonus || claiming) return;
    setClaiming(true);
    const snap = await get(ref(db, `stars/${username}`));
    const data = snap.val() || {};
    const streak = (data.streak || 0) + 1;
    const bonus = DAILY_BONUS + Math.min(streak - 1, 6) * 5;
    await update(ref(db, `stars/${username}`), {
      balance: (data.balance || 0) + bonus,
      lastBonus: Date.now(),
      streak,
    });
    await push(ref(db, `stars_log/${username}`), {
      type: "bonus",
      amount: bonus,
      note: `Kunlik bonus (${streak}-kun seriyasi)`,
      ts: Date.now(),
    });
    setCanBonus(false);
    setBonusStreak(streak);
    setClaiming(false);
    checkBonus();
  }

  async function sendStars() {
    const amt = parseInt(sendAmount);
    if (!sendTarget || isNaN(amt) || amt <= 0) { setSendError("Ma'lumotlarni to'ldiring"); return; }
    if (amt > starsBalance) { setSendError("Yetarli yulduz yo'q"); return; }
    if (sendTarget === username) { setSendError("O'zingizga yubora olmaysiz"); return; }
    setSending(true); setSendError(""); setSendSuccess("");
    const targetSnap = await get(ref(db, `users/${sendTarget}`));
    if (!targetSnap.exists()) { setSendError("Bunday foydalanuvchi topilmadi"); setSending(false); return; }
    // Deduct
    await update(ref(db, `stars/${username}`), { balance: increment(-amt) });
    await push(ref(db, `stars_log/${username}`), { type: "send", amount: -amt, to: sendTarget, note: sendNote || "Yulduz yuborish", ts: Date.now() });
    // Add to receiver
    const recvSnap = await get(ref(db, `stars/${sendTarget}`));
    const recvBal = recvSnap.val()?.balance || 0;
    await update(ref(db, `stars/${sendTarget}`), { balance: recvBal + amt });
    await push(ref(db, `stars_log/${sendTarget}`), { type: "receive", amount: amt, from: username, note: sendNote || "Yulduz olindi", ts: Date.now() });
    setSendSuccess(`✅ @${sendTarget} ga ${amt}⭐ yuborildi!`);
    setSendTarget(""); setSendAmount("10"); setSendNote("");
    setSending(false);
  }

  function txIcon(type: string) {
    if (type === "receive" || type === "bonus") return <ArrowDownLeft className="w-4 h-4 text-green-400" />;
    if (type === "send") return <ArrowUpRight className="w-4 h-4 text-rose-400" />;
    return <Star className="w-4 h-4 text-amber-400" />;
  }

  function txColor(type: string) {
    if (type === "receive" || type === "bonus") return "text-green-400";
    return "text-rose-400";
  }

  function timeSince(ts: number) {
    const d = Date.now() - ts;
    if (d < 60000) return "hozir";
    if (d < 3600000) return `${Math.floor(d / 60000)}d oldin`;
    if (d < 86400000) return `${Math.floor(d / 3600000)}s oldin`;
    return `${Math.floor(d / 86400000)}kun`;
  }

  const sent = transactions.filter(t => t.amount < 0).reduce((a, t) => a + Math.abs(t.amount), 0);
  const received = transactions.filter(t => t.amount > 0).reduce((a, t) => a + t.amount, 0);

  const activeCard = cards[activeCardIdx] ?? null;
  const cardNumber = activeCard ? genCardNumber(username + activeCard.id) : "";
  const cardCvv = activeCard ? genCvv(username + activeCard.id) : "";
  const cardExpiry = activeCard ? genExpiry(username + activeCard.id) : "";
  const maskedNum = cardNumber.replace(/(\d{4} \d{4} \d{4}) (\d{4})/, "•••• •••• •••• $2");

  function fmtAmt(n: number) {
    return Math.abs(n).toLocaleString("uz-UZ") + " UZS";
  }
  function timeSinceCard(ts: number) {
    const d = Date.now() - ts;
    if (d < 60000) return "hozir";
    if (d < 3600000) return `${Math.floor(d / 60000)}d oldin`;
    if (d < 86400000) return `${Math.floor(d / 3600000)}s oldin`;
    return `${Math.floor(d / 86400000)}kun`;
  }

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 page-enter overflow-hidden">

      {/* ── Hero Card ── */}
      <div className="px-4 pt-5 pb-4 flex-shrink-0">
        <div className="relative rounded-3xl overflow-hidden p-6"
          style={{ background: `linear-gradient(135deg, #451a03, #78350f, #92400e)` }}>
          <div className="absolute inset-0 card-shimmer" />
          <div className="relative">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-amber-400/70 text-xs font-bold uppercase tracking-widest">Yulduz Hamyon</p>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-5xl font-black text-amber-300">{starsBalance.toLocaleString()}</span>
                  <span className="text-amber-500 font-bold text-xl">⭐</span>
                </div>
                <p className="text-amber-600 text-xs mt-1">@{username}</p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-amber-900/50 flex items-center justify-center border border-amber-700/40">
                <Star className="w-8 h-8 text-amber-400" fill="currentColor" />
              </div>
            </div>
            <div className="flex gap-4 mt-4 pt-4 border-t border-amber-800/40">
              <div>
                <p className="text-amber-600 text-[10px]">Yuborildi</p>
                <p className="text-amber-300 font-bold text-sm">-{sent}⭐</p>
              </div>
              <div>
                <p className="text-amber-600 text-[10px]">Qabul qilindi</p>
                <p className="text-amber-300 font-bold text-sm">+{received}⭐</p>
              </div>
              <div>
                <p className="text-amber-600 text-[10px]">Seriya</p>
                <p className="text-amber-300 font-bold text-sm">🔥 {bonusStreak} kun</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Daily Bonus ── */}
      {canBonus && (
        <div className="px-4 pb-3 flex-shrink-0">
          <button onClick={claimBonus} disabled={claiming}
            className="w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] drop-in"
            style={{ background: `linear-gradient(135deg, ${accentColor}33, #6366f133)`, border: `1px solid ${accentColor}55`, color: accentColor }}>
            <Zap className="w-4 h-4" />
            {claiming ? "Olinmoqda..." : `Kunlik bonus olish · +${DAILY_BONUS + Math.min(bonusStreak, 6) * 5}⭐`}
            <span className="text-[10px] bg-current/20 px-2 py-0.5 rounded-full text-white">{bonusStreak + 1}-kun</span>
          </button>
        </div>
      )}

      {/* ── Tabs ── */}
      <div className="px-4 pb-3 flex-shrink-0 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
        <div className="flex gap-1 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60 min-w-max">
          {([
            { key: "overview",    label: "Asosiy",   icon: <TrendingUp className="w-3 h-3" /> },
            { key: "card",        label: "Karta",    icon: <CreditCard className="w-3 h-3" /> },
            { key: "missions",    label: "Vazifalar", icon: <Target className="w-3 h-3" /> },
            { key: "send",        label: "Yuborish",  icon: <Send className="w-3 h-3" /> },
            { key: "history",     label: "Tarix",     icon: <Star className="w-3 h-3" /> },
            { key: "leaderboard", label: "Reyting",   icon: <Crown className="w-3 h-3" /> },
          ] as const).map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl font-bold text-[11px] transition whitespace-nowrap"
              style={tab === t.key ? { background: accentColor + "22", color: accentColor } : { color: "#64748b" }}>
              {t.icon}{t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Card Toast ── */}
      {cardToast && (
        <div className="mx-4 mb-2 py-2.5 px-4 rounded-xl text-sm font-bold text-white text-center flex-shrink-0"
          style={{ background: "rgba(15,23,42,0.95)", border: "1px solid rgba(255,255,255,0.1)" }}>
          {cardToast}
        </div>
      )}

      {/* ── Tab Content ── */}
      <div className="flex-1 overflow-y-auto px-4 pb-6">

        {/* ────── VIRTUAL CARD TAB ────── */}
        {tab === "card" && (
          <div className="space-y-4 tab-slide-in">

            {/* Card carousel */}
            {cards.length === 0 ? (
              /* Empty state */
              <div className="flex flex-col items-center justify-center py-12 gap-5">
                <div className="w-24 h-24 rounded-3xl flex items-center justify-center"
                  style={{ background: `${accentColor}15`, border: `2px dashed ${accentColor}40` }}>
                  <CreditCard className="w-10 h-10" style={{ color: accentColor }} />
                </div>
                <div className="text-center">
                  <p className="text-base font-black text-slate-200">Virtual karta yo'q</p>
                  <p className="text-xs text-slate-500 mt-1">Birinchi virtual kartangizni yarating</p>
                </div>
                <button onClick={() => setShowNewCard(true)}
                  className="flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-sm transition active:scale-95"
                  style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, color: "#000" }}>
                  <Plus className="w-4 h-4" /> Karta yaratish
                </button>
              </div>
            ) : (
              <>
                {/* Swipeable card strip */}
                <div className="flex gap-3 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
                  {cards.map((card, i) => (
                    <div key={card.id}
                      onClick={() => setActiveCardIdx(i)}
                      className="flex-shrink-0 cursor-pointer transition-transform active:scale-[0.97]"
                      style={{ transform: activeCardIdx === i ? "scale(1)" : "scale(0.95)", opacity: activeCardIdx === i ? 1 : 0.5 }}>
                      {/* Mini card thumbnail */}
                      <div className="w-32 h-20 rounded-2xl flex flex-col justify-between p-3 relative overflow-hidden"
                        style={{ background: CARD_GRADIENTS[card.gradientIdx] }}>
                        <div className="absolute inset-0 opacity-20"
                          style={{ background: "radial-gradient(circle at 70% 30%, rgba(255,255,255,0.15), transparent 60%)" }} />
                        <p className="text-white/60 text-[9px] font-bold truncate">{card.label}</p>
                        <div>
                          <p className="text-white text-[10px] font-mono">•••• {genCardNumber(username + card.id).slice(-4)}</p>
                          {card.frozen && (
                            <span className="text-[8px] text-blue-300 font-bold">MUZLATILGAN</span>
                          )}
                        </div>
                        {activeCardIdx === i && (
                          <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white/80 animate-pulse" />
                        )}
                      </div>
                    </div>
                  ))}
                  {cards.length < 3 && (
                    <div onClick={() => setShowNewCard(true)}
                      className="flex-shrink-0 w-32 h-20 rounded-2xl border-2 border-dashed border-slate-700 flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-slate-500 transition">
                      <Plus className="w-5 h-5 text-slate-600" />
                      <span className="text-[9px] text-slate-600 font-bold">YANGI</span>
                    </div>
                  )}
                </div>

                {/* Main card display */}
                {activeCard && (
                  <div className="relative rounded-3xl overflow-hidden select-none"
                    style={{ background: CARD_GRADIENTS[activeCard.gradientIdx], aspectRatio: "1.586/1" }}>
                    {/* Shimmer */}
                    <div className="absolute inset-0"
                      style={{ background: "radial-gradient(circle at 75% 25%, rgba(255,255,255,0.12), transparent 55%)" }} />
                    <div className="absolute inset-0"
                      style={{ background: "linear-gradient(135deg, transparent 30%, rgba(255,255,255,0.04) 50%, transparent 70%)" }} />

                    {/* Frozen overlay */}
                    {activeCard.frozen && (
                      <div className="absolute inset-0 flex items-center justify-center z-10"
                        style={{ background: "rgba(14,22,60,0.75)", backdropFilter: "blur(4px)" }}>
                        <div className="text-center">
                          <Lock className="w-8 h-8 text-blue-300 mx-auto mb-1" />
                          <p className="text-blue-200 text-sm font-black">MUZLATILGAN</p>
                        </div>
                      </div>
                    )}

                    <div className="relative p-6 flex flex-col justify-between h-full">
                      {/* Top row */}
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest">Virtual Karta</p>
                          <p className="text-white font-black text-base mt-0.5 tracking-wide">{activeCard.label}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Wifi className="w-5 h-5 text-white/40 rotate-90" />
                          <div className="flex flex-col items-end">
                            <div className="w-8 h-8 rounded-full border-2 border-white/20 flex items-center justify-center">
                              <Sparkles className="w-4 h-4 text-white/60" />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Card number */}
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-white font-mono text-lg tracking-[0.18em] font-bold flex-1">
                            {showCardNum ? cardNumber : maskedNum}
                          </p>
                          <button onClick={() => setShowCardNum(v => !v)}
                            className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                            {showCardNum ? <EyeOff className="w-3.5 h-3.5 text-white/70" /> : <Eye className="w-3.5 h-3.5 text-white/70" />}
                          </button>
                          <button onClick={() => copyToClipboard(cardNumber, "num")}
                            className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                            {copied === "num" ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5 text-white/70" />}
                          </button>
                        </div>

                        {/* Bottom row */}
                        <div className="flex items-end justify-between">
                          <div>
                            <p className="text-white/40 text-[9px] uppercase tracking-widest">Karta egasi</p>
                            <p className="text-white font-bold text-sm tracking-widest uppercase">@{username}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-white/40 text-[9px] uppercase tracking-widest">Muddati</p>
                            <p className="text-white font-bold text-sm font-mono">{cardExpiry}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-white/40 text-[9px] uppercase tracking-widest">CVV</p>
                            <div className="flex items-center gap-1">
                              <p className="text-white font-bold text-sm font-mono">{showCvv ? cardCvv : "•••"}</p>
                              <button onClick={() => setShowCvv(v => !v)}
                                className="w-5 h-5 flex items-center justify-center">
                                {showCvv ? <EyeOff className="w-3 h-3 text-white/40" /> : <Eye className="w-3 h-3 text-white/40" />}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Balance display */}
                {activeCard && (
                  <div className="flex items-center justify-between p-4 rounded-2xl border border-slate-800/60"
                    style={{ background: "rgba(15,23,42,0.6)" }}>
                    <div>
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Balans</p>
                      <div className="flex items-baseline gap-2 mt-0.5">
                        <span className="text-3xl font-black text-white">{activeCard.balance.toLocaleString("uz-UZ")}</span>
                        <span className="text-slate-400 font-bold text-sm">UZS</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl"
                        style={{ background: activeCard.frozen ? "#1e3a5f40" : "#16a34a20", border: `1px solid ${activeCard.frozen ? "#3b82f640" : "#16a34a40"}` }}>
                        {activeCard.frozen
                          ? <Lock className="w-3.5 h-3.5 text-blue-400" />
                          : <ShieldCheck className="w-3.5 h-3.5 text-green-400" />}
                        <span className="text-[10px] font-bold" style={{ color: activeCard.frozen ? "#60a5fa" : "#4ade80" }}>
                          {activeCard.frozen ? "Muzlat." : "Faol"}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action buttons */}
                {activeCard && (
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => { setCardAction("topup"); setCardAmount(""); setCardNote(""); }}
                      className="flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-sm transition active:scale-95"
                      style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40`, color: accentColor }}>
                      <Plus className="w-4 h-4" /> Pul kiritish
                    </button>
                    <button onClick={() => { setCardAction("withdraw"); setCardAmount(""); setCardNote(""); }}
                      className="flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-sm transition active:scale-95"
                      style={{ background: "#ef444420", border: "1px solid #ef444440", color: "#ef4444" }}>
                      <Minus className="w-4 h-4" /> Pul chiqarish
                    </button>
                    <button onClick={toggleFreeze}
                      className="flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-xs transition active:scale-95"
                      style={{ background: activeCard.frozen ? "#16a34a20" : "#1e3a5f40", border: `1px solid ${activeCard.frozen ? "#16a34a40" : "#3b82f640"}`, color: activeCard.frozen ? "#4ade80" : "#60a5fa" }}>
                      <Lock className="w-3.5 h-3.5" /> {activeCard.frozen ? "Faollashtirish" : "Muzlatish"}
                    </button>
                    <button onClick={deleteCard}
                      className="flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-xs transition active:scale-95 text-slate-500 border border-slate-800 hover:border-red-900 hover:text-red-400">
                      <X className="w-3.5 h-3.5" /> Kartani o'chirish
                    </button>
                  </div>
                )}

                {/* Card action sheet */}
                {cardAction && activeCard && (
                  <div className="rounded-2xl border border-slate-800 overflow-hidden"
                    style={{ background: "rgba(15,23,42,0.95)" }}>
                    <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
                      <p className="text-sm font-black text-white">
                        {cardAction === "topup" ? "💵 Pul kiritish" : "💸 Pul chiqarish"}
                      </p>
                      <button onClick={() => setCardAction(null)}>
                        <X className="w-4 h-4 text-slate-500" />
                      </button>
                    </div>
                    <div className="p-4 space-y-3">
                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Miqdor (UZS)</label>
                        <input
                          type="number"
                          value={cardAmount}
                          onChange={e => setCardAmount(e.target.value)}
                          placeholder="0"
                          className="w-full mt-1.5 bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500/50 placeholder-slate-600"
                        />
                        <div className="flex gap-2 mt-2">
                          {[10000, 50000, 100000, 500000].map(v => (
                            <button key={v} onClick={() => setCardAmount(String(v))}
                              className="flex-1 py-1.5 rounded-lg text-[10px] font-bold transition border"
                              style={cardAmount === String(v)
                                ? { background: `${accentColor}30`, color: accentColor, borderColor: `${accentColor}50` }
                                : { background: "#1e293b", color: "#64748b", borderColor: "#334155" }}>
                              {v >= 1000000 ? `${v / 1000000}M` : v >= 1000 ? `${v / 1000}K` : v}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Izoh (ixtiyoriy)</label>
                        <input
                          value={cardNote}
                          onChange={e => setCardNote(e.target.value)}
                          placeholder="Maqsad yozing..."
                          className="w-full mt-1.5 bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500/50 placeholder-slate-600"
                        />
                      </div>
                      <button onClick={doCardAction} disabled={cardActionLoading || !cardAmount}
                        className="w-full py-3.5 rounded-2xl font-black text-sm transition active:scale-95 disabled:opacity-40"
                        style={{ background: cardAction === "topup" ? `linear-gradient(135deg,${accentColor},#6366f1)` : "linear-gradient(135deg,#ef4444,#dc2626)", color: "#fff" }}>
                        {cardActionLoading ? "Bajarilmoqda..." : cardAction === "topup" ? "Kiritish" : "Chiqarish"}
                      </button>
                    </div>
                  </div>
                )}

                {/* Card transaction history */}
                {activeCard && activeCard.transactions.length > 0 && (
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-600 mb-2 font-bold">Karta operatsiyalari</p>
                    <div className="space-y-1">
                      {activeCard.transactions.map((tx, i) => (
                        <div key={tx.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-900/30 transition">
                          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                            style={{ background: tx.type === "topup" ? "#16a34a20" : "#ef444420" }}>
                            {tx.type === "topup"
                              ? <ArrowDownLeft className="w-4 h-4 text-green-400" />
                              : <ArrowUpRight className="w-4 h-4 text-red-400" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-200 truncate">{tx.note}</p>
                            <p className="text-[10px] text-slate-600">{timeSinceCard(tx.ts)}</p>
                          </div>
                          <span className={`font-black text-sm ${tx.amount > 0 ? "text-green-400" : "text-red-400"}`}>
                            {tx.amount > 0 ? "+" : ""}{fmtAmt(tx.amount)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeCard && activeCard.transactions.length === 0 && !cardAction && (
                  <div className="text-center py-6 text-slate-600 text-sm">
                    <CreditCard className="w-8 h-8 mx-auto mb-2 opacity-20" />
                    Hali operatsiya yo'q
                  </div>
                )}
              </>
            )}

            {/* Security info */}
            <div className="p-3 rounded-2xl flex items-center gap-3"
              style={{ background: "rgba(15,23,42,0.5)", border: "1px solid rgba(255,255,255,0.05)" }}>
              <ShieldCheck className="w-5 h-5 text-green-400 flex-shrink-0" />
              <p className="text-[10px] text-slate-500 leading-relaxed">
                Virtual kartalar faqat ilovada ishlatiladi. Karta ma'lumotlari Firebase-da xavfsiz saqlanadi. Haqiqiy bank tizimlariga ulanmagan.
              </p>
            </div>
          </div>
        )}

        {/* Create card modal */}
        {showNewCard && (
          <div className="fixed inset-0 z-50 flex items-end justify-center"
            style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(16px)" }}>
            <div className="w-full max-w-sm bg-slate-900 rounded-t-3xl border-t border-slate-800 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-base font-black text-white">Yangi Virtual Karta</p>
                <button onClick={() => setShowNewCard(false)}>
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              {/* Preview */}
              <div className="relative rounded-2xl overflow-hidden h-36"
                style={{ background: CARD_GRADIENTS[newCardGrad] }}>
                <div className="absolute inset-0"
                  style={{ background: "radial-gradient(circle at 75% 25%, rgba(255,255,255,0.12), transparent 55%)" }} />
                <div className="relative p-5 flex flex-col justify-between h-full">
                  <div>
                    <p className="text-white/50 text-[9px] uppercase tracking-widest">Virtual Karta</p>
                    <p className="text-white font-black text-sm mt-0.5">{newCardLabel || "Karta nomi"}</p>
                  </div>
                  <div className="flex justify-between items-end">
                    <p className="text-white/70 font-mono text-sm tracking-widest">•••• •••• •••• ••••</p>
                    <p className="text-white/60 text-[10px] uppercase font-bold">@{username}</p>
                  </div>
                </div>
              </div>

              {/* Label */}
              <div>
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Karta nomi</label>
                <input
                  value={newCardLabel}
                  onChange={e => setNewCardLabel(e.target.value)}
                  placeholder="masalan: Asosiy karta"
                  maxLength={24}
                  className="w-full mt-1.5 bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500/50 placeholder-slate-600"
                />
              </div>

              {/* Gradient */}
              <div>
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2 block">Rang sxemasi</label>
                <div className="flex gap-2">
                  {CARD_GRADIENTS.map((g, i) => (
                    <button key={i} onClick={() => setNewCardGrad(i)}
                      className={`flex-1 h-9 rounded-xl border-2 transition ${newCardGrad === i ? "border-white scale-110" : "border-transparent"}`}
                      style={{ background: g }} />
                  ))}
                </div>
              </div>

              <button onClick={createCard} disabled={creatingCard || !newCardLabel.trim()}
                className="w-full py-3.5 rounded-2xl font-black text-sm transition active:scale-95 disabled:opacity-40"
                style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, color: "#000" }}>
                {creatingCard ? "Yaratilmoqda..." : "✨ Karta yaratish"}
              </button>
            </div>
          </div>
        )}

        {/* Overview */}
        {tab === "overview" && (
          <div className="space-y-3 tab-slide-in">
            {/* Quick actions */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: <Send className="w-5 h-5" />, label: "Yuborish", action: () => setTab("send"), color: accentColor },
                { icon: <Gift className="w-5 h-5" />, label: "Sovg'a", action: () => setTab("send"), color: "#a855f7" },
                { icon: <Award className="w-5 h-5" />, label: "Reyting", action: () => setTab("leaderboard"), color: "#f59e0b" },
              ].map((item, i) => (
                <button key={i} onClick={item.action}
                  className="flex flex-col items-center gap-2 p-4 rounded-2xl border transition active:scale-95"
                  style={{ background: item.color + "11", borderColor: item.color + "33", color: item.color }}>
                  {item.icon}
                  <span className="text-xs font-bold">{item.label}</span>
                </button>
              ))}
            </div>

            {/* Cooldown info */}
            {!canBonus && bonusCooldown && (
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/40 border border-slate-800/40">
                <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-lg">⏰</div>
                <div>
                  <p className="text-sm font-bold text-slate-300">Keyingi bonus</p>
                  <p className="text-xs text-slate-500">{bonusCooldown} da mavjud bo'ladi</p>
                </div>
              </div>
            )}

            {/* Recent transactions */}
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-600 mb-2 font-bold">So'nggi harakatlar</p>
              {transactions.length === 0 && (
                <div className="text-center py-8 text-slate-600 text-sm">Hali tranzaksiya yo'q</div>
              )}
              {transactions.slice(0, 5).map((t, i) => (
                <div key={t.id} className="flex items-center gap-3 py-3 border-b border-slate-800/40 stagger-1" style={{ animationDelay: `${i * 50}ms` }}>
                  <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center flex-shrink-0">
                    {txIcon(t.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-200 truncate">{t.note || t.type}</p>
                    <p className="text-[10px] text-slate-600">{timeSince(t.ts)}</p>
                  </div>
                  <span className={`font-black text-sm ${txColor(t.type)}`}>
                    {t.amount > 0 ? "+" : ""}{t.amount}⭐
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Send */}
        {tab === "send" && (
          <div className="space-y-4 tab-slide-in">
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/60 space-y-4">
              {/* User select */}
              <div>
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Kimga</label>
                <input list="users-list" value={sendTarget} onChange={e => setSendTarget(e.target.value)}
                  placeholder="@foydalanuvchi nomi"
                  className="w-full mt-1.5 bg-slate-800/60 border border-slate-700/60 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-slate-500 placeholder-slate-600 transition" />
                <datalist id="users-list">
                  {allUsers.map(u => <option key={u} value={u} />)}
                </datalist>
              </div>
              {/* Amount */}
              <div>
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Miqdor</label>
                <div className="flex gap-2 mt-1.5">
                  <div className="relative flex-1">
                    <input type="number" value={sendAmount} onChange={e => setSendAmount(e.target.value)} min="1" max={starsBalance}
                      className="w-full bg-slate-800/60 border border-slate-700/60 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-slate-500 transition pr-10" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-400 text-sm">⭐</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-2">
                  {[10, 25, 50, 100].map(v => (
                    <button key={v} onClick={() => setSendAmount(String(v))}
                      className="flex-1 py-1.5 rounded-lg text-xs font-bold transition"
                      style={sendAmount === String(v) ? { background: accentColor + "33", color: accentColor, border: `1px solid ${accentColor}55` } : { background: "#1e293b", color: "#64748b", border: "1px solid #334155" }}>
                      {v}⭐
                    </button>
                  ))}
                </div>
              </div>
              {/* Note */}
              <div>
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Izoh (ixtiyoriy)</label>
                <input value={sendNote} onChange={e => setSendNote(e.target.value)} placeholder="Sabab yozing..."
                  className="w-full mt-1.5 bg-slate-800/60 border border-slate-700/60 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-slate-500 placeholder-slate-600 transition" />
              </div>

              {sendError && <p className="text-rose-400 text-sm font-bold text-center">{sendError}</p>}
              {sendSuccess && <p className="text-green-400 text-sm font-bold text-center drop-in">{sendSuccess}</p>}

              <button onClick={sendStars} disabled={sending}
                className="w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 text-white transition active:scale-[0.98] disabled:opacity-50"
                style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
                <Send className="w-4 h-4" /> {sending ? "Yuborilmoqda..." : "Yulduz yuborish"}
              </button>
            </div>
          </div>
        )}

        {/* History */}
        {tab === "history" && (
          <div className="space-y-1 tab-slide-in">
            {transactions.length === 0 && (
              <div className="text-center py-16 text-slate-600">
                <Star className="w-12 h-12 mx-auto mb-3 opacity-20" />
                <p>Tranzaksiya tarixi yo'q</p>
              </div>
            )}
            {transactions.map((t, i) => (
              <div key={t.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-900/30 transition stagger-1" style={{ animationDelay: `${i * 30}ms` }}>
                <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center flex-shrink-0">
                  {txIcon(t.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-200 truncate">{t.note}</p>
                  <p className="text-[10px] text-slate-600">
                    {t.type === "send" ? `→ @${t.to}` : t.type === "receive" ? `← @${t.from}` : "🎁 Bonus"} · {timeSince(t.ts)}
                  </p>
                </div>
                <span className={`font-black text-sm ${txColor(t.type)}`}>
                  {t.amount > 0 ? "+" : ""}{t.amount}⭐
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Missions */}
        {tab === "missions" && (
          <div className="space-y-3 tab-slide-in">
            {/* Progress bar */}
            <div className="p-4 rounded-2xl border border-slate-800/60 bg-slate-900/40">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-bold text-slate-300">Bugungi vazifalar</p>
                <span className="text-xs font-black" style={{ color: accentColor }}>
                  {Object.keys(completedMissions).length}/{DAILY_MISSIONS.length}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${(Object.keys(completedMissions).length / DAILY_MISSIONS.length) * 100}%`, background: `linear-gradient(90deg, ${accentColor}, #8b5cf6)` }} />
              </div>
              {Object.keys(completedMissions).length === DAILY_MISSIONS.length && (
                <p className="text-center text-xs text-amber-400 font-bold mt-2 drop-in">🎉 Barcha vazifalar bajarildi! Ertaga qaytib keling.</p>
              )}
            </div>

            {/* Mission list */}
            {DAILY_MISSIONS.map((m, i) => {
              const done = !!completedMissions[m.id];
              const isClaiming = claimingMission === m.id;
              return (
                <div key={m.id}
                  className={`flex items-center gap-3 p-4 rounded-2xl border transition stagger-1 ${done ? "bg-green-950/20 border-green-800/40" : "bg-slate-900/40 border-slate-800/40"}`}
                  style={{ animationDelay: `${i * 60}ms` }}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                    style={{ background: done ? "#16a34a22" : accentColor + "11", border: `1px solid ${done ? "#16a34a44" : accentColor + "33"}` }}>
                    {m.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-bold truncate ${done ? "text-green-400 line-through opacity-60" : "text-slate-200"}`}>{m.label}</p>
                    <p className="text-[10px] text-slate-500 truncate">{m.desc}</p>
                    <p className="text-[10px] font-black text-amber-400 mt-0.5">+{m.reward}⭐ mukofot</p>
                  </div>
                  {done ? (
                    <CheckCircle2 className="w-6 h-6 text-green-400 flex-shrink-0" />
                  ) : (
                    <button onClick={() => claimMission(m.id, m.reward)} disabled={isClaiming}
                      className="px-3 py-2 rounded-xl text-xs font-black transition active:scale-95 flex-shrink-0 disabled:opacity-60"
                      style={{ background: accentColor + "22", color: accentColor, border: `1px solid ${accentColor}44` }}>
                      {isClaiming ? "..." : "Oldim ✓"}
                    </button>
                  )}
                </div>
              );
            })}

            <p className="text-center text-[10px] text-slate-600 pt-2">
              💡 Vazifalarni bajargandan keyin "Oldim" tugmasini bosing
            </p>
          </div>
        )}

        {/* Leaderboard */}
        {tab === "leaderboard" && (
          <div className="space-y-2 tab-slide-in">
            <div className="text-center py-3">
              <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">Top 10 · Eng ko'p yulduzlar</p>
            </div>
            {leaderboard.map((entry, i) => {
              const isMe = entry.username === username;
              const medals = ["🥇", "🥈", "🥉"];
              return (
                <div key={entry.username}
                  className={`flex items-center gap-3 p-3.5 rounded-2xl border transition stagger-1 ${isMe ? "bg-amber-950/20 border-amber-800/40" : "bg-slate-900/30 border-slate-800/30"}`}
                  style={{ animationDelay: `${i * 50}ms` }}>
                  <div className="w-8 text-center text-lg flex-shrink-0">
                    {medals[i] || <span className="text-slate-600 font-black text-sm">#{i + 1}</span>}
                  </div>
                  <div className="w-9 h-9 rounded-full flex items-center justify-center font-black text-sm flex-shrink-0"
                    style={{ background: i < 3 ? `linear-gradient(135deg, ${accentColor}44, #6366f133)` : "#1e293b", color: i < 3 ? accentColor : "#64748b" }}>
                    {entry.username[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-bold text-sm truncate ${isMe ? "text-amber-300" : "text-slate-200"}`}>
                      @{entry.username} {isMe && <span className="text-amber-500 text-[10px]">(siz)</span>}
                    </p>
                  </div>
                  <span className="font-black text-amber-400 text-sm">{entry.balance.toLocaleString()}⭐</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
