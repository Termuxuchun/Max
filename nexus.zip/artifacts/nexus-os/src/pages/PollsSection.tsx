import { useState, useEffect } from "react";
import { ref, push, onValue, update, get, remove } from "firebase/database";
import { db } from "../firebase";
import { Plus, Trash2, BarChart2, Clock, CheckCircle2, Lock, Globe, Users } from "lucide-react";

interface PollOption { text: string; votes: Record<string, true>; }
interface Poll {
  id: string;
  question: string;
  options: PollOption[];
  creator: string;
  createdAt: number;
  expiresAt: number;
  isPublic: boolean;
  totalVotes: number;
}

interface PollsSectionProps {
  username: string;
  accentColor: string;
}

const PRESET_DURATIONS = [
  { label: "1 soat", ms: 3600_000 },
  { label: "6 soat", ms: 21_600_000 },
  { label: "1 kun", ms: 86_400_000 },
  { label: "3 kun", ms: 259_200_000 },
  { label: "1 hafta", ms: 604_800_000 },
];

export default function PollsSection({ username, accentColor }: PollsSectionProps) {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", ""]);
  const [duration, setDuration] = useState(PRESET_DURATIONS[2].ms);
  const [isPublic, setIsPublic] = useState(true);
  const [creating, setCreating] = useState(false);
  const [filter, setFilter] = useState<"all" | "mine" | "active" | "ended">("all");

  useEffect(() => {
    return onValue(ref(db, "polls"), snap => {
      if (!snap.exists()) { setPolls([]); return; }
      const list: Poll[] = [];
      snap.forEach(c => {
        const d = c.val();
        const opts: PollOption[] = Object.values(d.options || {});
        const totalVotes = opts.reduce((s: number, o: PollOption) => s + Object.keys(o.votes || {}).length, 0);
        list.push({ id: c.key!, ...d, options: opts, totalVotes });
      });
      list.sort((a, b) => b.createdAt - a.createdAt);
      setPolls(list);
    });
  }, []);

  async function createPoll() {
    const validOpts = options.filter(o => o.trim());
    if (!question.trim() || validOpts.length < 2) return;
    setCreating(true);
    const newPoll = {
      question: question.trim(),
      options: validOpts.reduce((acc, text, i) => ({ ...acc, [i]: { text, votes: {} } }), {}),
      creator: username,
      createdAt: Date.now(),
      expiresAt: Date.now() + duration,
      isPublic,
    };
    await push(ref(db, "polls"), newPoll);
    setQuestion(""); setOptions(["", ""]); setShowCreate(false); setCreating(false);
  }

  async function vote(pollId: string, optionIdx: number) {
    const snap = await get(ref(db, `polls/${pollId}/options`));
    if (!snap.exists()) return;
    const opts = snap.val() as Record<string, PollOption>;
    // Remove previous vote
    const updates: Record<string, any> = {};
    Object.keys(opts).forEach(k => {
      if (opts[k].votes?.[username]) {
        updates[`polls/${pollId}/options/${k}/votes/${username}`] = null;
      }
    });
    // Add new vote
    updates[`polls/${pollId}/options/${optionIdx}/votes/${username}`] = true;
    await update(ref(db), updates);
  }

  function getVotedOption(poll: Poll): number | null {
    for (let i = 0; i < poll.options.length; i++) {
      if (poll.options[i].votes?.[username]) return i;
    }
    return null;
  }

  function timeLeft(expiresAt: number) {
    const ms = expiresAt - Date.now();
    if (ms <= 0) return null;
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    if (h > 24) return `${Math.floor(h / 24)}k`;
    if (h > 0) return `${h}s ${m}d`;
    return `${m}d`;
  }

  const filtered = polls.filter(p => {
    const active = p.expiresAt > Date.now();
    if (filter === "mine") return p.creator === username;
    if (filter === "active") return active;
    if (filter === "ended") return !active;
    return true;
  });

  const activeCnt = polls.filter(p => p.expiresAt > Date.now()).length;

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 page-enter overflow-hidden">

      {/* ── Header ── */}
      <div className="px-4 pt-5 pb-3 flex items-center justify-between flex-shrink-0">
        <div>
          <h1 className="text-2xl font-black" style={{ color: accentColor }}>📊 Ovozlar</h1>
          <p className="text-slate-500 text-xs mt-0.5">{activeCnt} ta faol · {polls.length} ta jami</p>
        </div>
        <button onClick={() => setShowCreate(s => !s)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl font-bold text-sm text-white transition active:scale-95"
          style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
          <Plus className="w-4 h-4" /> Yaratish
        </button>
      </div>

      {/* ── Create Panel ── */}
      {showCreate && (
        <div className="mx-4 mb-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/60 space-y-3 drop-in flex-shrink-0">
          <input value={question} onChange={e => setQuestion(e.target.value)} placeholder="Savol yozing..."
            className="w-full bg-slate-800/60 border border-slate-700/50 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-slate-500 placeholder-slate-600 font-bold transition" />

          <div className="space-y-2">
            {options.map((opt, i) => (
              <div key={i} className="flex gap-2">
                <input value={opt} onChange={e => { const n = [...options]; n[i] = e.target.value; setOptions(n); }}
                  placeholder={`Variant ${i + 1}`}
                  className="flex-1 bg-slate-800/60 border border-slate-700/50 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-slate-500 placeholder-slate-600 transition" />
                {options.length > 2 && (
                  <button onClick={() => setOptions(options.filter((_, j) => j !== i))}
                    className="w-9 h-9 rounded-xl bg-rose-950/40 flex items-center justify-center text-rose-400 hover:bg-rose-900/50 transition">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
            {options.length < 6 && (
              <button onClick={() => setOptions([...options, ""])}
                className="w-full py-2 rounded-xl border border-dashed border-slate-700 text-slate-500 hover:text-slate-300 hover:border-slate-500 text-xs font-bold transition flex items-center justify-center gap-1.5">
                <Plus className="w-3.5 h-3.5" /> Variant qo'shish
              </button>
            )}
          </div>

          {/* Duration */}
          <div>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-1.5">Muddat</p>
            <div className="flex gap-1.5 flex-wrap">
              {PRESET_DURATIONS.map(d => (
                <button key={d.ms} onClick={() => setDuration(d.ms)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold transition"
                  style={duration === d.ms ? { background: accentColor + "33", color: accentColor, border: `1px solid ${accentColor}55` } : { background: "#1e293b", color: "#64748b", border: "1px solid #334155" }}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {/* Visibility */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isPublic ? <Globe className="w-4 h-4 text-green-400" /> : <Lock className="w-4 h-4 text-amber-400" />}
              <span className="text-sm text-slate-300 font-medium">{isPublic ? "Hammaga ochiq" : "Faqat siz"}</span>
            </div>
            <button onClick={() => setIsPublic(p => !p)}
              className={`w-12 h-6 rounded-full transition relative ${isPublic ? "bg-green-600" : "bg-slate-700"}`}>
              <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all shadow ${isPublic ? "right-0.5" : "left-0.5"}`} />
            </button>
          </div>

          <div className="flex gap-2">
            <button onClick={() => setShowCreate(false)}
              className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-400 font-bold text-sm hover:bg-slate-800 transition">
              Bekor
            </button>
            <button onClick={createPoll} disabled={creating || !question.trim() || options.filter(o => o.trim()).length < 2}
              className="flex-1 py-2.5 rounded-xl font-bold text-sm text-white transition active:scale-95 disabled:opacity-40"
              style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
              {creating ? "Yaratilyapti..." : "Yaratish"}
            </button>
          </div>
        </div>
      )}

      {/* ── Filters ── */}
      <div className="px-4 pb-3 flex-shrink-0">
        <div className="flex gap-1.5">
          {(["all", "active", "mine", "ended"] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className="px-3 py-1.5 rounded-xl text-xs font-bold transition"
              style={filter === f ? { background: accentColor + "22", color: accentColor, border: `1px solid ${accentColor}44` } : { color: "#475569" }}>
              {f === "all" ? "Barchasi" : f === "active" ? "Faol" : f === "mine" ? "Meniki" : "Tugagan"}
            </button>
          ))}
        </div>
      </div>

      {/* ── Poll List ── */}
      <div className="flex-1 overflow-y-auto px-4 pb-6 space-y-3">
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
            <div className="text-6xl">📊</div>
            <p className="text-slate-400 font-bold">Hali so'rovnoma yo'q</p>
            <button onClick={() => setShowCreate(true)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm text-white transition active:scale-95"
              style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
              <Plus className="w-4 h-4" /> Birinchi so'rovnomani yarating
            </button>
          </div>
        )}

        {filtered.map((poll, pi) => {
          const active = poll.expiresAt > Date.now();
          const voted = getVotedOption(poll);
          const hasVoted = voted !== null;
          const tl = timeLeft(poll.expiresAt);
          return (
            <div key={poll.id} className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800/50 space-y-3 stagger-1"
              style={{ animationDelay: `${pi * 50}ms`, borderColor: !active ? "#1e293b" : undefined }}>

              {/* Poll header */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <p className={`font-bold text-sm leading-snug ${!active ? "text-slate-500" : "text-white"}`}>{poll.question}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] text-slate-600">@{poll.creator}</span>
                    <span className="text-slate-700">·</span>
                    <span className="flex items-center gap-0.5 text-[10px] text-slate-600">
                      <Users className="w-2.5 h-2.5" /> {poll.totalVotes} ovoz
                    </span>
                    {active && tl && (
                      <span className="flex items-center gap-0.5 text-[10px]" style={{ color: accentColor }}>
                        <Clock className="w-2.5 h-2.5" /> {tl}
                      </span>
                    )}
                    {!active && <span className="text-[10px] text-rose-500 font-bold">TUGADI</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {hasVoted && <CheckCircle2 className="w-4 h-4" style={{ color: accentColor }} />}
                  {poll.isPublic ? <Globe className="w-3.5 h-3.5 text-slate-700" /> : <Lock className="w-3.5 h-3.5 text-slate-700" />}
                  {poll.creator === username && (
                    <button onClick={() => remove(ref(db, `polls/${poll.id}`))}
                      className="w-6 h-6 rounded-lg bg-rose-950/30 flex items-center justify-center text-rose-500 hover:bg-rose-900/50 transition">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              {/* Options */}
              <div className="space-y-2">
                {poll.options.map((opt, i) => {
                  const optVotes = Object.keys(opt.votes || {}).length;
                  const pct = poll.totalVotes > 0 ? Math.round((optVotes / poll.totalVotes) * 100) : 0;
                  const isVoted = voted === i;
                  const showResult = hasVoted || !active;
                  return (
                    <button key={i} onClick={() => active && !hasVoted ? vote(poll.id, i) : undefined}
                      disabled={hasVoted || !active}
                      className="w-full text-left relative overflow-hidden rounded-xl transition"
                      style={{ cursor: active && !hasVoted ? "pointer" : "default" }}>
                      <div className="relative z-10 flex items-center justify-between px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition ${isVoted ? "border-current" : "border-slate-600"}`}
                            style={isVoted ? { borderColor: accentColor } : {}}>
                            {isVoted && <div className="w-2 h-2 rounded-full" style={{ background: accentColor }} />}
                          </div>
                          <span className={`text-sm font-medium ${isVoted ? "text-white" : "text-slate-300"}`}>{opt.text}</span>
                        </div>
                        {showResult && (
                          <span className={`text-xs font-black ${isVoted ? "" : "text-slate-500"}`}
                            style={isVoted ? { color: accentColor } : {}}>{pct}%</span>
                        )}
                      </div>
                      {/* Progress bar */}
                      {showResult && (
                        <div className="absolute inset-0 rounded-xl" style={{
                          background: isVoted ? accentColor + "22" : "#1e293b",
                          border: `1px solid ${isVoted ? accentColor + "44" : "#334155"}`,
                        }}>
                          <div className="absolute inset-y-0 left-0 rounded-xl transition-all duration-700"
                            style={{ width: `${pct}%`, background: isVoted ? accentColor + "33" : "#ffffff08" }} />
                        </div>
                      )}
                      {!showResult && (
                        <div className="absolute inset-0 rounded-xl bg-slate-800/50 border border-slate-700/50 hover:border-slate-500 hover:bg-slate-800 transition" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
