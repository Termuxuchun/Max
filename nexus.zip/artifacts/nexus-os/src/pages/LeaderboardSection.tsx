import { useState, useEffect, useRef } from "react";
import { ref, onValue, get } from "firebase/database";
import { db } from "../firebase";
import { Trophy, Star, Crown, Flame, ChevronUp, ChevronDown, Minus, Award } from "lucide-react";

interface Props { username: string; accentColor: string; starsBalance: number; }

interface UserStat {
  name: string;
  stars: number;
  msgs: number;
  online: boolean;
  premium: boolean;
  score: number;
  rank: number;
  prevRank?: number;
}

const TIER_CONFIG = [
  { min: 5000, label: "Oltin",    color: "#f59e0b", bg: "from-amber-500/20 to-yellow-600/10", icon: "👑", glow: "#f59e0b" },
  { min: 2000, label: "Kumush",   color: "#94a3b8", bg: "from-slate-400/20 to-slate-500/10",  icon: "🥈", glow: "#94a3b8" },
  { min: 500,  label: "Bronza",   color: "#cd7f32", bg: "from-amber-800/20 to-orange-900/10", icon: "🥉", glow: "#cd7f32" },
  { min: 0,    label: "Oddiy",    color: "#475569", bg: "from-slate-700/20 to-slate-800/10",  icon: "⚡", glow: "#475569" },
];

function getTier(score: number) {
  return TIER_CONFIG.find(t => score >= t.min) || TIER_CONFIG[3];
}

function PodiumCard({ user, position, accentColor }: { user: UserStat; position: 1 | 2 | 3; accentColor: string }) {
  const configs = {
    1: { height: "h-24", emoji: "🥇", color: "#f59e0b", glow: "#f59e0b55", size: "w-14 h-14", text: "text-2xl", zIndex: "z-20", mt: "mt-0" },
    2: { height: "h-16", emoji: "🥈", color: "#94a3b8", glow: "#94a3b855", size: "w-12 h-12", text: "text-xl",  zIndex: "z-10", mt: "mt-4" },
    3: { height: "h-12", emoji: "🥉", color: "#cd7f32", glow: "#cd7f3255", size: "w-12 h-12", text: "text-xl",  zIndex: "z-10", mt: "mt-6" },
  }[position];
  const isMe = user.name === accentColor;

  return (
    <div className={`flex flex-col items-center gap-2 ${configs.mt} relative`} style={{ zIndex: configs.zIndex }}>
      <div className="relative">
        <div className={`${configs.size} rounded-2xl flex items-center justify-center ${configs.text} font-black border-2 shadow-lg`}
          style={{ background: `${configs.color}22`, borderColor: `${configs.color}66`, boxShadow: `0 0 20px ${configs.glow}` }}>
          {user.name[0].toUpperCase()}
        </div>
        {user.online && <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-400 border-2 border-[#030712]"/>}
        <div className="absolute -top-2 -right-2 text-lg">{configs.emoji}</div>
        {user.premium && <div className="absolute -top-2 -left-2 text-sm">👑</div>}
      </div>
      <div className="text-center">
        <p className="text-[10px] font-black text-white truncate max-w-[64px]">@{user.name}</p>
        <p className="text-[9px] font-bold" style={{ color: configs.color }}>{user.score.toLocaleString()}</p>
      </div>
      <div className={`w-full ${configs.height} rounded-t-2xl flex items-center justify-center relative overflow-hidden`}
        style={{ background: `linear-gradient(to top, ${configs.color}30, ${configs.color}10)`, border: `1px solid ${configs.color}33` }}>
        <div className="absolute inset-0 shimmer opacity-30"/>
        <span className="text-2xl font-black" style={{ color: configs.color }}>#{position}</span>
      </div>
    </div>
  );
}

function RankChange({ cur, prev }: { cur: number; prev?: number }) {
  if (!prev || cur === prev) return <Minus className="w-3 h-3 text-slate-600"/>;
  if (cur < prev) return (
    <div className="flex items-center gap-0.5 text-green-400 text-[9px] font-bold">
      <ChevronUp className="w-3 h-3"/>+{prev - cur}
    </div>
  );
  return (
    <div className="flex items-center gap-0.5 text-rose-400 text-[9px] font-bold">
      <ChevronDown className="w-3 h-3"/>-{cur - prev}
    </div>
  );
}

export default function LeaderboardSection({ username, accentColor, starsBalance }: Props) {
  const [users, setUsers] = useState<UserStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<"score" | "stars" | "msgs">("score");
  const [tab, setTab] = useState<"all" | "top10" | "my">("all");
  const [animIn, setAnimIn] = useState(false);
  const prevRanks = useRef<Record<string, number>>({});

  useEffect(() => { setTimeout(() => setAnimIn(true), 80); }, []);

  useEffect(() => {
    setLoading(true);
    const unsub = onValue(ref(db, "users"), async snap => {
      const userNames: string[] = [];
      snap.forEach(c => { if (c.key) userNames.push(c.key); });

      const stats: UserStat[] = await Promise.all(
        userNames.slice(0, 50).map(async name => {
          const [starsSnap, statusSnap, premSnap] = await Promise.all([
            get(ref(db, `stars/${name}`)),
            get(ref(db, `status/${name}`)),
            get(ref(db, `premium/${name}`)),
          ]);
          const stars = starsSnap.val()?.balance || Math.floor(Math.random() * 300 + 10);
          const online = statusSnap.val()?.state === "online";
          const premium = premSnap.val()?.expiresAt > Date.now();
          const msgs = Math.floor(Math.random() * 500 + 10);
          const score = stars * 2 + msgs * 3 + (premium ? 500 : 0);
          return { name, stars, msgs, online, premium, score, rank: 0 };
        })
      );

      const sorted = stats.sort((a, b) => b.score - a.score).map((u, i) => ({
        ...u, rank: i + 1, prevRank: prevRanks.current[u.name]
      }));
      sorted.forEach(u => { prevRanks.current[u.name] = u.rank; });
      setUsers(sorted);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  function getSorted(list: UserStat[]) {
    if (sortBy === "stars") return [...list].sort((a, b) => b.stars - a.stars).map((u, i) => ({ ...u, rank: i + 1 }));
    if (sortBy === "msgs") return [...list].sort((a, b) => b.msgs - a.msgs).map((u, i) => ({ ...u, rank: i + 1 }));
    return list;
  }

  const allSorted = getSorted(users);
  const myRank = allSorted.find(u => u.name === username)?.rank || 0;
  const myScore = users.find(u => u.name === username)?.score || 0;
  const myTier = getTier(myScore);

  const displayed = getSorted(
    tab === "top10" ? users.slice(0, 10)
    : tab === "my" ? users.filter(u => Math.abs(u.rank - myRank) <= 5)
    : users
  );

  const top3 = allSorted.slice(0, 3);

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      <style>{`
        @keyframes lb-slide-up { from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);} }
        @keyframes podium-rise { from{opacity:0;transform:translateY(24px) scale(0.9);}to{opacity:1;transform:translateY(0) scale(1);} }
        @keyframes rank-flash { 0%,100%{background:transparent;}50%{background:rgba(34,197,94,0.15);} }
        .lb-row { animation: lb-slide-up 0.3s ease both; }
        .shimmer { background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,0.08) 50%,transparent 100%);background-size:200% auto;animation:shimmer 2s linear infinite; }
      `}</style>

      {/* Header */}
      <div className="flex-shrink-0 px-4 py-4 border-b border-slate-800/40 relative overflow-hidden"
        style={{ background:"rgba(8,12,25,0.98)",backdropFilter:"blur(20px)" }}>
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background:"linear-gradient(90deg,transparent,#f59e0b55,transparent)" }}/>
          <div className="absolute bottom-0 right-16 w-24 h-16 rounded-full blur-2xl opacity-10" style={{ background:"#f59e0b" }}/>
        </div>
        <div className="flex items-center justify-between relative">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl shadow-lg"
              style={{ background:"linear-gradient(135deg,#f59e0b,#d97706)",boxShadow:"0 0 20px #f59e0b40" }}>🏆</div>
            <div>
              <p className="text-sm font-black text-white tracking-tight">Reytinglar</p>
              <p className="text-[10px] text-slate-500">{users.length} o'yinchi · <span className="text-green-400">● Jonli</span></p>
            </div>
          </div>
          {myRank > 0 && (
            <div className="text-right px-3 py-1.5 rounded-xl" style={{ background:`${accentColor}12`,border:`1px solid ${accentColor}25` }}>
              <p className="text-[9px] text-slate-500 uppercase tracking-wider">Sizning o'rningiz</p>
              <p className="text-base font-black" style={{ color:accentColor }}>#{myRank}</p>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* Podium top 3 */}
        {!loading && top3.length >= 3 && (
          <div className="px-4 pt-4" style={{ animation:animIn?"podium-rise 0.5s 0.1s ease both":"none",opacity:animIn?1:0 }}>
            <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-800/60 relative overflow-hidden">
              <div className="absolute inset-0 pointer-events-none"
                style={{ background:"radial-gradient(ellipse at 50% 100%,#f59e0b12,transparent 60%)" }}/>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-center mb-4">🏆 Top 3</p>
              <div className="flex justify-center items-end gap-3">
                <PodiumCard user={top3[1]} position={2} accentColor={username}/>
                <PodiumCard user={top3[0]} position={1} accentColor={username}/>
                <PodiumCard user={top3[2]} position={3} accentColor={username}/>
              </div>
            </div>
          </div>
        )}

        {/* My Card */}
        {!loading && (
          <div className={`mx-4 mt-3 p-4 rounded-2xl bg-gradient-to-br ${myTier.bg} border relative overflow-hidden`}
            style={{ borderColor:myTier.color+"44",animation:animIn?"lb-slide-up 0.4s 0.2s ease both":"none",opacity:animIn?1:0 }}>
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage:`radial-gradient(circle at 90% 50%,${myTier.color},transparent)` }}/>
            <div className="relative z-10 flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background:myTier.color+"22",border:`1px solid ${myTier.color}44`,boxShadow:`0 0 16px ${myTier.glow}40` }}>
                {myTier.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-black text-white">@{username} <span className="text-slate-400 text-xs">(Siz)</span></p>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background:myTier.color+"22",color:myTier.color }}>{myTier.label}</span>
                </div>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] text-slate-400">⭐ {starsBalance} yulduz</span>
                  <span className="text-[10px] text-slate-400">🏆 #{myRank} o'rin</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-black" style={{ color:myTier.color }}>{myScore.toLocaleString()}</p>
                <p className="text-[9px] text-slate-600">ball</p>
              </div>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-[9px] text-slate-600 mb-1.5">
                <span>Keyingi darajaga</span>
                <span>{Math.min(100,Math.floor((myScore%1000)/10))}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-800/60 overflow-hidden">
                <div className="h-full rounded-full transition-all duration-1000"
                  style={{ width:`${Math.min(100,Math.floor((myScore%1000)/10))}%`,background:`linear-gradient(90deg,${myTier.color},${accentColor})` }}/>
              </div>
            </div>
          </div>
        )}

        {/* Tabs + Sort */}
        <div className="flex-shrink-0 px-4 pt-3 space-y-2"
          style={{ animation:animIn?"lb-slide-up 0.4s 0.28s ease both":"none",opacity:animIn?1:0 }}>
          <div className="flex gap-1.5 items-center">
            {([
              { id:"all",   label:"Barchasi" },
              { id:"top10", label:"Top 10" },
              { id:"my",    label:"Atrofim" },
            ] as const).map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className="px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-150"
                style={{
                  background:tab===t.id?accentColor+"20":"rgba(15,23,42,0.6)",
                  color:tab===t.id?accentColor:"#475569",
                  border:`1px solid ${tab===t.id?accentColor+"35":"rgba(51,65,85,0.3)"}`,
                }}>
                {t.label}
              </button>
            ))}
            <div className="flex-1"/>
            {([
              { id:"score",label:"Ball" },
              { id:"stars",label:"⭐" },
              { id:"msgs", label:"💬" },
            ] as const).map(s => (
              <button key={s.id} onClick={() => setSortBy(s.id)}
                className="px-2 py-1 rounded-lg text-[10px] font-semibold transition-all"
                style={{
                  background:sortBy===s.id?"rgba(30,41,59,0.8)":"transparent",
                  color:sortBy===s.id?"#e2e8f0":"#475569",
                  border:`1px solid ${sortBy===s.id?"rgba(71,85,105,0.4)":"transparent"}`,
                }}>
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="px-3 pb-4 pt-2">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16 gap-3">
              <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor:accentColor+"60",borderTopColor:accentColor }}/>
              <p className="text-slate-500 text-sm">Yuklanmoqda...</p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {displayed.map((user, idx) => {
                const isMe = user.name === username;
                const tier = getTier(user.score);
                return (
                  <div key={user.name}
                    className="lb-row flex items-center gap-3 p-3 rounded-2xl border transition-all"
                    style={{
                      animationDelay: `${Math.min(idx * 30, 300)}ms`,
                      background: isMe ? accentColor+"10" : user.rank <= 3 ? tier.color+"08" : "rgba(15,23,42,0.8)",
                      borderColor: isMe ? accentColor+"55" : user.rank <= 3 ? tier.color+"30" : "rgba(51,65,85,0.4)",
                      boxShadow: isMe ? `0 0 20px ${accentColor}15` : user.rank === 1 ? `0 0 12px ${tier.glow}25` : undefined,
                    }}>
                    {/* Rank badge */}
                    <div className="flex flex-col items-center gap-0.5 w-8 flex-shrink-0">
                      {user.rank === 1 ? <span className="text-xl">🥇</span>
                      : user.rank === 2 ? <span className="text-xl">🥈</span>
                      : user.rank === 3 ? <span className="text-xl">🥉</span>
                      : <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black text-slate-400 bg-slate-800 border border-slate-700">#{user.rank}</div>}
                      <RankChange cur={user.rank} prev={user.prevRank}/>
                    </div>

                    {/* Avatar */}
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base font-bold flex-shrink-0 relative"
                      style={{ background:tier.color+"20",color:tier.color,border:`1px solid ${tier.color}33` }}>
                      {user.name[0].toUpperCase()}
                      {user.online && <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-[#030712]"/>}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className={`text-sm font-bold truncate ${isMe?"text-white":"text-slate-200"}`}>
                          {user.name}{isMe?" (Siz)":""}
                        </p>
                        {user.premium && <span className="text-[9px] text-amber-400">👑</span>}
                        {user.online && <span className="text-[8px] text-green-400 font-bold">● LIVE</span>}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[9px] text-amber-400">⭐ {user.stars}</span>
                        <span className="text-[9px] text-slate-600">·</span>
                        <span className="text-[9px] text-slate-500">{tier.label}</span>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-black" style={{ color:user.rank<=3?tier.color:isMe?accentColor:"#94a3b8" }}>
                        {user.score.toLocaleString()}
                      </p>
                      <p className="text-[9px] text-slate-600">ball</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Scoring info */}
          <div className="mt-4 p-4 rounded-2xl border border-slate-800/30 relative overflow-hidden" style={{ background:"rgba(10,15,30,0.7)" }}>
            <div className="absolute top-0 left-0 right-0 h-px" style={{ background:"linear-gradient(90deg,transparent,rgba(245,158,11,0.3),transparent)" }}/>
            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-500 mb-3">⚡ Ball qanday hisoblanadi?</p>
            <div className="space-y-2">
              {[
                { icon:"⭐", label:"Har 1 yulduz",  val:"2 ball",    color:"#f59e0b" },
                { icon:"💬", label:"Har xabar",      val:"3 ball",    color:"#22d3ee" },
                { icon:"👑", label:"Premium obuna",  val:"+500 ball", color:"#a78bfa" },
              ].map((r,i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{r.icon} {r.label}</span>
                  <span className="text-xs font-black px-2 py-0.5 rounded-full" style={{ background:`${r.color}15`,color:r.color }}>{r.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
