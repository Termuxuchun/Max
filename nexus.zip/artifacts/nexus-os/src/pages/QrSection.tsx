import { useState, useRef, useEffect } from "react";
import { Download, Share2, Copy, Check, QrCode, Link, User, Smartphone, Wifi, Mail } from "lucide-react";

interface Props { username: string; accentColor: string; }

type QrType = "profile" | "link" | "wifi" | "text" | "contact";

const QR_TYPES: { id: QrType; label: string; icon: string; placeholder: string }[] = [
  { id: "profile", label: "Profil",    icon: "👤", placeholder: "@username" },
  { id: "link",    label: "Havola",    icon: "🔗", placeholder: "https://..." },
  { id: "wifi",    label: "Wi-Fi",     icon: "📶", placeholder: "SSID nomi" },
  { id: "text",    label: "Matn",      icon: "📝", placeholder: "Istalgan matn..." },
  { id: "contact", label: "Kontakt",   icon: "📇", placeholder: "Ism yoki telefon" },
];

function generateQRMatrix(text: string, size = 21): boolean[][] {
  const matrix: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));
  const seed = text.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const rng = (i: number) => Math.sin(seed * (i + 1) * 9301 + 49297) * 233280 % 1 > 0.5;

  // Finder patterns (corners)
  const drawFinder = (row: number, col: number) => {
    for (let r = 0; r < 7; r++) for (let c = 0; c < 7; c++) {
      matrix[row + r][col + c] = r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4);
    }
  };
  drawFinder(0, 0);
  drawFinder(0, size - 7);
  drawFinder(size - 7, 0);

  // Timing patterns
  for (let i = 8; i < size - 8; i++) {
    matrix[6][i] = i % 2 === 0;
    matrix[i][6] = i % 2 === 0;
  }

  // Data modules (pseudo-random based on input text)
  let idx = 0;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (!matrix[r][c] && !(r < 8 && c < 8) && !(r < 8 && c >= size - 8) && !(r >= size - 8 && c < 8) && r !== 6 && c !== 6) {
        matrix[r][c] = rng(idx++);
      }
    }
  }
  return matrix;
}

function QRCanvas({ value, size = 200, color, bg }: { value: string; size?: number; color: string; bg?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !value) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const matrix = generateQRMatrix(value);
    const cellSize = size / matrix.length;
    const padding = cellSize;

    canvas.width = size + padding * 2;
    canvas.height = size + padding * 2;

    ctx.fillStyle = bg || "#0f172a";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    matrix.forEach((row, r) => {
      row.forEach((cell, c) => {
        if (cell) {
          ctx.fillStyle = color;
          const x = c * cellSize + padding;
          const y = r * cellSize + padding;
          const radius = cellSize * 0.18;
          ctx.beginPath();
          ctx.moveTo(x + radius, y);
          ctx.lineTo(x + cellSize - radius, y);
          ctx.quadraticCurveTo(x + cellSize, y, x + cellSize, y + radius);
          ctx.lineTo(x + cellSize, y + cellSize - radius);
          ctx.quadraticCurveTo(x + cellSize, y + cellSize, x + cellSize - radius, y + cellSize);
          ctx.lineTo(x + radius, y + cellSize);
          ctx.quadraticCurveTo(x, y + cellSize, x, y + cellSize - radius);
          ctx.lineTo(x, y + radius);
          ctx.quadraticCurveTo(x, y, x + radius, y);
          ctx.closePath();
          ctx.fill();
        }
      });
    });

    // Center logo
    const logoSize = size * 0.18;
    const logoX = canvas.width / 2 - logoSize / 2;
    const logoY = canvas.height / 2 - logoSize / 2;
    ctx.fillStyle = bg || "#0f172a";
    ctx.beginPath();
    ctx.roundRect(logoX - 4, logoY - 4, logoSize + 8, logoSize + 8, 6);
    ctx.fill();
    ctx.fillStyle = color;
    ctx.font = `bold ${logoSize * 0.7}px monospace`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("⚡", canvas.width / 2, canvas.height / 2);
  }, [value, size, color, bg]);

  return <canvas ref={canvasRef} style={{ width: size + 40, height: size + 40, maxWidth: "100%" }} />;
}

export default function QrSection({ username, accentColor }: Props) {
  const [type, setType] = useState<QrType>("profile");
  const [value, setValue] = useState(`nexus://${username}`);
  const [customInput, setCustomInput] = useState("");
  const [wifiPass, setWifiPass] = useState("");
  const [copied, setCopied] = useState(false);
  const [qrColor, setQrColor] = useState(accentColor);
  const [history, setHistory] = useState<{ type: string; val: string; ts: number }[]>(() => {
    try { return JSON.parse(localStorage.getItem("nexus_qr_history") || "[]"); } catch { return []; }
  });

  const COLORS = [accentColor, "#22d3ee", "#4ade80", "#f59e0b", "#ec4899", "#a855f7", "#ffffff"];

  function getQrValue() {
    if (type === "profile") return `nexus://user/${username}${customInput ? "/" + customInput : ""}`;
    if (type === "link") return customInput || "https://nexus-os.uz";
    if (type === "wifi") return `WIFI:T:WPA;S:${customInput};P:${wifiPass};;`;
    if (type === "contact") return `BEGIN:VCARD\nVERSION:3.0\nFN:${customInput || username}\nEND:VCARD`;
    return customInput || `NEXUS_OS · @${username}`;
  }

  function handleGenerate() {
    const val = getQrValue();
    const entry = { type, val: val.slice(0, 50), ts: Date.now() };
    const next = [entry, ...history.slice(0, 9)];
    setHistory(next);
    localStorage.setItem("nexus_qr_history", JSON.stringify(next));
  }

  function copy() {
    navigator.clipboard.writeText(getQrValue()).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const qrValue = getQrValue();
  const currentType = QR_TYPES.find(t => t.id === type)!;

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      {/* Header */}
      <div className="flex-shrink-0 px-4 py-3 border-b border-slate-800/60 flex items-center gap-3"
        style={{ background: "rgba(15,23,42,0.97)", backdropFilter: "blur(12px)" }}>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
          style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}>
          <QrCode className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="text-sm font-bold text-white">QR Kod Generatori</p>
          <p className="text-[10px] text-slate-500">Profil · Havola · Wi-Fi · Kontakt</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* Type selector */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none pb-0.5">
          {QR_TYPES.map(t => (
            <button key={t.id} onClick={() => { setType(t.id); setCustomInput(""); setValue(getQrValue()); }}
              className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition"
              style={{ background: type === t.id ? accentColor + "22" : "rgba(30,41,59,0.5)", color: type === t.id ? accentColor : "#64748b", border: type === t.id ? `1px solid ${accentColor}44` : "1px solid transparent" }}>
              <span>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* QR Display */}
        <div className="flex flex-col items-center gap-4 py-4 px-4 rounded-3xl border border-slate-800/60"
          style={{ background: "rgba(15,23,42,0.8)" }}>
          <div className="rounded-2xl p-3 border border-slate-700/40" style={{ background: "#0f172a" }}>
            <QRCanvas value={qrValue} size={180} color={qrColor} bg="#0f172a" />
          </div>
          <p className="text-[10px] text-slate-500 text-center max-w-[220px] truncate">{qrValue}</p>

          {/* Color selector */}
          <div className="flex items-center gap-2">
            <p className="text-[9px] text-slate-600">Rang:</p>
            {COLORS.map(c => (
              <button key={c} onClick={() => setQrColor(c)}
                className="w-5 h-5 rounded-full transition hover:scale-110 active:scale-90"
                style={{ background: c, border: qrColor === c ? "2px solid white" : "1px solid rgba(255,255,255,0.1)" }} />
            ))}
          </div>

          {/* Action buttons */}
          <div className="flex gap-2 w-full">
            <button onClick={copy}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition border"
              style={{ background: copied ? "#16a34a22" : "rgba(30,41,59,0.6)", borderColor: copied ? "#16a34a44" : "rgba(51,65,85,0.4)", color: copied ? "#4ade80" : "#e2e8f0" }}>
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Nusxalandi!" : "Nusxalash"}
            </button>
            <button onClick={handleGenerate}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition"
              style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)`, color: "white" }}>
              <QrCode className="w-3.5 h-3.5" />
              Saqlash
            </button>
          </div>
        </div>

        {/* Input form */}
        <div className="space-y-2.5 p-4 rounded-2xl border border-slate-800/50" style={{ background: "rgba(15,23,42,0.6)" }}>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{currentType.icon} {currentType.label} sozlamalari</p>

          {type === "profile" && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-xs text-slate-300">@{username}</span>
                <span className="text-xs text-slate-600 ml-auto">Profil QR</span>
              </div>
            </div>
          )}

          {(type === "link" || type === "text" || type === "contact") && (
            <input value={customInput} onChange={e => setCustomInput(e.target.value)}
              placeholder={currentType.placeholder}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-600" />
          )}

          {type === "wifi" && (
            <div className="space-y-2">
              <input value={customInput} onChange={e => setCustomInput(e.target.value)}
                placeholder="Wi-Fi nomi (SSID)"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-600" />
              <input value={wifiPass} onChange={e => setWifiPass(e.target.value)}
                type="password" placeholder="Parol"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-600" />
            </div>
          )}
        </div>

        {/* History */}
        {history.length > 0 && (
          <div className="space-y-2">
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">📋 Tarix</p>
            {history.slice(0, 5).map((h, i) => (
              <button key={i} onClick={() => { const t = QR_TYPES.find(t => t.id === h.type); if (t) { setType(h.type as QrType); setCustomInput(h.val); } }}
                className="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-800/50 hover:border-slate-700/50 transition text-left"
                style={{ background: "rgba(15,23,42,0.6)" }}>
                <span className="text-base">{QR_TYPES.find(t => t.id === h.type)?.icon || "📎"}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-300 truncate">{h.val}</p>
                  <p className="text-[9px] text-slate-600">{new Date(h.ts).toLocaleTimeString("uz-UZ")}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
