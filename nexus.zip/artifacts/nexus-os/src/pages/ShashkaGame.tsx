import { useState, useEffect } from "react";

type Cell = 0 | 1 | 2;
type Board = Cell[][];

function createBoard(): Board {
  const b: Board = Array(8).fill(null).map(() => Array(8).fill(0) as Cell[]);
  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      if ((i + j) % 2 !== 0) {
        if (i < 3) b[i][j] = 2;
        if (i > 4) b[i][j] = 1;
      }
    }
  }
  return b;
}

function getValidMoves(board: Board, r: number, c: number): [number, number][] {
  const piece = board[r][c];
  if (!piece) return [];
  const moves: [number, number][] = [];
  const dirs = piece === 1 ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]];
  for (const [dr, dc] of dirs) {
    const nr = r + dr, nc = c + dc;
    if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && board[nr][nc] === 0) {
      moves.push([nr, nc]);
    }
    const jr = r + 2 * dr, jc = c + 2 * dc;
    if (jr >= 0 && jr < 8 && jc >= 0 && jc < 8 && board[nr][nc] !== 0 && board[nr][nc] !== piece && board[jr][jc] === 0) {
      moves.push([jr, jc]);
    }
  }
  return moves;
}

function botMove(board: Board): Board {
  const newBoard = board.map(r => [...r]) as Board;
  const botPieces: [number, number][] = [];
  for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) if (newBoard[i][j] === 2) botPieces.push([i, j]);
  const shuffled = botPieces.sort(() => Math.random() - 0.5);
  for (const [r, c] of shuffled) {
    const moves = getValidMoves(newBoard, r, c);
    if (moves.length) {
      const [nr, nc] = moves[Math.floor(Math.random() * moves.length)];
      if (Math.abs(nr - r) === 2) newBoard[Math.floor((r + nr) / 2)][Math.floor((c + nc) / 2)] = 0;
      newBoard[nr][nc] = 2;
      newBoard[r][c] = 0;
      return newBoard;
    }
  }
  return newBoard;
}

export default function ShashkaGame() {
  const [board, setBoard] = useState<Board>(createBoard());
  const [selected, setSelected] = useState<[number, number] | null>(null);
  const [validMoves, setValidMoves] = useState<[number, number][]>([]);
  const [turn, setTurn] = useState<1 | 2>(1);
  const [status, setStatus] = useState("🟢 SIZNING NAVBATINGIZ (OQ)");
  const [gameOver, setGameOver] = useState(false);

  useEffect(() => {
    if (turn === 2 && !gameOver) {
      setStatus("🔴 BOT O'YLAMOQDA...");
      const timer = setTimeout(() => {
        const newBoard = botMove(board);
        setBoard(newBoard);
        const whites = newBoard.flat().filter(c => c === 1).length;
        const blacks = newBoard.flat().filter(c => c === 2).length;
        if (whites === 0) { setStatus("💀 BOT YUTDI!"); setGameOver(true); return; }
        if (blacks === 0) { setStatus("🏆 SIZ YUTDINGIZ!"); setGameOver(true); return; }
        setTurn(1);
        setStatus("🟢 SIZNING NAVBATINGIZ (OQ)");
      }, 700);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [turn, gameOver]);

  function handleCellClick(r: number, c: number) {
    if (turn !== 1 || gameOver) return;
    const piece = board[r][c];
    if (selected) {
      const isMove = validMoves.some(([mr, mc]) => mr === r && mc === c);
      if (isMove) {
        const newBoard = board.map(row => [...row]) as Board;
        const [sr, sc] = selected;
        if (Math.abs(r - sr) === 2) newBoard[Math.floor((sr + r) / 2)][Math.floor((sc + c) / 2)] = 0;
        newBoard[r][c] = 1;
        newBoard[sr][sc] = 0;
        setBoard(newBoard);
        setSelected(null);
        setValidMoves([]);
        const blacks = newBoard.flat().filter(c => c === 2).length;
        if (blacks === 0) { setStatus("🏆 SIZ YUTDINGIZ!"); setGameOver(true); return; }
        setTurn(2);
        return;
      }
      setSelected(null);
      setValidMoves([]);
    }
    if (piece === 1) {
      const moves = getValidMoves(board, r, c);
      setSelected([r, c]);
      setValidMoves(moves);
    }
  }

  function reset() {
    setBoard(createBoard());
    setSelected(null);
    setValidMoves([]);
    setTurn(1);
    setStatus("🟢 SIZNING NAVBATINGIZ (OQ)");
    setGameOver(false);
  }

  const whites = board.flat().filter(c => c === 1).length;
  const blacks = board.flat().filter(c => c === 2).length;

  return (
    <div className="w-full h-full flex flex-col items-center justify-start overflow-y-auto py-4 px-2">
      <h2 className="text-lg font-black font-mono mb-1" style={{color:"#0f0", textShadow:"0 0 10px #0f0"}}>
        🎮 CYBER_NEXUS // SHASHKA_OS
      </h2>
      <div className="flex gap-4 text-xs font-mono mb-3">
        <span className="text-green-400">⬜ OQ (Siz): {whites}</span>
        <span className="text-slate-400">⬛ QO'RA (Bot): {blacks}</span>
      </div>
      <p className="text-sm font-mono mb-3" style={{color: turn === 1 ? "#0f0" : "#f00"}}>{status}</p>

      <div className="grid gap-0" style={{gridTemplateColumns:"repeat(8, 1fr)", width:"min(100%, 360px)", border:"3px solid #0f0", boxShadow:"0 0 20px #0f0"}}>
        {board.map((row, r) =>
          row.map((cell, c) => {
            const isDark = (r + c) % 2 !== 0;
            const isSelected = selected && selected[0] === r && selected[1] === c;
            const isValid = validMoves.some(([mr, mc]) => mr === r && mc === c);
            return (
              <div
                key={`${r}-${c}`}
                onClick={() => handleCellClick(r, c)}
                className="flex items-center justify-center cursor-pointer transition"
                style={{
                  width:"100%", aspectRatio:"1",
                  background: isSelected ? "rgba(0,255,0,0.3)" : isValid ? "rgba(0,255,0,0.15)" : isDark ? "#2d2d2d" : "#111",
                  border: isValid ? "1px solid #0f0" : "none"
                }}
              >
                {cell === 1 && (
                  <div className="rounded-full" style={{width:"70%", height:"70%", background:"radial-gradient(circle, #fff 30%, #aaa)", boxShadow:"0 2px 4px rgba(0,0,0,0.5)"}} />
                )}
                {cell === 2 && (
                  <div className="rounded-full" style={{width:"70%", height:"70%", background:"radial-gradient(circle, #555 30%, #222)", boxShadow:"0 2px 4px rgba(0,0,0,0.5)", border:"1px solid #0f0"}} />
                )}
              </div>
            );
          })
        )}
      </div>

      <button
        onClick={reset}
        className="mt-4 px-6 py-2 rounded-xl font-bold text-sm transition"
        style={{background:"transparent", border:"2px solid #0f0", color:"#0f0", fontFamily:"monospace"}}
      >
        🔄 QAYTA BOSHLASH
      </button>
    </div>
  );
}
