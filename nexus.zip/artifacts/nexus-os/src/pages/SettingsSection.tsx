import { useState, useEffect, useRef } from "react";
import { ref, get, update, remove, set } from "firebase/database";
import { db } from "../firebase";
import { compressAndUpload } from "../lib/uploadMedia";
import PremiumSection from "./PremiumSection";
import { useLang } from "../lib/LangContext";
import { LANG_NAMES, LANG_FLAGS, type Lang } from "../lib/i18n";
import { getDeviceInfo } from "../lib/device";

interface SettingsSectionProps {
  username: string;
  accentColor: string;
  onColorChange: (color: string) => void;
  onLogout: () => void;
}

const THEMES = [
  { name: "Cyan", color: "#22d3ee" },
  { name: "Purple", color: "#a855f7" },
  { name: "Green", color: "#22c55e" },
  { name: "Rose", color: "#f43f5e" },
  { name: "Orange", color: "#f97316" },
  { name: "Indigo", color: "#6366f1" },
  { name: "Amber", color: "#f59e0b" },
  { name: "Pink", color: "#ec4899" },
  { name: "Teal", color: "#14b8a6" },
  { name: "Lime", color: "#84cc16" },
  { name: "Red", color: "#ef4444" },
  { name: "Sky", color: "#38bdf8" },
];

const WALLPAPERS = [
  { name: "Qorong'i", value: "#030712" },
  { name: "Navy", value: "#0a0f1e" },
  { name: "Qoʻshimcha", value: "#0d0d0d" },
  { name: "Ko'k-Qora", value: "#020817" },
];

type SubTab = "profile" | "appearance" | "animation" | "privacy" | "notifications" | "security" | "premium" | "about" | "language" | "chat" | "keyboard" | "storage" | "export" | "accessibility" | "calls" | "shortcuts" | "network";

export const BADGES = [
  { id: "crown",     emoji: "👑", label: "Qirol",      color: "#f59e0b", anim: "animate-pulse",  glow: "#f59e0b" },
  { id: "fire",      emoji: "🔥", label: "Olov",       color: "#ef4444", anim: "animate-bounce", glow: "#ef4444" },
  { id: "lightning", emoji: "⚡", label: "Chaqmoq",    color: "#eab308", anim: "animate-ping",   glow: "#eab308" },
  { id: "star",      emoji: "🌟", label: "Yulduz",     color: "#f59e0b", anim: "animate-spin",   glow: "#f59e0b" },
  { id: "diamond",   emoji: "💎", label: "Olmos",      color: "#22d3ee", anim: "animate-pulse",  glow: "#22d3ee" },
  { id: "rocket",    emoji: "🚀", label: "Raketa",     color: "#8b5cf6", anim: "animate-bounce", glow: "#8b5cf6" },
  { id: "dragon",    emoji: "🐉", label: "Dragon",     color: "#ef4444", anim: "animate-pulse",  glow: "#ef4444" },
  { id: "unicorn",   emoji: "🦄", label: "Unicorn",    color: "#ec4899", anim: "animate-bounce", glow: "#ec4899" },
  { id: "moon",      emoji: "🌙", label: "Oy",         color: "#94a3b8", anim: "animate-pulse",  glow: "#c4b5fd" },
  { id: "sun",       emoji: "☀️", label: "Quyosh",     color: "#fbbf24", anim: "animate-spin",   glow: "#fbbf24" },
  { id: "trophy",    emoji: "🏆", label: "Chempion",   color: "#f59e0b", anim: "animate-bounce", glow: "#f59e0b" },
  { id: "crystal",   emoji: "🔮", label: "Kristal",    color: "#a855f7", anim: "animate-pulse",  glow: "#a855f7" },
  { id: "eagle",     emoji: "🦅", label: "Burgut",     color: "#64748b", anim: "animate-bounce", glow: "#94a3b8" },
  { id: "wave",      emoji: "🌊", label: "To'lqin",    color: "#0ea5e9", anim: "animate-pulse",  glow: "#0ea5e9" },
  { id: "butterfly", emoji: "🦋", label: "Kapalak",    color: "#ec4899", anim: "animate-bounce", glow: "#ec4899" },
  { id: "magic",     emoji: "💫", label: "Sehrli",     color: "#f59e0b", anim: "animate-spin",   glow: "#f59e0b" },
  { id: "target",    emoji: "🎯", label: "Nishon",     color: "#ef4444", anim: "animate-pulse",  glow: "#ef4444" },
  { id: "ghost",     emoji: "👻", label: "Arvoq",      color: "#94a3b8", anim: "animate-bounce", glow: "#e2e8f0" },
  { id: "alien",     emoji: "👾", label: "Kosmik",     color: "#22c55e", anim: "animate-pulse",  glow: "#22c55e" },
  { id: "ninja",     emoji: "🥷", label: "Ninja",      color: "#475569", anim: "animate-pulse",  glow: "#94a3b8" },
  { id: "wolf",      emoji: "🐺", label: "Bo'ri",      color: "#64748b", anim: "animate-bounce", glow: "#94a3b8" },
  { id: "phoenix",   emoji: "🦜", label: "Feniks",     color: "#f97316", anim: "animate-pulse",  glow: "#f97316" },
  { id: "ice",       emoji: "❄️", label: "Muz",        color: "#22d3ee", anim: "animate-pulse",  glow: "#bae6fd" },
  { id: "thunder",   emoji: "⛈️", label: "Bo'ron",     color: "#94a3b8", anim: "animate-bounce", glow: "#94a3b8" },
  // 16 yangi badge
  { id: "angel",     emoji: "😇", label: "Farishta",   color: "#e0e7ff", anim: "animate-pulse",  glow: "#c7d2fe" },
  { id: "demon",     emoji: "😈", label: "Iblis",      color: "#7c3aed", anim: "animate-bounce", glow: "#7c3aed" },
  { id: "cyber",     emoji: "🤖", label: "Kibor",      color: "#06b6d4", anim: "animate-pulse",  glow: "#06b6d4" },
  { id: "king",      emoji: "🤴", label: "Shahzoda",   color: "#fbbf24", anim: "animate-bounce", glow: "#fbbf24" },
  { id: "witch",     emoji: "🧙", label: "Sehrgar",    color: "#a855f7", anim: "animate-spin",   glow: "#a855f7" },
  { id: "vampire",   emoji: "🧛", label: "Vampir",     color: "#dc2626", anim: "animate-pulse",  glow: "#dc2626" },
  { id: "shark",     emoji: "🦈", label: "Akula",      color: "#0ea5e9", anim: "animate-bounce", glow: "#0ea5e9" },
  { id: "lion",      emoji: "🦁", label: "Sher",       color: "#f59e0b", anim: "animate-pulse",  glow: "#f59e0b" },
  { id: "panda",     emoji: "🐼", label: "Panda",      color: "#e2e8f0", anim: "animate-bounce", glow: "#f1f5f9" },
  { id: "snake",     emoji: "🐍", label: "Ilon",       color: "#22c55e", anim: "animate-pulse",  glow: "#22c55e" },
  { id: "skull",     emoji: "💀", label: "Kalla",      color: "#f1f5f9", anim: "animate-bounce", glow: "#e2e8f0" },
  { id: "joker",     emoji: "🃏", label: "Joker",      color: "#facc15", anim: "animate-spin",   glow: "#facc15" },
  { id: "samurai",   emoji: "⚔️", label: "Samuray",    color: "#dc2626", anim: "animate-pulse",  glow: "#dc2626" },
  { id: "galaxy2",   emoji: "🌌", label: "Galaktika",  color: "#818cf8", anim: "animate-pulse",  glow: "#818cf8" },
  { id: "toxic",     emoji: "☢️", label: "Toksik",     color: "#84cc16", anim: "animate-ping",   glow: "#84cc16" },
  { id: "vip",       emoji: "🎖️", label: "VIP",        color: "#f59e0b", anim: "animate-bounce", glow: "#f59e0b" },
];

const PROFILE_BGS = [
  { id: "", name: "Standart", className: "" },
  { id: "pbg-aurora", name: "🟢 Aurora", className: "pbg-aurora" },
  { id: "pbg-stars", name: "⭐ Yulduzlar", className: "pbg-stars" },
  { id: "pbg-cyber", name: "💻 Cyber", className: "pbg-cyber" },
  { id: "pbg-neon", name: "🌆 Neon", className: "pbg-neon" },
  { id: "pbg-sunset", name: "🌅 Quyosh", className: "pbg-sunset" },
  { id: "pbg-ocean", name: "🌊 Okean", className: "pbg-ocean" },
  { id: "pbg-forest", name: "🌲 O'rmon", className: "pbg-forest" },
  { id: "pbg-galaxy", name: "🌌 Galaxy", className: "pbg-galaxy" },
  { id: "pbg-fire", name: "🔥 Olov", className: "pbg-fire" },
  { id: "pbg-ice", name: "🧊 Muz", className: "pbg-ice" },
  { id: "pbg-hologram", name: "🔷 Hologram", className: "pbg-hologram" },
  { id: "pbg-void", name: "🌑 Void", className: "pbg-void" },
];

const WHO_CAN_MSG: { id: "all" | "contacts" | "nobody"; label: string; desc: string; premiumOnly?: boolean }[] = [
  { id: "all", label: "Hammasi", desc: "Har kim sizga yoza oladi" },
  { id: "contacts", label: "Faqat kontaktlar", desc: "Faqat kontaktlaringizdagi odamlar" },
  { id: "nobody", label: "Hech kim", desc: "Hech kim sizga yoza olmaydi (faqat Premium)", premiumOnly: true },
];

export default function SettingsSection({ username, accentColor, onColorChange, onLogout }: SettingsSectionProps) {
  const { lang, setLang, t } = useLang();
  const [sub, setSub] = useState<SubTab>("profile");
  const [toast, setToast] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [currentPass, setCurrentPass] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [premiumData, setPremiumData] = useState<any>(null);
  const [activeBadge, setActiveBadge] = useState<string>("");
  const [openSec, setOpenSec] = useState<Set<string>>(new Set(["badges"]));
  const togSec = (id: string) => setOpenSec(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });

  // Animation settings
  const [chatBubbleAnim, setChatBubbleAnim] = useState(() => localStorage.getItem("nx_bubble") || "slide");
  const [sendEffect, setSendEffect] = useState(() => localStorage.getItem("nx_send_fx") || "none");
  const [animSpeed, setAnimSpeed] = useState(() => localStorage.getItem("nx_anim_speed") || "normal");
  const [auraColor, setAuraColor] = useState("#22d3ee");
  const [auraIntensity, setAuraIntensity] = useState("medium");
  const [usernameEffect, setUsernameEffect] = useState("none");
  const [entryAnim, setEntryAnim] = useState(() => localStorage.getItem("nx_entry_anim") || "slide");
  const [statusAnim, setStatusAnim] = useState(() => localStorage.getItem("nx_status_anim") || "pulse");
  const [reactionStyle, setReactionStyle] = useState(() => localStorage.getItem("nx_reaction") || "default");
  const [profileGradient, setProfileGradient] = useState("");
  const [typingStyle, setTypingStyle] = useState(() => localStorage.getItem("nx_typing_style") || "dots");
  const [notifAnim, setNotifAnim] = useState(() => localStorage.getItem("nx_notif_anim") || "slide");
  const fileRef = useRef<HTMLInputElement>(null);

  // Settings state
  const [notifSound, setNotifSound] = useState(() => localStorage.getItem("nexus_notif_sound") !== "off");
  const [notifDesktop, setNotifDesktop] = useState(() => Notification.permission === "granted");
  const [msgPreview, setMsgPreview] = useState(() => localStorage.getItem("nexus_msg_preview") !== "off");
  const [readReceipts, setReadReceipts] = useState(() => localStorage.getItem("nexus_read_receipts") !== "off");
  const [onlineVisible, setOnlineVisible] = useState(() => localStorage.getItem("nexus_online_visible") !== "off");
  const [fontSize, setFontSize] = useState(() => localStorage.getItem("nexus_font_size") || "medium");
  const [bgBlur, setBgBlur] = useState(() => localStorage.getItem("nexus_bg_blur") !== "off");
  const [animEnabled, setAnimEnabled] = useState(() => localStorage.getItem("nexus_anim") !== "off");
  const [compactMode, setCompactMode] = useState(() => localStorage.getItem("nexus_compact") === "on");
  const [enterSend, setEnterSend] = useState(() => localStorage.getItem("nexus_enter_send") !== "off");
  const [linkPreview, setLinkPreview] = useState(() => localStorage.getItem("nexus_link_preview") !== "off");
  const [typingIndicator, setTypingIndicator] = useState(() => localStorage.getItem("nexus_typing") !== "off");
  const [autoPlay, setAutoPlay] = useState(() => localStorage.getItem("nexus_autoplay") !== "off");
  const [wallpaper, setWallpaper] = useState(() => localStorage.getItem("nexus_wallpaper") || "#030712");
  const [selectedLang, setSelectedLang] = useState(() => localStorage.getItem("nexus_lang") || "uz");
  const [profileBg, setProfileBg] = useState<string>("");
  const [whoCanMsg, setWhoCanMsg] = useState<"all" | "contacts" | "nobody">("all");
  const [customStatus, setCustomStatus] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [blockList, setBlockList] = useState<string[]>([]);
  const [blockInput, setBlockInput] = useState("");
  const [lastSeenVisible, setLastSeenVisible] = useState(() => localStorage.getItem("nexus_lastseen") !== "off");
  const [forwardHistory, setForwardHistory] = useState(() => localStorage.getItem("nexus_fwd_history") !== "off");
  const [nameFx, setNameFx] = useState(() => localStorage.getItem("nx_name_fx") || "none");
  const [msgSignature, setMsgSignature] = useState("");
  const [particlePreset, setParticlePreset] = useState(() => localStorage.getItem("nx_particle") || "none");
  const [sessionInfo] = useState(() => ({
    device: navigator.userAgent.includes("Mobile") ? "📱 Mobil" : "🖥️ Desktop",
    browser: navigator.userAgent.includes("Chrome") ? "Chrome" : navigator.userAgent.includes("Firefox") ? "Firefox" : "Browser",
    time: new Date().toLocaleString("uz-UZ")
  }));

  useEffect(() => {
    document.documentElement.style.fontSize = fontSize === "small" ? "14px" : fontSize === "large" ? "17px" : "16px";
  }, [fontSize]);

  useEffect(() => {
    get(ref(db, `users/${username}`)).then(snap => {
      if (snap.exists()) {
        const d = snap.val();
        setBio(d.bio || "");
        setAvatar(d.avatar || null);
        setProfileBg(d.profileBg || "");
        setWhoCanMsg((d.privacy?.whoCanMessage as any) || "all");
        setActiveBadge(d.badge || "");
        setCustomStatus(d.customStatus || "");
        setDisplayName(d.displayName || "");
        setBlockList(d.privacy?.blockList ? Object.values(d.privacy.blockList) as string[] : []);
        const animS = d.animSettings || {};
        if (animS.auraColor) setAuraColor(animS.auraColor);
        if (animS.auraIntensity) setAuraIntensity(animS.auraIntensity);
        if (animS.usernameEffect) setUsernameEffect(animS.usernameEffect);
        if (animS.profileGradient) setProfileGradient(animS.profileGradient);
        if (animS.nameFx) setNameFx(animS.nameFx);
        if (animS.msgSignature) setMsgSignature(animS.msgSignature);
        if (animS.particlePreset) setParticlePreset(animS.particlePreset);
      }
    });
    get(ref(db, `premium/${username}`)).then(snap => {
      setPremiumData(snap.exists() ? snap.val() : null);
    });
  }, [username]);


  const isPremiumFlag = premiumData && premiumData.expiresAt > Date.now();

  async function saveBadge(badgeId: string) {
    if (!isPremiumFlag) { showToast("🔒 Badge — faqat Premium uchun!"); return; }
    const newBadge = badgeId === activeBadge ? "" : badgeId;
    setActiveBadge(newBadge);
    await update(ref(db, `users/${username}`), { badge: newBadge || null });
    showToast(newBadge ? `✅ Badge tanlandi: ${BADGES.find(b=>b.id===newBadge)?.label}` : "✅ Badge olib tashlandi");
  }

  async function saveProfileBg(bg: string) {
    setProfileBg(bg);
    await update(ref(db, `users/${username}`), { profileBg: bg || null });
    showToast("✅ Background saqlandi");
  }

  async function saveAnimSetting(key: string, value: string, premiumOnly = false) {
    if (premiumOnly && !isPremiumFlag) { showToast("🔒 Bu xususiyat faqat Premium uchun!"); return; }
    await update(ref(db, `users/${username}/animSettings`), { [key]: value });
    showToast("✅ Saqlandi");
  }

  async function saveWhoCanMsg(v: "all" | "contacts" | "nobody") {
    if (v === "nobody" && !isPremiumFlag) {
      showToast("🔒 'Hech kim' — faqat Premium uchun");
      return;
    }
    setWhoCanMsg(v);
    await update(ref(db, `users/${username}/privacy`), { whoCanMessage: v });
    showToast("✅ Saqlandi");
  }

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  }

  function handleColorSelect(color: string) {
    onColorChange(color);
    localStorage.setItem("nexus_theme", color);
    showToast("✅ Rang saqlandi!");
  }

  function tog(key: string, state: boolean, setter: (v: boolean) => void) {
    setter(!state);
    localStorage.setItem(key, !state ? "on" : "off");
    showToast(!state ? "✅ Yoqildi" : "🔕 O'chirildi");
  }

  async function handleChangePassword() {
    if (!currentPass || !newPass || !confirmPass) { showToast("⚠️ Barcha maydonlarni to'ldiring!"); return; }
    if (newPass !== confirmPass) { showToast("⚠️ Yangi parollar mos kelmaydi!"); return; }
    if (newPass.length < 4) { showToast("⚠️ Parol kamida 4 belgi!"); return; }
    const snap = await get(ref(db, `users/${username}`));
    if (!snap.exists()) return;
    if (String(snap.val().password) !== currentPass) { showToast("🛑 Joriy parol noto'g'ri!"); return; }
    await update(ref(db, `users/${username}`), { password: newPass });
    setCurrentPass(""); setNewPass(""); setConfirmPass("");
    showToast("🔐 Parol o'zgartirildi!");
  }

  async function handleDeleteAccount() {
    if (!confirm("DIQQAT! Hisobingiz va barcha ma'lumotlaringiz o'chiriladi!")) return;
    const pass = prompt("Tasdiqlash uchun parolingizni kiriting:");
    const snap = await get(ref(db, `users/${username}`));
    if (!snap.exists() || String(snap.val().password) !== pass) { showToast("🛑 Parol noto'g'ri!"); return; }
    await remove(ref(db, `users/${username}`));
    await remove(ref(db, `status/${username}`));
    localStorage.clear();
    onLogout();
  }

  async function saveBio() {
    await update(ref(db, `users/${username}`), { bio });
    showToast("✅ Bio saqlandi!");
  }

  async function saveCustomStatus() {
    await update(ref(db, `users/${username}`), { customStatus: customStatus.trim() || null });
    showToast("✅ Status saqlandi!");
  }

  async function saveDisplayName() {
    await update(ref(db, `users/${username}`), { displayName: displayName.trim() || null });
    showToast("✅ Ism saqlandi!");
  }

  async function blockUser() {
    if (!blockInput.trim()) return;
    const key = `block_${Date.now()}`;
    await update(ref(db, `users/${username}/privacy/blockList`), { [key]: blockInput.trim() });
    setBlockList(prev => [...prev, blockInput.trim()]);
    setBlockInput("");
    showToast(`✅ @${blockInput.trim()} bloklandi`);
  }

  async function unblockUser(user: string) {
    const snap = await get(ref(db, `users/${username}/privacy/blockList`));
    if (!snap.exists()) return;
    const entries = Object.entries(snap.val() as Record<string, string>);
    const entry = entries.find(([, v]) => v === user);
    if (entry) {
      await remove(ref(db, `users/${username}/privacy/blockList/${entry[0]}`));
      setBlockList(prev => prev.filter(u => u !== user));
      showToast(`✅ @${user} blokdan chiqarildi`);
    }
  }

  function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) { showToast("⚠️ Rasm 10MB dan kichik bo'lishi shart!"); return; }
    setAvatarUploading(true);
    compressAndUpload(`avatars/${username}`, file, undefined, 400, 0.85)
      .then(async url => {
        await update(ref(db, `users/${username}`), { avatar: url });
        setAvatar(url);
        setAvatarUploading(false);
        showToast("✅ Profil rasmi yangilandi!");
      })
      .catch(err => {
        setAvatarUploading(false);
        showToast("⚠️ Yuklashda xato: " + (err instanceof Error ? err.message : String(err)));
      });
  }

  async function removeAvatar() {
    await update(ref(db, `users/${username}`), { avatar: null });
    setAvatar(null);
    showToast("✅ Rasm o'chirildi");
  }

  const isPremium = premiumData && premiumData.expiresAt > Date.now();
  const daysLeft = isPremium ? Math.ceil((premiumData.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)) : 0;

  // NEW: accessibility state
  const [reducedMotion, setReducedMotion] = useState(() => localStorage.getItem("nx_reduced_motion") === "on");
  const [highContrast, setHighContrast] = useState(() => localStorage.getItem("nx_high_contrast") === "on");
  const [largeButtons, setLargeButtons] = useState(() => localStorage.getItem("nx_large_buttons") === "on");
  const [screenReaderMode, setScreenReaderMode] = useState(() => localStorage.getItem("nx_screen_reader") === "on");
  const [fontScale, setFontScale] = useState<"90" | "100" | "115" | "130">(() => (localStorage.getItem("nx_font_scale") as any) || "100");

  // NEW: call settings state
  const [callQuality, setCallQuality] = useState<"auto" | "hd" | "sd">(() => (localStorage.getItem("nx_call_quality") as any) || "auto");
  const [ringtone, setRingtone] = useState(() => localStorage.getItem("nx_ringtone") || "cinnamon");
  const [callVibrate, setCallVibrate] = useState(() => localStorage.getItem("nx_call_vibrate") !== "off");
  const [noiseCancellation, setNoiseCancellation] = useState(() => localStorage.getItem("nx_noise_cancel") !== "off");
  const [callSpeaker, setCallSpeaker] = useState(() => localStorage.getItem("nx_call_speaker") === "on");
  const [exportProgress, setExportProgress] = useState(0);
  const [isExporting, setIsExporting] = useState(false);

  async function handleExport(format: "json" | "txt") {
    setIsExporting(true);
    setExportProgress(0);
    try {
      const snap = await get(ref(db, `users/${username}`));
      setExportProgress(30);
      const userData = snap.exists() ? snap.val() : {};
      setExportProgress(60);
      const exportData = {
        exported_at: new Date().toISOString(),
        username,
        profile: { bio: userData.bio || "", displayName: userData.displayName || "", customStatus: userData.customStatus || "" },
        settings: { theme: accentColor, fontSize, language: lang },
        note: "NEXUS_OS — ConnectUz export"
      };
      setExportProgress(90);
      let content = "", filename = "", mime = "";
      if (format === "json") {
        content = JSON.stringify(exportData, null, 2);
        filename = `nexus_export_${username}_${Date.now()}.json`;
        mime = "application/json";
      } else {
        content = `NEXUS_OS Ma'lumotlar Eksporti\n${"=".repeat(40)}\nFoydalanuvchi: @${username}\nSana: ${new Date().toLocaleString("uz-UZ")}\n\nProfil:\n  Bio: ${exportData.profile.bio || "—"}\n  Ism: ${exportData.profile.displayName || "—"}\n  Status: ${exportData.profile.customStatus || "—"}\n\nSozlamalar:\n  Rang: ${accentColor}\n  Shrift: ${fontSize}\n  Til: ${lang}\n`;
        filename = `nexus_export_${username}_${Date.now()}.txt`;
        mime = "text/plain";
      }
      const blob = new Blob([content], { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = filename; a.click();
      URL.revokeObjectURL(url);
      setExportProgress(100);
      showToast(`✅ ${format.toUpperCase()} yuklab olindi!`);
    } catch {
      showToast("❌ Eksport xatosi!");
    } finally {
      setTimeout(() => { setIsExporting(false); setExportProgress(0); }, 1500);
    }
  }

  const subItems: { id: SubTab; icon: string; label: string; isNew?: boolean }[] = [
    { id: "profile",       icon: "👤", label: t("profile") },
    { id: "appearance",    icon: "🎨", label: t("appearance") },
    { id: "animation",     icon: "✨", label: t("animation") },
    { id: "notifications", icon: "🔔", label: t("notifications") },
    { id: "privacy",       icon: "🔒", label: t("privacy") },
    { id: "security",      icon: "🛡️", label: t("security") },
    { id: "chat",          icon: "💬", label: t("chatSettings") },
    { id: "keyboard",      icon: "⌨️", label: t("keyboard") },
    { id: "storage",       icon: "💾", label: t("storage") },
    { id: "language",      icon: "🌐", label: t("language") },
    { id: "export",        icon: "📤", label: "Eksport", isNew: true },
    { id: "accessibility", icon: "♿", label: "Aksesibillik", isNew: true },
    { id: "calls",         icon: "📞", label: "Qo'ng'iroq", isNew: true },
    { id: "shortcuts",     icon: "⚡", label: "Yorliqlar", isNew: true },
    { id: "network",       icon: "🌐", label: "Tarmoq", isNew: true },
    { id: "premium",       icon: "👑", label: t("premium") },
    { id: "about",         icon: "ℹ️", label: t("about") },
  ];

  function Toggle({ label, desc, value, onToggle }: { label: string; desc?: string; value: boolean; onToggle: () => void }) {
    return (
      <div className="flex items-center justify-between py-3 border-b border-slate-800/50 last:border-0">
        <div>
          <p className="text-sm text-slate-200">{label}</p>
          {desc && <p className="text-xs text-slate-500 mt-0.5">{desc}</p>}
        </div>
        <button onClick={onToggle} className="w-12 h-6 rounded-full transition-all relative flex-shrink-0"
          style={{background: value ? accentColor : "#1e293b"}}>
          <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-all ${value ? "translate-x-6" : "translate-x-0.5"}`} />
        </button>
      </div>
    );
  }

  function GhostModeToggle({ username: u, showToast: st }: { username: string; showToast: (m: string) => void }) {
    const [ghost, setGhost] = useState(() => localStorage.getItem("nx_ghost_mode") === "on");
    async function toggle() {
      const next = !ghost;
      setGhost(next);
      localStorage.setItem("nx_ghost_mode", next ? "on" : "off");
      if (next) {
        await update(ref(db, `status/${u}`), { state: "offline" });
        st("👻 Arvoq rejimi yoqildi — siz ko'rinmaysiz");
      } else {
        await update(ref(db, `status/${u}`), { state: "online", lastSeen: Date.now() });
        st("✅ Arvoq rejimi o'chirildi — siz onlayn ko'rinasiz");
      }
    }
    return (
      <div className={`flex items-center justify-between py-3 border-b border-slate-800/50 rounded-xl px-2 mb-1 transition ${ghost ? "bg-slate-800/40" : ""}`}>
        <div>
          <p className="text-sm text-slate-200 flex items-center gap-1.5">
            <span className={ghost ? "animate-bounce" : ""}>👻</span>
            Arvoq rejimi
            {ghost && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full text-white bg-slate-600">YOQILGAN</span>}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Hech kim sizni onlayn ko'ra olmaydi</p>
        </div>
        <button onClick={toggle} className="w-12 h-6 rounded-full transition-all relative flex-shrink-0"
          style={{background: ghost ? "#475569" : "#1e293b"}}>
          <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-all ${ghost ? "translate-x-6" : "translate-x-0.5"}`} />
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Sub-nav */}
      <div className="w-44 flex-shrink-0 border-r border-slate-800/50 p-2 space-y-0.5 overflow-y-auto" style={{ background: "rgba(5,8,18,0.6)" }}>
        {subItems.map(item => (
          <button key={item.id} onClick={() => setSub(item.id)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium transition-all relative ${sub === item.id ? "font-bold" : "text-slate-500 hover:text-slate-300 hover:bg-slate-900/60"}`}
            style={sub === item.id ? { color: accentColor, background: `${accentColor}15`, border: `1px solid ${accentColor}25` } : { border: "1px solid transparent" }}
          >
            {sub === item.id && <div className="absolute left-0 top-1/4 bottom-1/4 w-0.5 rounded-r-full" style={{ background: accentColor }} />}
            <span>{item.icon}</span>
            <span className="truncate flex-1 text-left">{item.label}</span>
            {item.isNew && <span className="text-[8px] font-black px-1.5 py-0.5 rounded-full text-black flex-shrink-0" style={{ background: accentColor }}>NEW</span>}
            {item.id === "premium" && isPremium && <span className="text-amber-400 text-[10px] ml-auto">✓</span>}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {toast && (
          <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm font-medium shadow-xl">
            {toast}
          </div>
        )}

        {/* ────── PROFILE ────── */}
        {sub === "profile" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">Profil</h2>

            {/* Avatar */}
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
              <p className="text-sm font-bold text-slate-300 mb-4">Profil rasmi</p>
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden flex items-center justify-center text-3xl font-black flex-shrink-0"
                    style={{background: avatar ? "transparent" : `linear-gradient(135deg, ${accentColor}, #6366f1)`}}>
                    {avatar
                      ? <img src={avatar} alt="avatar" className="w-full h-full object-cover" />
                      : username[0]?.toUpperCase()
                    }
                  </div>
                  {isPremium && (
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-[10px]">✓</div>
                  )}
                </div>
                <div className="space-y-2 flex-1">
                  <input ref={fileRef} type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
                  <button onClick={() => fileRef.current?.click()}
                    disabled={avatarUploading}
                    className="w-full py-2.5 rounded-xl text-xs font-bold border border-slate-700 text-slate-300 hover:bg-slate-800 transition disabled:opacity-50">
                    {avatarUploading ? "⏳ Yuklanmoqda..." : "📷 Rasm yuklash"}
                  </button>
                  {avatar && (
                    <button onClick={removeAvatar} className="w-full py-2 rounded-xl text-xs font-bold border border-rose-900/60 text-rose-500 hover:bg-rose-950/30 transition">
                      🗑️ O'chirish
                    </button>
                  )}
                  <p className="text-[9px] text-slate-600 font-mono">Max: 2MB · JPG, PNG, GIF</p>
                </div>
              </div>
            </div>

            {/* User info */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <p className="text-[10px] text-slate-500 font-mono uppercase">Username</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <p className="text-xl font-black text-white">@{username}</p>
                    {isPremium && <span className="text-amber-400 font-bold">✓</span>}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-500 font-mono">Holat</p>
                  <p className="text-sm text-green-400 font-mono mt-0.5">🟢 Onlayn</p>
                </div>
              </div>

              {isPremium && (
                <div className="p-2.5 rounded-xl bg-amber-950/20 border border-amber-900/40 flex items-center gap-2">
                  <span className="text-amber-400">👑</span>
                  <div>
                    <p className="text-xs font-bold text-amber-300">Premium Foydalanuvchi</p>
                    <p className="text-[10px] text-amber-600 font-mono">{daysLeft} kun qoldi</p>
                  </div>
                </div>
              )}
            </div>

            {/* Bio */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Bio / Tavsif</p>
              <textarea
                value={bio}
                onChange={e => setBio(e.target.value)}
                rows={3}
                maxLength={160}
                placeholder="O'zingiz haqingizda qisqacha..."
                className="w-full bg-slate-950 border border-slate-700 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition resize-none"
              />
              <div className="flex items-center justify-between">
                <p className="text-[10px] text-slate-600 font-mono">{bio.length}/160</p>
                <button onClick={saveBio} className="px-4 py-2 rounded-xl text-xs font-bold text-white transition" style={{background: accentColor}}>
                  Saqlash
                </button>
              </div>
            </div>

            {/* Custom Status */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Maxsus status</p>
              <p className="text-xs text-slate-500">Profilingizda ko'rinadigan qisqa ibora yoki kayfiyat.</p>
              <div className="flex gap-2">
                <input value={customStatus} onChange={e => setCustomStatus(e.target.value)} maxLength={60}
                  placeholder="Masalan: 🎮 O'ynayapman yoki 💻 Ishda..."
                  className="flex-1 bg-slate-950 border border-slate-700 p-2.5 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
                <button onClick={saveCustomStatus}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-white transition" style={{background: accentColor}}>
                  Saqlash
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {["🎮 O'ynayapman", "💤 Dam olmoqdaman", "💻 Ishda", "🎵 Musiqa", "📚 O'qiyapman", "🚀 Bandman", "🌙 Tunda", "☕ Choy ichamiz"].map(s => (
                  <button key={s} onClick={() => setCustomStatus(s)}
                    className="text-[10px] px-2.5 py-1 rounded-full border border-slate-700 text-slate-400 hover:border-slate-500 hover:text-slate-200 transition">
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Display name */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Ko'rsatma ism</p>
              <p className="text-xs text-slate-500">Username o'rniga ko'rinadigan ism (ixtiyoriy).</p>
              <div className="flex gap-2">
                <input value={displayName} onChange={e => setDisplayName(e.target.value)} maxLength={40}
                  placeholder="Masalan: Alex 🦅 yoki Dilshod..."
                  className="flex-1 bg-slate-950 border border-slate-700 p-2.5 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
                <button onClick={saveDisplayName}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-white transition" style={{background: accentColor}}>
                  Saqlash
                </button>
              </div>
              {displayName && (
                <p className="text-xs text-slate-500">Ko'rinadi: <span className="text-white font-bold">{displayName}</span></p>
              )}
            </div>

            {/* Stats */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300">Tizim ma'lumotlari</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: "Protokol", val: "NEXUS v5.6" },
                  { label: "Shifrlash", val: "AES-256" },
                  { label: "Sessiya", val: sessionInfo.device },
                  { label: "Brauzer", val: sessionInfo.browser },
                  { label: "Backend", val: "Firebase RTDB" },
                  { label: "Kirish vaqti", val: sessionInfo.time },
                ].map(s => (
                  <div key={s.label} className="bg-slate-950/60 rounded-xl p-2.5">
                    <p className="text-[9px] text-slate-500 font-mono uppercase">{s.label}</p>
                    <p className="text-xs font-bold mt-0.5 truncate" style={{color: accentColor}}>{s.val}</p>
                  </div>
                ))}
              </div>
            </div>

            <button onClick={onLogout} className="w-full py-3 rounded-xl font-bold text-sm border border-rose-900/60 text-rose-500 hover:bg-rose-950/40 transition">
              🔌 Tizimdan chiqish
            </button>
          </div>
        )}

        {/* ────── APPEARANCE ────── */}
        {sub === "appearance" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">Ko'rinish</h2>

            {/* Theme colors */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
              <p className="text-sm font-bold text-slate-300">Accent rang ({THEMES.length} variant)</p>
              <div className="grid grid-cols-6 gap-2">
                {THEMES.map(t => (
                  <button key={t.color} onClick={() => handleColorSelect(t.color)} title={t.name}
                    className="flex flex-col items-center gap-1"
                  >
                    <div className="w-9 h-9 rounded-xl border-2 transition-all" style={{
                      background: t.color,
                      borderColor: accentColor === t.color ? "#fff" : "transparent",
                      transform: accentColor === t.color ? "scale(1.2)" : "scale(1)",
                      boxShadow: accentColor === t.color ? `0 0 14px ${t.color}` : "none"
                    }} />
                    <span className="text-[8px] text-slate-500">{t.name}</span>
                  </button>
                ))}
              </div>
              {/* Custom color */}
              <div className="flex items-center gap-3 pt-1">
                <p className="text-xs text-slate-400 flex-shrink-0">Maxsus rang:</p>
                <input type="color" value={accentColor} onChange={e => handleColorSelect(e.target.value)}
                  className="w-10 h-10 rounded-xl border-0 cursor-pointer bg-transparent" />
                <span className="text-xs font-mono text-slate-500">{accentColor}</span>
              </div>
            </div>

            {/* Font size */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Matn o'lchami</p>
              <div className="flex gap-2">
                {(["small", "medium", "large"] as const).map(s => (
                  <button key={s} onClick={() => { setFontSize(s); localStorage.setItem("nexus_font_size", s); showToast("✅ Saqlandi"); }}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition ${fontSize === s ? "border-cyan-500 bg-cyan-950/40" : "border-slate-700 text-slate-400"}`}
                    style={fontSize === s ? { color: accentColor } : undefined}
                  >
                    {s === "small" ? "Aa Kichik" : s === "medium" ? "Aa O'rta" : "Aa Katta"}
                  </button>
                ))}
              </div>
            </div>

            {/* Wallpaper */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Fon rangi</p>
              <div className="grid grid-cols-4 gap-2">
                {WALLPAPERS.map(w => (
                  <button key={w.value} onClick={() => { setWallpaper(w.value); localStorage.setItem("nexus_wallpaper", w.value); document.body.style.background = w.value; showToast("✅ Fon o'zgartirildi"); }}
                    className="flex flex-col items-center gap-1">
                    <div className="w-12 h-10 rounded-xl border-2 transition" style={{background: w.value, borderColor: wallpaper === w.value ? accentColor : "#334155"}} />
                    <span className="text-[9px] text-slate-400">{w.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label="Shaffof fon (blur)" desc="Oynalarda shisha effekti" value={bgBlur} onToggle={() => tog("nexus_bg_blur", bgBlur, setBgBlur)} />
              <Toggle label="Animatsiyalar" desc="Ochilish va yopilish effektlari" value={animEnabled} onToggle={() => tog("nexus_anim", animEnabled, setAnimEnabled)} />
              <Toggle label="Compact rejim" desc="Kichikroq xabar o'lchami" value={compactMode} onToggle={() => tog("nexus_compact", compactMode, setCompactMode)} />
              <Toggle label="Enter = yuborish" desc="Enter tugmasi xabar yuboradi" value={enterSend} onToggle={() => tog("nexus_enter_send", enterSend, setEnterSend)} />
              <Toggle label="Havola ko'rinishi" desc="URL dan preview ko'rsatish" value={linkPreview} onToggle={() => tog("nexus_link_preview", linkPreview, setLinkPreview)} />
            </div>

            {/* Language shortcut in Appearance tab */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300">🌐 {t("language")}</p>
              <div className="grid grid-cols-2 gap-2">
                {(Object.keys(LANG_NAMES) as Lang[]).map(l => (
                  <button key={l} onClick={() => { setLang(l); setSelectedLang(l); showToast(t("languageChanged")); }}
                    className={`py-2 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 ${lang === l ? "border-cyan-500 bg-cyan-950/30" : "border-slate-700 text-slate-400"}`}
                    style={lang === l ? {color: accentColor} : undefined}
                  >
                    {LANG_FLAGS[l]} {LANG_NAMES[l]}
                    {lang === l && <span className="text-[9px]">✓</span>}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-600 font-mono">Ilova tili darhol o'zgaradi</p>
            </div>
          </div>
        )}

        {/* ────── ANIMATION ────── */}
        {sub === "animation" && (() => {
          const Acc = ({ id, icon, title, badge, lock, children }: {
            id: string; icon: string; title: string; badge?: string; lock?: boolean; children: React.ReactNode;
          }) => {
            const isOpen = openSec.has(id);
            return (
              <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900/60">
                <button
                  onClick={() => togSec(id)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-slate-800/40 transition-colors text-left"
                >
                  <span className="text-base">{icon}</span>
                  <span className="flex-1 text-sm font-bold text-slate-200">{title}</span>
                  {badge && (
                    <span className="text-[9px] font-black px-2 py-0.5 rounded-full border"
                      style={lock ? { color: "#94a3b8", borderColor: "#334155", background: "transparent" }
                        : { color: "#000", background: "linear-gradient(90deg,#f59e0b,#ec4899)", border: "none" }}>
                      {lock ? "🔒 " : ""}{badge}
                    </span>
                  )}
                  <span className="text-slate-600 text-xs transition-transform duration-200" style={{ display: "inline-block", transform: isOpen ? "rotate(180deg)" : "rotate(0deg)" }}>▾</span>
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 pt-2 border-t border-slate-800/60 space-y-3">
                    {children}
                  </div>
                )}
              </div>
            );
          };

          const OptionRow = ({ label, desc, options, value, onChange, premium }: {
            label?: string; desc?: string;
            options: { val: string; label: string; icon?: string }[];
            value: string; onChange: (v: string) => void; premium?: boolean;
          }) => (
            <div>
              {label && <p className="text-xs font-bold text-slate-400 mb-2">{label}</p>}
              {desc && <p className="text-[10px] text-slate-600 mb-2">{desc}</p>}
              <div className="flex flex-wrap gap-2">
                {options.map(o => {
                  const active = value === o.val;
                  return (
                    <button
                      key={o.val}
                      onClick={() => { if (premium && !isPremiumFlag) { showToast("🔒 Premium kerak!"); return; } onChange(o.val); }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all"
                      style={active
                        ? { borderColor: accentColor, color: accentColor, background: `${accentColor}18`, boxShadow: `0 0 8px ${accentColor}44` }
                        : { borderColor: "#1e293b", color: "#64748b" }}
                    >
                      {o.icon && <span>{o.icon}</span>}
                      {o.label}
                      {active && <span className="text-[9px]">✓</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          );

          return (
            <div className="space-y-2.5 max-w-md">
              {/* Header */}
              <div className="flex items-center justify-between pb-1">
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  ✨ Animatsiyalar
                </h2>
                {isPremiumFlag
                  ? <span className="text-[10px] font-black px-2 py-1 rounded-full text-black" style={{ background: "linear-gradient(90deg,#f59e0b,#ec4899)" }}>PREMIUM</span>
                  : <span className="text-[10px] text-slate-500 bg-slate-800 px-2 py-1 rounded-full">🔒 Premium kerak</span>
                }
              </div>

              {/* 1. Nishonlar */}
              <Acc id="badges" icon="🏅" title="Nishonlar (Badge)" badge="Premium" lock={!isPremiumFlag}>
                <p className="text-[10px] text-slate-500">Chat xabarlaringizda ko'rinadigan animatsion nishon tanlang.</p>
                {activeBadge && (
                  <div className="flex items-center gap-2 p-2.5 rounded-xl border border-amber-700/40 bg-amber-950/20">
                    <span className="text-xl">{BADGES.find(b => b.id === activeBadge)?.emoji}</span>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-amber-300">{BADGES.find(b => b.id === activeBadge)?.label}</p>
                      <p className="text-[9px] text-amber-700">Faol nishon</p>
                    </div>
                    <button onClick={() => saveBadge(activeBadge)} className="text-[9px] text-slate-500 hover:text-slate-300 border border-slate-700 px-2 py-1 rounded-lg">✕ Olib tashlash</button>
                  </div>
                )}
                <div className={`grid grid-cols-4 gap-2 ${!isPremiumFlag ? "opacity-40 pointer-events-none" : ""}`}>
                  {BADGES.map(badge => {
                    const isActive = activeBadge === badge.id;
                    return (
                      <button key={badge.id} onClick={() => saveBadge(badge.id)}
                        className="flex flex-col items-center gap-1.5 p-2.5 rounded-xl border-2 transition-all hover:scale-105 active:scale-95"
                        style={isActive
                          ? { borderColor: badge.color, background: `${badge.color}18`, boxShadow: `0 0 12px ${badge.glow}44` }
                          : { borderColor: "#1e293b", background: "transparent" }}
                      >
                        <div className="relative">
                          <span className={`text-2xl block ${isActive ? badge.anim : ""}`}
                            style={isActive ? { filter: `drop-shadow(0 0 5px ${badge.glow})` } : undefined}>
                            {badge.emoji}
                          </span>
                          {isActive && <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full text-[8px] font-black text-black flex items-center justify-center" style={{ background: badge.color }}>✓</span>}
                        </div>
                        <span className="text-[8px] font-semibold truncate w-full text-center" style={{ color: isActive ? badge.color : "#475569" }}>{badge.label}</span>
                      </button>
                    );
                  })}
                </div>
              </Acc>

              {/* 2. Profil Foni */}
              <Acc id="profileBg" icon="🌌" title="Profil orqa fon" badge="Premium" lock={!isPremiumFlag}>
                <p className="text-[10px] text-slate-500 mb-1">Boshqalar profilingizga kirganda ko'radigan jonli fon. ({PROFILE_BGS.length} variant)</p>
                <div className={`grid grid-cols-3 gap-2 ${!isPremiumFlag ? "opacity-40 pointer-events-none" : ""}`}>
                  {PROFILE_BGS.map(bg => (
                    <button key={bg.id} onClick={() => saveProfileBg(bg.id)}
                      className="relative rounded-xl overflow-hidden border-2 transition-all hover:scale-105"
                      style={{ aspectRatio: "16/9", borderColor: profileBg === bg.id ? "#f59e0b" : "#1e293b" }}>
                      <div className={`absolute inset-0 ${bg.className || ""}`} style={!bg.id ? { background: "linear-gradient(135deg,#0f172a,#020617)" } : undefined} />
                      <span className="absolute bottom-0 left-0 right-0 text-center text-[9px] font-bold text-white bg-black/60 py-0.5">{bg.name}</span>
                      {profileBg === bg.id && <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-400 text-black text-[9px] font-black flex items-center justify-center">✓</span>}
                    </button>
                  ))}
                </div>
              </Acc>

              {/* 3. Chat Bubble Animatsiyasi */}
              <Acc id="chatBubble" icon="💬" title="Chat bubble animatsiyasi">
                <OptionRow
                  desc="Xabar ko'rinish uslubini tanlang"
                  options={[
                    { val: "slide", label: "Sirpanish", icon: "➡️" },
                    { val: "bounce", label: "Sakrash", icon: "⬆️" },
                    { val: "pop", label: "Pop", icon: "💥" },
                    { val: "fade", label: "So'nish", icon: "🌫️" },
                    { val: "scale", label: "Kengayish", icon: "🔍" },
                  ]}
                  value={chatBubbleAnim}
                  onChange={v => { setChatBubbleAnim(v); localStorage.setItem("nx_bubble", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 4. Yuborish Effekti */}
              <Acc id="sendFx" icon="✉️" title="Yuborish effekti">
                <OptionRow
                  desc="Xabar yuborganingizda animatsiya effekti"
                  options={[
                    { val: "none", label: "Yo'q", icon: "🚫" },
                    { val: "fire", label: "Olov", icon: "🔥" },
                    { val: "confetti", label: "Konfetti", icon: "🎊" },
                    { val: "hearts", label: "Yurak", icon: "❤️" },
                    { val: "stars", label: "Yulduz", icon: "⭐" },
                    { val: "rocket", label: "Raketa", icon: "🚀" },
                  ]}
                  value={sendEffect}
                  onChange={v => { setSendEffect(v); localStorage.setItem("nx_send_fx", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 5. Profil Aura */}
              <Acc id="aura" icon="🌟" title="Profil aura effekti" badge="Premium" lock={!isPremiumFlag}>
                <div className={!isPremiumFlag ? "opacity-40 pointer-events-none" : ""}>
                  <p className="text-[10px] text-slate-500 mb-3">Profil rasmingiz atrofidagi parlanish effekti</p>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black flex-shrink-0"
                      style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, boxShadow: `0 0 20px ${auraColor}88` }}>
                      {username[0]?.toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-slate-300 mb-1">Aura rangi</p>
                      <div className="flex items-center gap-2">
                        <input type="color" value={auraColor} onChange={e => setAuraColor(e.target.value)}
                          className="w-10 h-8 rounded-lg border-0 cursor-pointer bg-transparent" />
                        <span className="text-xs font-mono text-slate-500">{auraColor}</span>
                        <button onClick={() => saveAnimSetting("auraColor", auraColor, true)}
                          className="text-xs font-bold px-3 py-1.5 rounded-lg text-white transition" style={{ background: accentColor }}>
                          Saqlash
                        </button>
                      </div>
                    </div>
                  </div>
                  <OptionRow
                    label="Aura kuchliligi"
                    options={[
                      { val: "subtle", label: "Yengil" },
                      { val: "medium", label: "O'rta" },
                      { val: "strong", label: "Kuchli" },
                    ]}
                    value={auraIntensity}
                    onChange={v => { setAuraIntensity(v); saveAnimSetting("auraIntensity", v, true); }}
                  />
                </div>
              </Acc>

              {/* 6. Username Effekti */}
              <Acc id="usernameFx" icon="📛" title="Username effekti" badge="Premium" lock={!isPremiumFlag}>
                <div className={!isPremiumFlag ? "opacity-40 pointer-events-none" : ""}>
                  <p className="text-[10px] text-slate-500 mb-3">Ismingiz ko'rinadigan animatsion effekt</p>
                  <div className="mb-3 p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className={`text-base font-black ${
                      usernameEffect === "glow" ? "drop-shadow-[0_0_8px_#22d3ee]" :
                      usernameEffect === "rainbow" ? "animate-pulse" :
                      usernameEffect === "neon" ? "drop-shadow-[0_0_6px_#a855f7]" :
                      usernameEffect === "glitch" ? "animate-ping" : ""
                    }`} style={
                      usernameEffect === "glow" ? { color: "#22d3ee" } :
                      usernameEffect === "rainbow" ? { background: "linear-gradient(90deg,#f59e0b,#ec4899,#22d3ee)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" } :
                      usernameEffect === "neon" ? { color: "#a855f7", textShadow: "0 0 10px #a855f7" } :
                      usernameEffect === "glitch" ? { color: "#ef4444" } : { color: accentColor }
                    }>@{username}</span>
                  </div>
                  <OptionRow
                    options={[
                      { val: "none", label: "Oddiy", icon: "•" },
                      { val: "glow", label: "Glow", icon: "💡" },
                      { val: "rainbow", label: "Rainbow", icon: "🌈" },
                      { val: "neon", label: "Neon", icon: "🔮" },
                      { val: "glitch", label: "Glitch", icon: "⚡" },
                    ]}
                    value={usernameEffect}
                    onChange={v => { setUsernameEffect(v); saveAnimSetting("usernameEffect", v, true); }}
                  />
                </div>
              </Acc>

              {/* 7. Kirish Animatsiyasi */}
              <Acc id="entryAnim" icon="🚪" title="Xabar kirish animatsiyasi">
                <OptionRow
                  desc="Yangi xabar ekranga qanday kirishi"
                  options={[
                    { val: "slide", label: "Sirpanib", icon: "↘️" },
                    { val: "fade", label: "So'nib", icon: "🌫️" },
                    { val: "scale", label: "Kattalashib", icon: "🔍" },
                    { val: "flip", label: "Aylanib", icon: "🔄" },
                    { val: "drop", label: "Tushib", icon: "⬇️" },
                  ]}
                  value={entryAnim}
                  onChange={v => { setEntryAnim(v); localStorage.setItem("nx_entry_anim", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 8. Status Animatsiyasi */}
              <Acc id="statusAnim" icon="🟢" title="Status (Online) animatsiyasi">
                <OptionRow
                  desc="Online ko'rsatkichining harakatlanish turi"
                  options={[
                    { val: "pulse", label: "Puls", icon: "💓" },
                    { val: "blink", label: "Miltillash", icon: "✨" },
                    { val: "wave", label: "To'lqin", icon: "🌊" },
                    { val: "glow", label: "Yorqin", icon: "🌟" },
                    { val: "none", label: "Statik", icon: "•" },
                  ]}
                  value={statusAnim}
                  onChange={v => { setStatusAnim(v); localStorage.setItem("nx_status_anim", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 9. Emoji Reaksiya Uslubi */}
              <Acc id="reaction" icon="😍" title="Emoji reaksiya uslubi">
                <OptionRow
                  desc="Xabarlarga reaksiya berishda animatsiya turi"
                  options={[
                    { val: "default", label: "Oddiy", icon: "😊" },
                    { val: "big", label: "Katta", icon: "🔤" },
                    { val: "bounce", label: "Sakrash", icon: "⬆️" },
                    { val: "rain", label: "Yomg'ir", icon: "🌧️" },
                    { val: "explode", label: "Portlash", icon: "💥" },
                  ]}
                  value={reactionStyle}
                  onChange={v => { setReactionStyle(v); localStorage.setItem("nx_reaction", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 10. Terilish Animatsiyasi (Typing) */}
              <Acc id="typingAnim" icon="⌨️" title="Terilish indikatori animatsiyasi">
                <OptionRow
                  desc="'...yozmoqda' ko'rsatkichining ko'rinishi"
                  options={[
                    { val: "dots", label: "Nuqtalar", icon: "•••" },
                    { val: "wave", label: "To'lqin", icon: "〰️" },
                    { val: "bar", label: "Chiziq", icon: "━" },
                    { val: "bubble", label: "Pufakcha", icon: "💬" },
                    { val: "pulse", label: "Puls", icon: "💓" },
                  ]}
                  value={typingStyle}
                  onChange={v => { setTypingStyle(v); localStorage.setItem("nx_typing_style", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 11. Bildirishnoma Animatsiyasi */}
              <Acc id="notifAnim" icon="🔔" title="Bildirishnoma animatsiyasi">
                <OptionRow
                  desc="Yangi bildirishnoma qanday paydo bo'lishi"
                  options={[
                    { val: "slide", label: "Sirpanish", icon: "↘️" },
                    { val: "pop", label: "Pop", icon: "💥" },
                    { val: "shake", label: "Silkish", icon: "📳" },
                    { val: "flip", label: "Aylanish", icon: "🔄" },
                    { val: "zoom", label: "Zoom", icon: "🔍" },
                  ]}
                  value={notifAnim}
                  onChange={v => { setNotifAnim(v); localStorage.setItem("nx_notif_anim", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 12. Profil Gradiyenti */}
              <Acc id="gradient" icon="🎨" title="Profil rang gradiyenti" badge="Premium" lock={!isPremiumFlag}>
                <div className={!isPremiumFlag ? "opacity-40 pointer-events-none" : ""}>
                  <p className="text-[10px] text-slate-500 mb-3">Profil kartochkangizning fon gradiyenti</p>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { id: "", label: "Standart", bg: "linear-gradient(135deg,#0f172a,#020617)" },
                      { id: "cyber", label: "Cyber", bg: "linear-gradient(135deg,#00ffcc22,#00224400)" },
                      { id: "fire", label: "Olov", bg: "linear-gradient(135deg,#ef444433,#dc262622)" },
                      { id: "ocean", label: "Okean", bg: "linear-gradient(135deg,#0ea5e933,#06b6d422)" },
                      { id: "aurora", label: "Aurora", bg: "linear-gradient(135deg,#a855f733,#22d3ee22)" },
                      { id: "gold", label: "Oltin", bg: "linear-gradient(135deg,#f59e0b33,#d9770622)" },
                      { id: "night", label: "Kecha", bg: "linear-gradient(135deg,#1e293b,#0f172a)" },
                      { id: "matrix", label: "Matrix", bg: "linear-gradient(135deg,#22c55e22,#14532d22)" },
                    ].map(g => (
                      <button key={g.id} onClick={() => { setProfileGradient(g.id); saveAnimSetting("profileGradient", g.id, true); }}
                        className="relative rounded-xl border-2 transition-all hover:scale-105 flex flex-col items-center justify-center gap-1 py-3"
                        style={{
                          background: g.bg,
                          borderColor: profileGradient === g.id ? "#f59e0b" : "#1e293b",
                          aspectRatio: "1"
                        }}>
                        {profileGradient === g.id && <span className="absolute top-1 right-1 text-[9px] text-amber-400">✓</span>}
                        <span className="text-[8px] font-bold text-slate-300">{g.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </Acc>

              {/* 13. Animatsiya Tezligi */}
              <Acc id="speed" icon="⚡" title="Animatsiya tezligi">
                <OptionRow
                  desc="Barcha animatsiyalar uchun global tezlik"
                  options={[
                    { val: "slow", label: "Sekin", icon: "🐢" },
                    { val: "normal", label: "Normal", icon: "🚶" },
                    { val: "fast", label: "Tez", icon: "⚡" },
                    { val: "instant", label: "Tezkor", icon: "🚀" },
                  ]}
                  value={animSpeed}
                  onChange={v => { setAnimSpeed(v); localStorage.setItem("nx_anim_speed", v); showToast("✅ Saqlandi"); }}
                />
              </Acc>

              {/* 14. Ism rang effekti */}
              <Acc id="nameFx" icon="✍️" title="Ism/nomi rang effekti" badge="Premium" lock={!isPremiumFlag}>
                <p className="text-[10px] text-slate-500 mb-2">Chat sarlavhasida va profilda ismingizning ko'rinishi</p>
                <OptionRow
                  options={[
                    { val: "none", label: "Standart", icon: "📝" },
                    { val: "gold", label: "Oltin", icon: "🟡" },
                    { val: "cyan", label: "Neon Cyan", icon: "💠" },
                    { val: "pink", label: "Pushti", icon: "🌸" },
                    { val: "purple", label: "Binafsha", icon: "🟣" },
                    { val: "fire", label: "Olov", icon: "🔥" },
                    { val: "ice", label: "Muz", icon: "❄️" },
                    { val: "rainbow", label: "Kamalak", icon: "🌈" },
                  ]}
                  value={nameFx}
                  onChange={v => { setNameFx(v); localStorage.setItem("nx_name_fx", v); saveAnimSetting("nameFx", v, true); }}
                  premium
                />
                <div className={`mt-3 p-3 rounded-xl bg-slate-950/60 text-center ${nameFx === "gold" ? "name-glow-gold text-amber-400" : nameFx === "cyan" ? "name-glow-cyan text-cyan-400" : nameFx === "pink" ? "name-glow-pink text-pink-400" : nameFx === "purple" ? "name-glow-purple text-purple-400" : nameFx === "fire" ? "name-glow-fire text-orange-400" : nameFx === "ice" ? "name-glow-ice text-blue-200" : nameFx === "rainbow" ? "" : "text-slate-400"}`}
                  style={nameFx === "rainbow" ? { background: "linear-gradient(90deg,#f59e0b,#ec4899,#22d3ee)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" } : undefined}>
                  <span className="text-sm font-black">@{username}</span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Ko'rinish namunasi</span>
                </div>
              </Acc>

              {/* 15. Xabar imzosi */}
              <Acc id="signature" icon="✒️" title="Xabar imzosi (Signature)" badge="Premium" lock={!isPremiumFlag}>
                <p className="text-[10px] text-slate-500 mb-2">Har bir xabar oxiriga qo'shiladigan qisqa matn yoki emoji</p>
                <div className="flex gap-2">
                  <input value={msgSignature} onChange={e => setMsgSignature(e.target.value)} maxLength={40}
                    disabled={!isPremiumFlag}
                    placeholder="Masalan: 🚀 Power yoki ✨ ~Alex..."
                    className="flex-1 bg-slate-950 border border-slate-700 p-2.5 rounded-xl text-sm text-white outline-none focus:border-amber-500 transition" />
                  <button onClick={() => { saveAnimSetting("msgSignature", msgSignature, true); }}
                    disabled={!isPremiumFlag}
                    className="px-4 py-2.5 rounded-xl text-xs font-bold text-white disabled:opacity-50"
                    style={{ background: isPremiumFlag ? accentColor : "#1e293b" }}>
                    Saqlash
                  </button>
                </div>
                {msgSignature && (
                  <p className="text-xs text-slate-500 mt-2">Xabar oxirida: <span className="text-amber-400">— {msgSignature}</span></p>
                )}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {["🚀 Power", "✨ ~Premium", "💫 Nexus", "❄️ Ice", "🔥 Fire", "🌊 Wave"].map(s => (
                    <button key={s} onClick={() => setMsgSignature(s)}
                      className="text-[10px] px-2 py-1 rounded-full border border-amber-900/40 text-amber-400 hover:bg-amber-950/30 transition">
                      {s}
                    </button>
                  ))}
                </div>
              </Acc>

              {/* 16. Zarrachalar effekti */}
              <Acc id="particles" icon="✨" title="Zarrachalar effekti" badge="Premium" lock={!isPremiumFlag}>
                <p className="text-[10px] text-slate-500 mb-2">Xabar yuborilganda ekranda paydo bo'ladigan vizual effekt</p>
                <OptionRow
                  options={[
                    { val: "none", label: "Yo'q", icon: "🚫" },
                    { val: "stars", label: "Yulduzlar", icon: "⭐" },
                    { val: "hearts", label: "Yuraklar", icon: "❤️" },
                    { val: "snow", label: "Qor", icon: "❄️" },
                    { val: "confetti", label: "Konfetti", icon: "🎊" },
                    { val: "sparkle", label: "Yarqirash", icon: "✨" },
                    { val: "fire", label: "Olov", icon: "🔥" },
                    { val: "bubbles", label: "Pufaklar", icon: "🫧" },
                  ]}
                  value={particlePreset}
                  onChange={v => { setParticlePreset(v); localStorage.setItem("nx_particle", v); saveAnimSetting("particlePreset", v, true); }}
                  premium
                />
              </Acc>

              {/* Premium effektlar ro'yhati */}
              <div className="rounded-2xl border border-slate-800 bg-gradient-to-br from-amber-950/20 to-slate-900/60 overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-800/50 flex items-center gap-2">
                  <span className="text-base">✨</span>
                  <span className="text-sm font-bold text-slate-200">Premium effektlar</span>
                  {isPremiumFlag && <span className="ml-auto text-[9px] text-green-400 font-mono">FAOL</span>}
                </div>
                <div className="px-4 py-2">
                  {[
                    { i: "🏅", l: "24 ta animatsion nishon (badge)" },
                    { i: "🌌", l: "Jonli profil orqa fonlar (11 variant)" },
                    { i: "💎", l: "Verified ✓ tasdiq belgisi" },
                    { i: "🌟", l: "Profil aura effekti" },
                    { i: "📛", l: "Username animatsion effekt" },
                    { i: "🎨", l: "Profil rang gradiyenti (8 variant)" },
                    { i: "🎯", l: "Maxsus accent ranglar" },
                    { i: "🚀", l: "Tezroq xabar yetkazish" },
                  ].map(item => (
                    <div key={item.l} className="flex items-center gap-2.5 py-2 border-b border-slate-800/30 last:border-0">
                      <span className="text-base">{item.i}</span>
                      <p className="flex-1 text-xs text-slate-300">{item.l}</p>
                      {isPremiumFlag
                        ? <span className="text-[9px] text-green-400 font-bold">✓ FAOL</span>
                        : <span className="text-[9px] text-slate-600">🔒</span>
                      }
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })()}

        {sub === "notifications" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">Bildirishnomalar</h2>
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label="Ovozli signal" desc="Yangi xabarlarda tovush" value={notifSound} onToggle={() => tog("nexus_notif_sound", notifSound, setNotifSound)} />
              <Toggle label="Desktop bildirishnomalar" desc="Brauzer push xabarlari" value={notifDesktop} onToggle={async () => {
                if (!notifDesktop) {
                  const perm = await Notification.requestPermission();
                  if (perm === "granted") { setNotifDesktop(true); showToast("✅ Yoqildi"); }
                  else showToast("🚫 Brauzer ruxsat bermadi");
                } else { setNotifDesktop(false); showToast("🔕 O'chirildi"); }
              }} />
              <Toggle label="Xabar ko'rinishi" desc="Bildirishnomada xabar matni" value={msgPreview} onToggle={() => tog("nexus_msg_preview", msgPreview, setMsgPreview)} />
              <Toggle label="Yozish indikatori" desc="Kimdir yozsa ko'rsatish" value={typingIndicator} onToggle={() => tog("nexus_typing", typingIndicator, setTypingIndicator)} />
              <Toggle label="Media avtoyuklash" desc="Rasmlarni avtomatik yuklash" value={autoPlay} onToggle={() => tog("nexus_autoplay", autoPlay, setAutoPlay)} />
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-2">Bildirishnoma turlari</p>
              {[
                { label: "Shaxsiy xabarlar", icon: "💬" },
                { label: "Guruh xabarlari", icon: "👥" },
                { label: "Qo'ng'iroqlar", icon: "📞" },
                { label: "Admin xabarlari", icon: "🚨" },
                { label: "Premium tasdiqlar", icon: "👑" },
              ].map(item => (
                <div key={item.label} className="flex items-center justify-between py-2 border-b border-slate-800/40 last:border-0">
                  <p className="text-sm text-slate-300">{item.icon} {item.label}</p>
                  <div className="w-2 h-2 rounded-full bg-green-400" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ────── PRIVACY ────── */}
        {sub === "privacy" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">Maxfiylik</h2>
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <GhostModeToggle username={username} showToast={showToast} />
              <Toggle label="Online holat ko'rsatish" desc="Boshqalar siz onlayn ekanini ko'ra oladi" value={onlineVisible} onToggle={() => tog("nexus_online_visible", onlineVisible, setOnlineVisible)} />
              <Toggle label="O'qildi tasdiqlash (✔✔)" desc="Xabarlaringiz o'qilganda belgi ko'rsatiladi" value={readReceipts} onToggle={() => tog("nexus_read_receipts", readReceipts, setReadReceipts)} />
              <Toggle label="Yozish indikatori" desc="Kimga yozayotganingiz ko'rinadi" value={typingIndicator} onToggle={() => tog("nexus_typing", typingIndicator, setTypingIndicator)} />
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-2">Kim menga yoza oladi</p>
              {WHO_CAN_MSG.map(opt => {
                const active = whoCanMsg === opt.id;
                const locked = opt.premiumOnly && !isPremiumFlag;
                return (
                  <button key={opt.id} onClick={() => saveWhoCanMsg(opt.id)}
                    className={`w-full flex items-center justify-between py-2.5 px-2 rounded-xl transition border ${active ? "border-cyan-700 bg-cyan-950/20" : "border-transparent hover:bg-slate-800/40"}`}>
                    <div className="text-left">
                      <p className="text-sm text-slate-200 flex items-center gap-1.5">
                        {opt.label}
                        {opt.premiumOnly && <span className="text-amber-400 text-[10px]">👑 Premium</span>}
                      </p>
                      <p className="text-[10px] text-slate-500 mt-0.5">{opt.desc}</p>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 ${active ? "border-cyan-400 bg-cyan-400" : locked ? "border-slate-800" : "border-slate-700"}`} />
                  </button>
                );
              })}
            </div>
            {/* Last seen visibility */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label="Oxirgi kirish vaqti" desc="Boshqalar sizning oxirgi faollik vaqtingizni ko'ra oladi" value={lastSeenVisible}
                onToggle={() => { setLastSeenVisible(!lastSeenVisible); localStorage.setItem("nexus_lastseen", !lastSeenVisible ? "on" : "off"); showToast("✅ Saqlandi"); }} />
              <Toggle label="Yo'naltirish tarixi" desc="Xabarni yo'naltirganda manbani ko'rsatish" value={forwardHistory}
                onToggle={() => { setForwardHistory(!forwardHistory); localStorage.setItem("nexus_fwd_history", !forwardHistory ? "on" : "off"); showToast("✅ Saqlandi"); }} />
            </div>

            {/* Block list */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Bloklangan foydalanuvchilar</p>
              <div className="flex gap-2">
                <input value={blockInput} onChange={e => setBlockInput(e.target.value)} maxLength={30}
                  placeholder="@username bloklash..."
                  onKeyDown={e => e.key === "Enter" && blockUser()}
                  className="flex-1 bg-slate-950 border border-slate-700 p-2.5 rounded-xl text-sm text-white outline-none focus:border-rose-500 transition" />
                <button onClick={blockUser}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold border border-rose-900/60 text-rose-400 hover:bg-rose-950/40 transition">
                  Blok
                </button>
              </div>
              {blockList.length > 0 ? (
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {blockList.map(u => (
                    <div key={u} className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800">
                      <span className="text-sm text-slate-300">@{u}</span>
                      <button onClick={() => unblockUser(u)}
                        className="text-[10px] text-rose-400 hover:text-rose-300 font-bold">Olib tashla</button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-600 font-mono">Bloklangan foydalanuvchi yo'q</p>
              )}
            </div>

            <div className="p-4 rounded-2xl bg-amber-950/10 border border-amber-900/30">
              <p className="text-xs text-amber-400 font-mono">⚠️ Bu ilova demonstratsion maqsadda — real ma'lumotlarni saqlamang</p>
            </div>
          </div>
        )}

        {/* ────── SECURITY ────── */}
        {sub === "security" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">🛡️ Xavfsizlik</h2>

            {/* Password change */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">🔑 Parolni o'zgartirish</p>
              <input type={showPass ? "text" : "password"} value={currentPass} onChange={e => setCurrentPass(e.target.value)}
                placeholder="Joriy parol"
                className="w-full bg-slate-950 border border-slate-800 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
              <input type={showPass ? "text" : "password"} value={newPass} onChange={e => setNewPass(e.target.value)}
                placeholder="Yangi parol (min 4 belgi)"
                className="w-full bg-slate-950 border border-slate-800 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
              <input type={showPass ? "text" : "password"} value={confirmPass} onChange={e => setConfirmPass(e.target.value)}
                placeholder="Yangi parolni tasdiqlang"
                className="w-full bg-slate-950 border border-slate-800 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input type="checkbox" checked={showPass} onChange={e => setShowPass(e.target.checked)} className="rounded" />
                <span className="text-xs text-slate-400">Parolni ko'rsatish</span>
              </label>
              <button onClick={handleChangePassword} className="w-full py-3 rounded-xl font-bold text-sm text-white transition hover:opacity-90" style={{background: accentColor}}>
                🔐 Parolni o'zgartirish
              </button>
            </div>

            {/* Push Notifications */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-slate-200">🔔 Browser bildirishnomalari</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">Yangi xabar kelganda brauzer orqali xabar olish</p>
                </div>
                <button
                  onClick={async () => {
                    if (Notification.permission === "granted") {
                      showToast("✅ Bildirishnomalar allaqachon yoqilgan");
                    } else if (Notification.permission === "denied") {
                      showToast("🚫 Brauzer sozlamalaridan ruxsat bering");
                    } else {
                      const result = await Notification.requestPermission();
                      showToast(result === "granted" ? "✅ Bildirishnomalar yoqildi!" : "❌ Rad etildi");
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
                    Notification.permission === "granted"
                      ? "border-green-700 text-green-400 bg-green-950/20"
                      : "border-slate-700 text-slate-300 hover:border-cyan-700 hover:text-cyan-300"
                  }`}
                >
                  {Notification.permission === "granted" ? "✅ Yoqilgan" :
                   Notification.permission === "denied" ? "🚫 Bloklangan" : "Yoqish"}
                </button>
              </div>
            </div>

            {/* Security placeholder - trusted devices removed with 2FA */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">🔒 Sessiya xavfsizligi</p>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <p className="text-xs text-slate-400">Joriy qurilma: <span className="text-slate-200">{getDeviceInfo().device || "Noma'lum"}</span></p>
                <p className="text-[10px] text-slate-600 mt-1 font-mono">{getDeviceInfo().browser} · {new Date().toLocaleString("uz-UZ")}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse flex-shrink-0" />
                <span className="text-[11px] text-green-400 font-mono">Aktiv sessiya</span>
              </div>
            </div>


            {/* Active session */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-2">📡 Faol sessiyalar</p>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3">
                <span className="text-xl">{sessionInfo.device.split(" ")[0]}</span>
                <div className="flex-1">
                  <p className="text-xs font-bold text-slate-200">Joriy sessiya</p>
                  <p className="text-[10px] text-slate-500 font-mono">{sessionInfo.browser} · {sessionInfo.time}</p>
                </div>
                <span className="text-[9px] bg-green-900/30 text-green-400 px-2 py-0.5 rounded-full border border-green-900/50">AKTIV</span>
              </div>
            </div>

            {/* Danger zone */}
            <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-900/50 space-y-3">
              <p className="text-sm font-bold text-rose-400">⚠️ Xavfli zona</p>
              <p className="text-xs text-slate-400">Hisobingizni o'chirish barcha ma'lumotlaringizni yo'q qiladi. Bu amalni qaytarib bo'lmaydi.</p>
              <button onClick={handleDeleteAccount} className="w-full py-2.5 rounded-xl font-bold text-xs border border-rose-700 text-rose-400 hover:bg-rose-950/40 transition">
                🗑️ Hisobni butunlay o'chirish
              </button>
            </div>
          </div>
        )}

        {/* ────── PREMIUM ────── */}
        {sub === "premium" && (
          <div className="max-w-md">
            <h2 className="text-lg font-bold text-slate-100 mb-4">👑 Premium</h2>
            <PremiumSection username={username} accentColor={accentColor} />
          </div>
        )}

        {/* ────── ABOUT ────── */}
        {sub === "about" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">Tizim haqida</h2>
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
              <div className="text-5xl mb-2">⚡</div>
              <p className="text-2xl font-black" style={{background:`linear-gradient(to right, ${accentColor}, #6366f1)`, WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"}}>
                NEXUS_OS
              </p>
              <p className="text-xs text-slate-400 font-mono">ConnectUz Messaging System v5.6</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1 font-mono text-xs">
              {[
                ["Versiya", "5.6.0-STABLE"],
                ["Frontend", "React 18 + Vite 7"],
                ["Backend", "Firebase RTDB"],
                ["Real-time", "WebSocket"],
                ["Qo'ng'iroqlar", "WebRTC + STUN"],
                ["Shifrlash", "AES-256 (transit)"],
                ["UI", "Tailwind CSS v4"],
                ["Platform", "Replit Cloud"],
                ["Rington", "Cinnamon Girl"],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5 border-b border-slate-800/50 last:border-0">
                  <span className="text-slate-500">{k}</span>
                  <span style={{color: accentColor}}>{v}</span>
                </div>
              ))}
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
              <p className="text-xs text-slate-500 font-mono">
                © 2026 ConnectUz / NEXUS_CORE<br/>
                <span className="text-slate-600">Made with 🖤 for Uzbekistan</span>
              </p>
            </div>
          </div>
        )}

        {/* ────── LANGUAGE ────── */}
        {sub === "language" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">🌐 {t("appLanguage")}</h2>
            <p className="text-sm text-slate-400">{t("selectLanguage")}</p>

            <div className="space-y-2">
              {(Object.keys(LANG_NAMES) as Lang[]).map(l => {
                const active = lang === l;
                return (
                  <button key={l}
                    onClick={() => { setLang(l); setSelectedLang(l); showToast(t("languageChanged")); }}
                    className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all ${active ? "bg-slate-800/60" : "border-slate-800/60 bg-slate-900/40 hover:bg-slate-800/30"}`}
                    style={active ? { borderColor: accentColor, boxShadow: `0 0 16px ${accentColor}30` } : undefined}
                  >
                    <span className="text-3xl">{LANG_FLAGS[l]}</span>
                    <div className="flex-1 text-left">
                      <p className="font-bold text-slate-100">{LANG_NAMES[l]}</p>
                      <p className="text-xs text-slate-500 font-mono">{l.toUpperCase()}</p>
                    </div>
                    {active && (
                      <div className="w-6 h-6 rounded-full flex items-center justify-center text-black text-xs font-black"
                        style={{ background: accentColor }}>✓</div>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <p className="text-xs text-slate-400">
                💡 Til o'zgarishi darhol kuchga kiradi. Interfeys matnlari yangi tilda ko'rsatiladi.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-2">Tarjima holati</p>
              {[
                { l: "O'zbek", flag: "🇺🇿", pct: 100 },
                { l: "Русский", flag: "🇷🇺", pct: 100 },
                { l: "English", flag: "🇬🇧", pct: 100 },
                { l: "Qaraqalpaq", flag: "🏳️", pct: 85 },
              ].map(item => (
                <div key={item.l} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300">{item.flag} {item.l}</span>
                    <span className="text-slate-500 font-mono">{item.pct}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${item.pct}%`, background: accentColor }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ────── CHAT SETTINGS ────── */}
        {sub === "chat" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">💬 {t("chatSettings")}</h2>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label={t("enterSend")} desc="Enter tugmasi xabar yuboradi (Shift+Enter = yangi qator)" value={enterSend} onToggle={() => tog("nexus_enter_send", enterSend, setEnterSend)} />
              <Toggle label={t("linkPreview")} desc="Havola yuborganingizda preview ko'rsatish" value={linkPreview} onToggle={() => tog("nexus_link_preview", linkPreview, setLinkPreview)} />
              <Toggle label={t("forwardHistory")} desc="Xabarni yo'naltirganda manbani ko'rsatish" value={forwardHistory} onToggle={() => { setForwardHistory(!forwardHistory); localStorage.setItem("nexus_fwd_history", !forwardHistory ? "on" : "off"); showToast(t("saved")); }} />
              <Toggle label={t("typingIndicator")} desc="Kimga yozayotganingiz ko'rinadi" value={typingIndicator} onToggle={() => tog("nexus_typing", typingIndicator, setTypingIndicator)} />
              <Toggle label={t("autoPlayMedia")} desc="Rasm va videolarni avtomatik yuklash" value={autoPlay} onToggle={() => tog("nexus_autoplay", autoPlay, setAutoPlay)} />
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">{t("msgFontSize")}</p>
              <div className="flex gap-2">
                {(["small", "medium", "large"] as const).map(s => (
                  <button key={s} onClick={() => { setFontSize(s); localStorage.setItem("nexus_font_size", s); showToast(t("saved")); }}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition ${fontSize === s ? "border-cyan-500 bg-cyan-950/40" : "border-slate-700 text-slate-400"}`}
                    style={fontSize === s ? { color: accentColor } : undefined}
                  >
                    {s === "small" ? `${t("small")} (14px)` : s === "medium" ? `${t("medium")} (16px)` : `${t("large")} (17px)`}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">{t("bubbleStyle")}</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "modern",  label: "Zamonaviy",  preview: "rounded-2xl" },
                  { id: "classic", label: "Klassik",    preview: "rounded-md" },
                  { id: "minimal", label: "Minimal",    preview: "rounded-sm" },
                ].map(style => {
                  const stored = localStorage.getItem("nx_bubble_style") || "modern";
                  const active = stored === style.id;
                  return (
                    <button key={style.id} onClick={() => { localStorage.setItem("nx_bubble_style", style.id); showToast(t("saved")); }}
                      className={`p-3 rounded-xl border-2 transition flex flex-col items-center gap-2 ${active ? "" : "border-slate-800 hover:border-slate-600"}`}
                      style={active ? { borderColor: accentColor, background: `${accentColor}15` } : undefined}
                    >
                      <div className={`w-full h-6 ${style.preview} text-[9px] flex items-center justify-center font-bold`}
                        style={{ background: active ? accentColor : "#1e293b", color: active ? "#000" : "#64748b" }}>
                        Salom!
                      </div>
                      <span className="text-[10px] font-bold" style={{ color: active ? accentColor : "#64748b" }}>{style.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">{t("timeFormat")}</p>
              <div className="flex gap-2">
                {[
                  { id: "12h", label: "12 soat (2:30 PM)" },
                  { id: "24h", label: "24 soat (14:30)" },
                ].map(fmt => {
                  const stored = localStorage.getItem("nx_time_format") || "24h";
                  const active = stored === fmt.id;
                  return (
                    <button key={fmt.id} onClick={() => { localStorage.setItem("nx_time_format", fmt.id); showToast(t("saved")); }}
                      className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition ${active ? "border-cyan-500 bg-cyan-950/40" : "border-slate-700 text-slate-400"}`}
                      style={active ? { color: accentColor } : undefined}
                    >
                      {fmt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-950/10 border border-amber-900/30">
              <p className="text-xs text-amber-500">⚡ Bu sozlamalar darhol kuchga kiradi</p>
            </div>
          </div>
        )}

        {/* ────── KEYBOARD ────── */}
        {sub === "keyboard" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">⌨️ {t("keyboard")}</h2>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label={t("autocorrect")} desc="Yozayotganda xatolarni avtomatik tuzatish" value={localStorage.getItem("nx_autocorrect") !== "off"}
                onToggle={() => { const v = localStorage.getItem("nx_autocorrect") !== "off"; localStorage.setItem("nx_autocorrect", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
              <Toggle label={t("suggestions")} desc="Keyingi so'z tavsiyalarini ko'rsatish" value={localStorage.getItem("nx_suggestions") !== "off"}
                onToggle={() => { const v = localStorage.getItem("nx_suggestions") !== "off"; localStorage.setItem("nx_suggestions", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
              <Toggle label={t("hapticFeedback")} desc="Klaviatura bosganda tebranish (mobil)" value={localStorage.getItem("nx_haptic") !== "off"}
                onToggle={() => { const v = localStorage.getItem("nx_haptic") !== "off"; localStorage.setItem("nx_haptic", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
              <Toggle label={t("soundFeedback")} desc="Tugma bosganda tovush" value={localStorage.getItem("nx_key_sound") === "on"}
                onToggle={() => { const v = localStorage.getItem("nx_key_sound") === "on"; localStorage.setItem("nx_key_sound", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
              <Toggle label={t("swipeToReply")} desc="Xabar ustida chapga suring — javob berish" value={localStorage.getItem("nx_swipe_reply") !== "off"}
                onToggle={() => { const v = localStorage.getItem("nx_swipe_reply") !== "off"; localStorage.setItem("nx_swipe_reply", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">{t("keyboardHeight")}</p>
              <div className="flex gap-2">
                {[
                  { id: "short",  label: "Past",    h: "30%" },
                  { id: "medium", label: "O'rta",   h: "40%" },
                  { id: "tall",   label: "Baland",  h: "50%" },
                ].map(opt => {
                  const stored = localStorage.getItem("nx_kb_height") || "medium";
                  const active = stored === opt.id;
                  return (
                    <button key={opt.id} onClick={() => { localStorage.setItem("nx_kb_height", opt.id); showToast(t("saved")); }}
                      className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition ${active ? "border-cyan-500 bg-cyan-950/40" : "border-slate-700 text-slate-400"}`}
                      style={active ? { color: accentColor } : undefined}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Maxsus tugmalar (Emoji panel)</p>
              <div className="grid grid-cols-8 gap-1.5">
                {["😊","❤️","😂","🔥","✨","🥺","😎","🤙","💯","👍","🎉","😍","🤔","💪","🙏","😭"].map(e => (
                  <button key={e} className="w-full aspect-square rounded-lg bg-slate-800 hover:bg-slate-700 transition text-base flex items-center justify-center">
                    {e}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-2">Tez javoblar</p>
              {[
                "👍 Ok, tushundim!",
                "🙏 Rahmat!",
                "⏰ Hozir band, keyinroq javob beraman",
                "📍 Lokatsiyani yuboring",
              ].map(txt => (
                <div key={txt} className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-xs text-slate-300 truncate flex-1">{txt}</span>
                  <span className="text-[9px] text-slate-600 ml-2">tap</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ────── STORAGE ────── */}
        {sub === "storage" && (
          <div className="space-y-4 max-w-md">
            <h2 className="text-lg font-bold text-slate-100">💾 {t("storage")}</h2>

            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
              <p className="text-sm font-bold text-slate-300">Saqlash holati</p>
              {[
                { label: "Kesh", icon: "⚡", used: 12, max: 50, color: accentColor },
                { label: "Media fayllar", icon: "🖼️", used: 34, max: 100, color: "#22c55e" },
                { label: "Ovozli xabarlar", icon: "🎙️", used: 8, max: 50, color: "#f59e0b" },
                { label: "Hujjatlar", icon: "📄", used: 5, max: 50, color: "#8b5cf6" },
              ].map(item => (
                <div key={item.label} className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-300">{item.icon} {item.label}</span>
                    <span className="text-[10px] font-mono text-slate-500">{item.used} MB / {item.max} MB</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${(item.used / item.max) * 100}%`, background: item.color }} />
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label={t("downloadWifi")} desc="Faqat Wi-Fi da media fayllarni yuklash" value={localStorage.getItem("nx_dl_wifi") !== "off"}
                onToggle={() => { const v = localStorage.getItem("nx_dl_wifi") !== "off"; localStorage.setItem("nx_dl_wifi", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
              <Toggle label={t("downloadMobile")} desc="Mobil internet orqali media yuklash" value={localStorage.getItem("nx_dl_mobile") === "on"}
                onToggle={() => { const v = localStorage.getItem("nx_dl_mobile") === "on"; localStorage.setItem("nx_dl_mobile", v ? "off" : "on"); showToast(v ? t("disabled") : t("enabled")); }} />
              <Toggle label={t("autoDownload")} desc="Yangi xabarlardagi media avtomatik yuklash" value={autoPlay} onToggle={() => tog("nexus_autoplay", autoPlay, setAutoPlay)} />
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">{t("autoDownload")} sozlamalari</p>
              <div className="space-y-2">
                {[
                  { label: "Rasmlar", key: "nx_dl_img", icon: "🖼️" },
                  { label: "Videolar", key: "nx_dl_vid", icon: "🎬" },
                  { label: "Audio", key: "nx_dl_aud", icon: "🎵" },
                  { label: "Fayllar", key: "nx_dl_file", icon: "📁" },
                ].map(item => (
                  <div key={item.key} className="flex items-center justify-between py-2 border-b border-slate-800/40 last:border-0">
                    <span className="text-sm text-slate-300">{item.icon} {item.label}</span>
                    <button
                      onClick={() => { const v = localStorage.getItem(item.key) !== "off"; localStorage.setItem(item.key, v ? "off" : "on"); showToast(t("saved")); }}
                      className="w-10 h-5 rounded-full transition-all relative flex-shrink-0"
                      style={{ background: localStorage.getItem(item.key) !== "off" ? accentColor : "#1e293b" }}
                    >
                      <div className={`w-4 h-4 rounded-full bg-white shadow absolute top-0.5 transition-all ${localStorage.getItem(item.key) !== "off" ? "translate-x-5" : "translate-x-0.5"}`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <button onClick={() => { localStorage.removeItem("nx_cache"); showToast("✅ Kesh tozalandi!"); }}
              className="w-full py-3 rounded-2xl font-bold text-sm border border-slate-700 text-slate-300 hover:bg-slate-800 transition flex items-center justify-center gap-2">
              🧹 {t("clearCache")}
            </button>

            <div className="p-4 rounded-2xl bg-amber-950/10 border border-amber-900/30">
              <p className="text-xs text-amber-500 font-mono">💡 Keshni tozalash ilovani tezlashtiradi</p>
            </div>
          </div>
        )}

        {/* ────── EXPORT ────── */}
        {sub === "export" && (
          <div className="space-y-4 max-w-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40` }}>📤</div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Ma'lumotlarni eksport qilish</h2>
                <p className="text-xs text-slate-500">Profilingiz va sozlamalaringizni yuklab oling</p>
              </div>
            </div>

            {/* Export progress */}
            {isExporting && (
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-slate-300 font-medium">⏳ Eksport qilinmoqda...</p>
                  <span className="text-sm font-mono" style={{ color: accentColor }}>{exportProgress}%</span>
                </div>
                <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-300" style={{ width: `${exportProgress}%`, background: `linear-gradient(90deg, ${accentColor}, #6366f1)` }} />
                </div>
              </div>
            )}

            {/* Export formats */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Format tanlang</p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { format: "json" as const, icon: "{ }", label: "JSON", desc: "Dasturchilar uchun", color: "#22d3ee" },
                  { format: "txt" as const, icon: "📄", label: "Matn (TXT)", desc: "O'qish uchun qulay", color: "#22c55e" },
                ].map(opt => (
                  <button key={opt.format} onClick={() => handleExport(opt.format)}
                    disabled={isExporting}
                    className="p-4 rounded-2xl border-2 text-left transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed space-y-2"
                    style={{ borderColor: `${opt.color}40`, background: `${opt.color}08` }}
                  >
                    <div className="text-2xl font-black" style={{ color: opt.color }}>{opt.icon}</div>
                    <div>
                      <p className="text-sm font-bold text-slate-200">{opt.label}</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">{opt.desc}</p>
                    </div>
                    <div className="text-[10px] font-bold px-2 py-0.5 rounded-full inline-block" style={{ background: `${opt.color}20`, color: opt.color }}>
                      ↓ Yuklab olish
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* What is exported */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-3">📦 Eksport tarkibi</p>
              {[
                { icon: "👤", label: "Profil ma'lumotlari", sub: "Bio, ism, status" },
                { icon: "🎨", label: "Sozlamalar", sub: "Rang, shrift, til" },
                { icon: "📅", label: "Eksport sanasi", sub: new Date().toLocaleDateString("uz-UZ") },
                { icon: "🔒", label: "Parollar", sub: "Saqlanmaydi (xavfsiz)" },
              ].map(item => (
                <div key={item.label} className="flex items-center gap-3 py-2 border-b border-slate-800/40 last:border-0">
                  <span className="text-base w-7 flex-shrink-0">{item.icon}</span>
                  <div className="flex-1">
                    <p className="text-xs font-semibold text-slate-200">{item.label}</p>
                    <p className="text-[10px] text-slate-500">{item.sub}</p>
                  </div>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                    style={item.label === "Parollar" ? { background: "#1e293b", color: "#ef4444" } : { background: `${accentColor}20`, color: accentColor }}>
                    {item.label === "Parollar" ? "🔒 YO'Q" : "✓ HA"}
                  </span>
                </div>
              ))}
            </div>

            <div className="p-4 rounded-2xl bg-blue-950/20 border border-blue-900/40">
              <p className="text-xs text-blue-300">ℹ️ Ma'lumotlaringiz faqat sizning qurilmangizda saqlanadi. Hech qayerga yuklanmaydi.</p>
            </div>
          </div>
        )}

        {/* ────── ACCESSIBILITY ────── */}
        {sub === "accessibility" && (
          <div className="space-y-4 max-w-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40` }}>♿</div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Aksesibillik</h2>
                <p className="text-xs text-slate-500">Ko'rish va foydalanish qulayligini sozlang</p>
              </div>
            </div>

            {/* Motion & Visual */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Harakat va ko'rinish</p>
              <Toggle label="Animatsiyalarni kamaytirish" desc="Barcha harakat effektlarini o'chirib qo'yadi" value={reducedMotion}
                onToggle={() => { const v = !reducedMotion; setReducedMotion(v); localStorage.setItem("nx_reduced_motion", v ? "on" : "off"); document.documentElement.style.setProperty("--motion", v ? "none" : ""); showToast(v ? "✅ Animatsiyalar kamaytirildi" : "✅ Animatsiyalar yoqildi"); }} />
              <Toggle label="Yuqori kontrast" desc="Matn va elementlarni aniqroq ko'rsatadi" value={highContrast}
                onToggle={() => { const v = !highContrast; setHighContrast(v); localStorage.setItem("nx_high_contrast", v ? "on" : "off"); document.documentElement.classList.toggle("high-contrast", v); showToast(v ? "✅ Yuqori kontrast yoqildi" : "✅ O'chirildi"); }} />
              <Toggle label="Katta tugmalar" desc="Bosish maydonlarini kengaytiradi" value={largeButtons}
                onToggle={() => { const v = !largeButtons; setLargeButtons(v); localStorage.setItem("nx_large_buttons", v ? "on" : "off"); showToast(v ? "✅ Katta tugmalar yoqildi" : "✅ O'chirildi"); }} />
              <Toggle label="Ekran o'quvchi rejim" desc="Screen reader uchun optimallashtirilgan rejim" value={screenReaderMode}
                onToggle={() => { const v = !screenReaderMode; setScreenReaderMode(v); localStorage.setItem("nx_screen_reader", v ? "on" : "off"); showToast(v ? "✅ Yoqildi" : "✅ O'chirildi"); }} />
            </div>

            {/* Font scale */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-slate-300">Matn kattaligi koeffitsienti</p>
                <span className="text-xs font-mono font-bold" style={{ color: accentColor }}>{fontScale}%</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {(["90", "100", "115", "130"] as const).map(scale => (
                  <button key={scale} onClick={() => {
                    setFontScale(scale);
                    localStorage.setItem("nx_font_scale", scale);
                    document.documentElement.style.zoom = `${parseInt(scale) / 100}`;
                    showToast(`✅ ${scale}% qo'llanildi`);
                  }}
                    className="py-3 rounded-xl border-2 text-center transition-all"
                    style={fontScale === scale ? { borderColor: accentColor, background: `${accentColor}18`, color: accentColor } : { borderColor: "#1e293b", color: "#64748b" }}
                  >
                    <div className="font-bold" style={{ fontSize: scale === "90" ? "10px" : scale === "100" ? "12px" : scale === "115" ? "14px" : "16px" }}>Aa</div>
                    <div className="text-[9px] mt-0.5">{scale}%</div>
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-600 font-mono">Butun ilova matniga qo'llaniladi</p>
            </div>

            {/* Color blindness */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">Rang ko'rish filtri</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: "none",        label: "Standart",        desc: "Hech qanday filtr" },
                  { id: "protanopia",  label: "Protanopiya",     desc: "Qizil-yashil" },
                  { id: "deuteranopia", label: "Deuteranopiya", desc: "Yashil zaiflik" },
                  { id: "tritanopia",  label: "Tritanopiya",     desc: "Ko'k-sariq" },
                ].map(opt => {
                  const stored = localStorage.getItem("nx_color_blind") || "none";
                  const active = stored === opt.id;
                  return (
                    <button key={opt.id} onClick={() => { localStorage.setItem("nx_color_blind", opt.id); showToast(`✅ ${opt.label} filtri qo'llanildi`); }}
                      className="p-3 rounded-xl border-2 text-left transition-all"
                      style={active ? { borderColor: accentColor, background: `${accentColor}15` } : { borderColor: "#1e293b" }}
                    >
                      <p className="text-xs font-bold" style={active ? { color: accentColor } : { color: "#94a3b8" }}>{opt.label}</p>
                      <p className="text-[9px] text-slate-600 mt-0.5">{opt.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-green-950/20 border border-green-900/40">
              <p className="text-xs text-green-400">♿ Aksesibillik sozlamalari darhol kuchga kiradi. Qayta yuklash shart emas.</p>
            </div>
          </div>
        )}

        {/* ────── CALLS ────── */}
        {sub === "calls" && (
          <div className="space-y-4 max-w-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40` }}>📞</div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Qo'ng'iroq sozlamalari</h2>
                <p className="text-xs text-slate-500">Ovozli va video qo'ng'iroqlarni sozlang</p>
              </div>
            </div>

            {/* Ringtone */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">🎵 Rington</p>
              <div className="space-y-2">
                {[
                  { id: "cinnamon",  label: "Cinnamon Girl",  icon: "🎵", desc: "Standart (Neil Young)" },
                  { id: "nexus",     label: "NEXUS Beat",     icon: "⚡", desc: "Zamonaviy elektron" },
                  { id: "classic",   label: "Klassik",        icon: "🔔", desc: "An'anaviy qo'ng'iroq" },
                  { id: "vibrate",   label: "Faqat tebranish", icon: "📳", desc: "Ovosiz rejim" },
                  { id: "silent",    label: "Jim",             icon: "🔇", desc: "Bildirishnoma yo'q" },
                ].map(opt => {
                  const active = ringtone === opt.id;
                  return (
                    <button key={opt.id} onClick={() => { setRingtone(opt.id); localStorage.setItem("nx_ringtone", opt.id); showToast(`✅ ${opt.label} tanlandi`); }}
                      className="w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-all text-left"
                      style={active ? { borderColor: accentColor, background: `${accentColor}12` } : { borderColor: "#1e293b" }}
                    >
                      <span className="text-xl w-8 flex-shrink-0 text-center">{opt.icon}</span>
                      <div className="flex-1">
                        <p className="text-sm font-semibold" style={active ? { color: accentColor } : { color: "#cbd5e1" }}>{opt.label}</p>
                        <p className="text-[10px] text-slate-500">{opt.desc}</p>
                      </div>
                      {active && (
                        <div className="w-5 h-5 rounded-full flex items-center justify-center text-black text-[10px] font-black flex-shrink-0" style={{ background: accentColor }}>✓</div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Call quality */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">📶 Qo'ng'iroq sifati</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "sd" as const,   label: "Standart",  desc: "SD · Az internet", icon: "📡" },
                  { id: "auto" as const, label: "Avto",      desc: "Tarmoqqa qarab",   icon: "🔄" },
                  { id: "hd" as const,   label: "Yuqori HD", desc: "HD · Ko'p internet", icon: "🎯" },
                ].map(opt => {
                  const active = callQuality === opt.id;
                  return (
                    <button key={opt.id} onClick={() => { setCallQuality(opt.id); localStorage.setItem("nx_call_quality", opt.id); showToast(`✅ ${opt.label} sifat tanlandi`); }}
                      className="p-3 rounded-xl border-2 text-center transition-all space-y-1"
                      style={active ? { borderColor: accentColor, background: `${accentColor}18` } : { borderColor: "#1e293b" }}
                    >
                      <div className="text-xl">{opt.icon}</div>
                      <p className="text-xs font-bold" style={active ? { color: accentColor } : { color: "#94a3b8" }}>{opt.label}</p>
                      <p className="text-[9px] text-slate-600">{opt.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Toggles */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label="Tebranish" desc="Kiruvchi qo'ng'iroqda telefon titrashi" value={callVibrate}
                onToggle={() => { setCallVibrate(!callVibrate); localStorage.setItem("nx_call_vibrate", !callVibrate ? "on" : "off"); showToast(!callVibrate ? "✅ Yoqildi" : "✅ O'chirildi"); }} />
              <Toggle label="Shovqin filtri (AI)" desc="Fon shovqinlarini avtomatik yo'q qiladi" value={noiseCancellation}
                onToggle={() => { setNoiseCancellation(!noiseCancellation); localStorage.setItem("nx_noise_cancel", !noiseCancellation ? "on" : "off"); showToast(!noiseCancellation ? "✅ AI Filtr yoqildi" : "✅ O'chirildi"); }} />
              <Toggle label="Dinamik ovoz" desc="Qo'ng'iroq boshlanishida telefon dinamigidan ovoz" value={callSpeaker}
                onToggle={() => { setCallSpeaker(!callSpeaker); localStorage.setItem("nx_call_speaker", !callSpeaker ? "on" : "off"); showToast(!callSpeaker ? "✅ Dinamik yoqildi" : "✅ Quloqchin rejim"); }} />
            </div>

            {/* Stats */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <p className="text-sm font-bold text-slate-300 mb-2">📊 Qo'ng'iroq statistikasi</p>
              {[
                { label: "Kiruvchi qo'ng'iroqlar", val: "—", icon: "📲" },
                { label: "Chiquvchi qo'ng'iroqlar", val: "—", icon: "📤" },
                { label: "O'rtacha davomiyligi", val: "—", icon: "⏱️" },
                { label: "Protokol", val: "WebRTC + STUN", icon: "🔗" },
              ].map(s => (
                <div key={s.label} className="flex items-center justify-between py-1.5 border-b border-slate-800/40 last:border-0">
                  <span className="text-xs text-slate-400">{s.icon} {s.label}</span>
                  <span className="text-xs font-mono font-bold" style={{ color: accentColor }}>{s.val}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ────── NETWORK ────── */}
        {sub === "network" && (
          <div className="space-y-4 max-w-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40` }}>🌐</div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Tarmoq sozlamalari</h2>
                <p className="text-xs text-slate-500">WebRTC, STUN/TURN va ulanish</p>
              </div>
            </div>

            {/* Connection status */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">📡 Ulanish holati</p>
              {[
                { label: "Internet", val: navigator.onLine ? "Ulangan" : "Uzilgan", ok: navigator.onLine },
                { label: "WebRTC", val: typeof RTCPeerConnection !== "undefined" ? "Qo'llaniladi" : "Qo'llanilmaydi", ok: typeof RTCPeerConnection !== "undefined" },
                { label: "STUN", val: "Google + Twilio", ok: true },
                { label: "TURN", val: "OpenRelay (bepul)", ok: true },
                { label: "Protokol", val: "WebRTC + ICE + SDP", ok: true },
              ].map(item => (
                <div key={item.label} className="flex items-center justify-between py-1.5 border-b border-slate-800/40 last:border-0">
                  <span className="text-sm text-slate-400">{item.label}</span>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${item.ok ? "bg-green-400" : "bg-red-400"}`} />
                    <span className="text-xs font-mono" style={{ color: item.ok ? accentColor : "#ef4444" }}>{item.val}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* ICE servers */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">🔗 STUN/TURN Serverlar</p>
              <p className="text-xs text-slate-500">Bu serverlar qo'ng'iroqlaringiz turli tarmoqlarda ishlashini ta'minlaydi</p>
              {[
                { server: "stun.l.google.com:19302", type: "STUN", provider: "Google", ping: "~15ms" },
                { server: "stun1.l.google.com:19302", type: "STUN", provider: "Google", ping: "~18ms" },
                { server: "stun2.l.google.com:19302", type: "STUN", provider: "Google", ping: "~20ms" },
                { server: "global.stun.twilio.com:3478", type: "STUN", provider: "Twilio", ping: "~35ms" },
                { server: "openrelay.metered.ca:443", type: "TURN", provider: "OpenRelay", ping: "RELAY" },
              ].map(s => (
                <div key={s.server} className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-950/60">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black flex-shrink-0"
                    style={{ background: s.type === "TURN" ? "#7c3aed20" : `${accentColor}20`, color: s.type === "TURN" ? "#a78bfa" : accentColor }}>
                    {s.type}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-mono text-slate-300 truncate">{s.server}</p>
                    <p className="text-[10px] text-slate-600">{s.provider}</p>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full"
                    style={{ background: `${accentColor}15`, color: accentColor }}>
                    {s.ping}
                  </span>
                </div>
              ))}
            </div>

            {/* Data usage */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">📊 Ma'lumot sarfi (taxminan)</p>
              {[
                { label: "Audio qo'ng'iroq", val: "~0.6 MB/min", icon: "🎙️" },
                { label: "Video qo'ng'iroq (SD)", val: "~3.5 MB/min", icon: "📹" },
                { label: "Video qo'ng'iroq (HD)", val: "~8 MB/min", icon: "🎬" },
                { label: "Rasmlar", val: "~200 KB/dona", icon: "🖼️" },
                { label: "Ovozli xabar", val: "~50 KB/xabar", icon: "🎵" },
              ].map(item => (
                <div key={item.label} className="flex items-center justify-between py-1 border-b border-slate-800/40 last:border-0">
                  <span className="text-xs text-slate-400">{item.icon} {item.label}</span>
                  <span className="text-xs font-mono font-bold" style={{ color: accentColor }}>{item.val}</span>
                </div>
              ))}
            </div>

            {/* Quality settings */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300">⚙️ Ulanish imkoniyatlari</p>
              <div className="space-y-1">
                <Toggle label="ICE Candidate Pooling" desc="Tezroq ulanish uchun ICE nomzodlarini oldindan yig'ish (10 ta)" value={true} onToggle={() => showToast("ℹ️ Bu sozlama avtomatik boshqariladi")} />
                <Toggle label="ICE Restart (avtomatik)" desc="Ulanish uzilganda avtomatik qayta ulanishga harakat qilish" value={true} onToggle={() => showToast("ℹ️ Bu sozlama avtomatik boshqariladi")} />
                <Toggle label="TURN Relay" desc="To'g'ridan-to'g'ri ulanish imkoni bo'lmasa TURN serverdan foydalanish" value={true} onToggle={() => showToast("ℹ️ Bu sozlama avtomatik boshqariladi")} />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-900/30">
              <p className="text-xs text-cyan-400">
                💡 NEXUS_OS barcha qo'ng'iroqlar uchun end-to-end WebRTC shifrlashdan foydalanadi. STUN/TURN serverlar faqat ulanish uchun, media ma'lumotlar bevosita peer-to-peer uzatiladi.
              </p>
            </div>
          </div>
        )}

        {/* ────── SHORTCUTS ────── */}
        {sub === "shortcuts" && (
          <div className="space-y-4 max-w-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40` }}>⚡</div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Klaviatura yorliqlari</h2>
                <p className="text-xs text-slate-500">Ilovani tezroq boshqarish uchun tugmalar</p>
              </div>
            </div>

            {[
              {
                category: "💬 Xabar yozish",
                shortcuts: [
                  { keys: ["Enter"], desc: "Xabar yuborish" },
                  { keys: ["Shift", "Enter"], desc: "Yangi qator qo'shish" },
                  { keys: ["Ctrl", "Z"], desc: "Bekor qilish (Undo)" },
                  { keys: ["Ctrl", "B"], desc: "Qalin matn (Bold)" },
                  { keys: ["Ctrl", "I"], desc: "Kursiv matn (Italic)" },
                  { keys: ["@"], desc: "Foydalanuvchini belgilash" },
                ]
              },
              {
                category: "🗂️ Navigatsiya",
                shortcuts: [
                  { keys: ["Ctrl", "K"], desc: "Qidirish panelini ochish" },
                  { keys: ["Esc"], desc: "Yopish / Orqaga" },
                  { keys: ["Alt", "↑"], desc: "Avvalgi chat" },
                  { keys: ["Alt", "↓"], desc: "Keyingi chat" },
                  { keys: ["Ctrl", "/"], desc: "Yorliqlar ro'yhati" },
                ]
              },
              {
                category: "🎛️ Qo'ng'iroq",
                shortcuts: [
                  { keys: ["M"], desc: "Mikrofonni o'ch/yoq" },
                  { keys: ["V"], desc: "Kamerani o'ch/yoq" },
                  { keys: ["Esc"], desc: "Qo'ng'iroqdan chiqish" },
                  { keys: ["Space"], desc: "Push-to-talk (bosib tuting)" },
                ]
              },
              {
                category: "🔍 Qidiruv",
                shortcuts: [
                  { keys: ["Ctrl", "F"], desc: "Chatda qidirish" },
                  { keys: ["F3"], desc: "Keyingi natija" },
                  { keys: ["Shift", "F3"], desc: "Avvalgi natija" },
                ]
              },
            ].map(group => (
              <div key={group.category} className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900/60">
                <div className="px-4 py-3 border-b border-slate-800/50">
                  <p className="text-sm font-bold text-slate-200">{group.category}</p>
                </div>
                <div className="p-3 space-y-1">
                  {group.shortcuts.map(sc => (
                    <div key={sc.desc} className="flex items-center justify-between py-2 px-1 rounded-lg hover:bg-slate-800/30 transition">
                      <span className="text-sm text-slate-300">{sc.desc}</span>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {sc.keys.map((k, i) => (
                          <span key={i} className="flex items-center gap-1">
                            <kbd className="px-2 py-1 rounded-lg text-[10px] font-bold font-mono border"
                              style={{ background: "#0f172a", borderColor: `${accentColor}40`, color: accentColor, boxShadow: `0 2px 0 ${accentColor}30` }}>
                              {k}
                            </kbd>
                            {i < sc.keys.length - 1 && <span className="text-[9px] text-slate-600">+</span>}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <Toggle label="Yorliqlarni yoqish" desc="Klaviatura yorliqlarini faollashtirish" value={localStorage.getItem("nx_shortcuts") !== "off"}
                onToggle={() => { const v = localStorage.getItem("nx_shortcuts") !== "off"; localStorage.setItem("nx_shortcuts", v ? "off" : "on"); showToast(v ? "✅ Yoqildi" : "🔕 O'chirildi"); }} />
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 text-center">
              <p className="text-xs text-slate-400">💡 Barcha yorliqlar <span className="font-bold" style={{ color: accentColor }}>Desktop</span> uchun. Mobilda touch ishoralar ishlaydi.</p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
