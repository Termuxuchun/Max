import { useState, useEffect, useRef } from "react";
import { ref, set, get, onValue, push, remove, update, onDisconnect } from "firebase/database";
import { db } from "../firebase";
import { Mic, MicOff, PhoneOff, Users, Plus, Lock, Globe, Crown, X, Headphones, Radio } from "lucide-react";

interface Room {
  id: string;
  name: string;
  host: string;
  isPrivate: boolean;
  topic?: string;
  ts: number;
  participants?: Record<string, { muted: boolean; ts: number; role: "host" | "speaker" | "listener" }>;
}

interface Props {
  username: string;
  accentColor: string;
}

const ROOM_ICONS = ["🎙️", "🎵", "💬", "🎮", "📚", "💼", "🌍", "🎯", "🔥", "💡", "🎨", "🏆"];
const TOPICS = ["Umumiy suhbat", "O'yinlar", "Musiqa", "Ta'lim", "Texnologiya", "Biznes", "Ko'ngilochar", "Boshqa"];

const ROOM_GRADIENTS = [
  ["#ef4444", "#ec4899"],
  ["#8b5cf6", "#6366f1"],
  ["#22d3ee", "#3b82f6"],
  ["#10b981", "#22d3ee"],
  ["#f59e0b", "#ef4444"],
  ["#14b8a6", "#6366f1"],
];

function getRoomGradient(name: string): [string, string] {
  const idx = (name.charCodeAt(0) || 0) % ROOM_GRADIENTS.length;
  return ROOM_GRADIENTS[idx] as [string, string];
}

function Avatar({ name, size = 48, isSpeaking = false, isMuted = false, isHost = false }: {
  name: string; size?: number; isSpeaking?: boolean; isMuted?: boolean; isHost?: boolean;
}) {
  const [g1, g2] = getRoomGradient(name);
  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      {isSpeaking && (
        <div
          className="absolute inset-0 rounded-full"
          style={{
            border: "2px solid #22c55e",
            animation: "glow-green 1s ease-in-out infinite",
            boxShadow: "0 0 16px rgba(34,197,94,0.5)",
          }}
        />
      )}
      <div
        className="w-full h-full rounded-full flex items-center justify-center font-black text-white select-none"
        style={{ background: `linear-gradient(135deg, ${g1}, ${g2})`, fontSize: size * 0.36 }}
      >
        {name.slice(0, 2).toUpperCase()}
      </div>
      {isHost && (
        <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center text-[9px]">
          👑
        </div>
      )}
      <div
        className="absolute -bottom-0.5 -right-0.5 rounded-full border-2 border-[#030712] flex items-center justify-center"
        style={{ width: size * 0.3, height: size * 0.3, background: isMuted ? "#dc2626" : "#22c55e" }}
      >
        {isMuted
          ? <MicOff style={{ width: size * 0.15, height: size * 0.15, color: "white" }} />
          : <Mic style={{ width: size * 0.15, height: size * 0.15, color: "white" }} />
        }
      </div>
    </div>
  );
}

export default function VoiceRoomsSection({ username, accentColor }: Props) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [activeRoom, setActiveRoom] = useState<Room | null>(null);
  const [participants, setParticipants] = useState<Room["participants"]>({});
  const [isMuted, setIsMuted] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [roomName, setRoomName] = useState("");
  const [roomTopic, setRoomTopic] = useState("Umumiy suhbat");
  const [isPrivate, setIsPrivate] = useState(false);
  const [creating, setCreating] = useState(false);
  const [roomIcon, setRoomIcon] = useState("🎙️");
  const [speaking, setSpeaking] = useState<Set<string>>(new Set());

  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const speakingIntervalRef = useRef<ReturnType<typeof setInterval>>();

  useEffect(() => {
    return onValue(ref(db, "voicerooms"), snap => {
      const list: Room[] = [];
      if (snap.exists()) {
        snap.forEach(c => {
          const v = c.val();
          const parts = v.participants || {};
          const now = Date.now();
          const activeParts = Object.entries(parts).filter(([, p]: any) => now - p.ts < 30000);
          if (activeParts.length > 0 || v.host === username) {
            list.push({ id: c.key!, ...v });
          }
        });
      }
      setRooms(list.sort((a, b) => {
        const aCount = Object.keys(a.participants || {}).length;
        const bCount = Object.keys(b.participants || {}).length;
        return bCount - aCount;
      }));
    });
  }, [username]);

  useEffect(() => {
    if (!activeRoom) return;
    return onValue(ref(db, `voicerooms/${activeRoom.id}/participants`), snap => {
      setParticipants(snap.val() || {});
    });
  }, [activeRoom]);

  useEffect(() => {
    if (!activeRoom) return;
    const interval = setInterval(() => {
      update(ref(db, `voicerooms/${activeRoom.id}/participants/${username}`), { ts: Date.now() });
    }, 10000);
    return () => clearInterval(interval);
  }, [activeRoom, username]);

  async function joinRoom(room: Room) {
    if (activeRoom) await leaveRoom();
    setActiveRoom(room);
    await update(ref(db, `voicerooms/${room.id}/participants/${username}`), {
      muted: true, ts: Date.now(),
      role: room.host === username ? "host" : "listener"
    });
    onDisconnect(ref(db, `voicerooms/${room.id}/participants/${username}`)).remove();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      localStreamRef.current = stream;
      stream.getAudioTracks().forEach(t => t.enabled = false);
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);
      analyserRef.current.fftSize = 256;
    } catch { /* mikrofon yo'q */ }
  }

  async function leaveRoom() {
    if (!activeRoom) return;
    localStreamRef.current?.getTracks().forEach(t => t.stop());
    localStreamRef.current = null;
    peerConnectionsRef.current.forEach(pc => pc.close());
    peerConnectionsRef.current.clear();
    audioContextRef.current?.close();
    clearInterval(speakingIntervalRef.current);
    await remove(ref(db, `voicerooms/${activeRoom.id}/participants/${username}`));
    const snap = await get(ref(db, `voicerooms/${activeRoom.id}/participants`));
    if (!snap.exists() && activeRoom.host === username) {
      await remove(ref(db, `voicerooms/${activeRoom.id}`));
    }
    setActiveRoom(null);
    setParticipants({});
    setIsMuted(true);
    setSpeaking(new Set());
  }

  function toggleMute() {
    const track = localStreamRef.current?.getAudioTracks()[0];
    if (track) {
      track.enabled = isMuted;
      setIsMuted(!isMuted);
      if (activeRoom) {
        update(ref(db, `voicerooms/${activeRoom.id}/participants/${username}`), { muted: !isMuted });
      }
    }
  }

  async function createRoom() {
    if (!roomName.trim() || creating) return;
    setCreating(true);
    const newRef = push(ref(db, "voicerooms"));
    const room: Omit<Room, "id"> = { name: roomName.trim(), host: username, isPrivate, topic: roomTopic, ts: Date.now() };
    await set(newRef, room);
    setShowCreate(false);
    setRoomName("");
    setIsPrivate(false);
    setCreating(false);
    await joinRoom({ id: newRef.key!, ...room });
  }

  async function deleteRoom(roomId: string) {
    await remove(ref(db, `voicerooms/${roomId}`));
    if (activeRoom?.id === roomId) { setActiveRoom(null); setParticipants({}); }
  }

  const participantList = Object.entries(participants || {})
    .map(([name, data]: [string, any]) => ({ name, ...data }))
    .filter(p => Date.now() - p.ts < 30000);

  return (
    <div className="flex flex-col h-full bg-[#030712] overflow-hidden">
      {/* Header */}
      <div
        className="flex-shrink-0 flex items-center justify-between px-4 py-4 border-b border-slate-800/40 relative overflow-hidden"
        style={{ background: "rgba(8,12,25,0.98)", backdropFilter: "blur(24px)" }}
      >
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg,transparent,#ef444455,#9333ea55,transparent)" }} />
          <div className="absolute bottom-0 left-16 w-28 h-12 rounded-full blur-2xl opacity-10" style={{ background: "linear-gradient(90deg,#ef4444,#9333ea)" }} />
        </div>
        <div className="flex items-center gap-3 relative">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #ef4444, #9333ea)", boxShadow: "0 0 24px rgba(239,68,68,0.35)" }}
          >
            <Radio className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-black text-white tracking-tight">Ovozli Xonalar</p>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
              <span className="text-[10px] text-slate-500">{rooms.length} ta faol xona</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white transition-all active:scale-95 hover:opacity-90 relative"
          style={{ background: "linear-gradient(135deg, #ef4444, #9333ea)", boxShadow: "0 0 20px rgba(239,68,68,0.3)" }}
        >
          <Plus className="w-3.5 h-3.5" /> Xona
        </button>
      </div>

      {/* Active room bar */}
      {activeRoom && (
        <div
          className="flex-shrink-0 px-4 py-2.5 flex items-center gap-3 border-b border-green-900/30"
          style={{ background: "linear-gradient(90deg, rgba(22,101,52,0.25), rgba(20,83,45,0.15))" }}
        >
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse flex-shrink-0" />
            <span className="text-xs text-green-300 font-bold truncate">🎙️ {activeRoom.name}</span>
            <span className="text-[10px] text-green-600 flex-shrink-0">· {participantList.length} kishi</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={toggleMute}
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-all active:scale-90"
              style={{ background: isMuted ? "rgba(220,38,38,0.2)" : "rgba(34,197,94,0.2)", border: `1px solid ${isMuted ? "rgba(220,38,38,0.4)" : "rgba(34,197,94,0.4)"}` }}
            >
              {isMuted ? <MicOff className="w-3.5 h-3.5 text-red-400" /> : <Mic className="w-3.5 h-3.5 text-green-400" />}
            </button>
            <button
              onClick={leaveRoom}
              className="w-7 h-7 rounded-lg flex items-center justify-center bg-red-500/20 border border-red-500/40 transition-all active:scale-90"
            >
              <PhoneOff className="w-3.5 h-3.5 text-red-400" />
            </button>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto">
        {/* Room list */}
        {!activeRoom && (
          <div className="p-3 space-y-2">
            {rooms.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 gap-5">
                <div
                  className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
                  style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.15)" }}
                >
                  🎙️
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold text-slate-400">Faol xona yo'q</p>
                  <p className="text-xs text-slate-600 mt-1">Birinchi xonani siz yarating!</p>
                </div>
                <button
                  onClick={() => setShowCreate(true)}
                  className="px-6 py-2.5 rounded-xl text-sm font-bold text-white transition-all active:scale-95"
                  style={{ background: "linear-gradient(135deg, #ef4444, #9333ea)", boxShadow: "0 0 20px rgba(239,68,68,0.3)" }}
                >
                  + Xona yaratish
                </button>
              </div>
            )}

            {rooms.map((room) => {
              const parts = Object.entries(room.participants || {});
              const activeParts = parts.filter(([, p]: any) => Date.now() - p.ts < 30000);
              const [g1, g2] = getRoomGradient(room.name);
              return (
                <div
                  key={room.id}
                  className="relative rounded-2xl overflow-hidden transition-all duration-200 group"
                  style={{ background: "rgba(15,23,42,0.7)", border: "1px solid rgba(255,255,255,0.06)" }}
                >
                  {/* Gradient accent left */}
                  <div className="absolute left-0 top-0 bottom-0 w-0.5" style={{ background: `linear-gradient(to bottom, ${g1}, ${g2})` }} />

                  <div className="pl-4 pr-3 py-3 flex items-center gap-3">
                    {/* Icon */}
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl flex-shrink-0"
                      style={{ background: `linear-gradient(135deg, ${g1}20, ${g2}10)`, border: `1px solid ${g1}30` }}
                    >
                      🎙️
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <p className="text-sm font-bold text-white truncate">{room.name}</p>
                        {room.isPrivate
                          ? <Lock className="w-3 h-3 text-amber-400 flex-shrink-0" />
                          : <Globe className="w-3 h-3 text-slate-600 flex-shrink-0" />
                        }
                        {room.host === username && <Crown className="w-3 h-3 text-amber-400 flex-shrink-0" />}
                      </div>
                      <p className="text-[10px] text-slate-500 mb-1.5">@{room.host} · {room.topic}</p>

                      {/* Participants avatars */}
                      <div className="flex items-center gap-2">
                        <div className="flex -space-x-1.5">
                          {activeParts.slice(0, 6).map(([name]) => {
                            const [ag1, ag2] = getRoomGradient(name);
                            return (
                              <div
                                key={name}
                                className="w-5 h-5 rounded-full flex items-center justify-center text-[7px] font-bold text-white border border-[#030712]"
                                style={{ background: `linear-gradient(135deg, ${ag1}, ${ag2})` }}
                              >
                                {(name as string).slice(0, 1).toUpperCase()}
                              </div>
                            );
                          })}
                          {activeParts.length > 6 && (
                            <div className="w-5 h-5 rounded-full bg-slate-800 border border-[#030712] flex items-center justify-center text-[7px] text-slate-400">
                              +{activeParts.length - 6}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                          <span className="text-[10px] text-green-400 font-medium">{activeParts.length} kishi</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => joinRoom(room)}
                        className="px-3 py-1.5 rounded-xl text-[10px] font-bold text-white transition-all active:scale-90"
                        style={{ background: `linear-gradient(135deg, ${g1}, ${g2})` }}
                      >
                        Kirish
                      </button>
                      {room.host === username && (
                        <button
                          onClick={() => deleteRoom(room.id)}
                          className="px-3 py-1.5 rounded-xl text-[10px] font-bold text-red-400 bg-red-950/30 border border-red-900/40 transition-all active:scale-90"
                        >
                          Yopish
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* In-room view */}
        {activeRoom && (
          <div className="p-4 space-y-6">
            {/* Room title */}
            <div className="text-center space-y-1">
              <div
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-2"
                style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.2)" }}
              >
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs text-green-400 font-bold">JONLI</span>
              </div>
              <p className="text-xl font-black text-white">{activeRoom.name}</p>
              <p className="text-xs text-slate-500">{activeRoom.topic}</p>
            </div>

            {/* Participants grid */}
            <div className="grid grid-cols-3 gap-3">
              {participantList.map(p => (
                <div
                  key={p.name}
                  className="flex flex-col items-center gap-2 p-3 rounded-2xl transition-all duration-300"
                  style={{
                    background: speaking.has(p.name) ? "rgba(34,197,94,0.08)" : "rgba(15,23,42,0.6)",
                    border: speaking.has(p.name) ? "1px solid rgba(34,197,94,0.3)" : "1px solid rgba(51,65,85,0.4)",
                  }}
                >
                  <Avatar
                    name={p.name}
                    size={52}
                    isSpeaking={speaking.has(p.name)}
                    isMuted={p.muted}
                    isHost={p.name === activeRoom.host}
                  />
                  <p className="text-[10px] font-bold text-slate-200 truncate w-full text-center">@{p.name}</p>
                  <span
                    className="text-[8px] px-1.5 py-0.5 rounded-full"
                    style={{
                      background: p.role === "host" ? "rgba(245,158,11,0.15)" : "rgba(99,102,241,0.1)",
                      color: p.role === "host" ? "#fbbf24" : "#818cf8",
                    }}
                  >
                    {p.role === "host" ? "Host" : p.role === "speaker" ? "Nutqchi" : "Tinglovchi"}
                  </span>
                </div>
              ))}
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-5 pt-2">
              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={toggleMute}
                  className="w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 active:scale-90"
                  style={{
                    background: isMuted ? "rgba(220,38,38,0.15)" : "rgba(34,197,94,0.15)",
                    border: `2px solid ${isMuted ? "#dc262660" : "#22c55e60"}`,
                  }}
                >
                  {isMuted ? <MicOff className="w-6 h-6 text-red-400" /> : <Mic className="w-6 h-6 text-green-400" />}
                </button>
                <span className="text-[10px] text-slate-500">{isMuted ? "O'chiq" : "Yoqiq"}</span>
              </div>

              <div className="flex flex-col items-center gap-1.5">
                <button
                  onClick={leaveRoom}
                  className="w-16 h-16 rounded-full flex items-center justify-center transition-all active:scale-90 glow-red"
                  style={{ background: "linear-gradient(135deg, #dc2626, #9333ea)" }}
                >
                  <PhoneOff className="w-6 h-6 text-white" />
                </button>
                <span className="text-[10px] text-slate-500">Chiqish</span>
              </div>

              <div className="flex flex-col items-center gap-1.5">
                <button className="w-14 h-14 rounded-full flex items-center justify-center bg-white/10 border border-white/15 transition-all active:scale-90">
                  <Headphones className="w-6 h-6 text-slate-400" />
                </button>
                <span className="text-[10px] text-slate-500">Quloqchin</span>
              </div>
            </div>

            <p className="text-center text-[10px] text-slate-700 pb-2">
              {participantList.length} ishtirokchi · {isMuted ? "Mikrofon o'chiq" : "🔴 Mikrofon yoqiq"}
            </p>
          </div>
        )}
      </div>

      {/* Create Room Modal */}
      {showCreate && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center"
          style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(12px)" }}
        >
          <div
            className="w-full max-w-md rounded-t-3xl p-6 space-y-4"
            style={{ background: "rgba(9,14,30,0.98)", border: "1px solid rgba(255,255,255,0.08)", borderBottom: "none" }}
          >
            {/* Handle */}
            <div className="w-10 h-1 rounded-full bg-slate-700 mx-auto -mt-1" />

            <div className="flex items-center justify-between">
              <p className="font-black text-white">Yangi Xona</p>
              <button onClick={() => setShowCreate(false)} className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {/* Icon grid */}
            <div className="grid grid-cols-6 gap-2">
              {ROOM_ICONS.map(ic => (
                <button
                  key={ic}
                  onClick={() => setRoomIcon(ic)}
                  className="text-xl py-2 rounded-xl transition-all"
                  style={{
                    background: roomIcon === ic ? `${accentColor}20` : "rgba(30,41,59,0.4)",
                    border: roomIcon === ic ? `1px solid ${accentColor}50` : "1px solid transparent",
                  }}
                >
                  {ic}
                </button>
              ))}
            </div>

            <input
              value={roomName}
              onChange={e => setRoomName(e.target.value)}
              maxLength={40}
              placeholder="Xona nomi..."
              className="w-full px-4 py-3 rounded-xl text-sm bg-slate-900/60 border border-slate-800 text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-500/50 transition"
            />

            <div>
              <p className="text-[10px] text-slate-500 mb-2 font-semibold uppercase tracking-widest">Mavzu</p>
              <div className="flex flex-wrap gap-2">
                {TOPICS.map(t => (
                  <button
                    key={t}
                    onClick={() => setRoomTopic(t)}
                    className="px-3 py-1.5 rounded-xl text-xs font-medium transition"
                    style={{
                      background: roomTopic === t ? `${accentColor}20` : "rgba(30,41,59,0.5)",
                      color: roomTopic === t ? accentColor : "#64748b",
                      border: roomTopic === t ? `1px solid ${accentColor}40` : "1px solid transparent",
                    }}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setIsPrivate(!isPrivate)}
              className="flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all"
              style={{
                background: isPrivate ? "rgba(245,158,11,0.08)" : "rgba(30,41,59,0.4)",
                border: isPrivate ? "1px solid rgba(245,158,11,0.25)" : "1px solid rgba(51,65,85,0.3)",
              }}
            >
              {isPrivate ? <Lock className="w-4 h-4 text-amber-400" /> : <Globe className="w-4 h-4 text-slate-500" />}
              <span className="text-xs font-semibold" style={{ color: isPrivate ? "#fbbf24" : "#64748b" }}>
                {isPrivate ? "Xususiy (yopiq) xona" : "Ochiq xona — hamma ko'ra oladi"}
              </span>
            </button>

            <button
              onClick={createRoom}
              disabled={!roomName.trim() || creating}
              className="w-full py-3.5 rounded-xl text-sm font-black text-white transition-all active:scale-95 disabled:opacity-40"
              style={{ background: "linear-gradient(135deg, #ef4444, #9333ea)", boxShadow: "0 0 20px rgba(239,68,68,0.3)" }}
            >
              {creating ? "Yaratilmoqda..." : `${roomIcon} Xona yaratish`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
