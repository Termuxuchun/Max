import { useEffect, useRef, useState, useCallback } from "react";
import { ref, set, push, update, remove, get, onValue, onChildAdded, onChildChanged, onChildRemoved, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import { uploadToStorage } from "../lib/uploadMedia";
import { BADGES } from "./SettingsSection";
import { animClassForMsg, CHAT_ANIMATIONS } from "../lib/stars";
import {
  Send, Mic, Smile, Paperclip, Phone, Images, Search, Flame, MapPin, Globe,
  Reply, Pencil, Trash2, Pin, StopCircle, X, ChevronLeft, Bot,
  Forward, Bookmark, CheckCheck, Check, AtSign, Palette, MoreHorizontal,
  RotateCcw, Eraser
} from "lucide-react";

interface Message {
  id: string;
  sender: string;
  text: string;
  type: "text" | "image" | "voice" | "location";
  status: "sent" | "read";
  secret?: boolean;
  replyTo?: { id: string; sender: string; preview: string };
  pinned?: boolean;
  timestamp: number;
  edited?: boolean;
  originalText?: string;
  deleted?: boolean;
  deletedAt?: number;
  animation?: string;
  reactions?: Record<string, Record<string, boolean>>;
}

const QUICK_REACTIONS = ["❤️","👍","😂","😮","😢","🔥","🎉","👏"];

const CHAT_THEMES: { id: string; label: string; style: React.CSSProperties; dot: string }[] = [
  { id: "",         label: "Default",   style: {},                                                               dot: "#0f172a" },
  { id: "matrix",   label: "Matrix",    style: { backgroundImage: "repeating-linear-gradient(0deg,transparent,transparent 39px,rgba(74,222,128,0.04) 40px),repeating-linear-gradient(90deg,transparent,transparent 39px,rgba(74,222,128,0.03) 40px)" }, dot: "#4ade80" },
  { id: "purple",   label: "Nebula",    style: { backgroundImage: "radial-gradient(ellipse 80% 80% at 20% 20%,rgba(139,92,246,0.08) 0%,transparent 60%),radial-gradient(ellipse 60% 60% at 80% 80%,rgba(236,72,153,0.06) 0%,transparent 50%)" }, dot: "#8b5cf6" },
  { id: "ocean",    label: "Okean",     style: { backgroundImage: "linear-gradient(160deg,rgba(6,182,212,0.06) 0%,transparent 50%,rgba(59,130,246,0.06) 100%)" }, dot: "#06b6d4" },
  { id: "sunset",   label: "Sunset",    style: { backgroundImage: "linear-gradient(150deg,rgba(245,158,11,0.06) 0%,transparent 40%,rgba(239,68,68,0.05) 100%)" }, dot: "#f59e0b" },
  { id: "mint",     label: "Mint",      style: { backgroundImage: "radial-gradient(ellipse 100% 60% at 50% 0%,rgba(20,184,166,0.07) 0%,transparent 70%)" }, dot: "#14b8a6" },
  { id: "rose",     label: "Atirgul",   style: { backgroundImage: "radial-gradient(ellipse 80% 80% at 80% 20%,rgba(244,63,94,0.07) 0%,transparent 60%)" }, dot: "#f43f5e" },
  { id: "gold",     label: "Oltin",     style: { backgroundImage: "radial-gradient(ellipse 100% 80% at 50% 100%,rgba(234,179,8,0.07) 0%,transparent 60%)" }, dot: "#eab308" },
];

interface ChatSectionProps {
  username: string;
  targetUser: string;
  isGroup: boolean;
  groupMeta: any;
  onBack?: () => void;
  accentColor: string;
  onStartCall?: (peer: string) => void;
  onOpenProfile?: (peer: string) => void;
  isPremium?: boolean;
}

const BOTS = ["NexusBot", "StarBot", "QuizBot", "WeatherBot", "HoroscopeBot", "JokeBot", "MafiaBot", "AIBot"];

const BOT_RESPONSES: Record<string, (cmd: string, user: string) => Promise<string>> = {
  NexusBot: async (cmd, user) => {
    const c = cmd.trim().toLowerCase();
    if (c === "/start" || c === "start") return "👋 Salom! Men NexusBot — sizning shaxsiy yordamchingizman!\n\nBuyruqlar:\n/help — Barcha buyruqlar\n/stars — Star balansingiz\n/premium — Premium haqida\n/info — NEXUS haqida";
    if (c === "/help" || c === "help") return "📋 NexusBot buyruqlari:\n\n/stars — Yulduz balansingizni tekshirish\n/premium — Premium imtiyozlari haqida\n/info — Ilova haqida ma'lumot\n/start — Qayta boshlash\n\n💡 StarBot ga Stars sotib olish uchun murojaat qiling.";
    if (c === "/stars") {
      const { ref: dbRef, get: dbGet } = await import("firebase/database");
      const { db } = await import("../firebase");
      const snap = await dbGet(dbRef(db, `stars/${user}`));
      const bal = snap.val()?.balance || 0;
      return `⭐ Sizning balansingiz: ${bal} yulduz\n\nYulduzlar sovg'alar uchun ishlatiladi.\n💳 Sotib olish uchun StarBot ga yozing yoki ilovadagi ⭐ tugmasini bosing.`;
    }
    if (c === "/premium") return "👑 NEXUS Premium imtiyozlari:\n\n✨ Animatsiyali postlar va hikoyalar\n🎁 Stars bilan sovg'alar yuborish\n📡 Cheksiz kanallar\n🏆 Premium nishonlar\n⭐ Exclusive chat animatsiyalari\n\nPremium olish uchun Settings > Premium ga boring!";
    if (c === "/info") return "ℹ️ NEXUS_OS v5.6\n\nConnectUz tizimi — O'zbekistonning eng kuchli messenjer platformasi.\n\n🌐 Real-time xabarlar\n🎮 O'yinlar\n📡 Kanallar & Guruhlar\n⭐ Stars tizimi\n🎁 Sovg'alar\n📞 Audio/Video qo'ng'iroqlar";
    return "❓ Noma'lum buyruq. /help yozing buyruqlar ro'yxatini ko'rish uchun.";
  },
  StarBot: async (cmd, user) => {
    const c = cmd.trim().toLowerCase();
    if (c === "/start" || c === "start") return "⭐ StarBot ga xush kelibsiz!\n\nMen sizga Stars (yulduzlar) bilan ishlashda yordam beraman.\n\nBuyruqlar:\n/balance — Balansingizni ko'rish\n/buy — Paketlarni ko'rish\n/help — Yordam";
    if (c === "/balance") {
      const { ref: dbRef, get: dbGet } = await import("firebase/database");
      const { db } = await import("../firebase");
      const snap = await dbGet(dbRef(db, `stars/${user}`));
      const bal = snap.val()?.balance || 0;
      return `⭐ Balansingiz: ${bal} Stars\n\nYulduzlar sovg'alar yuborish uchun ishlatiladi:\n🌹 Atirgul — 5⭐\n🧸 Ayiqcha — 25⭐\n💍 Uzuk — 100⭐\n👑 Toj — 500⭐\n🐉 Ajdaho — 1000⭐`;
    }
    if (c === "/buy" || c === "/shop") return "🛒 Stars paketlari:\n\n⭐ 100 Stars — 0.99$\n⭐⭐ 250 Stars — 1.99$ 🔥\n🌟 500 Stars — 3.99$\n💫 1000 Stars — 6.99$\n✨ 2500 Stars — 14.99$\n🎆 5000 Stars — 24.99$\n\n👆 Ilovadagi ⭐ tugmasini bosib shop ni oching!\nSotib olish so'rovi admin tomonidan tasdiqlanadi.";
    if (c === "/help") return "⭐ StarBot buyruqlari:\n\n/balance — Balansingizni tekshirish\n/buy — Paketlarni ko'rish\n/start — Boshlash\n\n💡 Sovg'alar yuborish uchun foydalanuvchi profiliga kiring.";
    return "❓ Noma'lum buyruq. /help yozing yoki /buy Stars sotib olish uchun.";
  },

  QuizBot: async (cmd) => {
    const c = cmd.trim().toLowerCase();
    const QUIZZES = [
      { q: "🌍 Dunyo bo'yicha eng katta mamlakat?", a: "Rossiya", opts: ["Xitoy", "Rossiya", "Kanada", "AQSh"] },
      { q: "🧪 Oltin kimyoviy belgi?", a: "Au", opts: ["Go", "Au", "Ag", "Fe"] },
      { q: "🌊 Dunyo bo'yicha eng chuqur okean?", a: "Tinch okean", opts: ["Atlantika", "Hind", "Tinch okean", "Shimoliy muz"] },
      { q: "🦁 Afrikaning eng katta hayvoni?", a: "Fil", opts: ["Sher", "Begemot", "Fil", "Karkidon"] },
      { q: "🏔️ Dunyodagi eng baland tog'?", a: "Everest", opts: ["K2", "Everest", "Cho Oyu", "Kanchenjunga"] },
      { q: "🇺🇿 O'zbekistonning poytaxti?", a: "Toshkent", opts: ["Samarqand", "Buxoro", "Toshkent", "Namangan"] },
      { q: "🎵 Nota yozuvi nechanchi asrda paydo bo'lgan?", a: "XI asr", opts: ["X asr", "XI asr", "XII asr", "VIII asr"] },
      { q: "🔢 π (Pi) sonining qiymati (2 kasrdan keyin)?", a: "3.14", opts: ["3.12", "3.14", "3.16", "3.18"] },
      { q: "💡 Elektr lampasini kim ixtiro qilgan?", a: "Edison", opts: ["Tesla", "Edison", "Newton", "Faraday"] },
      { q: "🚀 Oyga birinchi qo'ngan inson?", a: "Neil Armstrong", opts: ["Buzz Aldrin", "Neil Armstrong", "Yuri Gagarin", "John Glenn"] },
    ];
    if (c === "/start" || c === "start") return "🎯 QuizBot ga xush kelibsiz!\n\nMen sizga bilim sinovlari o'tkazaman.\n\nBuyruqlar:\n/quiz — Tasodifiy savol\n/help — Yordam\n\n💡 Shunchaki yozing ham savolga javob beraman!";
    if (c === "/help") return "🎯 QuizBot buyruqlari:\n\n/quiz — Yangi savol\n/start — Boshlash\n\n📊 Bilim sohalari: Geografiya, Fan, Tarix, Sport, O'zbekiston";
    const q = QUIZZES[Math.floor(Math.random() * QUIZZES.length)];
    return `🎯 Savol:\n${q.q}\n\n${q.opts.map((o, i) => `${["A", "B", "C", "D"][i]}) ${o}`).join("\n")}\n\n✅ Javob: ${q.a}`;
  },

  WeatherBot: async (cmd) => {
    const c = cmd.trim().toLowerCase();
    const CITIES: Record<string, { temp: number; feel: number; cond: string; icon: string; humidity: number; wind: number }> = {
      toshkent:    { temp: Math.floor(18 + Math.random() * 15), feel: Math.floor(16 + Math.random() * 14), cond: "Qisman bulutli", icon: "⛅", humidity: 45, wind: 12 },
      samarqand:   { temp: Math.floor(20 + Math.random() * 13), feel: Math.floor(18 + Math.random() * 12), cond: "Quyoshli",       icon: "☀️", humidity: 38, wind: 8  },
      namangan:    { temp: Math.floor(17 + Math.random() * 14), feel: Math.floor(15 + Math.random() * 13), cond: "Bulutli",        icon: "🌤️", humidity: 52, wind: 15 },
      andijon:     { temp: Math.floor(19 + Math.random() * 12), feel: Math.floor(17 + Math.random() * 11), cond: "Quyoshli",       icon: "☀️", humidity: 40, wind: 10 },
      fargona:     { temp: Math.floor(18 + Math.random() * 13), feel: Math.floor(16 + Math.random() * 12), cond: "Bulutli",        icon: "⛅", humidity: 48, wind: 11 },
      buxoro:      { temp: Math.floor(22 + Math.random() * 15), feel: Math.floor(20 + Math.random() * 14), cond: "Issiq & quruq",  icon: "🌞", humidity: 25, wind: 6  },
      nukus:       { temp: Math.floor(15 + Math.random() * 18), feel: Math.floor(13 + Math.random() * 17), cond: "Shamolly",       icon: "🌬️", humidity: 55, wind: 22 },
      qarshi:      { temp: Math.floor(21 + Math.random() * 14), feel: Math.floor(19 + Math.random() * 13), cond: "Quyoshli",       icon: "☀️", humidity: 30, wind: 9  },
    };
    if (c === "/start" || c === "start") return "🌤️ WeatherBot ga xush kelibsiz!\n\nO'zbekiston shaharlarining ob-havosi:\n\n📍 Shahar nomini yozing, masalan:\nToshkent, Samarqand, Namangan...\n\nBuyruqlar:\n/cities — Barcha shaharlar\n/help — Yordam";
    if (c === "/cities" || c === "/list") return "📍 Mavjud shaharlar:\n\n🏙️ Toshkent\n🌹 Samarqand\n🧵 Namangan\n📱 Andijon\n🏭 Farg'ona\n🌵 Buxoro\n💧 Nukus\n⛏️ Qarshi\n\nShahar nomini yozing!";
    if (c === "/help") return "🌤️ WeatherBot buyruqlari:\n\n/cities — Barcha shaharlar\n/start — Boshlash\n\nYoki shahar nomini to'g'ridan-to'g'ri yozing.";
    const city = Object.keys(CITIES).find(k => c.includes(k));
    if (city) {
      const w = CITIES[city];
      w.temp = Math.floor(18 + Math.random() * 15);
      return `🌤️ ${city.charAt(0).toUpperCase() + city.slice(1)} ob-havosi:\n\n${w.icon} ${w.cond}\n🌡️ Harorat: ${w.temp}°C (his qilinadi: ${w.feel}°C)\n💧 Namlik: ${w.humidity}%\n💨 Shamol: ${w.wind} km/soat\n\n📅 ${new Date().toLocaleDateString("uz-UZ", { weekday: "long", day: "numeric", month: "long" })}`;
    }
    return `🌤️ Shahar topilmadi.\n\n/cities yozing mavjud shaharlar ro'yxati uchun.\n\nYoki: Toshkent, Samarqand, Namangan...`;
  },

  HoroscopeBot: async (cmd) => {
    const c = cmd.trim().toLowerCase();
    const SIGNS: Record<string, { emoji: string; dates: string; prediction: string[] }> = {
      hamal:    { emoji: "♈", dates: "Mar 21 — Apr 19", prediction: ["Bugun ajoyib yangiliklar kutmoqda!", "Ishda katta yutuqlar oldinda.", "Sevgi hayotingizda ijobiy o'zgarishlar bo'ladi.", "Moliyaviy jihatdan omadli kun."] },
      savr:     { emoji: "♉", dates: "Apr 20 — May 20", prediction: ["Sabr-qanoat bilan maqsadga erishing.", "Do'stlaringiz sizni qo'llab-quvvatlaydi.", "Yangi imkoniyatlar eshigi ochilmoqda.", "Sog'liqqa e'tibor bering."] },
      javzo:    { emoji: "♊", dates: "May 21 — Jun 20", prediction: ["Kommunikatsiya orqali muammolarni hal qiling.", "Ijodiy g'oyalar pul keltiради.", "Sayohat rejalashtiring.", "Eski do'stingiz bilan uchrashuvingiz kutmoqda."] },
      saraton:  { emoji: "♋", dates: "Jun 21 — Jul 22", prediction: ["Oila bilan vaqt o'tkazing.", "Intuitsiyangizga ishoning.", "Moliyaviy investitsiya foydali bo'ladi.", "Bugun yaxshi xabar olasiz."] },
      asad:     { emoji: "♌", dates: "Jul 23 — Aug 22", prediction: ["Liderlik sifatlaringiz namoyon bo'ladi.", "Ijodiy loyihalarda muvaffaqiyat.", "Sevgilidan sovg'a kutish mumkin.", "Obro'ingiz ko'tariladi."] },
      sunbula:  { emoji: "♍", dates: "Aug 23 — Sep 22", prediction: ["Tartib va intizom muvaffaqiyat keltiradi.", "Sog'liq uchun sport bilan shug'ullaning.", "Ish joydagi muammolar hal bo'ladi.", "Diqqatli bo'ling, muhim hujjatlarni tekshiring."] },
      mezon:    { emoji: "♎", dates: "Sep 23 — Oct 22", prediction: ["Muvozanat saqlang.", "Yangi tanishlar hayotingizga kiradi.", "Estetik jihatdan iste'dodingiz yorqin namoyon bo'ladi.", "Hamkorlikdan foyda olasiz."] },
      aqrab:    { emoji: "♏", dates: "Oct 23 — Nov 21", prediction: ["Sirlarni oshkor qilmang.", "Qizg'in sevgi hislari kuchayadi.", "Moliyaviy operatsiyalarda ehtiyot bo'ling.", "Kuchli intuitsiyangizdan foydalaning."] },
      qavs:     { emoji: "♐", dates: "Nov 22 — Dec 21", prediction: ["Yangi bilim olishga intiling.", "Uzoq safar yangi imkoniyatlar ochadi.", "Optimizm muvaffaqiyat kaliti.", "Yangi do'stliklar paydo bo'ladi."] },
      jaddi:    { emoji: "♑", dates: "Dec 22 — Jan 19", prediction: ["Mehnatkor bo'lish natija beradi.", "Eski loyiha nihoyat tugallanadi.", "Moliyaviy barqarorlik kuchayadi.", "Oilada baxt muhiti hukm suradi."] },
      dalv:     { emoji: "♒", dates: "Jan 20 — Feb 18", prediction: ["Inqilobiy g'oyalar amalga oshadi.", "Texnologiya sohasida yangiliklar kutmoqda.", "Do'stlar yordamida maqsadga erishing.", "Original fikrlar e'tiborni jalb qiladi."] },
      hut:      { emoji: "♓", dates: "Feb 19 — Mar 20", prediction: ["Ijodiy qobiliyatlaringiz cho'qqisiga chiqadi.", "Sevgida yangi bosqich boshlanadi.", "Ruhiy tinchlikni saqlang.", "Intuitsiyangizni tinglab harakAt qiling."] },
    };
    if (c === "/start" || c === "start") return "⭐ HoroscopeBot ga xush kelibsiz!\n\nBurjingizni yozing:\n♈ Hamal · ♉ Savr · ♊ Javzo\n♋ Saraton · ♌ Asad · ♍ Sunbula\n♎ Mezon · ♏ Aqrab · ♐ Qavs\n♑ Jaddi · ♒ Dalv · ♓ Hut\n\n/help — Yordam";
    if (c === "/help") return "⭐ HoroscopeBot buyruqlari:\n\n/today — Bugungi umumiy fol\n/signs — Barcha burjlar\n\nYoki burj nomini yozing: Hamal, Savr...";
    if (c === "/today") return `🌟 Bugun ${new Date().toLocaleDateString("uz-UZ", { day: "numeric", month: "long" })} — Umumiy bashorat:\n\nKun omadli kunlardan biri! Muhim qarorlar qabul qilishga tayyor bo'ling. Moliyaviy jihatdan ehtiyot bo'ling, lekin kichik xarajatlar uchun xavotir olmang. Sevgilingiz bilan ochiq muloqot muhim. 🌙`;
    const sign = Object.keys(SIGNS).find(s => c.includes(s));
    if (sign) {
      const sg = SIGNS[sign];
      const pred = sg.prediction[Math.floor(Math.random() * sg.prediction.length)];
      return `${sg.emoji} ${sign.charAt(0).toUpperCase() + sign.slice(1)} — ${sg.dates}\n\n⭐ Bugungi bashorat:\n${pred}\n\n🌙 ${new Date().toLocaleDateString("uz-UZ", { weekday: "long", day: "numeric", month: "long" })}`;
    }
    return "⭐ Burjingizni to'g'ri yozing.\n\nMasalan: Hamal, Savr, Javzo, Saraton...\n\n/help — Barcha buyruqlar";
  },

  JokeBot: async (cmd) => {
    const c = cmd.trim().toLowerCase();
    const JOKES = [
      "Programmist kolbasa sotib olmoqchi edi.\n— Bir dona kolbasa kerak!\nDo'konchi: — Ko'proq olsangizchi?\nProgrammist: — Index 0 dan boshlanadi, 1 ta yetarli! 😄",
      "Matematikdan imtihon:\n— 2 × 2 nechchi?\nBoy bola: — 4.\nO'qituvchi: — Yana bir urinib ko'r!\nBoy bola: — Ular nechtasini xohlashadi? 😂",
      "O'g'il bolaga: — Nima bo'lmoqchisan?\n— Doktor!\n— Nima uchun?\n— Chunki hammani kasalxonaga yotatishadi, men esa ularning noutbuklarini olib ketaman! 😅",
      "WiFi parolingiz nima?\n— Bir daqiqa kuting!\nParol: birdaqiqakuting 😂",
      "Stomatolog: — Og'zimni oching!\nBemorning og'zi allaqachon ochiq edi... stomatolog ham ochiq og'iz qoldi! 😁",
      "Ingliz tili: — Apple — olma\nO'quvchi: — Demak, pineapple — pine + apple?\nO'qituvchi: — Ha, nima demoqchisiz?\nO'quvchi: — Pine suz... kasal olma? 🤔😂",
      "Chol: — Yoshligimda 10 km yo'ldim!\nNevara: — Bugun ham 10 km yurding, lekin qaysi yo'nalishdasan? 😂",
      "Programmist xotiniga: — Tuz olib kel, yuz bo'lmasa, olib kelma!\nXotin ikki soatdan keyin qaytib keldi... 😄",
      "— Hayotda eng qo'rqinchli narsa nima?\nProgrammist: — `undefined is not a function` xatosi 😱",
      "Talaba imtihonga kech keldi.\n— Nimaga kechdingiz?\nTalaba: — Ertalab soat 8 da keladigan avtobus bor edi, men uyquda qoldim.\nO'qituvchi: — U avtobus 8 da yo'q!\nTalaba: — Aniq shundaymi? Men uxlab qoldim deb o'ylabman... 😄",
    ];
    if (c === "/start" || c === "start") return "😂 JokeBot ga xush kelibsiz!\n\nKun bo'yi kayfiyatingizni ko'tarib turaman!\n\nBuyruqlar:\n/joke — Tasodifiy latifa\n/help — Yordam\n\n💡 Istalgan narsa yozing — javob beraman!";
    if (c === "/help") return "😂 JokeBot buyruqlari:\n\n/joke — Yangi latifa\n/start — Boshlash\n\n🎭 Dasturlash, maktab, hayot haqida qiziqarli latifalari bor!";
    return `${JOKES[Math.floor(Math.random() * JOKES.length)]}`;
  },

  MafiaBot: async (cmd, user) => {
    const c = cmd.trim().toLowerCase();
    const { ref: dbRef, set: dbSet, get: dbGet, update: dbUpdate } = await import("firebase/database");
    const { db: fireDb } = await import("../firebase");

    if (c === "/start" || c === "start") {
      return "🕵️ MafiaBot ga xush kelibsiz!\n\nMen orqali Mafia o'yiniga multiplayer rejimida qo'shilishingiz mumkin.\n\nBuyruqlar:\n/create — Yangi o'yin xonasi yaratish\n/join KOD — Xonaga qo'shilish\n/help — Yordam\n\n🎮 O'yinlar bo'limida ham o'ynashingiz mumkin!";
    }
    if (c === "/help") {
      return "🕵️ MafiaBot buyruqlari:\n\n/create — Yangi multiplayer xona yaratish\n/join KOD — Mavjud xonaga qo'shilish\n/start — Boshlash\n\n🎯 Rollar:\n🎩 Katta Usta · 🕵️ Mafia\n🔍 Detektiv · 💊 Shifokor\n🛡️ Himoyachi · ⭐ Meriya\n🧙 Jodugar · ⚡ Qahramon\n🏛️ Mayor · 🃏 Masxaraboz · 👤 Fuqaro";
    }

    if (c === "/create") {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
      const roomId = Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
      const now = Date.now();
      await dbSet(dbRef(fireDb, `mafia_rooms/${roomId}`), {
        host: user,
        status: "waiting",
        createdAt: now,
        startAt: now + 300000,
        phase: "lobby",
        day: 0,
        players: { [user]: { name: user, alive: true, role: null, ready: true, joinedAt: now } },
        nightActions: {},
        voteActions: {},
        morningNews: [],
        winner: null,
        chatLines: {},
      });
      await dbSet(dbRef(fireDb, `users/${user}/activeMafiaRoom`), roomId);
      return `🎮 Yangi Mafia xonasi yaratildi!\n\n🔑 Xona kodi: ${roomId}\n\nDo'stlaringizga ushbu kodni yuboring.\nUlar /join ${roomId} buyrug'ini yoki O'yinlar → Mafia → Multiplayer bo'limini ishlatsin.\n\n⏱️ O'yin 5 daqiqadan so'ng avtomatik boshlanadi yoki siz boshlashingiz mumkin.\n\n👥 O'yin boshlash uchun O'yinlar → Mafia → Multiplayer → Xona kodini kiriting: ${roomId}`;
    }

    const joinMatch = c.match(/^\/join\s+([a-z0-9]{4,8})$/i);
    if (joinMatch) {
      const roomId = joinMatch[1].toUpperCase();
      const snap = await dbGet(dbRef(fireDb, `mafia_rooms/${roomId}`));
      if (!snap.exists()) return `❌ Xona topilmadi: ${roomId}\n\nKodni tekshiring yoki yangi o'yin yaratingiz: /create`;
      const room = snap.val();
      if (room.status !== "waiting") return `⚠️ Bu xona allaqachon o'yin boshlagan.\n\nYangi xona: /create`;
      const playerCount = Object.keys(room.players || {}).length;
      if (playerCount >= 12) return `❌ Xona to'liq (12/12).\n\nYangi xona: /create`;
      await dbUpdate(dbRef(fireDb, `mafia_rooms/${roomId}/players/${user}`), {
        name: user, alive: true, role: null, ready: true, joinedAt: Date.now(),
      });
      await dbSet(dbRef(fireDb, `users/${user}/activeMafiaRoom`), roomId);
      const timeLeft = Math.max(0, Math.floor((room.startAt - Date.now()) / 1000));
      const mins = Math.floor(timeLeft / 60), secs = timeLeft % 60;
      return `✅ Xonaga qo'shildingiz: ${roomId}\n\n👥 O'yinchilar: ${playerCount + 1}/${12}\n⏱️ Boshlanishgacha: ${mins}:${String(secs).padStart(2, "0")}\n\n🎮 O'yin boshlash uchun:\nO'yinlar → Mafia → Multiplayer → Kod kiriting: ${roomId}`;
    }

    if (c.startsWith("/join")) {
      return "⚠️ To'g'ri format: /join XONAKODI\nMasalan: /join AB3X7K";
    }

    return "🕵️ Men Mafia o'yini botiman!\n\n/create — Yangi xona yaratish\n/join KOD — Xonaga qo'shilish\n/help — Barcha buyruqlar";
  },

  AIBot: async (cmd, user) => {
    const c = cmd.trim();
    const storageKey = `nexus_aibot_key_${user}`;
    const historyKey = `nexus_aibot_history_${user}`;

    if (c.toLowerCase() === "/clear") {
      localStorage.removeItem(historyKey);
      return "🗑️ Suhbat tarixi tozalandi! Yangi suhbat boshlashingiz mumkin.";
    }

    if (c.toLowerCase() === "/deletekey") {
      localStorage.removeItem(storageKey);
      localStorage.removeItem(historyKey);
      return "🔑 API kalit o'chirildi.\n\nYangi kalit kiritish uchun:\n/apikey YOUR_KEY";
    }

    if (c.toLowerCase().startsWith("/apikey ")) {
      const key = c.slice(8).trim();
      if (!key) return "❌ Kalit bo'sh. Format:\n/apikey sk-proj-...  (OpenAI)\n/apikey AIzaSy...    (Gemini)";
      localStorage.setItem(storageKey, key);
      localStorage.removeItem(historyKey);
      const isOpenAI = key.startsWith("sk-");
      const isGemini = key.startsWith("AIza");
      return `✅ API kalit saqlandi!\n\n🔧 Tur: ${isOpenAI ? "OpenAI (GPT-4o mini)" : isGemini ? "Google Gemini 1.5 Flash" : "Noma'lum"}\n🛡️ Kalit faqat qurilmangizda saqlanadi.\n\nBuyruqlar:\n/clear — Tarixni tozalash\n/deletekey — Kalitni o'chirish\n\nEndi istalgan savolingizni bering! 🤖`;
    }

    if (c.toLowerCase() === "/apikey" || c.toLowerCase() === "/help") {
      const apiKey = localStorage.getItem(storageKey);
      return `🤖 AI Bot buyruqlari:\n\n/apikey KEY — API kalit saqlash\n/clear — Suhbat tarixini tozalash\n/deletekey — Kalitni o'chirish\n\n${apiKey ? "✅ Kalit mavjud — savollaringizni bering!" : "⚠️ Kalit yo'q — /apikey KEY yozing"}`;
    }

    const apiKey = localStorage.getItem(storageKey);
    if (!apiKey) {
      return "🤖 AI Bot ga xush kelibsiz!\n\n━━━━━━━━━━━━━━━━━━━\n🔑 Ishlash uchun API kalit kerak.\n━━━━━━━━━━━━━━━━━━━\n\n📌 1. OpenAI (GPT-4o mini):\n   platform.openai.com/api-keys\n   → /apikey sk-proj-abc123...\n\n📌 2. Google Gemini (BEPUL):\n   aistudio.google.com/app/apikey\n   → /apikey AIzaSyAbc123...\n\n🛡️ Kalit faqat telefon/kompyuteringizda saqlanadi, serverga yuborilmaydi.\n\n📝 Kalit kiritish:\n/apikey YOUR_API_KEY_HERE";
    }

    let history: { role: string; content: string }[] = [];
    try { history = JSON.parse(localStorage.getItem(historyKey) || "[]"); } catch {}

    history.push({ role: "user", content: c });
    if (history.length > 20) history = history.slice(-20);

    try {
      let responseText = "";

      if (apiKey.startsWith("sk-")) {
        const res = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              { role: "system", content: "Sen NEXUS_OS messenjeri ichidagi AI yordamchisisan. Asosan O'zbek tilida, kerak bo'lsa boshqa tillarda ham javob ber. Qisqa, aniq va foydali javoblar ber." },
              ...history.map(h => ({ role: h.role, content: h.content }))
            ],
            max_tokens: 800,
            temperature: 0.7,
          }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          if (res.status === 401) return "❌ API kalit noto'g'ri yoki muddati o'tgan.\n\nYangi kalit:\n/apikey NEW_KEY";
          if (res.status === 429) return "⏳ So'rovlar juda ko'p. Biroz kuting va qayta yuboring.";
          if (res.status === 402) return "💳 OpenAI hisob balansi tugagan. Hisobni to'ldiring.";
          return `❌ OpenAI xato (${res.status}): ${(err as any).error?.message || res.statusText}`;
        }
        const data: any = await res.json();
        responseText = data.choices?.[0]?.message?.content || "❓ Bo'sh javob olindi.";

      } else {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
        const systemPair = [
          { role: "user", parts: [{ text: "Sen NEXUS_OS messenjeri ichidagi AI yordamchisisan. Asosan O'zbek tilida javob ber. Qisqa va foydali bo'l." }] },
          { role: "model", parts: [{ text: "Yaxshi, O'zbek tilida yordam beraman!" }] },
        ];
        const contents = history.map(h => ({
          role: h.role === "assistant" ? "model" : "user",
          parts: [{ text: h.content }],
        }));
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contents: [...systemPair, ...contents] }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          if (res.status === 400) return "❌ Gemini API kalit noto'g'ri.\n\nYangi kalit:\n/apikey NEW_KEY";
          if (res.status === 429) return "⏳ Gemini limit. 1 daqiqa kuting.";
          return `❌ Gemini xato (${res.status}): ${(err as any).error?.message || res.statusText}`;
        }
        const data: any = await res.json();
        responseText = data.candidates?.[0]?.content?.parts?.[0]?.text || "❓ Bo'sh javob olindi.";
      }

      history.push({ role: "assistant", content: responseText });
      if (history.length > 20) history = history.slice(-20);
      localStorage.setItem(historyKey, JSON.stringify(history));
      return responseText;

    } catch (err: any) {
      if (err?.message?.includes("fetch") || err?.message?.includes("network") || err?.message?.includes("Network")) {
        return "🌐 Internet ulanishida xato. Qayta urinib ko'ring.";
      }
      return `❌ Kutilmagan xato: ${err?.message || "Noma'lum"}`;
    }
  },
};

const EMOJI_CATEGORIES: Record<string, string[]> = {
  "😀": ["😀","😃","😄","😁","😆","🥹","😅","😂","🤣","🥲","☺️","😊","😇","🙂","🙃","😉","😌","😍","🥰","😘","😗","😙","😚","😋","😛","😝","😜","🤪","🤨","🧐","🤓","😎","🥸","🤩","🥳","😏","😒","😞","😔","😟","😕","🙁","☹️","😣","😖","😫","😩","🥺","😢","😭","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🤭","🤫","🤥","😶","😐","😑","😬","🙄","😯","😦","😧","😮","😲","🥱","😴","🤤","😪","😵","🤐","🥴","🤢","🤮","🤧","😷","🤒","🤕","🤑","🤠","😈","👿","👹","👺","🤡","💩","👻","💀","☠️","👽","👾","🤖"],
  "👋": ["👋","🤚","🖐️","✋","🖖","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","🖕","👇","☝️","👍","👎","✊","👊","🤛","🤜","👏","🙌","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦾","🦵","🦿","🦶","👂","🦻","👃","🧠","🫀","🫁","🦷","🦴","👀","👁️","👅","👄","💋"],
  "❤️": ["❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💟","♥️","💌","💢","💥","💫","💦","💨","🕳️","💣","💬","👁️‍🗨️","🗨️","🗯️","💭","💤"],
  "🐶": ["🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐻‍❄️","🐨","🐯","🦁","🐮","🐷","🐽","🐸","🐵","🙈","🙉","🙊","🐒","🐔","🐧","🐦","🐤","🐣","🐥","🦆","🦅","🦉","🦇","🐺","🐗","🐴","🦄","🐝","🪱","🐛","🦋","🐌","🐞","🐜","🪰","🐢","🐍","🦎","🦖","🦕","🐙","🦑","🦐","🦞","🦀","🐡","🐠","🐟","🐬","🐳","🐋","🦈","🐊"],
  "🍎": ["🍎","🍐","🍊","🍋","🍌","🍉","🍇","🍓","🫐","🍈","🍒","🍑","🥭","🍍","🥥","🥝","🍅","🍆","🥑","🥦","🥬","🥒","🌶️","🫑","🌽","🥕","🫒","🧄","🧅","🥔","🍠","🥐","🥯","🍞","🥖","🥨","🧀","🥚","🍳","🧈","🥞","🧇","🥓","🥩","🍗","🍖","🦴","🌭","🍔","🍟","🍕","🥪","🥙","🧆","🌮","🌯","🥗","🥘","🍝","🍜","🍲","🍛","🍣","🍱","🥟","🦪","🍤","🍙","🍚","🍘","🍥","🥠","🥮","🍢","🍡","🍧","🍨","🍦","🥧","🧁","🍰","🎂","🍮","🍭","🍬","🍫","🍿","🍩","🍪","🌰","🥜","🍯","🥛","🍼","☕","🫖","🍵","🥤","🧋","🍶","🍺","🍻","🥂","🍷","🥃","🍸","🍹","🍾","🧊"],
  "⚽": ["⚽","🏀","🏈","⚾","🥎","🎾","🏐","🏉","🥏","🎱","🪀","🏓","🏸","🏒","🏑","🥍","🏏","🪃","🥅","⛳","🪁","🏹","🎣","🤿","🥊","🥋","🎽","🛹","🛼","🛷","⛸️","🥌","🎿","⛷️","🏂","🪂","🏋️","🤼","🤸","⛹️","🤺","🤾","🏌️","🏇","🧘","🏄","🏊","🤽","🚣","🧗","🚵","🚴","🏆","🥇","🥈","🥉","🏅","🎖️","🏵️","🎗️","🎫","🎟️","🎪","🤹","🎭","🩰","🎨","🎬","🎤","🎧","🎼","🎹","🥁","🪘","🎷","🎺","🪗","🎸","🪕","🎻","🎲","♟️","🎯","🎳","🎮","🎰","🧩"],
  "🚗": ["🚗","🚕","🚙","🚌","🚎","🏎️","🚓","🚑","🚒","🚐","🛻","🚚","🚛","🚜","🦯","🦽","🦼","🛴","🚲","🛵","🏍️","🛺","🚨","🚔","🚍","🚘","🚖","🚡","🚠","🚟","🚃","🚋","🚞","🚝","🚄","🚅","🚈","🚂","🚆","🚇","🚊","🚉","✈️","🛫","🛬","🛩️","💺","🛰️","🚀","🛸","🚁","🛶","⛵","🚤","🛥️","🛳️","⛴️","🚢","⚓","⛽","🚧","🚦","🚥","🚏","🗺️","🗿","🗽","🗼","🏰","🏯","🏟️","🎡","🎢","🎠","⛲","⛱️","🏖️","🏝️","🏜️","🌋","⛰️","🏔️","🗻","🏕️","⛺","🏠","🏡","🏘️","🏚️","🏗️","🏭","🏢","🏬","🏣","🏤","🏥","🏦","🏨","🏪","🏫","🏩","💒","🏛️","⛪","🕌","🛕","🕍","⛩️"],
  "💡": ["💡","🔦","🕯️","🪔","🧯","🛢️","💸","💵","💴","💶","💷","🪙","💰","💳","💎","⚖️","🪜","🧰","🪛","🔧","🔨","⚒️","🛠️","⛏️","🪚","🔩","⚙️","🪤","🧱","⛓️","🧲","🔫","💣","🧨","🪓","🔪","🗡️","⚔️","🛡️","🚬","⚰️","🪦","⚱️","🏺","🔮","📿","🧿","💈","⚗️","🔭","🔬","🕳️","🩹","🩺","💊","💉","🩸","🧬","🦠","🧫","🧪","🌡️","🧹","🪠","🧺","🧻","🚽","🚰","🚿","🛁","🛀","🧼","🪥","🪒","🧽","🪣","🧴","🛎️","🔑","🗝️","🚪","🪑","🛋️","🛏️","🛌","🧸","🪆","🖼️","🪞","🪟","🛍️","🛒","🎁","🎈","🎏","🎀","🪄","🪅","🎊","🎉","🎎","🏮","🎐","🧧"],
  "🚩": ["🚩","🏳️","🏴","🏁","🏳️‍🌈","🏳️‍⚧️","🏴‍☠️","✅","❌","⭕","🚫","♻️","✳️","❇️","💯","🔢","#️⃣","*️⃣","0️⃣","1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟","✔️","☑️","🔘","🔴","🟠","🟡","🟢","🔵","🟣","⚫","⚪","🟤","🔺","🔻","🔸","🔹","🔶","🔷","🔳","🔲","▪️","▫️","◾","◽","◼️","◻️","⬛","⬜"],
};
const EMOJI_TABS = Object.keys(EMOJI_CATEGORIES);

export default function ChatSection({ username, targetUser, isGroup, groupMeta, onBack, accentColor, onStartCall, onOpenProfile, isPremium }: ChatSectionProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [selfDestruct, setSelfDestruct] = useState(false);
  const [typing, setTyping] = useState(false);
  const [isChatLocked, setIsChatLocked] = useState(false);
  const [privacyBlocked, setPrivacyBlocked] = useState<"nobody" | "contacts" | null>(null);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [editMsg, setEditMsg] = useState<Message | null>(null);
  const [pinnedMsg, setPinnedMsg] = useState<Message | null>(null);
  const [showPinned, setShowPinned] = useState(false);
  const [mediaGallery, setMediaGallery] = useState<Message[]>([]);
  const [showGallery, setShowGallery] = useState(false);
  const [selectedMsg, setSelectedMsg] = useState<string | null>(null);
  const [longPressTimer, setLongPressTimer] = useState<ReturnType<typeof setTimeout>>();
  const [senderBadges, setSenderBadges] = useState<Record<string, string>>({});
  const [chatAnim, setChatAnim] = useState("none");
  const [showAnimPicker, setShowAnimPicker] = useState(false);
  const [translatingMsg, setTranslatingMsg] = useState<string | null>(null);
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(`nexus_bookmarks_${username}`) || "[]"); } catch { return []; }
  });
  const chatBgKey = isGroup ? `nexus_chatbg_grp_${targetUser}` : `nexus_chatbg_${[username, targetUser].sort().join("_")}`;
  const [chatBg, setChatBg] = useState<string>(() => localStorage.getItem(isGroup ? `nexus_chatbg_grp_${targetUser}` : `nexus_chatbg_${[username, targetUser].sort().join("_")}`) || "");
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [showHeaderMenu, setShowHeaderMenu] = useState(false);
  const [hasBackup, setHasBackup] = useState(false);
  const [expandedOriginals, setExpandedOriginals] = useState<Set<string>>(new Set());
  const ghostMode = localStorage.getItem("nx_ghost_mode") === "on";
  const msgContainerRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const botRespondedRef = useRef<Set<string>>(new Set());

  const isOfficialMax = targetUser === "Max" && groupMeta?.isOfficialMax;
  const isBot = BOTS.includes(targetUser) && !isGroup;
  const isChannel = isGroup && groupMeta?.type === "channel";
  const isGroupAdmin = isGroup && groupMeta?.createdBy === username;
  const canWrite = !isOfficialMax && !(isChannel && !isGroupAdmin);
  const isLocked = isChatLocked && username !== "Max";

  const getChatPath = useCallback(() => {
    if (isOfficialMax) return "messages/global_max";
    if (isGroup) return `group_messages/${targetUser}`;
    const chatId = [username, targetUser].sort().join("_");
    return `messages/${chatId}`;
  }, [username, targetUser, isGroup, isOfficialMax]);

  useEffect(() => {
    if (username === "Max") return undefined;
    return onValue(ref(db, "system/lockdown"), snap => setIsChatLocked(snap.exists() && snap.val() === true));
  }, [username]);

  useEffect(() => {
    if (ghostMode) return;
    set(ref(db, `status/${username}`), { state: "online", lastSeen: serverTimestamp(), typingTo: "none" });
  }, [username, ghostMode]);

  useEffect(() => {
    if (isGroup || isOfficialMax) return;
    return onValue(ref(db, `status/${targetUser}`), snap => {
      const d = snap.val();
      setTyping(d?.typingTo === username);
    });
  }, [targetUser, username, isGroup, isOfficialMax]);

  useEffect(() => {
    if (isGroup || isOfficialMax || targetUser === "Max") return;
    get(ref(db, `users/${targetUser}/privacy/whoCanMessage`)).then(snap => {
      const val = snap.val() as "all" | "contacts" | "nobody" | null;
      if (!val || val === "all") { setPrivacyBlocked(null); return; }
      if (val === "nobody") { setPrivacyBlocked("nobody"); return; }
      if (val === "contacts") {
        get(ref(db, `contacts/${targetUser}/${username}`)).then(cs => {
          setPrivacyBlocked(cs.exists() ? null : "contacts");
        });
      }
    });
  }, [targetUser, username, isGroup, isOfficialMax]);

  // Bot greeting on first open
  useEffect(() => {
    if (!isBot) return;
    const path = getChatPath();
    get(ref(db, path)).then(snap => {
      if (!snap.exists()) {
        const GREETINGS: Record<string, string> = {
          NexusBot: "👋 Salom! Men NexusBot — sizning shaxsiy yordamchingizman!\n\nBuyruqlar:\n/help — Barcha buyruqlar\n/stars — Star balansingiz\n/premium — Premium haqida\n/info — NEXUS haqida",
          StarBot: "⭐ StarBot ga xush kelibsiz!\n\nMen sizga Stars (yulduzlar) bilan ishlashda yordam beraman.\n\nBuyruqlar:\n/balance — Balansingizni ko'rish\n/buy — Paketlarni ko'rish\n/help — Yordam",
          QuizBot: "🎯 QuizBot ga xush kelibsiz!\n\nBilim sinovlari o'tkazaman!\n\n/quiz — Savol berish\n/help — Yordam",
          WeatherBot: "🌤️ WeatherBot ga xush kelibsiz!\n\nO'zbekiston shaharlarining ob-havosi.\n\nShahar nomini yozing: Toshkent, Samarqand...\n/cities — Barcha shaharlar",
          HoroscopeBot: "♈ HoroscopeBot ga xush kelibsiz!\n\nBurjingizni yozing bashorat olish uchun:\nHamal, Savr, Javzo...\n\n/help — Barcha buyruqlar",
          JokeBot: "😂 JokeBot ga xush kelibsiz!\n\nHar kuni yangi latifahlar!\n\n/joke — Latifa\n/help — Yordam",
          MafiaBot: "🕵️ MafiaBot ga xush kelibsiz!\n\nMultiplayer Mafia o'yini uchun:\n\n/create — Yangi xona\n/join KOD — Xonaga qo'shilish\n/help — Yordam",
          AIBot: "🤖 AI Bot ga xush kelibsiz!\n\n━━━━━━━━━━━━━━━━━━━\n🔑 Ishlash uchun API kalit kerak.\n━━━━━━━━━━━━━━━━━━━\n\n📌 1. OpenAI (GPT-4o mini):\n   platform.openai.com/api-keys\n   → /apikey sk-proj-abc123...\n\n📌 2. Google Gemini (BEPUL):\n   aistudio.google.com/app/apikey\n   → /apikey AIzaSyAbc123...\n\n🛡️ Kalit faqat qurilmangizda saqlanadi.\n\n📝 Kalit kiritish:\n/apikey YOUR_API_KEY_HERE",
        };
        const greet = GREETINGS[targetUser] || `👋 ${targetUser} ga xush kelibsiz!\n\n/help — Yordam`;
        setTimeout(() => push(ref(db, path), {
          sender: targetUser, text: greet, type: "text", status: "sent", timestamp: Date.now(),
        }), 600);
      }
    });
  }, [isBot, targetUser]);

  // Bot autoresponse
  useEffect(() => {
    if (!isBot) return;
    const path = getChatPath();
    return onChildAdded(ref(db, path), async snap => {
      const msg = snap.val();
      if (!msg || msg.sender !== username) return;
      if (botRespondedRef.current.has(snap.key!)) return;
      botRespondedRef.current.add(snap.key!);
      const responder = BOT_RESPONSES[targetUser];
      if (!responder) return;
      const delay = 700 + Math.random() * 500;
      setTimeout(async () => {
        const response = await responder(msg.text || "", username);
        if (response) {
          await push(ref(db, path), {
            sender: targetUser, text: response, type: "text", status: "sent", timestamp: Date.now(),
          });
        }
      }, delay);
    });
  }, [isBot, targetUser, username, getChatPath]);

  // Load pinned message
  useEffect(() => {
    const pinnedRef = ref(db, `${getChatPath()}_meta/pinned`);
    return onValue(pinnedRef, snap => {
      if (snap.exists()) setPinnedMsg(snap.val());
      else setPinnedMsg(null);
    });
  }, [getChatPath]);

  useEffect(() => {
    const path = getChatPath();
    setMessages([]);

    const addUnsub = onChildAdded(ref(db, path), snap => {
      const data = snap.val() as Message;
      const msg: Message = { ...data, id: snap.key! };
      setMessages(prev => prev.find(m => m.id === msg.id) ? prev : [...prev, msg]);
      if (!isGroup && data.sender !== username && data.status === "sent") {
        update(ref(db, `${path}/${snap.key}`), { status: "read" });
      }
      setTimeout(() => { if (msgContainerRef.current) msgContainerRef.current.scrollTop = msgContainerRef.current.scrollHeight; }, 50);
    });

    const changeUnsub = onChildChanged(ref(db, path), snap => {
      setMessages(prev => prev.map(m => m.id === snap.key ? { ...m, ...snap.val() } : m));
    });

    const removeUnsub = onChildRemoved(ref(db, path), snap => {
      setMessages(prev => prev.filter(m => m.id !== snap.key));
    });

    return () => { addUnsub(); changeUnsub(); removeUnsub(); };
  }, [targetUser, username, isGroup, isOfficialMax, getChatPath]);

  // Self-destruct timer for secret messages
  useEffect(() => {
    messages.forEach(msg => {
      if (msg.secret && msg.sender !== username && msg.status === "read") {
        const elapsed = Date.now() - (msg.timestamp || 0);
        const delay = Math.max(0, 30000 - elapsed);
        setTimeout(() => remove(ref(db, `${getChatPath()}/${msg.id}`)), delay);
      }
    });
    setMediaGallery(messages.filter(m => m.type === "image"));
  }, [messages]);

  // Load badges for all unique senders
  useEffect(() => {
    const uniqueSenders = [...new Set(messages.map(m => m.sender))];
    uniqueSenders.forEach(sender => {
      if (senderBadges[sender] !== undefined) return;
      get(ref(db, `users/${sender}/badge`)).then(snap => {
        setSenderBadges(prev => ({ ...prev, [sender]: snap.exists() ? snap.val() : "" }));
      });
    });
  }, [messages]);

  function handleTyping() {
    if (isGroup || isOfficialMax) return;
    update(ref(db, `status/${username}`), { typingTo: targetUser });
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => update(ref(db, `status/${username}`), { typingTo: "none" }), 2000);
  }

  async function sendMessage() {
    if ((!inputText.trim() && !editMsg) || isLocked) return;
    const path = getChatPath();
    if (!isGroup) { clearTimeout(typingTimeoutRef.current); update(ref(db, `status/${username}`), { typingTo: "none" }); }

    if (editMsg) {
      await update(ref(db, `${path}/${editMsg.id}`), {
        text: inputText,
        edited: true,
        originalText: editMsg.originalText ?? editMsg.text,
      });
      setEditMsg(null); setInputText(""); return;
    }

    // @BotName inline command handler
    const atBotMatch = inputText.trim().match(/^@(\w+)\s(.+)$/s);
    if (atBotMatch) {
      const botName = atBotMatch[1];
      const botCmd = atBotMatch[2];
      if (BOTS.includes(botName) && BOT_RESPONSES[botName]) {
        const msgData: any = {
          sender: username, text: inputText, type: "text", status: "sent",
          secret: selfDestruct, timestamp: serverTimestamp(),
          ...(isPremium && chatAnim !== "none" ? { animation: chatAnim } : {}),
        };
        await push(ref(db, path), msgData);
        setInputText(""); setReplyTo(null);
        const responder = BOT_RESPONSES[botName];
        setTimeout(async () => {
          const response = await responder(botCmd, username);
          if (response) await push(ref(db, path), {
            sender: botName, text: response, type: "text", status: "sent", timestamp: Date.now(),
          });
        }, 700 + Math.random() * 400);
        return;
      }
    }

    const msgData: any = {
      sender: username, text: inputText, type: "text", status: "sent",
      secret: selfDestruct, timestamp: serverTimestamp(),
      ...(isPremium && chatAnim !== "none" ? { animation: chatAnim } : {}),
    };
    if (replyTo) {
      msgData.replyTo = { id: replyTo.id, sender: replyTo.sender, preview: replyTo.text?.substring(0, 50) };
    }
    await push(ref(db, path), msgData);
    setInputText(""); setReplyTo(null);
  }

  async function sendLocation() {
    if (isLocked) return;
    if (!navigator.geolocation) { alert("Joylashuv qo'llab-quvvatlanmaydi!"); return; }
    navigator.geolocation.getCurrentPosition(async pos => {
      const { latitude, longitude } = pos.coords;
      await push(ref(db, getChatPath()), {
        sender: username, text: `${latitude},${longitude}`, type: "location",
        status: "sent", secret: selfDestruct, timestamp: serverTimestamp(),
      });
    }, () => alert("Joylashuvga ruxsat berilmagan!"), { enableHighAccuracy: true, timeout: 8000 });
  }

  async function translateMessage(msg: Message) {
    if (msg.type !== "text" || !msg.text || translatingMsg) return;
    setTranslatingMsg(msg.id);
    try {
      const hasCyrillic = /[а-яёА-ЯЁ]/.test(msg.text);
      const srcLang = hasCyrillic ? "ru" : "en";
      const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(msg.text.slice(0, 500))}&langpair=${srcLang}|uz`);
      const data = await res.json();
      const translated = data.responseData?.translatedText;
      if (translated && translated.toLowerCase() !== "translation unavailable") {
        setTranslations(prev => ({ ...prev, [msg.id]: translated }));
      }
    } catch { /* silent */ } finally { setTranslatingMsg(null); }
  }

  async function toggleBookmark(msg: Message) {
    const key = `nexus_bookmarks_${username}`;
    const isSaved = bookmarks.includes(msg.id);
    const next = isSaved ? bookmarks.filter(id => id !== msg.id) : [...bookmarks, msg.id];
    setBookmarks(next);
    localStorage.setItem(key, JSON.stringify(next));
    // Also sync to RTDB for cross-device access
    const savePath = `saved_messages/${username}/${msg.id}`;
    if (isSaved) {
      await remove(ref(db, savePath));
    } else {
      await set(ref(db, savePath), {
        text: msg.type === "text" ? msg.text : "",
        sender: msg.sender,
        type: msg.type,
        timestamp: msg.timestamp || Date.now(),
        savedAt: Date.now(),
        chatWith: targetUser,
        isGroup,
      });
    }
    setSelectedMsg(null);
  }

  async function toggleReaction(msg: Message, emoji: string) {
    const path = `${getChatPath()}/${msg.id}/reactions/${emoji}/${username}`;
    const hasReacted = msg.reactions?.[emoji]?.[username];
    if (hasReacted) {
      await remove(ref(db, path));
    } else {
      await set(ref(db, path), true);
    }
    setSelectedMsg(null);
  }

  function changeChatTheme(themeId: string) {
    setChatBg(themeId);
    localStorage.setItem(chatBgKey, themeId);
    setShowThemePicker(false);
  }

  async function forwardMessage(msg: Message) {
    const to = prompt("Kim ga yubormoqchisiz? (username kiriting):");
    if (!to?.trim()) return;
    const fwdPath = `messages/${[username, to.trim()].sort().join("_")}`;
    await push(ref(db, fwdPath), {
      sender: username, text: `↪️ ${msg.sender} dan:\n${msg.text}`, type: "text",
      status: "sent", timestamp: Date.now(),
    });
    setSelectedMsg(null);
    alert(`✅ @${to.trim()} ga yuborildi!`);
  }

  async function sendImage(file: File) {
    if (file.size > 50 * 1024 * 1024) { alert("Rasm 50MB dan kichik bo'lishi kerak!"); return; }
    try {
      const chatId = [username, targetUser].sort().join("_");
      const ts = Date.now();
      const ext = file.type.includes("png") ? "png" : "jpg";
      const url = await uploadToStorage(`chat/${chatId}/img_${ts}.${ext}`, file);
      await push(ref(db, getChatPath()), {
        sender: username, text: url, type: "image",
        status: "sent", secret: selfDestruct, timestamp: serverTimestamp(),
        ...(replyTo ? { replyTo: { id: replyTo.id, sender: replyTo.sender, preview: "📷 Rasm" } } : {})
      });
      setReplyTo(null);
    } catch (err) {
      alert("Rasm yuborishda xato: " + (err instanceof Error ? err.message : String(err)));
    }
  }

  async function toggleVoiceRecording() {
    if (!isRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mr = new MediaRecorder(stream);
        audioChunksRef.current = [];
        mr.ondataavailable = e => audioChunksRef.current.push(e.data);
        mr.onstop = async () => {
          const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
          if (blob.size < 1000) { stream.getTracks().forEach(t => t.stop()); return; }
          try {
            const chatRoomId = [username, targetUser].sort().join("_");
            const url = await uploadToStorage(`chat/${chatRoomId}/voice_${Date.now()}.webm`, blob);
            await push(ref(db, getChatPath()), {
              sender: username, text: url, type: "voice",
              status: "sent", secret: selfDestruct, timestamp: serverTimestamp()
            });
          } catch (err) {
            alert("Ovoz yuborishda xato: " + (err instanceof Error ? err.message : String(err)));
          }
          stream.getTracks().forEach(t => t.stop());
        };
        mr.start();
        mediaRecorderRef.current = mr;
        setIsRecording(true);
      } catch { alert("Mikrofon ruxsati berilmagan!"); }
    } else {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
    }
  }

  async function deleteMessage(msg: Message) {
    const canDelete = msg.sender === username || (isGroup && groupMeta?.createdBy === username) || username === "Max";
    if (!canDelete) return;
    if (!confirm("Xabarni o'chirasizmi?")) return;
    if (msg.secret) {
      await remove(ref(db, `${getChatPath()}/${msg.id}`));
    } else {
      await update(ref(db, `${getChatPath()}/${msg.id}`), { deleted: true, deletedAt: Date.now() });
    }
    setSelectedMsg(null);
  }

  async function clearChat() {
    if (!confirm("Chatni tozalashni xohlaysizmi? Zaxira saqlanadi.")) return;
    const path = getChatPath();
    const snap = await get(ref(db, path));
    if (snap.exists()) {
      const chatId = isGroup ? `grp_${targetUser}` : [username, targetUser].sort().join("_");
      await set(ref(db, `chat_backup/${chatId}`), { data: snap.val(), savedAt: Date.now(), chatPath: path });
      setHasBackup(true);
    }
    const kids: string[] = [];
    snap.forEach(c => { kids.push(c.key!); });
    await Promise.all(kids.map(k => remove(ref(db, `${path}/${k}`))));
    setShowHeaderMenu(false);
  }

  async function restoreChat() {
    if (!confirm("Chatni tiklashni xohlaysizmi?")) return;
    const chatId = isGroup ? `grp_${targetUser}` : [username, targetUser].sort().join("_");
    const snap = await get(ref(db, `chat_backup/${chatId}`));
    if (!snap.exists()) { alert("Zaxira topilmadi"); return; }
    const backup = snap.val();
    const path = backup.chatPath || getChatPath();
    const data: Record<string, any> = backup.data || {};
    await Promise.all(Object.entries(data).map(([k, v]) => set(ref(db, `${path}/${k}`), v)));
    await remove(ref(db, `chat_backup/${chatId}`));
    setHasBackup(false);
    setShowHeaderMenu(false);
  }

  async function pinMessage(msg: Message) {
    if (msg.type !== "text") return;
    await set(ref(db, `${getChatPath()}_meta/pinned`), { id: msg.id, sender: msg.sender, text: msg.text });
    setSelectedMsg(null);
  }

  async function unpinMessage() {
    await remove(ref(db, `${getChatPath()}_meta/pinned`));
  }

  function startEdit(msg: Message) {
    if (msg.sender !== username || msg.type !== "text") return;
    setEditMsg(msg);
    setInputText(msg.text);
    setSelectedMsg(null);
    inputRef.current?.focus();
  }

  function startReply(msg: Message) {
    setReplyTo(msg);
    setSelectedMsg(null);
    inputRef.current?.focus();
  }

  function handleMsgLongPress(id: string) {
    setSelectedMsg(prev => prev === id ? null : id);
  }

  useEffect(() => {
    const chatId = isGroup ? `grp_${targetUser}` : [username, targetUser].sort().join("_");
    get(ref(db, `chat_backup/${chatId}`)).then(snap => setHasBackup(snap.exists()));
  }, [targetUser, username, isGroup]);

  const filtered = searchQuery.trim()
    ? messages.filter(m => m.text?.toLowerCase().includes(searchQuery.toLowerCase()) && m.type === "text")
    : messages;

  return (
    <div className="w-full h-full flex flex-col overflow-hidden relative">
      {/* HEADER */}
      <header className="flex-shrink-0 px-4 py-3.5 border-b border-slate-800/40 flex items-center justify-between gap-2 relative overflow-hidden" style={{background:"rgba(5,8,18,0.97)", backdropFilter:"blur(28px)", boxShadow:"0 1px 0 rgba(255,255,255,0.04)"}}>
        <div className="flex items-center gap-2 min-w-0">
          {onBack && (
            <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition flex-shrink-0">←</button>
          )}
          <button
            onClick={() => !isGroup && !isOfficialMax && onOpenProfile?.(targetUser)}
            className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 hover:scale-105 transition"
            style={{
              background: isOfficialMax ? "#1d4ed8" : isGroup ? "linear-gradient(135deg,#7c3aed,#4f46e5)" : `linear-gradient(135deg, ${accentColor}55, #4f46e5)`,
              cursor: (!isGroup && !isOfficialMax) ? "pointer" : "default"
            }}>
            {isOfficialMax ? "🛡️" : isBot ? (targetUser === "NexusBot" ? "🤖" : targetUser === "StarBot" ? "⭐" : targetUser === "QuizBot" ? "🎯" : targetUser === "WeatherBot" ? "🌤️" : targetUser === "HoroscopeBot" ? "♈" : targetUser === "JokeBot" ? "😂" : "🤖") : isGroup ? "👥" : targetUser[0]?.toUpperCase()}
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <p className={`font-semibold text-sm truncate ${isOfficialMax ? "text-blue-300" : "text-slate-100"}`}>
                {isOfficialMax ? "" : isGroup ? "#" : "@"}{targetUser}
              </p>
              {isOfficialMax && <span className="bg-blue-500 text-white rounded-full w-3.5 h-3.5 flex items-center justify-center text-[8px] flex-shrink-0">✓</span>}
            </div>
            <p className="text-[10px] truncate" style={{color: typing ? accentColor : "#64748b"}}>
              {typing ? "yozmoqda..." : isOfficialMax ? "Rasmiy kanal" : isBot ? "🤖 Bot · Avtomatik javob" : isChannel ? "Broadcast kanal" : isGroup ? "Guruh" : "Shaxsiy suhbat"}
            </p>
          </div>
        </div>
        <div className="relative flex-shrink-0">
          <button
            onClick={() => { setShowHeaderMenu(m => !m); setShowThemePicker(false); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center border transition ${showHeaderMenu ? "bg-slate-800 border-slate-600 text-white" : "border-slate-700 text-slate-400 hover:bg-slate-800"}`}
            title="Menyu">
            <MoreHorizontal className="w-5 h-5" />
          </button>
          {showHeaderMenu && (
            <div className="absolute right-0 top-11 z-50 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl w-56 overflow-hidden" onClick={e => e.stopPropagation()}>
              {!isGroup && !isOfficialMax && onStartCall && (
                <button onClick={() => { onStartCall(targetUser); setShowHeaderMenu(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-800 transition text-left border-b border-slate-800/60">
                  <Phone className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-slate-200">Qo'ng'iroq</span>
                </button>
              )}
              <button onClick={() => { setShowGallery(true); setShowHeaderMenu(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-800 transition text-left border-b border-slate-800/60">
                <Images className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-slate-200">Media galereya</span>
              </button>
              <button onClick={() => { setShowSearch(s => !s); setSearchQuery(""); setShowHeaderMenu(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-800 transition text-left border-b border-slate-800/60">
                <Search className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-200">Qidirish</span>
                {showSearch && <span className="ml-auto text-[10px] text-cyan-400">Yoqilgan</span>}
              </button>
              <button onClick={() => { setShowThemePicker(p => !p); }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-800 transition text-left border-b border-slate-800/60">
                <Palette className="w-4 h-4 text-violet-400" />
                <span className="text-sm text-slate-200">Chat foni</span>
                {chatBg && <span className="ml-auto w-3 h-3 rounded-full" style={{background: CHAT_THEMES.find(t=>t.id===chatBg)?.dot || "#8b5cf6"}} />}
              </button>
              {showThemePicker && (
                <div className="px-3 py-2 border-b border-slate-800/60 bg-slate-950/40">
                  <div className="grid grid-cols-4 gap-1.5">
                    {CHAT_THEMES.map(th => (
                      <button key={th.id} onClick={() => changeChatTheme(th.id)}
                        className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition ${chatBg === th.id ? "bg-slate-700" : "hover:bg-slate-800"}`}>
                        <div className="w-7 h-7 rounded-lg border border-slate-700 flex items-center justify-center" style={{background: th.dot+"44"}}>
                          <div className="w-3 h-3 rounded-full" style={{background: th.dot}} />
                        </div>
                        <span className="text-[7px] text-slate-500">{th.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {!isOfficialMax && canWrite && (
                <button onClick={() => { setSelfDestruct(s => !s); setShowHeaderMenu(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-800 transition text-left border-b border-slate-800/60 ${selfDestruct ? "bg-rose-950/20" : ""}`}>
                  <Flame className={`w-4 h-4 ${selfDestruct ? "text-rose-400 animate-pulse" : "text-slate-400"}`} />
                  <span className={`text-sm ${selfDestruct ? "text-rose-300" : "text-slate-200"}`}>Maxfiy rejim</span>
                  {selfDestruct && <span className="ml-auto text-[10px] text-rose-400">Yoqilgan</span>}
                </button>
              )}
              {hasBackup && (
                <button onClick={restoreChat}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-800 transition text-left border-b border-slate-800/60 bg-emerald-950/10">
                  <RotateCcw className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm text-emerald-300">Chatni tiklash</span>
                </button>
              )}
              <button onClick={clearChat}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-rose-950/30 transition text-left">
                <Eraser className="w-4 h-4 text-rose-400" />
                <span className="text-sm text-rose-300">Chatni tozalash</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* SEARCH BAR */}
      {showSearch && (
        <div className="flex-shrink-0 px-4 py-2 border-b border-slate-800/50 bg-slate-900/50">
          <input
            autoFocus
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Xabarlarda qidirish..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-slate-200 outline-none focus:border-slate-600 transition"
          />
          {searchQuery && <p className="text-[10px] text-slate-500 mt-1 font-mono">{filtered.length} ta natija</p>}
        </div>
      )}

      {/* PINNED MESSAGE */}
      {pinnedMsg && (
        <div className="flex-shrink-0 px-4 py-2 border-b border-slate-800/40 bg-slate-900/30 flex items-center gap-2 cursor-pointer hover:bg-slate-900/50 transition" onClick={() => setShowPinned(true)}>
          <span className="text-[10px] text-amber-400 font-mono flex-shrink-0">📌 PIN</span>
          <p className="text-[11px] text-slate-300 truncate flex-1">{pinnedMsg.text}</p>
          {(isGroupAdmin || username === "Max") && (
            <button onClick={e => { e.stopPropagation(); unpinMessage(); }} className="text-slate-600 hover:text-slate-400 text-xs flex-shrink-0">✕</button>
          )}
        </div>
      )}

      {/* MESSAGES */}
      <div ref={msgContainerRef} className="flex-1 overflow-y-auto p-4 space-y-2 transition-all"
        style={CHAT_THEMES.find(t => t.id === chatBg)?.style || {}}
        onClick={() => { setShowThemePicker(false); setShowAnimPicker(false); setShowHeaderMenu(false); }}>
        {filtered.length === 0 && !searchQuery && (
          <div className="flex flex-col items-center justify-center h-full text-slate-700 text-center gap-2">
            <p className="text-3xl">💬</p>
            <p className="text-sm font-mono">Hali xabar yo'q</p>
          </div>
        )}
        {filtered.length === 0 && searchQuery && (
          <div className="flex flex-col items-center justify-center h-full text-slate-600">
            <p className="text-sm font-mono">"{searchQuery}" topilmadi</p>
          </div>
        )}
        {filtered.map(msg => {
          const isMe = msg.sender === username;
          const isMaxSender = msg.sender === "Max" && isOfficialMax;
          const isSelected = selectedMsg === msg.id;
          return (
            <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"} ${isSelected ? "relative z-10" : ""}`}>
              <div className="flex flex-col max-w-[75%] gap-0.5">
                {/* Context menu */}
                {isSelected && (
                  <div className={`flex gap-1 mb-1 flex-wrap ${isMe ? "justify-end" : "justify-start"}`}>
                    {/* Quick reactions */}
                    <div className="w-full flex gap-1 mb-1 flex-wrap">
                      {QUICK_REACTIONS.map(emoji => {
                        const reacted = msg.reactions?.[emoji]?.[username];
                        const count = msg.reactions?.[emoji] ? Object.keys(msg.reactions[emoji]).length : 0;
                        return (
                          <button key={emoji} onClick={() => toggleReaction(msg, emoji)}
                            className={`flex items-center gap-0.5 text-base px-2 py-0.5 rounded-xl transition border ${reacted ? "bg-indigo-900/50 border-indigo-500/60 text-white" : "bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-500"}`}>
                            {emoji}
                            {count > 0 && <span className="text-[9px] ml-0.5 text-slate-400">{count}</span>}
                          </button>
                        );
                      })}
                    </div>
                    <button onClick={() => startReply(msg)} className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition">
                      <Reply className="w-2.5 h-2.5" />Reply
                    </button>
                    {isMe && msg.type === "text" && (
                      <button onClick={() => startEdit(msg)} className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition">
                        <Pencil className="w-2.5 h-2.5" />Edit
                      </button>
                    )}
                    {msg.type === "text" && (
                      <button onClick={() => translateMessage(msg)} disabled={translatingMsg === msg.id}
                        className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-cyan-950/40 border border-cyan-900/60 text-cyan-400 hover:text-cyan-200 transition disabled:opacity-50">
                        <Globe className="w-2.5 h-2.5" />
                        {translatingMsg === msg.id ? "..." : "Tarjima"}
                      </button>
                    )}
                    <button onClick={() => forwardMessage(msg)} className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition">
                      <Forward className="w-2.5 h-2.5" />Yuborish
                    </button>
                    <button onClick={() => toggleBookmark(msg)} className={`flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg border transition ${bookmarks.includes(msg.id) ? "bg-amber-950/40 border-amber-900 text-amber-400" : "bg-slate-800 border-slate-700 text-slate-300 hover:text-white"}`}>
                      <Bookmark className="w-2.5 h-2.5" />
                      {bookmarks.includes(msg.id) ? "Saqlangan" : "Saqlash"}
                    </button>
                    {(isMe || isGroupAdmin || username === "Max") && (
                      <button onClick={() => deleteMessage(msg)} className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-rose-950/40 border border-rose-900 text-rose-400 transition">
                        <Trash2 className="w-2.5 h-2.5" />Del
                      </button>
                    )}
                    {isGroup && (isGroupAdmin || username === "Max") && msg.type === "text" && (
                      <button onClick={() => pinMessage(msg)} className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-amber-950/40 border border-amber-900 text-amber-400 transition">
                        <Pin className="w-2.5 h-2.5" />Pin
                      </button>
                    )}
                    <button onClick={() => setSelectedMsg(null)} className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 transition">
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </div>
                )}

                {/* Reply preview */}
                {msg.replyTo && (
                  <div className={`text-[10px] px-3 py-1.5 rounded-lg mb-0.5 border-l-2 ${isMe ? "bg-slate-800/60 border-r-0 ml-auto" : "bg-slate-800/60"}`} style={{borderLeftColor: accentColor}}>
                    <p className="font-bold" style={{color: accentColor}}>@{msg.replyTo.sender}</p>
                    <p className="text-slate-400 truncate">{msg.replyTo.preview}</p>
                  </div>
                )}

                <div
                  onClick={() => handleMsgLongPress(msg.id)}
                  className={`px-4 py-2.5 rounded-2xl cursor-pointer select-none transition-all ${
                    isMaxSender ? "bg-[#1e3a8a]/60 border border-blue-700/50 rounded-tl-sm"
                      : isMe ? "rounded-tr-sm" : "bg-slate-800/80 border border-slate-700/40 rounded-tl-sm"
                  } ${isSelected ? "ring-1 ring-white/20" : ""} ${animClassForMsg(msg.animation)}`}
                  style={isMe && !isMaxSender ? {background: `linear-gradient(135deg, ${accentColor}30, ${accentColor}20)`, borderLeft:`1px solid ${accentColor}40`, borderTop:`1px solid ${accentColor}30`} : undefined}
                >
                  {isMaxSender && <span className="text-[9px] text-blue-400 font-bold uppercase tracking-wider block mb-1">🛡️ MAX ✓</span>}
                  {!isMe && !isMaxSender && isGroup && (
                    <span className="text-[9px] font-bold flex items-center gap-1 mb-1" style={{color: accentColor}}>
                      @{msg.sender}
                      {senderBadges[msg.sender] && (() => {
                        const b = BADGES.find(x => x.id === senderBadges[msg.sender]);
                        return b ? (
                          <span
                            className={`text-[11px] leading-none ${b.anim}`}
                            style={{ filter: `drop-shadow(0 0 4px ${b.glow})` }}
                            title={b.label}
                          >{b.emoji}</span>
                        ) : null;
                      })()}
                    </span>
                  )}
                  {!isMe && !isGroup && !isMaxSender && senderBadges[msg.sender] && (() => {
                    const b = BADGES.find(x => x.id === senderBadges[msg.sender]);
                    return b ? (
                      <span
                        className={`text-[11px] leading-none block mb-1 ${b.anim}`}
                        style={{ filter: `drop-shadow(0 0 4px ${b.glow})` }}
                        title={b.label}
                      >{b.emoji}</span>
                    ) : null;
                  })()}

                  {msg.deleted ? (
                    <div className="flex items-center gap-1.5 italic opacity-60">
                      <Trash2 className="w-3 h-3 text-slate-500 flex-shrink-0" />
                      <span className="text-xs text-slate-500">Bu xabar o'chirildi</span>
                    </div>
                  ) : msg.type === "voice" ? (
                    <div className="space-y-1">
                      {msg.secret && <span className="text-[9px] text-rose-400 font-bold block">🔥 Maxfiy audio</span>}
                      <audio src={msg.text} controls className="w-48 h-8 rounded-lg" />
                    </div>
                  ) : msg.type === "image" ? (
                    <img src={msg.text} className="rounded-xl max-w-[220px] max-h-64 object-cover cursor-zoom-in"
                      onClick={e => { e.stopPropagation(); window.open(msg.text, "_blank"); }}
                      alt="img"
                    />
                  ) : msg.type === "location" ? (() => {
                    const parts = msg.text.split(",");
                    const lat = parseFloat(parts[0]);
                    const lng = parseFloat(parts[1]);
                    const mapsUrl = `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=16/${lat}/${lng}`;
                    return (
                      <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                        className="block rounded-xl overflow-hidden border border-slate-600/60 bg-slate-900/80 min-w-[180px] hover:border-slate-500 transition"
                        onClick={e => e.stopPropagation()}>
                        <div className="h-24 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center relative">
                          <div className="absolute inset-0 opacity-20"
                            style={{backgroundImage:"radial-gradient(circle at 1px 1px, #475569 1px, transparent 0)", backgroundSize:"20px 20px"}} />
                          <div className="relative flex flex-col items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-red-500/20 border-2 border-red-400 flex items-center justify-center">
                              <MapPin className="w-4 h-4 text-red-400" />
                            </div>
                            <div className="w-1 h-3 bg-red-400/60 rounded-full" />
                          </div>
                        </div>
                        <div className="px-3 py-2 flex items-center justify-between">
                          <div>
                            <p className="text-xs font-semibold text-slate-200 flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-red-400" />Joylashuv ulashildi
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono">{lat.toFixed(4)}, {lng.toFixed(4)}</p>
                          </div>
                          <span className="text-[10px] text-cyan-400 font-semibold">Ochish →</span>
                        </div>
                      </a>
                    );
                  })() : (
                    <div>
                      <p className="text-sm text-slate-100 whitespace-pre-wrap break-words leading-relaxed">
                        {msg.text.split(/(nexus:\/\/\S+)/g).map((part: string, idx: number) =>
                          part.startsWith("nexus://") ? (
                            <button key={idx} onClick={() => {
                              if (part.startsWith("nexus://join/")) {
                                const channelId = part.replace("nexus://join/", "");
                                window.dispatchEvent(new CustomEvent("nexus-navigate", { detail: { type: "channel", channelId } }));
                              } else if (part.startsWith("nexus://user/")) {
                                const user = part.replace("nexus://user/", "");
                                window.dispatchEvent(new CustomEvent("nexus-navigate", { detail: { type: "user", username: user } }));
                              }
                            }} className="text-cyan-400 underline hover:text-cyan-300 transition font-medium">{part}</button>
                          ) : part
                        )}
                      </p>
                      {translations[msg.id] && (
                        <div className="mt-1.5 pt-1.5 border-t border-slate-700/60">
                          <p className="text-[10px] text-cyan-500 font-semibold flex items-center gap-1 mb-0.5">
                            <Globe className="w-2.5 h-2.5" />Tarjima (O'zbek):
                          </p>
                          <p className="text-xs text-slate-300 whitespace-pre-wrap">{translations[msg.id]}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {msg.edited && msg.originalText && !msg.deleted && (
                    <div className="mt-1.5 border-t border-slate-700/50 pt-1">
                      <button
                        onClick={e => { e.stopPropagation(); setExpandedOriginals(prev => { const n = new Set(prev); n.has(msg.id) ? n.delete(msg.id) : n.add(msg.id); return n; }); }}
                        className="flex items-center gap-1 text-[9px] text-slate-500 hover:text-slate-400 transition">
                        <Pencil className="w-2.5 h-2.5" />
                        tahrirlangan — {expandedOriginals.has(msg.id) ? "yashirish ▲" : "aslini ko'rish ▼"}
                      </button>
                      {expandedOriginals.has(msg.id) && (
                        <div className="mt-1 px-2 py-1 bg-slate-900/60 rounded-lg border border-slate-700/40">
                          <p className="text-[9px] text-slate-500 mb-0.5">Avvalgi matn:</p>
                          <p className="text-xs text-slate-400 whitespace-pre-wrap line-through opacity-60">{msg.originalText}</p>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-1 mt-1">
                    {msg.edited && !msg.originalText && <span className="text-[9px] text-slate-500 font-mono">tahrirlangan</span>}
                    {msg.secret && msg.type !== "voice" && <span className="text-[9px] text-rose-400">🔥30s</span>}
                    <span className="text-[9px] text-slate-500 font-mono">
                      {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                    </span>
                    {isMe && !isGroup && (
                      <span className={`flex items-center ${msg.status === "read" ? "text-cyan-400" : "text-slate-500"}`}>
                        {msg.status === "read" ? <CheckCheck className="w-3 h-3" /> : <Check className="w-3 h-3" />}
                      </span>
                    )}
                  </div>
                </div>

                {/* Reaction pills */}
                {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                  <div className={`flex flex-wrap gap-1 mt-0.5 ${isMe ? "justify-end" : "justify-start"}`}>
                    {Object.entries(msg.reactions).filter(([, users]) => Object.keys(users).length > 0).map(([emoji, users]) => {
                      const count = Object.keys(users).length;
                      const iMine = !!users[username];
                      return (
                        <button key={emoji} onClick={() => toggleReaction(msg, emoji)}
                          className={`flex items-center gap-0.5 text-xs px-1.5 py-0.5 rounded-full transition border ${iMine ? "bg-indigo-900/60 border-indigo-500/70 text-white" : "bg-slate-800/80 border-slate-700/60 text-slate-300 hover:border-slate-500"}`}>
                          <span>{emoji}</span>
                          <span className="text-[9px] font-bold">{count}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* EMOJI PICKER — iOS style */}
      {showEmoji && (
        <EmojiPicker onPick={e => setInputText(t => t + e)} onClose={() => setShowEmoji(false)} accentColor={accentColor} />
      )}

      {/* REPLY/EDIT PREVIEW */}
      {(replyTo || editMsg) && (
        <div className="flex-shrink-0 px-4 py-2 border-t border-slate-800 bg-slate-900/60 flex items-center gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-bold" style={{color: accentColor}}>
              {editMsg ? "✏️ Tahrirlash" : `↩️ @${replyTo?.sender}`}
            </p>
            <p className="text-[10px] text-slate-400 truncate">{editMsg ? editMsg.text : replyTo?.text || "📷 Rasm"}</p>
          </div>
          <button onClick={() => { setReplyTo(null); setEditMsg(null); setInputText(""); }} className="text-slate-500 hover:text-slate-300 text-sm">✕</button>
        </div>
      )}

      {/* FOOTER */}
      {isOfficialMax ? (
        <footer className="flex-shrink-0 p-4 border-t border-slate-900 text-center text-[11px] font-bold text-blue-500/40 tracking-wider bg-slate-950/80">
          🔒 RASMIY KANAL — JAVOB YOZISH MUMKIN EMAS
        </footer>
      ) : isChannel && !isGroupAdmin ? (
        <footer className="flex-shrink-0 p-4 border-t border-slate-900 text-center text-[11px] text-amber-500/60 tracking-wider bg-slate-950/80">
          📡 FAQAT ADMIN XABAR YOZA OLADI
        </footer>
      ) : privacyBlocked === "nobody" ? (
        <footer className="flex-shrink-0 p-4 border-t border-slate-900/60 text-center bg-slate-950/80 space-y-1">
          <p className="text-2xl">🔒</p>
          <p className="text-xs font-bold text-rose-400">@{targetUser} xabarlarga ruxsat bermagan</p>
          <p className="text-[10px] text-slate-600">Bu foydalanuvchi "Hech kim" sozlamasini tanlagan</p>
        </footer>
      ) : privacyBlocked === "contacts" ? (
        <footer className="flex-shrink-0 p-4 border-t border-slate-900/60 text-center bg-slate-950/80 space-y-1">
          <p className="text-2xl">👤</p>
          <p className="text-xs font-bold text-amber-400">Faqat kontaktlar yoza oladi</p>
          <p className="text-[10px] text-slate-600">@{targetUser} faqat kontaktlariga ruxsat bergan. Avval ularni kontaktga qo'shing.</p>
        </footer>
      ) : (
        <footer className={`flex-shrink-0 px-3 py-3 border-t border-slate-800/60 bg-[#030712] flex items-end gap-2 ${isLocked ? "opacity-40 pointer-events-none" : ""}`}>
          <div className="flex flex-col gap-1 flex-shrink-0">
            <button onClick={() => setShowEmoji(e => !e)}
              className={`w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800 border border-slate-800 transition ${showEmoji ? "bg-slate-800 text-white" : "text-slate-400"}`}
              title="Emoji">
              <Smile className="w-4 h-4" />
            </button>
            <label className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800 border border-slate-800 text-slate-400 cursor-pointer transition" title="Rasm yuborish">
              <Paperclip className="w-4 h-4" />
              <input type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) sendImage(f); e.target.value = ""; }} />
            </label>
            <button onClick={sendLocation}
              className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800 border border-slate-800 text-slate-400 transition"
              title="Joylashuv ulashish">
              <MapPin className="w-4 h-4" />
            </button>
            {isPremium && (
              <div className="relative">
                <button onClick={() => setShowAnimPicker(a => !a)}
                  title="Xabar animatsiyasi"
                  className={`w-9 h-9 rounded-xl flex items-center justify-center text-base hover:bg-slate-800 border transition ${chatAnim !== "none" ? "border-amber-500 text-amber-400 bg-amber-950/20" : "border-slate-800 text-slate-400"}`}>
                  {chatAnim !== "none" ? (CHAT_ANIMATIONS.find(a => a.id === chatAnim)?.icon || "✨") : "✨"}
                </button>
                {showAnimPicker && (
                  <div className="absolute bottom-full left-0 mb-2 w-44 rounded-2xl border border-slate-700 bg-slate-900/98 p-2 space-y-0.5 animate-[scale-in_0.15s] z-50 shadow-xl">
                    <p className="text-[9px] font-bold uppercase text-slate-500 px-2 mb-1.5">✨ Chat Animatsiya</p>
                    {CHAT_ANIMATIONS.map(a => (
                      <button key={a.id} onClick={() => { setChatAnim(a.id); setShowAnimPicker(false); }}
                        className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs transition ${chatAnim === a.id ? "bg-amber-900/40 text-amber-400" : "text-slate-300 hover:bg-slate-800"}`}>
                        <span>{a.icon}</span>
                        <span>{a.label}</span>
                        {chatAnim === a.id && <span className="ml-auto text-[10px]">✓</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex-1 flex flex-col gap-1 min-w-0">
            <textarea
              ref={inputRef}
              value={inputText}
              onChange={e => { setInputText(e.target.value); handleTyping(); }}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
              placeholder={isLocked ? "🚨 Chat bloklangan..." : "@BotName buyruq yoki xabar yozing..."}
              rows={1}
              className="w-full bg-slate-900/80 border border-slate-700/60 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-slate-500 transition resize-none"
              style={{maxHeight:"120px"}}
            />
            {inputText.startsWith("@") && BOTS.some(b => inputText.startsWith(`@${b}`)) && (
              <p className="text-[10px] text-cyan-500 px-1 flex items-center gap-1">
                <AtSign className="w-2.5 h-2.5" />Inline bot buyruq — istalgan chatda ishlaydi
              </p>
            )}
          </div>

          <div className="flex flex-col gap-1 flex-shrink-0">
            <button onClick={toggleVoiceRecording}
              className={`w-9 h-9 rounded-xl flex items-center justify-center border transition ${isRecording ? "bg-rose-600 border-rose-500 animate-pulse text-white" : "hover:bg-slate-800 border-slate-800 text-slate-400"}`}
              title={isRecording ? "To'xtatish" : "Ovozli xabar"}>
              {isRecording ? <StopCircle className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
            <button onClick={sendMessage} disabled={!inputText.trim()}
              className="w-9 h-9 rounded-xl flex items-center justify-center border border-transparent transition disabled:opacity-30 text-white"
              style={inputText.trim() ? { background: accentColor } : { background: "#1e293b", borderColor: "#334155" }}
              title="Yuborish">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </footer>
      )}

      {/* MEDIA GALLERY MODAL */}
      {showGallery && (
        <div className="absolute inset-0 z-50 bg-black/90 flex flex-col" onClick={() => setShowGallery(false)}>
          <div className="p-4 border-b border-slate-800 flex items-center justify-between" onClick={e => e.stopPropagation()}>
            <p className="font-bold text-sm">🖼️ Media ({mediaGallery.length} ta rasm)</p>
            <button onClick={() => setShowGallery(false)} className="text-slate-400 hover:text-white text-xl">✕</button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 grid grid-cols-3 gap-2" onClick={e => e.stopPropagation()}>
            {mediaGallery.length === 0 && <p className="col-span-3 text-center text-slate-500 py-10 text-sm">Rasm yo'q</p>}
            {mediaGallery.map(m => (
              <img key={m.id} src={m.text} className="w-full aspect-square object-cover rounded-xl cursor-pointer hover:opacity-80 transition"
                onClick={() => window.open(m.text, "_blank")}
                alt="media"
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function EmojiPicker({ onPick, onClose, accentColor }: { onPick: (e: string) => void; onClose: () => void; accentColor: string }) {
  const [tab, setTab] = useState(EMOJI_TABS[0]);
  return (
    <div className="flex-shrink-0 border-t border-slate-800 bg-slate-950/95 animate-[scale-in_0.15s_ease-out]" style={{ maxHeight: 280 }}>
      <div className="flex items-center justify-between px-2 pt-2">
        <div className="flex gap-1 overflow-x-auto flex-1">
          {EMOJI_TABS.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-shrink-0 w-9 h-9 rounded-lg ios-emoji text-lg transition ${tab === t ? "bg-slate-800" : "hover:bg-slate-900"}`}
              style={tab === t ? { boxShadow: `0 0 0 2px ${accentColor}` } : {}}>{t}</button>
          ))}
        </div>
        <button onClick={onClose} className="ml-2 w-9 h-9 rounded-lg text-slate-400 hover:bg-slate-800 text-sm">✕</button>
      </div>
      <div className="px-2 py-2 overflow-y-auto grid grid-cols-8 gap-1" style={{ maxHeight: 210 }}>
        {EMOJI_CATEGORIES[tab].map(e => (
          <button key={e} onClick={() => onPick(e)}
            className="ios-emoji text-2xl rounded-lg hover:bg-slate-800 active:scale-90 transition-transform aspect-square flex items-center justify-center">
            {e}
          </button>
        ))}
      </div>
    </div>
  );
}
