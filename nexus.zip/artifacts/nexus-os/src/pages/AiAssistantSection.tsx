import { useState, useRef, useEffect, useCallback } from "react";
import { ref, push, onValue, set, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import { Bot, Send, Trash2, Sparkles, Copy, RefreshCw, ChevronDown, Mic, MicOff, X } from "lucide-react";

interface AiMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  ts: number;
}

interface Props {
  username: string;
  accentColor: string;
}

const SYSTEM_PROMPT = `Sen Nexus OS platformasining AI yordamchisisans - NEXUS AI. 
Sen O'zbek, Rus va Ingliz tillarida gaplasha olasan.
Foydalanuvchilarga chat, o'yinlar, muzika, hamyon va boshqa funksiyalar haqida yordam berasan.
Qisqa, aniq va do'stona javob ber. Emojilardan foydalanish mumkin.`;

const QUICK_PROMPTS = [
  { icon: "💬", text: "Suhbat qilish bo'yicha maslahat ber" },
  { icon: "🎮", text: "Qaysi o'yin qiziqroq?" },
  { icon: "⭐", text: "Yulduz topishning yo'llari" },
  { icon: "🔒", text: "Maxfiy chat nima?" },
  { icon: "📊", text: "Analitika haqida tushuntir" },
  { icon: "🌐", text: "Kanallar qanday ishlaydi?" },
];

const LOCAL_RESPONSES: Record<string, string[]> = {
  salom: [
    "Salom! 👋 Men NEXUS AI — Nexus OS'ning aqlli yordamchisi. Bugun sizga qanday yordam bera olaman?",
    "Assalomu alaykum! 🤖 Xush kelibsiz! Savollaringizni bering — javob berishga tayyor.",
    "Hey! 😊 NEXUS AI bu yerda. Nexus haqida, o'yinlar, hamyon, chatlar — istalgan narsani so'rang!"
  ],
  hello: [
    "Hello! 👋 I'm NEXUS AI. How can I help you today?",
    "Hi there! 🤖 Ask me anything about Nexus OS features!"
  ],
  привет: [
    "Привет! 👋 Я NEXUS AI — ваш помощник в Nexus OS. Чем могу помочь?",
    "Здравствуйте! 🤖 Задайте любой вопрос о Nexus!"
  ],
  yordam: [
    "Albatta! 💡 Quyidagi bo'limlar mavjud:\n\n💬 **Chatlar** — real-vaqt xabar almashish\n📰 **Lenta** — postlar va hikoyalar\n🎮 **O'yinlar** — 17+ o'yin\n⭐ **Hamyon** — yulduzlar va sovg'alar\n🔒 **Maxfiy chat** — shifrlangan suhbat\n🌤️ **Ob-havo** — O'zbekiston bo'ylab\n₿ **Kripto** — narx kuzatuvi\n🤖 **AI Bot** — men bu yerda!\n\nQaysi bo'lim haqida batafsil bilmoqchisiz?"
  ],
  help: [
    "Sure! Here's what Nexus OS offers:\n\n💬 Chats — real-time messaging\n🎮 Games — 17+ games\n⭐ Wallet — stars & gifts\n🔒 Secret chat — encrypted\n📰 Feed — posts & stories\n\nWhat would you like to know more about?"
  ],
  chat: [
    "💬 Chatlar bo'limida:\n\n✅ Real-vaqt xabar almashish\n✅ Rasmlar, ovoz va fayl yuborish\n✅ Guruhlar va kanallar yaratish\n✅ Xabarlarni pin qilish\n✅ Emoji reaksiyalar\n✅ Xabarlarni tahrirlash/o'chirish\n✅ Maxfiy chat rejimi\n✅ Ovozli va video qo'ng'iroqlar\n\nBoshlash uchun yon paneldagi 💬 tugmasini bosing!",
    "Chat bo'limida do'stlaringiz bilan real vaqtda gaplashing! 💬\n\nGuruh yaratish uchun: Chatlar → Yangi guruh tugmasi → Nom kiriting."
  ],
  yulduz: [
    "⭐ Yulduzlar — Nexus'ning virtual valyutasi!\n\n💰 **Qanday topish:**\n• Har kuni kirish bonusi\n• Missiyalarni bajarish\n• Do'stlardan sovg'a qabul qilish\n• O'yinlarda g'alaba\n\n🛒 **Nima uchun:**\n• Premium obuna sotib olish\n• Maxsus badge va animatsiyalar\n• Star Shop'dan sovg'alar\n• Do'stlarga yuborish\n\nHamyon bo'limiga o'ting: ⭐ Hamyon",
  ],
  stars: [
    "⭐ Stars are Nexus virtual currency!\n\n• Earn daily login bonus\n• Complete missions\n• Receive gifts from friends\n• Win in games\n\nSpend stars on Premium, badges, and gifts in the Star Shop!"
  ],
  premium: [
    "💎 **Premium obuna imtiyozlari:**\n\n👑 Maxsus premium badge\n✨ Animatsiyali badge'lar\n📸 Ko'proq hikoya postlar\n📁 50MB gacha media yuklash\n🔒 Maxfiy kanal yaratish\n🎨 Maxsus tema ranglari\n⚡ Ustuvor texnik yordam\n\nPremium olish: Hamyon → Premium → To'lov",
  ],
  oyun: [
    "🎮 **17+ O'yin mavjud!**\n\n🔴 To'rt Kettachi (Connect Four)\n🔢 2048 — sonlarni birlashtir\n⚓ Dengiz Jangi\n🕵️ Mafia — rol o'yini\n🐍 Snake — klassik\n🧮 Matematika testi\n🏃 NEXUS RUNNER 3D\n♟️ Shashka\n🃏 Blackjack\n🎯 Word Guess\n🧩 Memory karta\n🔤 Anagram\n...va boshqalar!\n\nO'yinlar bo'limiga o'tish: 🎮",
  ],
  games: [
    "🎮 Nexus has 17+ games!\n\nConnect Four, 2048, Sea Battle, Mafia, Snake, Math Test, NEXUS RUNNER 3D, Checkers, Blackjack, and more!\n\nHead to the Games section to play!"
  ],
  "ob-havo": [
    "🌤️ Ob-havo bo'limida:\n\n• O'zbekistonning 12 shahri\n• Hozirgi harorat va namlik\n• Soatlik prognoz\n• 7 kunlik forecast\n• Shamol tezligi\n\nOb-havo → Kerakli shaharni tanlang."
  ],
  weather: [
    "🌤️ Weather section shows real-time weather for 12 Uzbek cities using Open-Meteo API!\n\nFeatures: current temp, humidity, wind speed, hourly & 7-day forecast."
  ],
  kripto: [
    "₿ **Kripto bo'limi:**\n\n• Bitcoin, Ethereum, va 50+ koin narxlari\n• Real-vaqt narx o'zgarishi\n• 24 soatlik grafiklar\n• Bozor qiymatini kuzatish\n• Sevimli koinlar ro'yxati\n\nKripto → 'Bozor' bo'limini ko'ring.",
  ],
  crypto: [
    "₿ Crypto section tracks Bitcoin, Ethereum, and 50+ coins!\n\nReal-time prices, 24h changes, market cap tracking, and favorite coins list."
  ],
  kanal: [
    "📡 **Kanallar bo'limida:**\n\n• Ochiq kanallar ro'yxati\n• Kanal yaratish (Premium)\n• Obuna bo'lish\n• Post va media ko'rish\n• @Max rasmiy kanali mavjud\n\nKanallar → Barcha kanallar.",
  ],
  maxfiy: [
    "🔒 **Maxfiy chat:**\n\n• End-to-end shifrlangan\n• Xabarlar faqat siz va qabul qiluvchida saqlanadi\n• Avtomatik o'chirish mumkin\n• Screenshot himoyasi\n• Tarix saqlanmaydi\n\nChatlar → Maxfiy chat tugmasi.",
  ],
  ovoz: [
    "🎙️ **Ovoz Xonalari:**\n\n• Ko'p foydalanuvchi ovozli suhbat\n• Xonalar yaratish va ulashish\n• Moderator imkoniyatlari\n• Real-vaqt audio\n\nOvoz Xonalari bo'limiga o'ting.",
  ],
  voice: [
    "🎙️ Voice Rooms allow group audio conversations!\n\nCreate a room, invite friends, and chat in real-time with moderation tools."
  ],
  til: [
    "🧠 **Til O'rganish (Flashcard):**\n\n• So'z kartalari\n• Inglizcha/Ruscha/O'zbekcha\n• Haftalik progress\n• Testlar\n\nTil O'rganish bo'limiga o'ting: 🧠",
  ],
  profil: [
    "👤 **Profil sozlamalari:**\n\n• Avatar va bio o'zgartirish\n• Holat (status) qo'yish\n• Do'stlar ro'yxati\n• Statistika ko'rish\n• QR kod orqali ulashish\n\nProfil → Mening profilim.",
  ],
  sozlamalar: [
    "⚙️ **Sozlamalar:**\n\n• Interfeys rangi (16+ rang)\n• Til tanlash (UZ/RU/EN/KK)\n• Bildirishnomalar\n• Maxfiylik\n• Hisob boshqaruvi\n• Tizimdan chiqish",
  ],
  musiqa: [
    "🎵 **Musiqa bo'limida:**\n\n• YouTube linki orqali musiqa qo'shish\n• Playlist yaratish\n• Background rejimda tinglash\n• Sevimlilar ro'yxati\n\nMusiqa → Media player.",
  ],
  nexus: [
    "⚡ **Nexus OS nima?**\n\nNexus OS — O'zbekiston uchun yaratilgan zamonaviy ijtimoiy platforma!\n\n🌟 **Imkoniyatlar:**\n• Real-vaqt chat va qo'ng'iroqlar\n• 17+ o'yin\n• Virtual hamyon\n• AI yordamchi\n• Ob-havo & Kripto\n• Ovoz xonalari\n• Kanal va guruhlar\n\nVersion 5.6 · CONNECTUZ tizimi",
  ],
  default: [
    "Qiziqarli savol! 🤔\n\nMen NEXUS AI sifatida Nexus OS platformasi haqida yordam bera olaman. Chatlar, o'yinlar, hamyon, ob-havo, kripto, AI, ovoz xonalari — bulardan birini so'rang!\n\nYoki GPT-4o bilan bog'lanish uchun yuqoridagi 🔑 API tugmasini bosib OpenAI kalitingizni kiriting.",
    "Tushundim! 💡 Bu mavzu bo'yicha ko'proq ma'lumot uchun Nexus'ning mos bo'limini ko'ring, yoki savolni boshqacha so'rab ko'ring.\n\nMen Nexus funksiyalari, o'yinlar, hamyon, chatlar haqida batafsil javob bera olaman!",
    "Qidirayotgan narsangizni topish uchun 🔍 Global Qidiruv'dan foydalaning (yuqori o'ng burchakdagi lupa ikonkasi). Men esa Nexus'ning istalgan bo'limi haqida yordam beraman! 😊",
  ]
};

function getLocalResponse(text: string): string {
  const lower = text.toLowerCase();
  for (const [key, responses] of Object.entries(LOCAL_RESPONSES)) {
    if (key === "default") continue;
    if (lower.includes(key)) {
      return responses[Math.floor(Math.random() * responses.length)];
    }
  }
  const defaults = LOCAL_RESPONSES.default;
  return defaults[Math.floor(Math.random() * defaults.length)];
}

export default function AiAssistantSection({ username, accentColor }: Props) {
  const [messages, setMessages] = useState<AiMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("nexus_ai_key") || "");
  const [showApiSetup, setShowApiSetup] = useState(false);
  const [tempKey, setTempKey] = useState("");
  const [model, setModel] = useState<"local" | "gpt">("local");
  const [isListening, setIsListening] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const storageKey = `nexus_ai_chat_${username}`;

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
      setMessages(saved);
    } catch {
      setMessages([]);
    }
  }, [storageKey]);

  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem(storageKey, JSON.stringify(messages.slice(-100)));
    }
    setTimeout(() => scrollToBottom(), 50);
  }, [messages]);

  function scrollToBottom() {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }

  function handleScroll() {
    const el = scrollRef.current;
    if (!el) return;
    setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > 200);
  }

  function copyMsg(content: string, id: string) {
    navigator.clipboard.writeText(content).then(() => {
      setCopied(id);
      setTimeout(() => setCopied(null), 2000);
    });
  }

  async function sendMessage(text?: string) {
    const msgText = (text || input).trim();
    if (!msgText || loading) return;
    setInput("");

    const userMsg: AiMessage = { id: Date.now().toString(), role: "user", content: msgText, ts: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    await new Promise(r => setTimeout(r, 600 + Math.random() * 800));

    let responseText = "";

    if (model === "gpt" && apiKey) {
      try {
        const history = [...messages.slice(-10), userMsg].map(m => ({ role: m.role, content: m.content }));
        const res = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [{ role: "system", content: SYSTEM_PROMPT }, ...history],
            max_tokens: 500,
            temperature: 0.8,
          })
        });
        if (res.ok) {
          const data = await res.json();
          responseText = data.choices?.[0]?.message?.content || "Xatolik yuz berdi.";
        } else {
          responseText = "❌ API xatosi. Kalit noto'g'ri yoki limit tugagan.";
        }
      } catch {
        responseText = "❌ Tarmoq xatosi. Iltimos qayta urinib ko'ring.";
      }
    } else {
      responseText = getLocalResponse(msgText);
    }

    const aiMsg: AiMessage = { id: (Date.now() + 1).toString(), role: "assistant", content: responseText, ts: Date.now() };
    setMessages(prev => [...prev, aiMsg]);
    setLoading(false);
  }

  function clearChat() {
    setMessages([]);
    localStorage.removeItem(storageKey);
  }

  function saveApiKey() {
    localStorage.setItem("nexus_ai_key", tempKey);
    setApiKey(tempKey);
    setModel(tempKey ? "gpt" : "local");
    setShowApiSetup(false);
  }

  function startVoice() {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const recog = new SpeechRecognition();
    recog.lang = "uz-UZ";
    recog.continuous = false;
    recog.interimResults = false;
    recog.onresult = (e: any) => {
      const txt = e.results[0][0].transcript;
      setInput(txt);
      setIsListening(false);
    };
    recog.onerror = () => setIsListening(false);
    recog.onend = () => setIsListening(false);
    recognitionRef.current = recog;
    recog.start();
    setIsListening(true);
  }

  function stopVoice() {
    recognitionRef.current?.stop();
    setIsListening(false);
  }

  function formatContent(content: string) {
    return content.split("\n").map((line, i) => (
      <span key={i}>{line}{i < content.split("\n").length - 1 && <br />}</span>
    ));
  }

  return (
    <div className="flex flex-col h-full" style={{ background: "#030712" }}>
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-4 border-b border-slate-800/40 relative overflow-hidden"
        style={{ background: "rgba(8,12,25,0.98)", backdropFilter: "blur(20px)" }}>
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg,transparent,#7c3aed55,#06b6d455,transparent)" }} />
          <div className="absolute top-1/2 left-1/3 w-32 h-12 -translate-y-1/2 rounded-full blur-2xl opacity-10" style={{ background: "linear-gradient(90deg,#7c3aed,#06b6d4)" }} />
        </div>
        <div className="flex items-center gap-3 relative">
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl relative"
            style={{ background: "linear-gradient(135deg,#7c3aed,#06b6d4)", boxShadow: "0 0 20px #7c3aed40" }}>
            🤖
            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-green-400 border-2 border-[#030712] animate-pulse" />
          </div>
          <div>
            <p className="text-sm font-black text-white tracking-tight">NEXUS AI</p>
            <p className="text-[10px] font-mono" style={{ color: "#7c3aed" }}>
              {model === "gpt" ? "⚡ GPT-4o-mini · Pro" : "💡 Lokal · Asosiy rejim"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 relative">
          <button onClick={() => { setTempKey(apiKey); setShowApiSetup(true); }}
            className="px-2.5 py-1.5 rounded-xl text-[10px] font-bold border transition hover:opacity-80"
            style={{ borderColor: "#7c3aed40", color: "#a78bfa", background: "#7c3aed12" }}>
            {apiKey ? "⚙️ Sozla" : "🔑 API"}
          </button>
          <button onClick={clearChat} className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-slate-800 text-slate-600 hover:text-rose-400 transition" title="Chatni tozalash">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* API Setup Modal */}
      {showApiSetup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" style={{ backdropFilter: "blur(8px)" }}>
          <div className="w-80 p-6 rounded-2xl border border-slate-700/60 space-y-4" style={{ background: "#0f172a" }}>
            <div className="flex items-center justify-between">
              <p className="font-bold text-white">OpenAI API Kalit</p>
              <button onClick={() => setShowApiSetup(false)} className="text-slate-500 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <p className="text-xs text-slate-400">OpenAI API kalitingizni kiriting. Kalit qurilmangizda saqlanadi va faqat siz ko'ra olasiz.</p>
            <input
              value={tempKey}
              onChange={e => setTempKey(e.target.value)}
              placeholder="sk-..."
              type="password"
              className="w-full px-3 py-2.5 rounded-xl text-sm bg-slate-900 border border-slate-700 text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-500"
            />
            <div className="flex gap-2">
              <button onClick={() => { setTempKey(""); saveApiKey(); }}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition">
                Kalitsiz (Lokal)
              </button>
              <button onClick={saveApiKey}
                className="flex-1 py-2 rounded-xl text-xs font-bold text-white transition"
                style={{ background: "linear-gradient(135deg,#7c3aed,#06b6d4)" }}>
                Saqlash
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      <div ref={scrollRef} onScroll={handleScroll} className="flex-1 overflow-y-auto px-4 py-4 space-y-3 relative">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-6 py-10">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl"
              style={{ background: "linear-gradient(135deg,#7c3aed22,#06b6d422)", border: "1px solid #7c3aed33" }}>
              🤖
            </div>
            <div>
              <p className="text-lg font-bold text-white mb-1">NEXUS AI</p>
              <p className="text-xs text-slate-500 max-w-xs">Savollaringizga javob beraman, yo'nalish beraman va Nexus'dan maximum foydalanishga yordam qilaman</p>
            </div>
            <div className="grid grid-cols-2 gap-2 w-full max-w-sm">
              {QUICK_PROMPTS.map((q, i) => (
                <button key={i} onClick={() => sendMessage(q.text)}
                  className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-left text-xs text-slate-300 hover:text-white border border-slate-800 hover:border-slate-600 transition"
                  style={{ background: "rgba(30,41,59,0.5)" }}>
                  <span>{q.icon}</span>
                  <span className="truncate">{q.text}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map(msg => (
          <div key={msg.id} className={`flex gap-2.5 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
            <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-sm"
              style={{
                background: msg.role === "user"
                  ? `linear-gradient(135deg,${accentColor},#4f46e5)`
                  : "linear-gradient(135deg,#7c3aed,#06b6d4)"
              }}>
              {msg.role === "user" ? username[0]?.toUpperCase() : "🤖"}
            </div>
            <div className={`max-w-[78%] group relative`}>
              <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                msg.role === "user"
                  ? "text-white"
                  : "text-slate-100"
              }`} style={{
                background: msg.role === "user"
                  ? `linear-gradient(135deg,${accentColor}cc,#4f46e588)`
                  : "rgba(30,41,59,0.8)",
                border: msg.role === "assistant" ? "1px solid rgba(139,92,246,0.2)" : "none"
              }}>
                {formatContent(msg.content)}
              </div>
              <button
                onClick={() => copyMsg(msg.content, msg.id)}
                className="absolute -top-2 right-0 opacity-0 group-hover:opacity-100 transition-all px-1.5 py-0.5 rounded-lg text-[9px] font-bold bg-slate-800 text-slate-400 hover:text-white border border-slate-700">
                {copied === msg.id ? "✓" : <Copy className="w-2.5 h-2.5" />}
              </button>
              <p className="text-[9px] text-slate-600 mt-1 px-1">
                {new Date(msg.ts).toLocaleTimeString("uz-UZ", { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex gap-2.5">
            <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "linear-gradient(135deg,#7c3aed,#06b6d4)" }}>🤖</div>
            <div className="px-4 py-3 rounded-2xl" style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(139,92,246,0.2)" }}>
              <div className="flex items-center gap-1.5">
                {[0,1,2].map(i => (
                  <div key={i} className="w-2 h-2 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: `${i * 150}ms` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Scroll to bottom btn */}
      {showScrollBtn && (
        <button onClick={scrollToBottom}
          className="absolute bottom-24 right-4 w-9 h-9 rounded-full flex items-center justify-center shadow-lg border border-slate-700 transition hover:border-slate-500"
          style={{ background: "#0f172a" }}>
          <ChevronDown className="w-4 h-4 text-slate-400" />
        </button>
      )}

      {/* Input */}
      <div className="flex-shrink-0 p-3 border-t border-slate-800/60">
        <div className="flex items-end gap-2 rounded-2xl border p-2" style={{ background: "rgba(15,23,42,0.9)", borderColor: "rgba(139,92,246,0.25)" }}>
          <button
            onClick={isListening ? stopVoice : startVoice}
            className={`p-2 rounded-xl transition flex-shrink-0 ${isListening ? "text-rose-400 animate-pulse" : "text-slate-500 hover:text-slate-300"}`}>
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="Savolingizni yozing... (Shift+Enter yangi qator)"
            rows={1}
            className="flex-1 bg-transparent text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none resize-none leading-5"
            style={{ maxHeight: "120px", minHeight: "24px" }}
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || loading}
            className="p-2 rounded-xl transition flex-shrink-0 disabled:opacity-40"
            style={{ background: input.trim() ? `linear-gradient(135deg,#7c3aed,${accentColor})` : "#1e293b" }}>
            {loading ? <RefreshCw className="w-4 h-4 text-slate-400 animate-spin" /> : <Send className="w-4 h-4 text-white" />}
          </button>
        </div>
        <p className="text-[9px] text-slate-700 text-center mt-1.5">
          {model === "gpt" ? "GPT-4o-mini · OpenAI API" : "Lokal rejim · Asosiy javoblar"} · Enter = Yuborish
        </p>
      </div>
    </div>
  );
}
