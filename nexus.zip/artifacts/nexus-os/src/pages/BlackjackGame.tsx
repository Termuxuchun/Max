import { useState } from "react";

type Card = { suit: string; name: string; value: number };
type GameState = "betting" | "playing" | "dealerTurn" | "ended";

const SUITS = ["♠", "♥", "♦", "♣"];
const VALUES = [
  { n: "2", v: 2 }, { n: "3", v: 3 }, { n: "4", v: 4 }, { n: "5", v: 5 },
  { n: "6", v: 6 }, { n: "7", v: 7 }, { n: "8", v: 8 }, { n: "9", v: 9 },
  { n: "10", v: 10 }, { n: "J", v: 10 }, { n: "Q", v: 10 }, { n: "K", v: 10 }, { n: "A", v: 11 }
];

function createDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) for (const val of VALUES) deck.push({ suit, name: val.n, value: val.v });
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function calcScore(hand: Card[]): number {
  let score = 0, aces = 0;
  for (const card of hand) { score += card.value; if (card.name === "A") aces++; }
  while (score > 21 && aces > 0) { score -= 10; aces--; }
  return score;
}

function CardView({ card, hidden }: { card: Card; hidden?: boolean }) {
  if (hidden) {
    return (
      <div className="w-14 h-20 rounded-lg flex items-center justify-center text-2xl font-bold border border-cyan-900/50" style={{background:"linear-gradient(135deg,#0a0a2e,#1a1a4e)"}}>
        🂠
      </div>
    );
  }
  const isRed = card.suit === "♥" || card.suit === "♦";
  return (
    <div className="w-14 h-20 rounded-lg flex flex-col justify-between p-1.5 border border-slate-700" style={{background:"#f0f0f0"}}>
      <span className={`text-xs font-black leading-none ${isRed ? "text-red-600" : "text-slate-900"}`}>{card.name}{card.suit}</span>
      <span className={`text-2xl leading-none text-center ${isRed ? "text-red-600" : "text-slate-900"}`}>{card.suit}</span>
      <span className={`text-xs font-black leading-none self-end rotate-180 ${isRed ? "text-red-600" : "text-slate-900"}`}>{card.name}{card.suit}</span>
    </div>
  );
}

export default function BlackjackGame() {
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [gameState, setGameState] = useState<GameState>("betting");
  const [result, setResult] = useState("");
  const [chips, setChips] = useState(100);
  const [bet, setBet] = useState(10);
  const [showDealer, setShowDealer] = useState(false);

  function startGame() {
    if (bet > chips || bet <= 0) return;
    const newDeck = createDeck();
    const p = [newDeck.pop()!, newDeck.pop()!];
    const d = [newDeck.pop()!, newDeck.pop()!];
    setDeck(newDeck);
    setPlayerHand(p);
    setDealerHand(d);
    setShowDealer(false);
    setResult("");
    setGameState("playing");
    if (calcScore(p) === 21) {
      endGame(newDeck, p, d, true);
    }
  }

  function hit() {
    if (gameState !== "playing") return;
    const newDeck = [...deck];
    const newHand = [...playerHand, newDeck.pop()!];
    setDeck(newDeck);
    setPlayerHand(newHand);
    const score = calcScore(newHand);
    if (score > 21) {
      setShowDealer(true);
      setResult(`💥 BUST! Siz yutqazdingiz! (-${bet})`);
      setChips(c => c - bet);
      setGameState("ended");
    } else if (score === 21) {
      endGame(newDeck, newHand, dealerHand, false);
    }
  }

  function stand() {
    if (gameState !== "playing") return;
    endGame(deck, playerHand, dealerHand, false);
  }

  function endGame(d: Card[], p: Card[], dealer: Card[], isBlackjack: boolean) {
    let newDealer = [...dealer];
    const newDeck = [...d];
    while (calcScore(newDealer) < 17) newDealer = [...newDealer, newDeck.pop()!];
    setDealerHand(newDealer);
    setShowDealer(true);
    const pScore = calcScore(p);
    const dScore = calcScore(newDealer);

    let msg = "";
    if (isBlackjack && pScore === 21) {
      msg = `🎉 BLACKJACK! Siz yutdingiz! (+${bet * 2})`;
      setChips(c => c + bet * 2);
    } else if (dScore > 21) {
      msg = `🎉 Dealer bust! Siz yutdingiz! (+${bet})`;
      setChips(c => c + bet);
    } else if (pScore > dScore) {
      msg = `🏆 Siz yutdingiz! (+${bet})`;
      setChips(c => c + bet);
    } else if (pScore === dScore) {
      msg = `🤝 Durrang! Bet qaytarildi.`;
    } else {
      msg = `💀 Dealer yutdi! (-${bet})`;
      setChips(c => c - bet);
    }
    setResult(msg);
    setGameState("ended");
  }

  const pScore = calcScore(playerHand);
  const dScore = calcScore(dealerHand);

  return (
    <div className="w-full h-full flex flex-col items-center justify-start overflow-y-auto py-4 px-2">
      <h2 className="text-lg font-black font-mono mb-1 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
        🃏 BLACKJACK 21 // CYBER_CASINO
      </h2>
      <p className="text-xs font-mono text-slate-400 mb-4">Chiplar: <span className="text-cyan-400 font-bold">{chips}</span></p>

      {gameState === "betting" && (
        <div className="flex flex-col items-center gap-4 w-full max-w-xs">
          <div className="w-full">
            <p className="text-xs text-slate-400 mb-2 text-center">Stavka: <span className="text-cyan-400 font-bold">{bet}</span></p>
            <div className="flex gap-2 justify-center flex-wrap">
              {[5, 10, 25, 50].map(v => (
                <button key={v} onClick={() => setBet(v)} className={`px-4 py-2 rounded-xl text-xs font-bold border transition ${bet === v ? "bg-cyan-600 border-cyan-500 text-white" : "bg-slate-900 border-slate-700 text-slate-300 hover:border-cyan-600"}`}>
                  {v}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={startGame}
            disabled={bet > chips}
            className="px-8 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 disabled:opacity-50 transition"
          >
            🃏 O'YINNI BOSHLASH
          </button>
          {chips <= 0 && <p className="text-rose-400 text-xs font-mono animate-pulse">💸 Chiplar tugadi! Sahifani yangilang.</p>}
        </div>
      )}

      {gameState !== "betting" && (
        <div className="w-full max-w-sm space-y-4">
          {/* Dealer hand */}
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <p className="text-xs text-slate-400 mb-2 font-mono">DEALER {showDealer ? `(${dScore})` : "(?)"}</p>
            <div className="flex gap-2 flex-wrap">
              {dealerHand.map((card, i) => (
                <CardView key={i} card={card} hidden={!showDealer && i === 1} />
              ))}
            </div>
          </div>

          {/* Player hand */}
          <div className="p-3 rounded-xl bg-slate-900/60 border border-cyan-900/40">
            <p className="text-xs text-cyan-400 mb-2 font-mono">SIZ ({pScore})</p>
            <div className="flex gap-2 flex-wrap">
              {playerHand.map((card, i) => <CardView key={i} card={card} />)}
            </div>
          </div>

          {result && (
            <div className={`text-center font-bold text-sm p-3 rounded-xl border ${result.includes("yutdingiz") ? "bg-green-900/30 border-green-700 text-green-400" : result.includes("Durrang") ? "bg-slate-900 border-slate-600 text-slate-300" : "bg-rose-900/30 border-rose-700 text-rose-400"}`}>
              {result}
            </div>
          )}

          <div className="flex gap-3">
            {gameState === "playing" && (
              <>
                <button onClick={hit} className="flex-1 py-3 rounded-xl font-bold text-sm bg-cyan-600 hover:bg-cyan-500 transition">
                  HIT (+1)
                </button>
                <button onClick={stand} className="flex-1 py-3 rounded-xl font-bold text-sm bg-slate-700 hover:bg-slate-600 transition">
                  STAND
                </button>
              </>
            )}
            {gameState === "ended" && (
              <button onClick={() => setGameState("betting")} className="flex-1 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-cyan-600 to-purple-600 hover:opacity-90 transition">
                🃏 YANA O'YNAYMIZ
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
