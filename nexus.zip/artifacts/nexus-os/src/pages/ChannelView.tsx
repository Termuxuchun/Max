import { useEffect, useRef, useState } from "react";
import { ref, onValue, push, remove, update, set, get } from "firebase/database";
import { db } from "../firebase";

interface Props {
  channelId: string;
  username: string;
  accentColor: string;
  isPremium: boolean;
  onBack: () => void;
  onOpenProfile: (peer: string) => void;
}

interface ChMsg { id: string; from: string; text: string; ts: number; animation?: string; reactions?: Record<string, string[]>; }
type PanelTab = "messages" | "members" | "settings";

const ANIMATIONS = [
  { id: "none", label: "Yo'q", premium: false },
  { id: "fade", label: "✨ Fade", premium: false },
  { id: "slide", label: "➡️ Slide", premium: true },
  { id: "bounce", label: "🎈 Bounce", premium: true },
  { id: "sparkle", label: "💫 Sparkle", premium: true },
  { id: "neon", label: "🌈 Neon", premium: true },
];

const REACTION_EMOJIS = ["❤️", "👍", "😂", "🔥", "🎉", "😮", "👀", "🙏"];

export default function ChannelView({ channelId, username, accentColor, isPremium, onBack, onOpenProfile }: Props) {
  const [channel, setChannel] = useState<any>(null);
  const [messages, setMessages] = useState<ChMsg[]>([]);
  const [input, setInput] = useState("");
  const [tab, setTab] = useState<PanelTab>("messages");
  const [welcomeMsg, setWelcomeMsg] = useState("");
  const [chosenAnim, setChosenAnim] = useState("none");
  const [channelName, setChannelName] = useState("");
  const [channelDesc, setChannelDesc] = useState("");
  const [onlineMembers, setOnlineMembers] = useState<Set<string>>(new Set());
  const [reactionMsgId, setReactionMsgId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [pinnedMsg, setPinnedMsg] = useState<ChMsg | null>(null);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const isOwner = channel?.owner === username;
  const isAdmin = isOwner || channel?.members?.[username] === "admin";
  const canWrite = channel?.type === "group" || isAdmin;
  const memberCount = channel ? Object.keys(channel.members || {}).length : 0;
  const membersList = Object.entries(channel?.members || {}) as [string, string][];
  const onlineMemberCount = membersList.filter(([m]) => onlineMembers.has(m)).length;

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  }

  useEffect(() => {
    const u1 = onValue(ref(db, `channels/${channelId}`), s => {
      if (!s.exists()) { onBack(); return; }
      const d = s.val();
      setChannel(d);
      setWelcomeMsg(d.welcomeMessage || "");
      setChosenAnim(d.animation || "none");
      setChannelName(d.name || "");
      setChannelDesc(d.description || "");
      if (d.pinnedMessageId) {
        get(ref(db, `channelMessages/${channelId}/${d.pinnedMessageId}`)).then(ps => {
          if (ps.exists()) setPinnedMsg({ id: d.pinnedMessageId, ...ps.val() });
        });
      } else {
        setPinnedMsg(null);
      }
    });
    const u2 = onValue(ref(db, `channelMessages/${channelId}`), s => {
      if (!s.exists()) { setMessages([]); return; }
      const list: ChMsg[] = [];
      s.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => a.ts - b.ts);
      setMessages(list);
      setTimeout(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, 50);
    });
    const u3 = onValue(ref(db, "status"), s => {
      const online = new Set<string>();
      s.forEach(c => { if (c.val()?.state === "online") online.add(c.key!); });
      setOnlineMembers(online);
    });
    return () => { u1(); u2(); u3(); };
  }, [channelId, onBack]);

  async function sendMessage() {
    if (!input.trim() || !canWrite) return;
    await push(ref(db, `channelMessages/${channelId}`), {
      from: username, text: input.trim(), ts: Date.now(),
      animation: channel?.animation || "none",
    });
    setInput("");
    inputRef.current?.focus();
  }

  async function react(msgId: string, emoji: string) {
    const msgRef = ref(db, `channelMessages/${channelId}/${msgId}/reactions/${emoji}`);
    const snap = await get(msgRef);
    const list: string[] = snap.val() || [];
    if (list.includes(username)) {
      const next = list.filter(u => u !== username);
      if (next.length === 0) await remove(msgRef);
      else await set(msgRef, next);
    } else {
      await set(msgRef, [...list, username]);
    }
    setReactionMsgId(null);
  }

  async function pinMessage(msg: ChMsg) {
    if (!isAdmin) return;
    await update(ref(db, `channels/${channelId}`), { pinnedMessageId: msg.id });
    setPinnedMsg(msg);
    showToast("📌 Xabar pin qilindi");
  }

  async function unpinMessage() {
    if (!isAdmin) return;
    await update(ref(db, `channels/${channelId}`), { pinnedMessageId: null });
    setPinnedMsg(null);
    showToast("✅ Pin olib tashlandi");
  }

  async function deleteMessage(msgId: string) {
    if (!isAdmin) return;
    await remove(ref(db, `channelMessages/${channelId}/${msgId}`));
  }

  async function kickMember(member: string) {
    if (!isAdmin || member === username || member === channel?.owner) return;
    if (!confirm(`@${member} ni chiqarasizmi?`)) return;
    await remove(ref(db, `channels/${channelId}/members/${member}`));
    showToast(`⚡ @${member} chiqarildi`);
  }

  async function promoteMember(member: string) {
    if (!isOwner || member === username) return;
    const current = channel?.members?.[member];
    const newRole = current === "admin" ? "member" : "admin";
    await set(ref(db, `channels/${channelId}/members/${member}`), newRole);
    showToast(newRole === "admin" ? `⭐ @${member} admin bo'ldi` : `↓ @${member} oddiy a'zo`);
  }

  async function leaveChannel() {
    if (!confirm("Kanaldan chiqasizmi?")) return;
    await remove(ref(db, `channels/${channelId}/members/${username}`));
    onBack();
  }

  async function deleteChannel() {
    if (!isOwner) return;
    if (!confirm("Kanal butunlay o'chirilsinmi?")) return;
    await remove(ref(db, `channels/${channelId}`));
    await remove(ref(db, `channelMessages/${channelId}`));
    onBack();
  }

  async function saveSettings() {
    if (!isAdmin) return;
    setSaving(true);
    await update(ref(db, `channels/${channelId}`), {
      name: channelName.trim() || channel.name,
      description: channelDesc.trim(),
      welcomeMessage: welcomeMsg,
      animation: chosenAnim,
    });
    setSaving(false);
    showToast("✅ Saqlandi");
  }

  async function saveAnimation(animId: string) {
    const anim = ANIMATIONS.find(a => a.id === animId);
    if (anim?.premium && !isPremium) { showToast("🔒 Premium kerak!"); return; }
    setChosenAnim(animId);
    await update(ref(db, `channels/${channelId}`), { animation: animId });
  }

  const filteredMessages = searchQuery.trim()
    ? messages.filter(m => m.text.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  if (!channel) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="w-8 h-8 border-2 rounded-full animate-spin" style={{ borderColor: accentColor, borderTopColor: "transparent" }} />
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm font-medium shadow-xl animate-[scale-in_0.2s]">
          {toast}
        </div>
      )}

      {/* Header */}
      <header className="flex-shrink-0 px-3 py-2.5 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90" style={{ backdropFilter: "blur(12px)" }}>
        <button onClick={onBack} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-white transition text-lg">←</button>
        <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg flex-shrink-0"
          style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}>
          {channel.type === "channel" ? "📡" : "👥"}
        </div>
        <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setTab("settings")}>
          <div className="flex items-center gap-1.5">
            <p className="font-bold text-sm text-white truncate">{channel.name}</p>
            {channel.isPrivate && <span className="text-xs">🔐</span>}
            {channel.type === "channel"
              ? <span className="text-[9px] font-bold text-cyan-400 bg-cyan-950/40 px-1.5 py-0.5 rounded border border-cyan-900/40">KANAL</span>
              : <span className="text-[9px] font-bold text-purple-400 bg-purple-950/40 px-1.5 py-0.5 rounded border border-purple-900/40">GURUH</span>}
          </div>
          <p className="text-[10px] text-slate-500">
            {memberCount} a'zo
            {onlineMemberCount > 0 && <span className="text-green-400"> · {onlineMemberCount} 🟢</span>}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setShowSearch(!showSearch)}
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${showSearch ? "bg-slate-700 text-white" : "hover:bg-slate-800 text-slate-400"}`}>🔍</button>
          <button onClick={() => setTab("members")}
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${tab === "members" ? "bg-slate-700 text-white" : "hover:bg-slate-800 text-slate-400"}`}>👥</button>
          <button onClick={() => setTab("settings")}
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${tab === "settings" ? "bg-slate-700 text-white" : "hover:bg-slate-800 text-slate-400"}`}>⚙️</button>
        </div>
      </header>

      {/* Tab bar */}
      <div className="flex border-b border-slate-800/60 flex-shrink-0 bg-[#030712]/60">
        {(["messages", "members", "settings"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2 text-xs font-bold transition border-b-2 ${tab === t ? "border-current" : "border-transparent text-slate-500 hover:text-slate-300"}`}
            style={tab === t ? { color: accentColor } : undefined}>
            {t === "messages" ? "💬 Xabarlar" : t === "members" ? `👥 (${memberCount})` : "⚙️ Sozlamalar"}
          </button>
        ))}
      </div>

      {/* Search bar */}
      {showSearch && tab === "messages" && (
        <div className="px-3 py-2 border-b border-slate-800/60 bg-slate-900/60 flex-shrink-0">
          <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            placeholder="🔍 Xabarlarni qidirish..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-slate-500 transition" />
        </div>
      )}

      {/* Pinned message banner */}
      {pinnedMsg && tab === "messages" && (
        <div className="px-3 py-2 border-b border-amber-900/30 bg-amber-950/10 flex items-center gap-2 flex-shrink-0">
          <span className="text-amber-400 text-sm flex-shrink-0">📌</span>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] text-amber-500 font-bold uppercase">Pinlangan</p>
            <p className="text-xs text-slate-300 truncate">{pinnedMsg.text}</p>
          </div>
          {isAdmin && <button onClick={unpinMessage} className="text-[10px] text-slate-600 hover:text-slate-300 flex-shrink-0 px-2">✕</button>}
        </div>
      )}

      {/* ── MESSAGES TAB ── */}
      {tab === "messages" && (
        <>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2">
            {channel.welcomeMessage && messages.length === 0 && (
              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
                <p className="text-3xl mb-2">👋</p>
                <p className="text-sm text-slate-300 leading-relaxed">{channel.welcomeMessage}</p>
              </div>
            )}
            {filteredMessages.length === 0 && !channel.welcomeMessage && (
              <div className="flex flex-col items-center justify-center py-20 text-slate-700">
                <p className="text-5xl mb-3">{channel.type === "channel" ? "📡" : "💬"}</p>
                <p className="text-sm font-mono">{searchQuery ? "Xabar topilmadi" : "Hali xabar yo'q"}</p>
              </div>
            )}
            {filteredMessages.map(m => {
              const isMe = m.from === username;
              const animClass = m.animation === "fade" ? "animate-[fade-in_0.4s]"
                : m.animation === "slide" ? "animate-[slide-in-right_0.4s]"
                : m.animation === "bounce" ? "animate-[scale-in_0.3s_cubic-bezier(0.34,1.56,0.64,1)]"
                : m.animation === "sparkle" ? "ring-2 ring-amber-400/40 shadow-[0_0_16px_rgba(245,158,11,0.3)]"
                : m.animation === "neon" ? "ring-1 ring-cyan-400/50 shadow-[0_0_12px_rgba(34,211,238,0.3)]"
                : "";
              return (
                <div key={m.id} className="group">
                  <div className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                    <div className="max-w-[80%]">
                      {!isMe && (
                        <button onClick={() => onOpenProfile(m.from)}
                          className="text-[10px] font-bold mb-0.5 ml-1 hover:underline" style={{ color: accentColor }}>
                          @{m.from}
                        </button>
                      )}
                      <div className={`relative px-4 py-2.5 rounded-2xl ${isMe ? "rounded-tr-sm" : "bg-slate-800/80 border border-slate-700/40 rounded-tl-sm"} ${animClass}`}
                        style={isMe ? { background: `linear-gradient(135deg,${accentColor}30,${accentColor}20)`, border: `1px solid ${accentColor}40` } : undefined}>
                        <p className="text-sm text-white whitespace-pre-wrap break-words leading-relaxed">
                          {m.text.split(/(nexus:\/\/\S+)/g).map((part, idx) =>
                            part.startsWith("nexus://") ? (
                              <button key={idx} onClick={() => {
                                if (part.startsWith("nexus://join/")) {
                                  const channelId = part.replace("nexus://join/", "");
                                  window.dispatchEvent(new CustomEvent("nexus-navigate", { detail: { type: "channel", channelId } }));
                                } else if (part.startsWith("nexus://user/")) {
                                  const user = part.replace("nexus://user/", "");
                                  onOpenProfile(user);
                                }
                              }} className="text-cyan-400 underline hover:text-cyan-300 transition font-medium">{part}</button>
                            ) : part
                          )}
                        </p>
                        <p className="text-[9px] text-slate-500 font-mono text-right mt-1">
                          {new Date(m.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                        {/* Hover actions */}
                        <div className="absolute -top-8 right-0 hidden group-hover:flex items-center gap-1 bg-slate-800 border border-slate-700 rounded-xl px-2 py-1.5 shadow-xl z-10">
                          <button onClick={() => setReactionMsgId(reactionMsgId === m.id ? null : m.id)} title="Reaksiya" className="text-base hover:scale-125 transition">😊</button>
                          {isAdmin && <button onClick={() => pinMessage(m)} title="Pin" className="text-sm hover:scale-125 transition">📌</button>}
                          {isAdmin && <button onClick={() => deleteMessage(m.id)} title="O'chirish" className="text-sm hover:scale-125 transition text-rose-400">🗑️</button>}
                        </div>
                      </div>
                      {/* Reactions display */}
                      {m.reactions && Object.keys(m.reactions).length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {Object.entries(m.reactions).map(([emoji, users]) => (
                            <button key={emoji} onClick={() => react(m.id, emoji)}
                              className={`text-[11px] px-2 py-0.5 rounded-full border transition ${(users as string[]).includes(username) ? "bg-cyan-950/60 border-cyan-700 text-cyan-300" : "bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-500"}`}>
                              {emoji} {(users as string[]).length}
                            </button>
                          ))}
                        </div>
                      )}
                      {/* Reaction picker */}
                      {reactionMsgId === m.id && (
                        <div className="flex gap-1.5 mt-1 p-2 bg-slate-900 border border-slate-700 rounded-xl w-fit animate-[scale-in_0.15s] shadow-xl">
                          {REACTION_EMOJIS.map(e => (
                            <button key={e} onClick={() => react(m.id, e)} className="text-lg hover:scale-125 transition">{e}</button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {canWrite ? (
            <footer className="flex-shrink-0 px-3 py-2.5 border-t border-slate-800/60 bg-[#030712] flex items-end gap-2">
              <textarea ref={inputRef} value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                placeholder="Xabar yozing..."
                rows={1}
                className="flex-1 bg-slate-900/80 border border-slate-700/60 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-slate-500 resize-none transition"
                style={{ maxHeight: "120px" }} />
              <button onClick={sendMessage} disabled={!input.trim()}
                className="w-10 h-10 rounded-xl flex items-center justify-center disabled:opacity-30 transition active:scale-95 flex-shrink-0"
                style={input.trim() ? { background: accentColor } : { background: "#1e293b" }}>
                ➤
              </button>
            </footer>
          ) : (
            <footer className="flex-shrink-0 p-4 border-t border-slate-900 text-center text-[11px] text-amber-500/60 bg-slate-950/80">
              📡 FAQAT ADMIN XABAR YOZA OLADI
            </footer>
          )}
        </>
      )}

      {/* ── MEMBERS TAB ── */}
      {tab === "members" && (
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          <p className="text-[10px] font-bold text-slate-500 uppercase px-1 mb-2">
            {memberCount} a'zo · <span className="text-green-400">{onlineMemberCount} onlayn</span>
          </p>
          {membersList.map(([member, role]) => {
            const isOnline = onlineMembers.has(member);
            const isMe = member === username;
            const isChannelOwner = channel?.owner === member;
            return (
              <div key={member}
                className={`flex items-center gap-3 p-3 rounded-xl border transition ${isMe ? "bg-cyan-950/10 border-cyan-900/30" : "bg-slate-900/60 border-slate-800 hover:border-slate-700"}`}>
                <div className="relative flex-shrink-0">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm"
                    style={{ background: `linear-gradient(135deg,${accentColor}44,#4f46e5)` }}>
                    {member[0]?.toUpperCase()}
                  </div>
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#030712] ${isOnline ? "bg-green-400" : "bg-slate-600"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button onClick={() => onOpenProfile(member)} className="text-sm font-bold text-slate-200 hover:text-white">@{member}</button>
                    {isChannelOwner && <span className="text-[9px] bg-amber-900/40 text-amber-400 px-1.5 py-0.5 rounded font-bold">OWNER</span>}
                    {!isChannelOwner && role === "admin" && <span className="text-[9px] bg-blue-900/40 text-blue-400 px-1.5 py-0.5 rounded font-bold">ADMIN</span>}
                    {isMe && <span className="text-[9px] text-cyan-400 font-bold">(Men)</span>}
                  </div>
                  <p className="text-[10px] font-mono" style={{ color: isOnline ? "#4ade80" : "#475569" }}>
                    {isOnline ? "🟢 Onlayn" : "⚫ Oflayn"}
                  </p>
                </div>
                {isAdmin && !isMe && !isChannelOwner && (
                  <div className="flex gap-1.5">
                    {isOwner && (
                      <button onClick={() => promoteMember(member)}
                        className={`text-[9px] px-2 py-1.5 rounded-lg font-bold transition ${role === "admin" ? "bg-slate-800 border border-slate-700 text-slate-400 hover:bg-slate-700" : "bg-amber-950/30 border border-amber-900/50 text-amber-400 hover:bg-amber-950/50"}`}>
                        {role === "admin" ? "↓ Tushir" : "⭐ Admin"}
                      </button>
                    )}
                    <button onClick={() => kickMember(member)}
                      className="text-[9px] px-2 py-1.5 rounded-lg bg-rose-950/30 border border-rose-900/50 text-rose-400 font-bold hover:bg-rose-950/50 transition">
                      ⚡ Chiqar
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── SETTINGS TAB ── */}
      {tab === "settings" && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Channel info */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}>
                {channel.type === "channel" ? "📡" : "👥"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white">{channel.name}</p>
                <p className="text-xs text-slate-500 font-mono">@{channelId}</p>
                {channel.description && <p className="text-xs text-slate-400 mt-0.5 italic truncate">"{channel.description}"</p>}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "A'zolar", val: memberCount, c: accentColor },
                { label: "Onlayn", val: onlineMemberCount, c: "#4ade80" },
                { label: "Xabarlar", val: messages.length, c: "#a855f7" },
              ].map(s => (
                <div key={s.label} className="p-2 rounded-xl bg-slate-950/60 text-center">
                  <p className="text-lg font-black" style={{ color: s.c }}>{s.val}</p>
                  <p className="text-[9px] text-slate-500">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Invite link */}
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <p className="text-xs font-bold text-slate-400 uppercase">🔗 Taklif havolasi</p>
            <div className="flex gap-2">
              <input readOnly value={`nexus://join/${channelId}`}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-400 outline-none font-mono" />
              <button onClick={() => { navigator.clipboard?.writeText(`nexus://join/${channelId}`); showToast("✅ Nusxalandi!"); }}
                className="px-3 py-2 rounded-xl text-xs font-bold text-white transition active:scale-95" style={{ background: accentColor }}>
                Nusxa
              </button>
            </div>
          </div>

          {/* Admin settings */}
          {isAdmin && (
            <>
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                <p className="text-xs font-bold text-slate-400 uppercase">✏️ Tahrirlash</p>
                <input value={channelName} onChange={e => setChannelName(e.target.value)} maxLength={50}
                  placeholder="Kanal nomi"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-500 transition" />
                <textarea value={channelDesc} onChange={e => setChannelDesc(e.target.value)} rows={2} maxLength={200}
                  placeholder="Tavsif..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-500 transition resize-none" />
              </div>

              <div className={`p-4 rounded-2xl border space-y-2 ${isPremium ? "bg-amber-950/10 border-amber-800/40" : "bg-slate-900/60 border-slate-800 opacity-60"}`}>
                <p className="text-xs font-bold text-slate-400 uppercase flex items-center gap-2">
                  🤖 Xush kelibsiz xabari {!isPremium && <span className="text-amber-400">👑 Premium</span>}
                </p>
                <textarea value={welcomeMsg} onChange={e => setWelcomeMsg(e.target.value)} disabled={!isPremium}
                  placeholder="Yangi a'zolarga ko'rinadigan xabar..." rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none resize-none" />
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <p className="text-xs font-bold text-slate-400 uppercase">🎨 Xabar animatsiyasi</p>
                <div className="grid grid-cols-3 gap-2">
                  {ANIMATIONS.map(a => (
                    <button key={a.id} onClick={() => saveAnimation(a.id)}
                      className={`p-2.5 rounded-xl text-xs border transition ${chosenAnim === a.id ? "border-cyan-500 bg-cyan-950/30 text-cyan-300" : "border-slate-700 bg-slate-800 text-slate-300 hover:border-slate-600"} ${a.premium && !isPremium ? "opacity-60" : ""}`}>
                      {a.label}{a.premium && !isPremium && " 👑"}
                    </button>
                  ))}
                </div>
              </div>

              <button onClick={saveSettings} disabled={saving}
                className="w-full py-3 rounded-xl font-bold text-sm text-white transition disabled:opacity-50 active:scale-95"
                style={{ background: accentColor }}>
                {saving ? "⏳ Saqlanmoqda..." : "💾 O'zgarishlarni saqlash"}
              </button>
            </>
          )}

          <div className="pt-1">
            {isOwner ? (
              <button onClick={deleteChannel} className="w-full py-3 rounded-xl font-bold text-sm border border-rose-900/60 text-rose-400 hover:bg-rose-950/40 transition">
                🗑️ Kanal/guruhni o'chirish
              </button>
            ) : (
              <button onClick={leaveChannel} className="w-full py-3 rounded-xl font-bold text-sm border border-rose-900/60 text-rose-400 hover:bg-rose-950/40 transition">
                🚪 Kanaldan chiqish
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
