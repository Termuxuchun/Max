import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight, RotateCcw, Check, X, Zap, Trophy, BookOpen, Languages, Star, Brain, Target, Volume2 } from "lucide-react";

type Lang = "uz" | "ru" | "en";

interface Flashcard {
  id: string;
  uz: string;
  ru: string;
  en: string;
  category: string;
  level: "beginner" | "intermediate" | "advanced";
  example?: string;
}

interface Props { username: string; accentColor: string; }

const CARDS: Flashcard[] = [
  // Greetings
  { id: "g1", uz: "Salom", ru: "Привет", en: "Hello", category: "Salomlashish", level: "beginner", example: "Salom, qandaysiz? — Hello, how are you?" },
  { id: "g2", uz: "Xayr", ru: "Пока", en: "Goodbye", category: "Salomlashish", level: "beginner" },
  { id: "g3", uz: "Rahmat", ru: "Спасибо", en: "Thank you", category: "Salomlashish", level: "beginner" },
  { id: "g4", uz: "Iltimos", ru: "Пожалуйста", en: "Please", category: "Salomlashish", level: "beginner" },
  { id: "g5", uz: "Kechirasiz", ru: "Извините", en: "Excuse me", category: "Salomlashish", level: "beginner" },
  { id: "g6", uz: "Assalomu alaykum", ru: "Мир вам", en: "Peace be upon you", category: "Salomlashish", level: "beginner" },

  // Numbers
  { id: "n1", uz: "Bir", ru: "Один", en: "One", category: "Raqamlar", level: "beginner" },
  { id: "n2", uz: "Ikki", ru: "Два", en: "Two", category: "Raqamlar", level: "beginner" },
  { id: "n3", uz: "Uch", ru: "Три", en: "Three", category: "Raqamlar", level: "beginner" },
  { id: "n4", uz: "To'rt", ru: "Четыре", en: "Four", category: "Raqamlar", level: "beginner" },
  { id: "n5", uz: "Besh", ru: "Пять", en: "Five", category: "Raqamlar", level: "beginner" },
  { id: "n6", uz: "O'n", ru: "Десять", en: "Ten", category: "Raqamlar", level: "beginner" },
  { id: "n7", uz: "Yuz", ru: "Сто", en: "Hundred", category: "Raqamlar", level: "beginner" },

  // Family
  { id: "f1", uz: "Oila", ru: "Семья", en: "Family", category: "Oila", level: "beginner" },
  { id: "f2", uz: "Ona", ru: "Мама", en: "Mother", category: "Oila", level: "beginner" },
  { id: "f3", uz: "Ota", ru: "Папа", en: "Father", category: "Oila", level: "beginner" },
  { id: "f4", uz: "Aka/Uka", ru: "Брат", en: "Brother", category: "Oila", level: "beginner" },
  { id: "f5", uz: "Singil/Opa", ru: "Сестра", en: "Sister", category: "Oila", level: "beginner" },
  { id: "f6", uz: "Bola", ru: "Ребёнок", en: "Child", category: "Oila", level: "beginner" },

  // Food
  { id: "fo1", uz: "Non", ru: "Хлеб", en: "Bread", category: "Taom", level: "beginner" },
  { id: "fo2", uz: "Suv", ru: "Вода", en: "Water", category: "Taom", level: "beginner" },
  { id: "fo3", uz: "Osh", ru: "Плов", en: "Pilaf", category: "Taom", level: "beginner" },
  { id: "fo4", uz: "Samsa", ru: "Самса", en: "Samsa", category: "Taom", level: "beginner" },
  { id: "fo5", uz: "Go'sht", ru: "Мясо", en: "Meat", category: "Taom", level: "beginner" },
  { id: "fo6", uz: "Meva", ru: "Фрукт", en: "Fruit", category: "Taom", level: "beginner" },

  // Technology
  { id: "t1", uz: "Telefon", ru: "Телефон", en: "Phone", category: "Texnologiya", level: "intermediate" },
  { id: "t2", uz: "Kompyuter", ru: "Компьютер", en: "Computer", category: "Texnologiya", level: "intermediate" },
  { id: "t3", uz: "Internet", ru: "Интернет", en: "Internet", category: "Texnologiya", level: "intermediate" },
  { id: "t4", uz: "Dastur", ru: "Программа", en: "Software", category: "Texnologiya", level: "intermediate" },
  { id: "t5", uz: "Ilova", ru: "Приложение", en: "Application", category: "Texnologiya", level: "intermediate" },

  // Business
  { id: "b1", uz: "Ish", ru: "Работа", en: "Work", category: "Biznes", level: "intermediate" },
  { id: "b2", uz: "Pul", ru: "Деньги", en: "Money", category: "Biznes", level: "intermediate" },
  { id: "b3", uz: "Bank", ru: "Банк", en: "Bank", category: "Biznes", level: "intermediate" },
  { id: "b4", uz: "Shartnoma", ru: "Договор", en: "Contract", category: "Biznes", level: "advanced" },
  { id: "b5", uz: "Savdo", ru: "Торговля", en: "Trade", category: "Biznes", level: "advanced" },

  // Nature
  { id: "na1", uz: "Quyosh", ru: "Солнце", en: "Sun", category: "Tabiat", level: "beginner" },
  { id: "na2", uz: "Oy", ru: "Луна", en: "Moon", category: "Tabiat", level: "beginner" },
  { id: "na3", uz: "Yulduz", ru: "Звезда", en: "Star", category: "Tabiat", level: "beginner" },
  { id: "na4", uz: "Daryo", ru: "Река", en: "River", category: "Tabiat", level: "beginner" },
  { id: "na5", uz: "Tog'", ru: "Гора", en: "Mountain", category: "Tabiat", level: "beginner" },

  // Verbs
  { id: "v1", uz: "Yurmoq", ru: "Идти", en: "To walk", category: "Fe'llar", level: "intermediate" },
  { id: "v2", uz: "O'qimoq", ru: "Читать", en: "To read", category: "Fe'llar", level: "intermediate" },
  { id: "v3", uz: "Yozmoq", ru: "Писать", en: "To write", category: "Fe'llar", level: "intermediate" },
  { id: "v4", uz: "Gapirmoq", ru: "Говорить", en: "To speak", category: "Fe'llar", level: "intermediate" },
  { id: "v5", uz: "Sevmoq", ru: "Любить", en: "To love", category: "Fe'llar", level: "intermediate" },
  { id: "v6", uz: "O'rganmoq", ru: "Учиться", en: "To learn", category: "Fe'llar", level: "intermediate" },

  // Colors
  { id: "c1", uz: "Qizil", ru: "Красный", en: "Red", category: "Ranglar", level: "beginner" },
  { id: "c2", uz: "Ko'k", ru: "Синий", en: "Blue", category: "Ranglar", level: "beginner" },
  { id: "c3", uz: "Yashil", ru: "Зелёный", en: "Green", category: "Ranglar", level: "beginner" },
  { id: "c4", uz: "Sariq", ru: "Жёлтый", en: "Yellow", category: "Ranglar", level: "beginner" },
  { id: "c5", uz: "Oq", ru: "Белый", en: "White", category: "Ranglar", level: "beginner" },
  { id: "c6", uz: "Qora", ru: "Чёрный", en: "Black", category: "Ranglar", level: "beginner" },
];

const CATEGORIES = ["Barchasi", ...Array.from(new Set(CARDS.map(c => c.category)))];
const LEVELS = ["Barchasi", "beginner", "intermediate", "advanced"];
const LEVEL_LABELS: Record<string, string> = { beginner: "Boshlang'ich", intermediate: "O'rtacha", advanced: "Ilg'or" };

export default function FlashcardSection({ username, accentColor }: Props) {
  const [targetLang, setTargetLang] = useState<Lang>("en");
  const [sourceLang, setSourceLang] = useState<Lang>("uz");
  const [category, setCategory] = useState("Barchasi");
  const [level, setLevel] = useState("Barchasi");
  const [deck, setDeck] = useState<Flashcard[]>([]);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [mode, setMode] = useState<"study" | "quiz" | "stats">("study");
  const [correct, setCorrect] = useState(0);
  const [incorrect, setIncorrect] = useState(0);
  const [sessionCards, setSessionCards] = useState(0);
  const [learned, setLearned] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(`nexus_fc_learned_${username}`) || "[]"); } catch { return []; }
  });
  const [streak, setStreak] = useState(() => parseInt(localStorage.getItem(`nexus_fc_streak_${username}`) || "0"));
  const [quizOptions, setQuizOptions] = useState<string[]>([]);
  const [quizAnswer, setQuizAnswer] = useState<string | null>(null);
  const [quizResult, setQuizResult] = useState<boolean | null>(null);

  const buildDeck = useCallback(() => {
    let cards = CARDS;
    if (category !== "Barchasi") cards = cards.filter(c => c.category === category);
    if (level !== "Barchasi") cards = cards.filter(c => c.level === level);
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setDeck(shuffled);
    setIndex(0);
    setFlipped(false);
    setQuizAnswer(null);
    setQuizResult(null);
  }, [category, level]);

  useEffect(() => { buildDeck(); }, [buildDeck]);

  useEffect(() => {
    if (mode === "quiz" && deck[index]) {
      const correct = deck[index][targetLang];
      const wrong = CARDS
        .filter(c => c.id !== deck[index].id)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)
        .map(c => c[targetLang]);
      const opts = [...wrong, correct].sort(() => Math.random() - 0.5);
      setQuizOptions(opts);
      setQuizAnswer(null);
      setQuizResult(null);
    }
  }, [index, mode, deck, targetLang]);

  const card = deck[index];

  function goNext() {
    setFlipped(false);
    setQuizAnswer(null);
    setQuizResult(null);
    setIndex(i => Math.min(i + 1, deck.length - 1));
  }
  function goPrev() {
    setFlipped(false);
    setQuizAnswer(null);
    setQuizResult(null);
    setIndex(i => Math.max(i - 1, 0));
  }

  function markLearned() {
    if (!card) return;
    const next = learned.includes(card.id) ? learned.filter(id => id !== card.id) : [...learned, card.id];
    setLearned(next);
    localStorage.setItem(`nexus_fc_learned_${username}`, JSON.stringify(next));
    setCorrect(c => c + 1);
    setSessionCards(s => s + 1);
    const newStreak = streak + 1;
    setStreak(newStreak);
    localStorage.setItem(`nexus_fc_streak_${username}`, String(newStreak));
    goNext();
  }

  function markSkip() {
    setIncorrect(i => i + 1);
    setSessionCards(s => s + 1);
    goNext();
  }

  function answerQuiz(option: string) {
    if (quizAnswer) return;
    const isCorrect = option === card[targetLang];
    setQuizAnswer(option);
    setQuizResult(isCorrect);
    if (isCorrect) {
      setCorrect(c => c + 1);
      setStreak(s => { const n = s + 1; localStorage.setItem(`nexus_fc_streak_${username}`, String(n)); return n; });
    } else {
      setIncorrect(i => i + 1);
    }
    setSessionCards(s => s + 1);
    setTimeout(goNext, 1200);
  }

  function speak(text: string, lang: Lang) {
    if ("speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang === "uz" ? "uz-UZ" : lang === "ru" ? "ru-RU" : "en-US";
      window.speechSynthesis.speak(u);
    }
  }

  const langLabel: Record<Lang, string> = { uz: "O'zbek 🇺🇿", ru: "Rus 🇷🇺", en: "Ingliz 🇬🇧" };
  const total = learned.length;
  const progress = deck.length > 0 ? ((index + 1) / deck.length) * 100 : 0;
  const accuracy = sessionCards > 0 ? Math.round((correct / sessionCards) * 100) : 0;

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      {/* Header */}
      <div className="flex-shrink-0 px-4 py-3 border-b border-slate-800/60 flex items-center justify-between"
        style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(12px)" }}>
        <div className="flex items-center gap-3">
          <div className="text-2xl">🧠</div>
          <div>
            <p className="text-sm font-bold text-white">Til O'rganish</p>
            <p className="text-[10px] text-slate-500">{CARDS.length} so'z · {total} o'rganildi · 🔥 {streak} seriya</p>
          </div>
        </div>
        <div className="flex gap-1">
          {[
            { id: "study", label: "📖" },
            { id: "quiz",  label: "🎯" },
            { id: "stats", label: "📊" },
          ].map(m => (
            <button key={m.id} onClick={() => setMode(m.id as any)}
              className="p-2 rounded-xl text-base transition"
              style={{ background: mode === m.id ? accentColor + "22" : "transparent" }}>
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="flex-shrink-0 px-4 py-2.5 border-b border-slate-800/40 space-y-2">
        {/* Lang selector */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 flex-shrink-0">Manba → Maqsad:</span>
          <div className="flex gap-1 flex-1 overflow-x-auto scrollbar-none">
            {(["uz", "ru", "en"] as Lang[]).map(l => (
              <button key={l} onClick={() => setSourceLang(l)}
                className={`flex-shrink-0 px-2 py-1 rounded-lg text-[10px] font-bold transition ${sourceLang === l ? "text-white" : "text-slate-500"}`}
                style={{ background: sourceLang === l ? accentColor + "33" : "rgba(30,41,59,0.4)" }}>
                {langLabel[l]}
              </button>
            ))}
            <span className="text-slate-600 self-center">→</span>
            {(["uz", "ru", "en"] as Lang[]).map(l => (
              <button key={l} onClick={() => setTargetLang(l)}
                className={`flex-shrink-0 px-2 py-1 rounded-lg text-[10px] font-bold transition ${targetLang === l ? "text-white" : "text-slate-500"}`}
                style={{ background: targetLang === l ? "#4f46e533" : "rgba(30,41,59,0.4)", color: targetLang === l ? "#a5b4fc" : undefined }}>
                {langLabel[l]}
              </button>
            ))}
          </div>
        </div>
        {/* Category + Level */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none">
          {CATEGORIES.slice(0, 6).map(cat => (
            <button key={cat} onClick={() => setCategory(cat)}
              className="flex-shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-medium transition"
              style={{ background: category === cat ? accentColor + "22" : "rgba(30,41,59,0.4)", color: category === cat ? accentColor : "#64748b" }}>
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Mode */}
      {mode === "stats" && (
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "O'rganilgan so'zlar", val: total, icon: "📚", color: "#4ade80" },
              { label: "Bugungi seriya", val: streak, icon: "🔥", color: "#f97316" },
              { label: "Sessiya aniqligi", val: `${accuracy}%`, icon: "🎯", color: accentColor },
              { label: "Umumiy so'zlar", val: CARDS.length, icon: "📖", color: "#a78bfa" },
            ].map((s, i) => (
              <div key={i} className="p-4 rounded-2xl border border-slate-800/60" style={{ background: "rgba(15,23,42,0.8)" }}>
                <div className="text-2xl mb-2">{s.icon}</div>
                <p className="text-2xl font-black" style={{ color: s.color }}>{s.val}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="p-4 rounded-2xl border border-slate-800/60" style={{ background: "rgba(15,23,42,0.6)" }}>
            <p className="text-xs font-bold text-slate-400 mb-3">Kategoriyalar bo'yicha</p>
            {Array.from(new Set(CARDS.map(c => c.category))).map(cat => {
              const catCards = CARDS.filter(c => c.category === cat);
              const catLearned = catCards.filter(c => learned.includes(c.id));
              const pct = Math.round((catLearned.length / catCards.length) * 100);
              return (
                <div key={cat} className="mb-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">{cat}</span>
                    <span className="text-slate-500">{catLearned.length}/{catCards.length}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: accentColor }} />
                  </div>
                </div>
              );
            })}
          </div>
          <button onClick={() => { setLearned([]); localStorage.removeItem(`nexus_fc_learned_${username}`); setStreak(0); localStorage.removeItem(`nexus_fc_streak_${username}`); }}
            className="w-full py-2.5 rounded-xl text-xs font-bold border border-rose-800/40 text-rose-500 hover:bg-rose-950/30 transition">
            🗑️ Progressni tozalash
          </button>
        </div>
      )}

      {/* Study / Quiz mode */}
      {mode !== "stats" && (
        <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-4">
          {/* Progress */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-300" style={{ width: `${progress}%`, background: accentColor }} />
            </div>
            <span className="text-[10px] text-slate-500 flex-shrink-0">{index + 1}/{deck.length}</span>
          </div>

          {!card ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-4">
              <div className="text-5xl">🎉</div>
              <p className="text-white font-bold">Barcha kartlar ko'rib chiqildi!</p>
              <button onClick={buildDeck} className="px-6 py-2.5 rounded-xl font-bold text-white transition" style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}>
                Qayta boshlash
              </button>
            </div>
          ) : mode === "study" ? (
            <>
              {/* Flashcard */}
              <div onClick={() => setFlipped(f => !f)} className="relative cursor-pointer select-none"
                style={{ perspective: "1000px" }}>
                <div className="w-full rounded-3xl p-8 min-h-[200px] flex flex-col items-center justify-center text-center transition-all duration-500 border"
                  style={{
                    background: flipped
                      ? "linear-gradient(135deg,rgba(79,70,229,0.2),rgba(6,182,212,0.1))"
                      : "linear-gradient(135deg,rgba(30,41,59,0.8),rgba(15,23,42,0.9))",
                    borderColor: flipped ? accentColor + "44" : "rgba(51,65,85,0.5)"
                  }}>
                  {!flipped ? (
                    <>
                      <p className="text-[10px] text-slate-500 mb-3 uppercase tracking-widest">{card.category} · {LEVEL_LABELS[card.level]}</p>
                      <p className="text-4xl font-black text-white mb-3">{card[sourceLang]}</p>
                      <button onClick={e => { e.stopPropagation(); speak(card[sourceLang], sourceLang); }}
                        className="text-slate-500 hover:text-slate-300 transition">
                        <Volume2 className="w-4 h-4" />
                      </button>
                      <p className="text-xs text-slate-600 mt-4">Karta uchun bosing</p>
                    </>
                  ) : (
                    <>
                      <p className="text-[10px] mb-3 uppercase tracking-widest" style={{ color: accentColor }}>Tarjima</p>
                      <p className="text-4xl font-black text-white mb-2">{card[targetLang]}</p>
                      <button onClick={e => { e.stopPropagation(); speak(card[targetLang], targetLang); }}
                        className="text-slate-500 hover:text-slate-300 transition mb-2">
                        <Volume2 className="w-4 h-4" />
                      </button>
                      {card.example && <p className="text-xs text-slate-500 mt-2 italic">"{card.example}"</p>}
                    </>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <button onClick={goPrev} disabled={index === 0} className="p-3 rounded-2xl bg-slate-800/60 text-slate-400 hover:text-white disabled:opacity-30 transition">
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button onClick={markSkip} className="flex-1 py-3 rounded-2xl font-bold text-sm border border-rose-800/40 text-rose-400 hover:bg-rose-950/30 transition flex items-center justify-center gap-2">
                  <X className="w-4 h-4" /> O'tkazib yuborish
                </button>
                <button onClick={markLearned} className="flex-1 py-3 rounded-2xl font-bold text-sm text-white transition flex items-center justify-center gap-2"
                  style={{ background: `linear-gradient(135deg,#16a34a,#15803d)` }}>
                  <Check className="w-4 h-4" /> Bildim!
                </button>
                <button onClick={goNext} disabled={index === deck.length - 1} className="p-3 rounded-2xl bg-slate-800/60 text-slate-400 hover:text-white disabled:opacity-30 transition">
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </>
          ) : (
            /* Quiz mode */
            <>
              <div className="p-6 rounded-3xl border border-slate-700/60 text-center" style={{ background: "rgba(15,23,42,0.9)" }}>
                <p className="text-[10px] text-slate-500 mb-2 uppercase tracking-widest">{card.category}</p>
                <p className="text-3xl font-black text-white">{card[sourceLang]}</p>
                <p className="text-xs text-slate-600 mt-1">{langLabel[sourceLang]} → {langLabel[targetLang]}</p>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                {quizOptions.map((opt, i) => {
                  let style: React.CSSProperties = { background: "rgba(30,41,59,0.6)", borderColor: "rgba(51,65,85,0.4)" };
                  if (quizAnswer) {
                    if (opt === card[targetLang]) style = { background: "rgba(22,163,74,0.2)", borderColor: "#16a34a88" };
                    else if (opt === quizAnswer && quizResult === false) style = { background: "rgba(220,38,38,0.2)", borderColor: "#dc262688" };
                  }
                  return (
                    <button key={i} onClick={() => answerQuiz(opt)} disabled={!!quizAnswer}
                      className="w-full py-3.5 px-4 rounded-2xl text-sm font-medium text-left transition border"
                      style={style}>
                      <span className="text-slate-300 mr-2">{["A", "B", "C", "D"][i]})</span>
                      <span className="text-white font-bold">{opt}</span>
                    </button>
                  );
                })}
              </div>

              {quizResult !== null && (
                <div className={`py-3 px-4 rounded-2xl text-center font-bold text-sm ${quizResult ? "text-green-400 bg-green-950/30" : "text-red-400 bg-red-950/30"}`}>
                  {quizResult ? "✅ To'g'ri!" : `❌ Noto'g'ri! To'g'ri: ${card[targetLang]}`}
                </div>
              )}
            </>
          )}

          {/* Session stats */}
          {sessionCards > 0 && (
            <div className="flex items-center justify-center gap-6 py-2">
              <div className="flex items-center gap-1.5 text-green-400">
                <Check className="w-3.5 h-3.5" />
                <span className="text-xs font-bold">{correct}</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-500">
                <Target className="w-3.5 h-3.5" />
                <span className="text-xs font-bold">{accuracy}%</span>
              </div>
              <div className="flex items-center gap-1.5 text-rose-400">
                <X className="w-3.5 h-3.5" />
                <span className="text-xs font-bold">{incorrect}</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
