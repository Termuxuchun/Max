import { useEffect, useState, useMemo } from "react";
import { ref, onValue, get, set, remove, update, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import ShareModal from "../components/ShareModal";
import QRScannerModal from "../components/QRScannerModal";
import { Search, X, Plus, Scan, Users, Link2, Settings, Trash2, Crown, Lock, Radio, Send } from "lucide-react";

interface Props {
  username: string;
  accentColor: string;
  isPremium: boolean;
  onOpen: (channelId: string) => void;
}

interface Channel {
  id: string;
  type: "channel" | "group";
  name: string;
  description?: string;
  avatar?: string;
  owner: string;
  createdAt: number;
  members?: Record<string, "admin" | "member">;
  isPrivate?: boolean;
}

const GRAD_PAIRS: [string,string][] = [
  ["#22d3ee","#6366f1"],["#a855f7","#ec4899"],["#22c55e","#14b8a6"],
  ["#f59e0b","#ef4444"],["#38bdf8","#818cf8"],["#84cc16","#22c55e"],
  ["#f97316","#f43f5e"],["#8b5cf6","#6366f1"],
];

function chanGrad(id: string): [string,string] {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) & 0xffffffff;
  return GRAD_PAIRS[Math.abs(h) % GRAD_PAIRS.length];
}

type MainTab = "mine" | "discover";

export default function ChannelsSection({ username, accentColor, isPremium, onOpen }: Props) {
  const [channels,         setChannels]         = useState<Channel[]>([]);
  const [search,           setSearch]           = useState("");
  const [foundChannel,     setFoundChannel]     = useState<Channel | null>(null);
  const [searching,        setSearching]        = useState(false);
  const [showCreate,       setShowCreate]       = useState(false);
  const [shareChannel,     setShareChannel]     = useState<Channel | null>(null);
  const [memberListChan,   setMemberListChan]   = useState<Channel | null>(null);
  const [memberList,       setMemberList]       = useState<{ name: string; role: string }[]>([]);
  const [showScanner,      setShowScanner]      = useState(false);
  const [editChannel,      setEditChannel]      = useState<Channel | null>(null);
  const [editName,         setEditName]         = useState("");
  const [editDesc,         setEditDesc]         = useState("");
  const [inviteUsername,   setInviteUsername]   = useState("");
  const [mainTab,          setMainTab]          = useState<MainTab>("mine");
  const [typeFilter,       setTypeFilter]       = useState<"all" | "channel" | "group">("all");

  const [cType,     setCType]     = useState<"channel" | "group">("group");
  const [cUsername, setCUsername] = useState("");
  const [cName,     setCName]     = useState("");
  const [cDesc,     setCDesc]     = useState("");
  const [cPrivate,  setCPrivate]  = useState(false);
  const [creating,  setCreating]  = useState(false);

  useEffect(() => {
    return onValue(ref(db, "channels"), s => {
      if (!s.exists()) { setChannels([]); return; }
      const list: Channel[] = [];
      s.forEach(c => {
        const d = c.val();
        if (d.members?.[username]) list.push({ id: c.key!, ...d });
      });
      list.sort((a, b) => b.createdAt - a.createdAt);
      setChannels(list);
    });
  }, [username]);

  useEffect(() => {
    if (!search.trim()) { setFoundChannel(null); return; }
    setSearching(true);
    const id = search.trim().replace(/^@/, "").toLowerCase();
    get(ref(db, `channels/${id}`)).then(s => {
      setSearching(false);
      if (s.exists()) setFoundChannel({ id, ...s.val() });
      else setFoundChannel(null);
    });
  }, [search]);

  async function joinChannel(c: Channel) {
    await set(ref(db, `channels/${c.id}/members/${username}`), "member");
    setSearch(""); setFoundChannel(null);
    onOpen(c.id);
  }

  async function openMemberList(c: Channel) {
    setMemberListChan(c);
    const snap = await get(ref(db, `channels/${c.id}/members`));
    if (snap.exists()) {
      const list: { name: string; role: string }[] = [];
      snap.forEach((ch: any) => { list.push({ name: ch.key!, role: ch.val() }); });
      setMemberList(list.sort((a, b) => (a.role === "admin" ? -1 : 1)));
    }
  }

  async function kickMember(channelId: string, member: string) {
    if (!confirm(`@${member} guruhdan chiqarilsinmi?`)) return;
    await remove(ref(db, `channels/${channelId}/members/${member}`));
    setMemberList(prev => prev.filter(m => m.name !== member));
  }

  async function inviteMember(channelId: string) {
    const uname = inviteUsername.trim().replace(/^@/, "").toLowerCase();
    if (!uname) return;
    await set(ref(db, `channels/${channelId}/members/${uname}`), "member");
    setInviteUsername("");
    setMemberList(prev => [...prev, { name: uname, role: "member" }]);
  }

  async function saveEditChannel() {
    if (!editChannel) return;
    await update(ref(db, `channels/${editChannel.id}`), {
      name:        editName.trim() || editChannel.name,
      description: editDesc.trim(),
    });
    setEditChannel(null);
  }

  async function deleteChannel(c: Channel) {
    if (!confirm(`"${c.name}" o'chirilsinmi? Bu amalni qaytarib bo'lmaydi!`)) return;
    await remove(ref(db, `channels/${c.id}`));
    setMemberListChan(null);
  }

  function handleScanResult(text: string) {
    setShowScanner(false);
    if (text.startsWith("nexus://join/")) setSearch("@" + text.replace("nexus://join/", ""));
    else if (text.startsWith("nexus://user/")) alert(`Profil: ${text.replace("nexus://user/", "@")}`);
    else alert(`QR kod: ${text}`);
  }

  async function createChannel() {
    const myCount = channels.filter(c => c.owner === username).length;
    if (!isPremium && myCount >= 3) { alert("🔒 Tekin limit (3 ta) tugadi.\n👑 Premium — cheksiz!"); return; }
    const id = cUsername.trim().replace(/^@/, "").toLowerCase();
    if (!/^[a-z0-9_]{3,20}$/.test(id)) { alert("Username 3-20 belgi, faqat a-z, 0-9, _"); return; }
    if (!cName.trim()) { alert("Nom kerak!"); return; }
    setCreating(true);
    const existing = await get(ref(db, `channels/${id}`));
    if (existing.exists()) { alert("Bu username band!"); setCreating(false); return; }
    await set(ref(db, `channels/${id}`), {
      type: cType, name: cName.trim(), description: cDesc.trim(),
      owner: username, createdAt: Date.now(),
      members: { [username]: "admin" }, isPrivate: cPrivate && isPremium,
    });
    setCreating(false); setShowCreate(false);
    setCUsername(""); setCName(""); setCDesc(""); setCPrivate(false);
    onOpen(id);
  }

  const displayed = useMemo(() => {
    if (typeFilter === "all") return channels;
    return channels.filter(c => c.type === typeFilter);
  }, [channels, typeFilter]);

  const myChannelsCount  = channels.filter(c => c.type === "channel").length;
  const myGroupsCount    = channels.filter(c => c.type === "group").length;
  const isAdmin          = (c: Channel) => c.members?.[username] === "admin";

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* ===== top bar ===== */}
      <div className="flex-shrink-0 px-4 pt-4 pb-3 space-y-3">
        {/* title row */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-mono">Kanallar</p>
            <p className="text-lg font-black text-white mt-0.5">Channels</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowScanner(true)}
              className="w-8 h-8 rounded-xl flex items-center justify-center transition hover:scale-105 active:scale-95 text-cyan-400"
              style={{ background:"rgba(14,116,144,0.15)", border:"1px solid rgba(14,116,144,0.3)" }}>
              <Scan className="w-4 h-4" />
            </button>
            <button onClick={() => setShowCreate(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-white transition hover:scale-105 active:scale-95"
              style={{ background: accentColor, boxShadow: `0 4px 14px ${accentColor}44` }}>
              <Plus className="w-3.5 h-3.5" />
              Yaratish
            </button>
          </div>
        </div>

        {/* search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="@username orqali qidirish..."
            className="w-full pl-9 pr-9 py-2.5 rounded-xl text-sm text-white outline-none transition-all duration-200"
            style={{
              background:"rgba(15,23,42,0.7)",
              border:`1px solid ${search ? accentColor + "44" : "rgba(255,255,255,0.07)"}`,
            }}
          />
          {search && (
            <button onClick={() => { setSearch(""); setFoundChannel(null); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* main tabs */}
        <div className="flex gap-1">
          {([
            { key: "mine",     label: "Mening",   count: channels.length },
            { key: "discover", label: "Discover", count: null, badge: "🔭" },
          ] as { key: MainTab; label: string; count: number | null; badge?: string }[]).map(tab => (
            <button key={tab.key} onClick={() => setMainTab(tab.key)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all duration-200"
              style={mainTab === tab.key
                ? { background:`${accentColor}20`, color: accentColor, border:`1px solid ${accentColor}35` }
                : { background:"transparent", color:"#64748b", border:"1px solid transparent" }
              }>
              {tab.badge && <span>{tab.badge}</span>}
              {tab.label}
              {tab.count !== null && tab.count > 0 && (
                <span className="min-w-[16px] h-4 flex items-center justify-center rounded-full text-[9px] font-black px-1"
                  style={mainTab === tab.key
                    ? { background: accentColor, color:"white" }
                    : { background:"#1e293b", color:"#64748b" }}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ===== body ===== */}
      <div className="flex-1 overflow-y-auto px-4 space-y-3 pb-4">

        {/* search result */}
        {search.trim() && (
          <div className="mb-1">
            {searching ? (
              <div className="flex items-center justify-center py-8 gap-2 text-slate-500">
                <div className="w-4 h-4 rounded-full border-2 border-t-transparent animate-spin"
                  style={{ borderColor: accentColor, borderTopColor:"transparent" }} />
                <span className="text-xs font-mono">Qidirilmoqda...</span>
              </div>
            ) : foundChannel ? (
              <div className="p-4 rounded-2xl border space-y-3"
                style={{ background:"rgba(15,23,42,0.8)", borderColor:`${accentColor}25`, boxShadow:`0 0 20px ${accentColor}08` }}>
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 shadow-lg"
                    style={{ background:`linear-gradient(135deg,${chanGrad(foundChannel.id).join(",")})` }}>
                    {foundChannel.type === "channel" ? "📡" : "👥"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="font-black text-white">{foundChannel.name}</p>
                      {foundChannel.isPrivate && <Lock className="w-3 h-3 text-amber-400" />}
                    </div>
                    <p className="text-[11px] text-slate-500">@{foundChannel.id} · {foundChannel.type === "channel" ? "Kanal" : "Guruh"}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Users className="w-3 h-3 text-slate-600" />
                      <span className="text-[10px] text-slate-500">{Object.keys(foundChannel.members || {}).length} a'zo</span>
                    </div>
                  </div>
                </div>
                {foundChannel.description && (
                  <p className="text-xs text-slate-400 italic border-t border-slate-800 pt-2">"{foundChannel.description}"</p>
                )}
                {foundChannel.members?.[username] ? (
                  <button onClick={() => onOpen(foundChannel.id)}
                    className="w-full py-2.5 rounded-xl font-bold text-sm bg-slate-800 text-slate-200 border border-slate-700 hover:bg-slate-700 transition flex items-center justify-center gap-2">
                    <Radio className="w-4 h-4" /> Ochish
                  </button>
                ) : (
                  <button onClick={() => joinChannel(foundChannel)}
                    className="w-full py-2.5 rounded-xl font-bold text-sm text-white transition hover:opacity-90 active:scale-[0.98] flex items-center justify-center gap-2"
                    style={{ background:`linear-gradient(135deg,${accentColor},#6366f1)`, boxShadow:`0 4px 16px ${accentColor}44` }}>
                    <Send className="w-4 h-4" /> Qo'shilish
                  </button>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-600">
                <p className="text-3xl mb-2">🔍</p>
                <p className="text-xs font-mono">«{search}» topilmadi</p>
              </div>
            )}
            <div className="border-b border-slate-800/50 mt-3" />
          </div>
        )}

        {mainTab === "mine" && (
          <>
            {/* stats strip */}
            {channels.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label:"Jami",   val: channels.length,       icon:"📋" },
                  { label:"Kanal",  val: myChannelsCount,        icon:"📡" },
                  { label:"Guruh",  val: myGroupsCount,          icon:"👥" },
                ].map((s, i) => (
                  <div key={i} className="p-2.5 rounded-xl text-center border border-slate-800 bg-slate-900/50">
                    <p className="text-base">{s.icon}</p>
                    <p className="text-sm font-black text-white">{s.val}</p>
                    <p className="text-[9px] text-slate-500 font-mono">{s.label}</p>
                  </div>
                ))}
              </div>
            )}

            {/* type filter */}
            {channels.length > 0 && (
              <div className="flex gap-1">
                {(["all","channel","group"] as const).map(t => (
                  <button key={t} onClick={() => setTypeFilter(t)}
                    className="px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all duration-200"
                    style={typeFilter === t
                      ? { background:`${accentColor}20`, color: accentColor, border:`1px solid ${accentColor}30` }
                      : { background:"transparent", color:"#64748b", border:"1px solid rgba(255,255,255,0.06)" }
                    }>
                    {t === "all" ? "Barchasi" : t === "channel" ? "📡 Kanal" : "👥 Guruh"}
                  </button>
                ))}
              </div>
            )}

            {/* empty */}
            {displayed.length === 0 && !search && (
              <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
                <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
                  style={{ background:`${accentColor}10`, border:`1px solid ${accentColor}20` }}>
                  📡
                </div>
                <div>
                  <p className="text-slate-300 font-bold">Kanallar yo'q</p>
                  <p className="text-xs text-slate-600 mt-1">Yarating yoki username orqali qidiring</p>
                </div>
                <button onClick={() => setShowCreate(true)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white transition hover:opacity-90"
                  style={{ background: accentColor }}>
                  <Plus className="w-4 h-4" /> Yangi yaratish
                </button>
              </div>
            )}

            {/* channel cards */}
            <div className="space-y-2">
              {displayed.map(c => {
                const [g1, g2] = chanGrad(c.id);
                const memberCount = Object.keys(c.members || {}).length;
                const amAdmin = isAdmin(c);
                return (
                  <div key={c.id}
                    className="group flex items-center gap-3 p-3 rounded-2xl border transition-all duration-200 hover:border-slate-600 cursor-pointer"
                    style={{ background:"rgba(15,23,42,0.7)", borderColor:"rgba(255,255,255,0.07)" }}>

                    {/* avatar */}
                    <button onClick={() => onOpen(c.id)} className="flex-shrink-0">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-md"
                        style={{ background:`linear-gradient(135deg,${g1},${g2})`, boxShadow:`0 4px 14px ${g1}33` }}>
                        {c.type === "channel" ? "📡" : "👥"}
                      </div>
                    </button>

                    {/* info */}
                    <button onClick={() => onOpen(c.id)} className="flex-1 min-w-0 text-left">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-sm font-bold text-slate-100 truncate">{c.name}</span>
                        {c.owner === username && (
                          <span className="flex items-center gap-0.5 text-[8px] font-black px-1.5 py-0.5 rounded-full bg-amber-950/50 text-amber-400 border border-amber-800/50">
                            <Crown className="w-2 h-2" /> OWNER
                          </span>
                        )}
                        {c.isPrivate && <Lock className="w-3 h-3 text-slate-500" />}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[11px] text-slate-500 font-mono">@{c.id}</span>
                        <span className="text-slate-700 text-[10px]">·</span>
                        <span className="flex items-center gap-0.5 text-[10px] text-slate-600">
                          <Users className="w-2.5 h-2.5" /> {memberCount}
                        </span>
                      </div>
                      {c.description && (
                        <p className="text-[10px] text-slate-600 truncate mt-0.5">{c.description}</p>
                      )}
                    </button>

                    {/* actions */}
                    <div className="flex gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <button onClick={() => openMemberList(c)} title="A'zolar"
                        className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition active:scale-90">
                        <Users className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => setShareChannel(c)} title="Ulashish"
                        className="w-8 h-8 rounded-xl bg-indigo-950/40 border border-indigo-800/40 flex items-center justify-center text-indigo-400 hover:text-indigo-300 hover:bg-indigo-900/40 transition active:scale-90">
                        <Link2 className="w-3.5 h-3.5" />
                      </button>
                      {amAdmin && (
                        <button onClick={() => { setEditChannel(c); setEditName(c.name); setEditDesc(c.description || ""); }}
                          className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition active:scale-90">
                          <Settings className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {mainTab === "discover" && (
          <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
              style={{ background:`${accentColor}10`, border:`1px solid ${accentColor}20` }}>
              🔭
            </div>
            <div>
              <p className="text-slate-300 font-bold">Kanal topish</p>
              <p className="text-xs text-slate-500 mt-1 max-w-[240px]">
                Kanal nomini @username orqali qidiring va ularga qo'shiling
              </p>
            </div>
            <button onClick={() => { setMainTab("mine"); setTimeout(() => document.querySelector<HTMLInputElement>('input[placeholder*="username"]')?.focus(), 100); }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold text-white transition hover:opacity-90"
              style={{ background: accentColor }}>
              <Search className="w-4 h-4" /> Qidirish
            </button>
          </div>
        )}
      </div>

      {/* ===== modals ===== */}
      {shareChannel && (
        <ShareModal
          title={shareChannel.name}
          subtitle={`@${shareChannel.id} · ${shareChannel.type === "channel" ? "Kanal" : "Guruh"} · ${Object.keys(shareChannel.members || {}).length} a'zo`}
          link={`nexus://join/${shareChannel.id}`}
          displayLink={`nexus://join/${shareChannel.id}`}
          onClose={() => setShareChannel(null)}
        />
      )}

      {showScanner && <QRScannerModal onResult={handleScanResult} onClose={() => setShowScanner(false)} />}

      {/* member list modal */}
      {memberListChan && (
        <div className="fixed inset-0 z-[110] flex items-end sm:items-center justify-center p-4"
          style={{ background:"rgba(0,0,0,0.85)", backdropFilter:"blur(16px)" }}
          onClick={() => setMemberListChan(null)}>
          <div className="w-full max-w-md rounded-3xl border border-slate-800/60 overflow-hidden flex flex-col"
            style={{ background:"#0a0f1e", maxHeight:"80vh", boxShadow:"0 24px 64px rgba(0,0,0,0.8)" }}
            onClick={e => e.stopPropagation()}>

            <div className="p-4 border-b border-slate-800/60 flex items-center justify-between">
              <div>
                <p className="font-black text-white">{memberListChan.name}</p>
                <p className="text-[10px] text-slate-500 font-mono">{memberList.length} a'zo</p>
              </div>
              <button onClick={() => setMemberListChan(null)}
                className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition">
                <X className="w-4 h-4" />
              </button>
            </div>

            {memberListChan.members?.[username] === "admin" && (
              <div className="p-3 border-b border-slate-800/40 flex gap-2">
                <input
                  value={inviteUsername}
                  onChange={e => setInviteUsername(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") inviteMember(memberListChan.id); }}
                  placeholder="@username qo'shish"
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-cyan-500 transition"
                />
                <button onClick={() => inviteMember(memberListChan.id)}
                  className="px-3 py-2 rounded-xl text-xs font-bold text-white transition hover:opacity-90"
                  style={{ background: accentColor }}>
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
              {memberList.map(m => (
                <div key={m.name} className="flex items-center gap-3 p-2.5 rounded-xl border border-slate-800 bg-slate-900/50">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm flex-shrink-0"
                    style={{ background:`linear-gradient(135deg,${accentColor}33,#4f46e5)`, color: accentColor }}>
                    {m.name[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-100 truncate">@{m.name}</p>
                    <p className={`text-[9px] font-bold uppercase ${m.role === "admin" ? "text-amber-400" : "text-slate-600"}`}>
                      {m.role === "admin" ? "👑 Admin" : "A'zo"}
                    </p>
                  </div>
                  {memberListChan.members?.[username] === "admin" && m.name !== username && (
                    <button onClick={() => kickMember(memberListChan.id, m.name)}
                      className="text-[10px] text-rose-400 hover:text-rose-300 px-2.5 py-1 rounded-lg bg-rose-950/20 border border-rose-900/40 transition">
                      Chiqarish
                    </button>
                  )}
                </div>
              ))}
            </div>

            {memberListChan.owner === username && (
              <div className="p-3 border-t border-slate-800/40 flex gap-2">
                <button onClick={() => { setEditChannel(memberListChan); setEditName(memberListChan.name); setEditDesc(memberListChan.description || ""); setMemberListChan(null); }}
                  className="flex-1 py-2 rounded-xl text-xs font-bold text-slate-200 bg-slate-800 border border-slate-700 hover:bg-slate-700 transition flex items-center justify-center gap-1">
                  <Settings className="w-3.5 h-3.5" /> Tahrirlash
                </button>
                <button onClick={() => setShareChannel(memberListChan)}
                  className="flex-1 py-2 rounded-xl text-xs font-bold text-indigo-300 bg-indigo-950/30 border border-indigo-800/50 hover:bg-indigo-900/30 transition flex items-center justify-center gap-1">
                  <Link2 className="w-3.5 h-3.5" /> Ulashish
                </button>
                <button onClick={() => deleteChannel(memberListChan)}
                  className="py-2 px-3 rounded-xl text-xs font-bold text-rose-400 bg-rose-950/20 border border-rose-900/40 hover:bg-rose-900/30 transition">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* edit modal */}
      {editChannel && (
        <div className="fixed inset-0 z-[115] flex items-end sm:items-center justify-center p-4"
          style={{ background:"rgba(0,0,0,0.85)", backdropFilter:"blur(16px)" }}
          onClick={() => setEditChannel(null)}>
          <div className="w-full max-w-sm rounded-3xl border border-slate-800 p-5 space-y-4"
            style={{ background:"#0a0f1e" }}
            onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <p className="font-black text-white flex items-center gap-2"><Settings className="w-4 h-4" style={{ color: accentColor }} /> Sozlamalar</p>
              <button onClick={() => setEditChannel(null)} className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="space-y-2">
              <input value={editName} onChange={e => setEditName(e.target.value)} placeholder="Nom"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500 transition" />
              <textarea value={editDesc} onChange={e => setEditDesc(e.target.value)} placeholder="Tavsif" rows={2}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500 transition resize-none" />
            </div>
            <button onClick={saveEditChannel}
              className="w-full py-3 rounded-xl font-black text-sm text-white transition hover:opacity-90 active:scale-[0.98]"
              style={{ background: accentColor }}>
              ✅ Saqlash
            </button>
          </div>
        </div>
      )}

      {/* create modal */}
      {showCreate && (
        <div className="fixed inset-0 z-[110] flex items-end sm:items-center justify-center p-4"
          style={{ background:"rgba(0,0,0,0.88)", backdropFilter:"blur(20px)" }}
          onClick={() => setShowCreate(false)}>
          <div className="w-full max-w-md rounded-3xl border border-slate-800/60 p-6 space-y-5"
            style={{ background:"#090e1e", boxShadow:"0 24px 64px rgba(0,0,0,0.8)", animation:"auth-card-in 0.25s ease-out" }}
            onClick={e => e.stopPropagation()}>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                  style={{ background:`${accentColor}18`, border:`1px solid ${accentColor}30` }}>
                  <Plus className="w-5 h-5" style={{ color: accentColor }} />
                </div>
                <h3 className="text-base font-black text-white">Yangi yaratish</h3>
              </div>
              <button onClick={() => setShowCreate(false)}
                className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* type picker */}
            <div className="grid grid-cols-2 gap-2.5">
              {(["group","channel"] as const).map(t => (
                <button key={t} onClick={() => setCType(t)}
                  className="p-4 rounded-2xl border-2 transition-all duration-200 text-center hover:scale-[1.02] active:scale-[0.98]"
                  style={cType === t
                    ? { borderColor: accentColor, background:`${accentColor}12`, boxShadow:`0 0 20px ${accentColor}18` }
                    : { borderColor:"rgba(255,255,255,0.07)", background:"rgba(255,255,255,0.02)" }}>
                  <p className="text-2xl mb-1.5">{t === "channel" ? "📡" : "👥"}</p>
                  <p className="text-xs font-bold text-slate-200">{t === "channel" ? "Kanal" : "Guruh"}</p>
                  <p className="text-[9px] text-slate-500 mt-0.5">{t === "channel" ? "Faqat admin yozadi" : "Hamma yozadi"}</p>
                </button>
              ))}
            </div>

            <div className="space-y-2.5">
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm font-mono">@</span>
                <input value={cUsername} onChange={e => setCUsername(e.target.value)} placeholder="username"
                  className="w-full pl-8 pr-4 py-3 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition font-mono" />
              </div>
              <input value={cName} onChange={e => setCName(e.target.value)} placeholder="Nom" maxLength={50}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500 transition" />
              <textarea value={cDesc} onChange={e => setCDesc(e.target.value)} placeholder="Tavsif (ixtiyoriy)" rows={2} maxLength={200}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-500 transition resize-none" />
            </div>

            <label className={`flex items-center justify-between p-3.5 rounded-2xl border cursor-pointer ${isPremium ? "border-amber-700/40 bg-amber-950/10" : "border-slate-800 bg-slate-900/30 opacity-50"}`}>
              <div className="flex items-center gap-2.5">
                <Lock className="w-4 h-4 text-amber-400" />
                <div>
                  <p className="text-sm text-slate-200">Maxfiy kanal
                    {!isPremium && <span className="ml-1.5 text-[9px] text-amber-400 font-bold bg-amber-950/40 px-1.5 py-0.5 rounded-full border border-amber-800/40">👑 PREMIUM</span>}
                  </p>
                  <p className="text-[10px] text-slate-500">Faqat link orqali kirish</p>
                </div>
              </div>
              <input type="checkbox" disabled={!isPremium} checked={cPrivate} onChange={e => setCPrivate(e.target.checked)}
                className="w-4 h-4 accent-amber-400" />
            </label>

            <button onClick={createChannel} disabled={creating}
              className="w-full py-3.5 rounded-xl font-black text-sm text-white transition hover:opacity-90 active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
              style={{ background:`linear-gradient(135deg,${accentColor},#6366f1)`, boxShadow:`0 4px 20px ${accentColor}44` }}>
              {creating ? (
                <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Yaratilmoqda...</>
              ) : (
                <><Send className="w-4 h-4" /> Yaratish</>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
