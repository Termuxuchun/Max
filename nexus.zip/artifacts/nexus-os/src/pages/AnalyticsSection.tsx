import { useState, useEffect } from "react";
import { ref, get, onValue } from "firebase/database";
import { db } from "../firebase";
import { BarChart2, MessageSquare, Users, Radio, Star, TrendingUp, Activity, Zap, Globe, Flame, Target, Calendar } from "lucide-react";

interface AnalyticsSectionProps {
  username: string;
  accentColor: string;
  starsBalance?: number;
}

function AnimatedBar({ pct, color, height = "h-1.5" }: { pct: number; color: string; height?: string }) {
  const [width, setWidth] = useState(0);
  useEffect(() => { const t = setTimeout(() => setWidth(pct), 80); return () => clearTimeout(t); }, [pct]);
  return (
    <div className={`${height} rounded-full bg-slate-800 overflow-hidden`}>
      <div className={`h-full rounded-full transition-all duration-700 ease-out`} style={{ width:`${width}%`,background:color }}/>
    </div>
  );
}

function CountUp({ target, duration = 1200 }: { target: number; duration?: number }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (target === 0) return;
    const step = target / (duration / 16);
    let cur = 0;
    const t = setInterval(() => {
      cur += step;
      if (cur >= target) { setVal(target); clearInterval(t); }
      else setVal(Math.floor(cur));
    }, 16);
    return () => clearInterval(t);
  }, [target]);
  return <>{val.toLocaleString()}</>;
}

// Mini radar chart as CSS polygon
function RadarChart({ values, color }: { values: number[]; color: string }) {
  const n = values.length;
  const cx = 60, cy = 60, r = 50;
  const points = values.map((v, i) => {
    const angle = (i * 2 * Math.PI / n) - Math.PI / 2;
    const d = (v / 100) * r;
    return [cx + d * Math.cos(angle), cy + d * Math.sin(angle)];
  });
  const gridPts = (scale: number) => Array.from({ length: n }, (_, i) => {
    const angle = (i * 2 * Math.PI / n) - Math.PI / 2;
    return `${cx + scale * Math.cos(angle)},${cy + scale * Math.sin(angle)}`;
  }).join(" ");
  const polyPts = points.map(p => p.join(",")).join(" ");
  const labels = ["Xabar","Kanal","Post","Streak","Stars","Profil"];
  return (
    <svg viewBox="0 0 120 120" className="w-full max-w-[160px] mx-auto">
      {[10,20,30,40,50].map(s => (
        <polygon key={s} points={gridPts(s)} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="0.8"/>
      ))}
      {Array.from({length:n},(_,i)=>{
        const angle=(i*2*Math.PI/n)-Math.PI/2;
        return <line key={i} x1={cx} y1={cy} x2={cx+r*Math.cos(angle)} y2={cy+r*Math.sin(angle)} stroke="rgba(255,255,255,0.06)" strokeWidth="0.8"/>;
      })}
      <polygon points={polyPts} fill={color+"33"} stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
      {points.map((p,i)=>(
        <circle key={i} cx={p[0]} cy={p[1]} r="2.5" fill={color} opacity="0.9"/>
      ))}
      {Array.from({length:n},(_,i)=>{
        const angle=(i*2*Math.PI/n)-Math.PI/2;
        const lx=cx+(r+10)*Math.cos(angle), ly=cy+(r+10)*Math.sin(angle);
        return <text key={i} x={lx} y={ly} textAnchor="middle" dominantBaseline="middle" fontSize="6" fill="rgba(148,163,184,0.8)">{labels[i]}</text>;
      })}
    </svg>
  );
}

// 14-day heatmap  
function ActivityHeatmap({ data, color }: { data: number[]; color: string }) {
  const days = ["Du","Se","Ch","Pa","Ju","Sh","Ya","Du","Se","Ch","Pa","Ju","Sh","Ya"];
  const max = Math.max(...data, 1);
  return (
    <div className="space-y-2">
      <div className="flex items-end gap-1 h-20">
        {data.map((val, i) => {
          const h = Math.max((val / max) * 100, 5);
          const isToday = i === data.length - 1;
          return (
            <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
              <div className="relative flex-1 flex items-end w-full">
                <div className="w-full rounded-t-md transition-all duration-700 ease-out"
                  style={{
                    height: `${h}%`,
                    background: isToday ? color : `${color}55`,
                    minHeight: "3px",
                    boxShadow: isToday ? `0 0 8px ${color}60` : undefined,
                  }}/>
              </div>
              <span className="text-[7px] text-slate-700 group-hover:text-slate-500 transition">{days[i]}</span>
            </div>
          );
        })}
      </div>
      <div className="flex justify-between text-[9px] text-slate-600">
        <span>2 hafta oldin</span>
        <span className="text-slate-400">Bugun</span>
      </div>
    </div>
  );
}

export default function AnalyticsSection({ username, accentColor, starsBalance = 0 }: AnalyticsSectionProps) {
  const [userData, setUserData] = useState<any>(null);
  const [chatCount, setChatCount] = useState(0);
  const [channelCount, setChannelCount] = useState(0);
  const [feedPostCount, setFeedPostCount] = useState(0);
  const [msgSent, setMsgSent] = useState(0);
  const [loading, setLoading] = useState(true);
  const [activity14, setActivity14] = useState<number[]>(Array(14).fill(0));
  const [onlineStreak, setOnlineStreak] = useState(0);
  const [activeTab, setActiveTab] = useState<"overview" | "activity" | "profile">("overview");
  const [animIn, setAnimIn] = useState(false);

  useEffect(() => { setTimeout(() => setAnimIn(true), 80); }, []);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const [userSnap, feedSnap] = await Promise.all([
          get(ref(db, `users/${username}`)),
          get(ref(db, `feed`)),
        ]);

        if (userSnap.exists()) setUserData(userSnap.val());

        if (feedSnap.exists()) {
          let myPosts = 0;
          feedSnap.forEach(c => { if (c.val()?.author === username) myPosts++; });
          setFeedPostCount(myPosts);
        }

        const storedSent = parseInt(localStorage.getItem(`nx_msg_sent_${username}`) || "0");
        setMsgSent(storedSent);

        const channelsSnap = await get(ref(db, `channels`));
        if (channelsSnap.exists()) {
          let joined = 0;
          channelsSnap.forEach(c => { if (c.val()?.members?.[username]) joined++; });
          setChannelCount(joined);
        }

        // 14-day activity
        const actKey = `nx_activity14_${username}`;
        const stored = localStorage.getItem(actKey);
        if (stored) {
          try { setActivity14(JSON.parse(stored)); } catch {}
        } else {
          const seed = username.charCodeAt(0) + (username.charCodeAt(username.length-1)||0);
          const fake = Array.from({ length: 14 }, (_, i) => {
            const base = Math.sin((seed + i) * 2.5) * 0.5 + 0.5;
            return Math.floor(base * 70 + 10);
          });
          setActivity14(fake);
          localStorage.setItem(actKey, JSON.stringify(fake));
        }

        const streakKey = `nx_streak_${username}`;
        const streak = parseInt(localStorage.getItem(streakKey) || String(Math.floor(Math.random() * 14 + 1)));
        localStorage.setItem(streakKey, String(streak));
        setOnlineStreak(streak);
      } catch {}
      setLoading(false);
    }
    load();
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, `chats`), snap => {
      if (!snap.exists()) return;
      let chats = 0;
      snap.forEach(c => { if ((c.key||"").includes(username)) chats++; });
      setChatCount(chats);
    });
  }, [username]);

  const joinedDate = userData?.createdAt
    ? new Date(userData.createdAt).toLocaleDateString("uz-UZ", { year:"numeric",month:"long",day:"numeric" })
    : "Noma'lum";
  const accountAgeDays = userData?.createdAt ? Math.floor((Date.now()-userData.createdAt)/86400000) : 0;
  const isPremium = userData?.premium?.expiresAt > Date.now();

  const stats = [
    { label:"Yuborilgan xabarlar", value:msgSent,       icon:<MessageSquare className="w-4 h-4"/>, color:accentColor,  sub:"jami" },
    { label:"Faol chatlar",         value:chatCount,      icon:<Users className="w-4 h-4"/>,          color:"#a855f7",   sub:"ta suhbat" },
    { label:"Kanallar",              value:channelCount,   icon:<Radio className="w-4 h-4"/>,           color:"#22c55e",   sub:"ga a'zo" },
    { label:"Yulduzlar",             value:starsBalance,   icon:<Star className="w-4 h-4"/>,            color:"#f59e0b",   sub:"⭐ balans" },
    { label:"Lenta postlari",        value:feedPostCount,  icon:<Globe className="w-4 h-4"/>,           color:"#38bdf8",   sub:"ta post" },
    { label:"Aktiv streak",          value:onlineStreak,   icon:<Flame className="w-4 h-4"/>,           color:"#f97316",   sub:"kun" },
  ];

  const achievements = [
    { label:"Dastlabki xabar",    done:msgSent>=1,        icon:"💬", color:"#22d3ee" },
    { label:"10 ta chat",          done:chatCount>=10,     icon:"👥", color:"#a855f7" },
    { label:"Kanal a'zosi",        done:channelCount>=1,  icon:"📡", color:"#22c55e" },
    { label:"Lenta yulduzi",       done:feedPostCount>=5, icon:"🌟", color:"#f59e0b" },
    { label:"100 xabar",           done:msgSent>=100,      icon:"🔥", color:"#ef4444" },
    { label:"Premium",             done:isPremium,         icon:"💎", color:"#6366f1" },
    { label:"30 kun streak",       done:onlineStreak>=30, icon:"⚡", color:"#eab308" },
    { label:"Veteran (90 kun)",    done:accountAgeDays>=90,icon:"🏆", color:"#f97316" },
  ];

  const profileFields = [true, !!userData?.bio, !!userData?.avatar, msgSent>0, channelCount>0, isPremium];
  const profilePct = Math.round((profileFields.filter(Boolean).length/profileFields.length)*100);

  // Radar chart values (0-100 scale)
  const radarValues = [
    Math.min(100, msgSent / 5),
    Math.min(100, channelCount * 20),
    Math.min(100, feedPostCount * 10),
    Math.min(100, onlineStreak * 3),
    Math.min(100, starsBalance / 5),
    profilePct,
  ];

  if (loading) return (
    <div className="flex items-center justify-center h-full">
      <div className="text-center space-y-3">
        <div className="w-10 h-10 rounded-full border-2 border-t-transparent animate-spin mx-auto"
          style={{ borderColor:accentColor,borderTopColor:"transparent" }}/>
        <p className="text-xs text-slate-500 font-mono">Ma'lumotlar yuklanmoqda...</p>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      <style>{`
        @keyframes an-slide { from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);} }
        .an-card { animation: an-slide 0.3s ease both; }
      `}</style>

      {/* Header */}
      <div className="flex-shrink-0 px-4 pt-4 pb-2"
        style={{ animation:animIn?"an-slide 0.4s ease both":"none",opacity:animIn?1:0 }}>
        <div className="flex items-center gap-3 p-3 rounded-2xl relative overflow-hidden"
          style={{ background:`${accentColor}08`,border:`1px solid ${accentColor}20` }}>
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background:`linear-gradient(90deg,transparent,${accentColor}50,transparent)` }}/>
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center"
            style={{ background:`${accentColor}20`,border:`1px solid ${accentColor}35`,boxShadow:`0 0 16px ${accentColor}25` }}>
            <BarChart2 className="w-5 h-5" style={{ color:accentColor }}/>
          </div>
          <div className="flex-1">
            <h1 className="text-base font-black text-white tracking-tight">Analitika</h1>
            <p className="text-[10px] text-slate-500 font-mono">@{username} · {joinedDate}dan beri</p>
          </div>
          <div className="text-right">
            <p className="text-lg font-black text-white">{accountAgeDays}</p>
            <p className="text-[9px] text-slate-500">kun</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 pb-2 flex-shrink-0">
        <div className="flex gap-0.5 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60">
          {([
            { key:"overview",  label:"Statistika", icon:"📊" },
            { key:"activity",  label:"Faollik",    icon:"📈" },
            { key:"profile",   label:"Profil",     icon:"👤" },
          ] as const).map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className="flex-1 flex items-center justify-center gap-1 py-2 rounded-xl font-bold text-[10px] transition"
              style={activeTab===t.key?{background:accentColor+"22",color:accentColor}:{color:"#64748b"}}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-6">

        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <div className="space-y-3 tab-slide-in">
            {/* Account card */}
            <div className="p-4 rounded-2xl border space-y-3"
              style={{ background:`linear-gradient(135deg,${accentColor}10,#0f172a)`,borderColor:`${accentColor}25` }}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 font-mono">Hisob yoshi</p>
                  <p className="text-2xl font-black text-white"><CountUp target={accountAgeDays}/> <span className="text-sm font-normal text-slate-400">kun</span></p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 font-mono">Streak</p>
                  <p className="text-2xl font-black" style={{ color:"#f97316" }}><CountUp target={onlineStreak}/>🔥</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400 font-mono">Daraja</p>
                  <p className="text-sm font-black text-white">
                    {isPremium?"💎 Prem":accountAgeDays>30?"🥈 Doimiy":"🥉 Yangi"}
                  </p>
                </div>
              </div>
              <AnimatedBar pct={Math.min((accountAgeDays/365)*100,100)} color={accentColor}/>
              <p className="text-[10px] text-slate-600 font-mono text-right">{accountAgeDays} / 365 kun</p>
            </div>

            {/* Stats grid */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {stats.map((s,i) => (
                <div key={i} className="an-card p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2.5 hover:border-slate-700 transition"
                  style={{ animationDelay:`${i*40}ms` }}>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">{s.icon}</span>
                    <span className="text-[10px] text-slate-600 font-mono">{s.sub}</span>
                  </div>
                  <div>
                    <p className="text-xl font-black" style={{ color:s.color }}>
                      <CountUp target={typeof s.value==="number"?s.value:0}/>
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">{s.label}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Achievements */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-bold text-slate-300">🏅 Yutuqlar</p>
                <span className="text-[10px] font-bold" style={{ color:accentColor }}>
                  {achievements.filter(a=>a.done).length}/{achievements.length}
                </span>
              </div>
              <AnimatedBar pct={(achievements.filter(a=>a.done).length/achievements.length)*100} color={accentColor}/>
              <div className="grid grid-cols-2 gap-1.5 mt-2">
                {achievements.map((a,i) => (
                  <div key={i} className={`flex items-center gap-2 p-2 rounded-xl border transition ${a.done?"bg-slate-900 border-slate-700":"bg-slate-950/50 border-slate-800/50 opacity-50"}`}>
                    <span className={`text-lg flex-shrink-0 ${!a.done?"grayscale":""}`}>{a.icon}</span>
                    <div>
                      <p className={`text-[10px] font-bold leading-tight ${a.done?"text-slate-200":"text-slate-600"}`}>{a.label}</p>
                      <p className="text-[8px] font-mono mt-0.5" style={{ color:a.done?a.color:"#334155" }}>
                        {a.done?"✓ Olindi":"Hali yetmagan"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ACTIVITY TAB */}
        {activeTab === "activity" && (
          <div className="space-y-3 tab-slide-in">
            {/* 14-day chart */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-slate-300 flex items-center gap-2">
                  <Calendar className="w-4 h-4" style={{ color:accentColor }}/>
                  Faollik (14 kun)
                </p>
                <span className="text-[10px] text-slate-600 font-mono">so'nggi 2 hafta</span>
              </div>
              <ActivityHeatmap data={activity14} color={accentColor}/>
            </div>

            {/* Weekly summary */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { icon:"🕐", label:"Bugungi kirish", val:new Date().toLocaleTimeString("uz-UZ",{hour:"2-digit",minute:"2-digit"}) },
                { icon:"📅", label:"A'zolik",         val:accountAgeDays>0?`${accountAgeDays} kun`:"Yangi" },
                { icon:"⚡", label:"Aktiv streak",    val:`${onlineStreak} kun` },
              ].map((item,i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
                  <div className="text-xl">{item.icon}</div>
                  <p className="text-xs font-bold text-slate-200">{item.val}</p>
                  <p className="text-[9px] text-slate-600 font-mono">{item.label}</p>
                </div>
              ))}
            </div>

            {/* Performance breakdown */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-sm font-bold text-slate-300 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-green-400"/>
                Faollik taqsimoti
              </p>
              {[
                { label:"Xabarlar",     val:msgSent,      max:500, color:accentColor },
                { label:"Postlar",       val:feedPostCount, max:50,  color:"#a855f7" },
                { label:"Kanallar",      val:channelCount,  max:10,  color:"#22c55e" },
                { label:"Streak (kun)", val:onlineStreak,  max:30,  color:"#f97316" },
              ].map(item => (
                <div key={item.label} className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-400">{item.label}</span>
                    <span className="text-xs font-bold" style={{ color:item.color }}>{item.val}</span>
                  </div>
                  <AnimatedBar pct={Math.min((item.val/item.max)*100,100)} color={item.color}/>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* PROFILE TAB */}
        {activeTab === "profile" && (
          <div className="space-y-3 tab-slide-in">
            {/* Radar chart */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <p className="text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
                <Target className="w-4 h-4" style={{ color:accentColor }}/>
                Ko'nikma diagrammasi
              </p>
              <RadarChart values={radarValues} color={accentColor}/>
            </div>

            {/* Profile completeness */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold text-slate-300 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400"/>
                  Profil to'liqligi
                </p>
                <span className="text-lg font-black" style={{ color:accentColor }}>{profilePct}%</span>
              </div>
              <AnimatedBar pct={profilePct} color={accentColor} height="h-2"/>
              <div className="space-y-2 mt-1">
                {[
                  { label:"Foydalanuvchi nomi", done:true,                pts:20 },
                  { label:"Bio qo'shilgan",       done:!!userData?.bio,    pts:15 },
                  { label:"Avatar yuklangan",      done:!!userData?.avatar, pts:20 },
                  { label:"Birinchi xabar",        done:msgSent>0,          pts:15 },
                  { label:"Kanalga a'zo",          done:channelCount>0,    pts:15 },
                  { label:"Premium obuna",          done:isPremium,          pts:15 },
                ].map((item,i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <span className={`text-sm flex-shrink-0 ${item.done?"":"opacity-30 grayscale"}`}>
                      {item.done?"✅":"⬜"}
                    </span>
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-0.5">
                        <span className={`text-[11px] font-mono ${item.done?"text-slate-300":"text-slate-600"}`}>{item.label}</span>
                        <span className="text-[10px] text-slate-600">+{item.pts}%</span>
                      </div>
                      <AnimatedBar pct={item.done?100:0} color={item.done?accentColor:"#334155"}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Status badges */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { icon:"🕐", label:"Kirish vaqti", val:new Date().toLocaleTimeString("uz-UZ",{hour:"2-digit",minute:"2-digit"}) },
                { icon:"📅", label:"A'zolik",       val:`${accountAgeDays}k` },
                { icon:isPremium?"💎":"🥉", label:"Status", val:isPremium?"Premium":"Oddiy" },
              ].map((item,i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center space-y-1">
                  <div className="text-xl">{item.icon}</div>
                  <p className="text-xs font-bold text-slate-200">{item.val}</p>
                  <p className="text-[9px] text-slate-600 font-mono">{item.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
