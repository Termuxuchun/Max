import { useState, useEffect, useRef, useCallback } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Heart, Shuffle, Repeat, Music, ListMusic, Loader2, ExternalLink } from "lucide-react";

function isDirectAudioUrl(url: string): boolean {
  if (!url) return false;
  try {
    const u = new URL(url);
    const path = u.pathname.toLowerCase();
    return /\.(mp3|ogg|wav|flac|aac|m4a|opus|webm)(\?|$)/.test(path);
  } catch {
    return /\.(mp3|ogg|wav|flac|aac|m4a|opus|webm)(\?|$)/i.test(url);
  }
}

function getYouTubeVideoId(url: string): string | null {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (u.hostname === "youtu.be") return u.pathname.slice(1).split("?")[0];
    if (u.hostname.includes("youtube.com") || u.hostname.includes("music.youtube.com")) {
      return u.searchParams.get("v");
    }
  } catch {}
  return null;
}

function getYandexMusicEmbedUrl(url: string): string | null {
  try {
    const u = new URL(url);
    if (!u.hostname.includes("music.yandex")) return null;
    const parts = u.pathname.split("/").filter(Boolean);
    const albumIdx = parts.indexOf("album");
    const trackIdx = parts.indexOf("track");
    if (albumIdx >= 0 && trackIdx >= 0) {
      const albumId = parts[albumIdx + 1];
      const trackId = parts[trackIdx + 1];
      if (albumId && trackId) {
        return `https://music.yandex.ru/iframe/#track/${trackId}/${albumId}`;
      }
    }
  } catch {}
  return null;
}

function getExternalServiceName(url: string): string {
  if (!url) return "Tashqi musiqa";
  if (url.includes("music.youtube.com") || (url.includes("youtube.com") && !url.includes("music.yandex"))) return "YouTube Music";
  if (url.includes("youtu.be")) return "YouTube";
  if (url.includes("music.yandex")) return "Yandex Music";
  if (url.includes("spotify.com")) return "Spotify";
  if (url.includes("soundcloud.com")) return "SoundCloud";
  if (url.includes("apple.com")) return "Apple Music";
  if (url.includes("deezer.com")) return "Deezer";
  return "Tashqi musiqa";
}

interface Track {
  id: string;
  title: string;
  artist: string;
  url: string;
  emoji: string;
  color: string;
  genre: string;
  order?: number;
}

interface MusicSectionProps {
  accentColor: string;
  username: string;
}

export default function MusicSection({ accentColor, username }: MusicSectionProps) {
  const [tracks, setTracks]       = useState<Track[]>([]);
  const [loading, setLoading]     = useState(true);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress]   = useState(0);
  const [volume, setVolume]       = useState(0.7);
  const [isMuted, setIsMuted]     = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat]   = useState(false);
  const [liked, setLiked]         = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(`nexus_liked_${username}`) || "[]"); } catch { return []; }
  });
  const [view, setView]   = useState<"player" | "playlist" | "liked">("player");
  const [genre, setGenre] = useState<string>("Barchasi");

  const audioRef   = useRef<HTMLAudioElement | null>(null);
  const timerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const tracksRef  = useRef<Track[]>([]);
  const [bars]     = useState(() =>
    Array.from({ length: 24 }, (_, i) => ({ d: i * 0.12, max: 8 + Math.sin(i) * 20 }))
  );

  // Keep tracksRef in sync
  useEffect(() => { tracksRef.current = tracks; }, [tracks]);

  // ── Load tracks from Firebase ──
  useEffect(() => {
    return onValue(ref(db, "music/tracks"), snap => {
      setLoading(false);
      if (!snap.exists()) { setTracks([]); return; }
      const list: Track[] = [];
      snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
      setTracks(list);
      // Set first track only if nothing is selected yet
      setCurrentId(prev => prev ?? (list[0]?.id || null));
    });
  }, []);

  const currentTrack = tracks.find(t => t.id === currentId) ?? tracks[0] ?? null;
  const isExternal = currentTrack ? !isDirectAudioUrl(currentTrack.url) : false;

  // ── Audio: load new track ──
  useEffect(() => {
    if (!currentTrack) return;

    // External (non-direct-audio) URL — stop audio and don't load
    if (!isDirectAudioUrl(currentTrack.url)) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
      }
      setIsPlaying(false);
      setProgress(0);
      return;
    }

    // Create audio element once
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }
    const audio = audioRef.current;

    // Only reload src when URL actually changes
    if (audio.src !== currentTrack.url) {
      audio.pause();
      audio.src = currentTrack.url;
      audio.volume = isMuted ? 0 : volume;
      audio.load();
      setProgress(0);
    }

    audio.onended = () => {
      if (isRepeat) {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      } else {
        skipNext();
      }
    };

    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentId]); // Only re-run when track ID changes, NOT on every render

  // ── Audio: play / pause ──
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || isExternal) return;
    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
      timerRef.current = setInterval(() => {
        if (audio.duration) setProgress((audio.currentTime / audio.duration) * 100);
      }, 300);
    } else {
      audio.pause();
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isPlaying, isExternal]);

  // ── Audio: volume ──
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = isMuted ? 0 : volume;
  }, [volume, isMuted]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      audioRef.current?.pause();
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const filtered = genre === "Barchasi" ? tracks : tracks.filter(t => t.genre === genre);

  const skipNext = useCallback(() => {
    const list = genre === "Barchasi" ? tracksRef.current : tracksRef.current.filter(t => t.genre === genre);
    if (!list.length) return;
    const idx = list.findIndex(t => t.id === currentId);
    const next = isShuffle
      ? list[Math.floor(Math.random() * list.length)]
      : list[(idx + 1) % list.length];
    setCurrentId(next.id);
    setIsPlaying(true);
    setProgress(0);
  }, [currentId, genre, isShuffle]);

  const skipPrev = useCallback(() => {
    const list = genre === "Barchasi" ? tracksRef.current : tracksRef.current.filter(t => t.genre === genre);
    if (!list.length) return;
    const idx = list.findIndex(t => t.id === currentId);
    const prev = list[(idx - 1 + list.length) % list.length];
    setCurrentId(prev.id);
    setIsPlaying(true);
    setProgress(0);
  }, [currentId, genre]);

  function togglePlay() { if (currentTrack) setIsPlaying(p => !p); }

  function playTrack(track: Track) {
    if (track.id === currentId) { togglePlay(); return; }
    setCurrentId(track.id);
    setIsPlaying(true);
    setProgress(0);
  }

  function seek(e: React.MouseEvent<HTMLDivElement>) {
    const audio = audioRef.current;
    if (!audio?.duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const p = (e.clientX - rect.left) / rect.width;
    audio.currentTime = p * audio.duration;
    setProgress(p * 100);
  }

  function toggleLike(id: string) {
    const next = liked.includes(id) ? liked.filter(l => l !== id) : [...liked, id];
    setLiked(next);
    localStorage.setItem(`nexus_liked_${username}`, JSON.stringify(next));
  }

  const genres  = ["Barchasi", ...Array.from(new Set(tracks.map(t => t.genre)))];
  const elapsed = audioRef.current?.duration ? Math.floor(audioRef.current.currentTime) : 0;
  const total   = audioRef.current?.duration ? Math.floor(audioRef.current.duration) : 0;
  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  // ── Loading ──
  if (loading) return (
    <div className="flex flex-col h-full bg-[#030712] items-center justify-center gap-3">
      <Loader2 className="w-8 h-8 animate-spin" style={{ color: accentColor }} />
      <p className="text-slate-500 text-sm">Treklarni yuklanmoqda...</p>
    </div>
  );

  // ── Empty ──
  if (tracks.length === 0) return (
    <div className="flex flex-col h-full bg-[#030712] items-center justify-center gap-4 px-6 text-center">
      <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-5xl"
        style={{ background: accentColor + "22" }}>🎵</div>
      <div>
        <p className="text-white font-black text-lg">Musiqa yo'q</p>
        <p className="text-slate-500 text-sm mt-1 leading-relaxed">
          Admin panel → 🎵 Musiqa bo'limida treklarni qo'shing
        </p>
      </div>
      <div className="flex items-center gap-2 text-xs text-slate-600 border border-slate-800 rounded-xl px-4 py-3 bg-slate-900/50">
        <span>💡</span>
        <span>"Standart treklarni yuklash" tugmasi bilan 12 ta trek bir anda yuklanadi</span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 page-enter overflow-hidden">

      {/* ── Tabs ── */}
      <div className="px-4 pt-4 pb-3 flex gap-1.5 flex-shrink-0 border-b border-slate-800/40" style={{ background: "rgba(5,8,18,0.95)", backdropFilter: "blur(20px)" }}>
        <button onClick={() => setView("player")}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm transition-all duration-150"
          style={view === "player"
            ? { background: accentColor + "20", color: accentColor, border: `1px solid ${accentColor}40` }
            : { color: "#475569", border: "1px solid transparent" }}>
          <Music className="w-4 h-4" /> Pleyer
        </button>
        <button onClick={() => setView("playlist")}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm transition-all duration-150"
          style={view === "playlist"
            ? { background: accentColor + "20", color: accentColor, border: `1px solid ${accentColor}40` }
            : { color: "#475569", border: "1px solid transparent" }}>
          <ListMusic className="w-4 h-4" /> Playlist · {tracks.length}
        </button>
        <button onClick={() => setView("liked")}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm transition-all duration-150"
          style={view === "liked"
            ? { background: "#f43f5e20", color: "#f43f5e", border: "1px solid #f43f5e40" }
            : { color: "#475569", border: "1px solid transparent" }}>
          <Heart className="w-4 h-4" /> Sevimlilar · {liked.length}
        </button>
      </div>

      {/* ── PLAYER VIEW ── */}
      {view === "player" && currentTrack && (
        <div className="flex-1 flex flex-col items-center overflow-y-auto px-4 pb-6">

          {/* Album art — vinyl disc */}
          <div className="relative mt-4 mb-4 flex items-center justify-center">
            {/* Outer glow ring */}
            {isPlaying && (
              <div className="absolute rounded-full pointer-events-none"
                style={{ width:240,height:240,
                  background:`conic-gradient(from 0deg,${currentTrack.color}44,${currentTrack.color}11,${currentTrack.color}44)`,
                  animation:"vinyl-spin 4s linear infinite",
                  filter:`blur(1px)` }}/>
            )}
            {/* Vinyl disc */}
            <div
              className="relative z-10 flex items-center justify-center"
              style={{ width:208,height:208,
                borderRadius:"50%",
                background:`conic-gradient(from 0deg at 50% 50%,${currentTrack.color}18 0deg,#0f172a 30deg,${currentTrack.color}14 60deg,#0f172a 90deg,${currentTrack.color}18 120deg,#0f172a 150deg,${currentTrack.color}14 180deg,#0f172a 210deg,${currentTrack.color}18 240deg,#0f172a 270deg,${currentTrack.color}14 300deg,#0f172a 330deg)`,
                boxShadow: isPlaying ? `0 0 50px ${currentTrack.color}45, 0 24px 60px rgba(0,0,0,0.6)` : "0 16px 48px rgba(0,0,0,0.6)",
                animation: isPlaying ? "vinyl-spin 3s linear infinite" : undefined,
              }}>
              {/* Inner grooves */}
              {[0.78,0.65,0.52,0.40].map((s,i) => (
                <div key={i} className="absolute rounded-full border pointer-events-none"
                  style={{ width:`${s*100}%`,height:`${s*100}%`,
                    borderColor:`${currentTrack.color}${["18","14","10","0C"][i]}`,borderWidth:1 }}/>
              ))}
              {/* Label center */}
              <div className="relative z-20 w-20 h-20 rounded-full flex items-center justify-center border"
                style={{ background:`radial-gradient(circle at 40% 35%,${currentTrack.color}40,${currentTrack.color}18)`,
                  borderColor:`${currentTrack.color}55`,
                  boxShadow:`0 0 16px ${currentTrack.color}40` }}>
                <span className="text-4xl select-none">{currentTrack.emoji}</span>
                {/* Center spindle */}
                <div className="absolute w-2 h-2 rounded-full bg-slate-900 border border-slate-600"/>
              </div>
            </div>
          </div>

          {/* Waveform visualizer */}
          <div className="flex items-end justify-center gap-[3px] h-10 mb-3 px-4">
            {bars.map((b, i) => {
              const mid = Math.abs(i - bars.length / 2);
              const maxH = 40 - mid * 0.8;
              return (
                <div key={i}
                  className="rounded-full flex-shrink-0"
                  style={{
                    width: 3,
                    background: `linear-gradient(to top,${currentTrack.color},${currentTrack.color}66)`,
                    minHeight: 3,
                    height: isPlaying ? `${Math.max(3, maxH * 0.5)}px` : 3,
                    opacity: isPlaying ? 0.6 + (i % 4) * 0.1 : 0.18,
                    animation: isPlaying ? `wave-bar ${0.6 + b.d * 0.1}s ease-in-out infinite` : "none",
                    animationDelay: `${b.d * 0.5}s`,
                    alignSelf: "flex-end",
                  }} />
              );
            })}
          </div>

          {/* Track info */}
          <div className="text-center mb-6 w-full max-w-xs">
            <div className="flex items-center justify-center gap-3">
              <div className="text-center flex-1">
                <p className="font-black text-xl text-white">{currentTrack.title}</p>
                <p className="text-slate-400 text-sm">{currentTrack.artist || "Noma'lum"}</p>
                <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full"
                  style={{ background: currentTrack.color + "22", color: currentTrack.color }}>
                  {currentTrack.genre}
                </span>
                {isExternal && (
                  <p className="text-[10px] text-amber-400 mt-1">
                    🔗 {getExternalServiceName(currentTrack.url)} havolasi
                  </p>
                )}
              </div>
              <button onClick={() => toggleLike(currentTrack.id)} className="flex-shrink-0">
                <Heart className={`w-6 h-6 transition-all ${liked.includes(currentTrack.id) ? "fill-rose-500 text-rose-500 scale-110" : "text-slate-600"}`} />
              </button>
            </div>
          </div>

          {/* External URL — embed or open button */}
          {isExternal ? (() => {
            const ytId = getYouTubeVideoId(currentTrack.url);
            const yandexEmbed = !ytId ? getYandexMusicEmbedUrl(currentTrack.url) : null;
            const serviceName = getExternalServiceName(currentTrack.url);

            return (
              <div className="w-full mb-4 flex flex-col items-center gap-3">
                {ytId ? (
                  /* ── YouTube / YouTube Music embed ── */
                  <div className="w-full rounded-2xl overflow-hidden border border-slate-700 shadow-xl"
                    style={{ boxShadow: `0 0 30px ${currentTrack.color}33` }}>
                    <iframe
                      key={ytId}
                      src={`https://www.youtube.com/embed/${ytId}?autoplay=1&controls=1&rel=0&modestbranding=1`}
                      title={currentTrack.title}
                      allow="autoplay; encrypted-media; picture-in-picture"
                      allowFullScreen
                      className="w-full"
                      style={{ height: "200px", border: "none" }}
                    />
                  </div>
                ) : yandexEmbed ? (
                  /* ── Yandex Music embed ── */
                  <div className="w-full rounded-2xl overflow-hidden border border-slate-700 shadow-xl"
                    style={{ boxShadow: `0 0 30px ${currentTrack.color}33` }}>
                    <iframe
                      key={yandexEmbed}
                      src={yandexEmbed}
                      title={currentTrack.title}
                      allow="autoplay"
                      className="w-full"
                      style={{ height: "180px", border: "none" }}
                    />
                  </div>
                ) : (
                  /* ── Other external — open link ── */
                  <>
                    <div className="text-center text-xs text-slate-500 px-4 py-3 rounded-2xl bg-slate-900/60 border border-slate-800 w-full">
                      Bu trek <span className="text-amber-400 font-semibold">{serviceName}</span> xizmatida joylashgan.
                    </div>
                    <a href={currentTrack.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm transition active:scale-95"
                      style={{ background: `linear-gradient(135deg, ${currentTrack.color}, ${accentColor})`, color: "#fff", boxShadow: `0 0 20px ${currentTrack.color}44` }}>
                      <ExternalLink className="w-4 h-4" />
                      {serviceName} da eshitish
                    </a>
                  </>
                )}

                <div className="flex items-center gap-3 mt-1">
                  <button onClick={skipPrev}
                    className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition active:scale-90 border border-slate-700">
                    <SkipBack className="w-5 h-5 text-slate-200" fill="currentColor" />
                  </button>
                  <a href={currentTrack.url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white transition">
                    <ExternalLink className="w-3.5 h-3.5" /> {serviceName}
                  </a>
                  <button onClick={skipNext}
                    className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition active:scale-90 border border-slate-700">
                    <SkipForward className="w-5 h-5 text-slate-200" fill="currentColor" />
                  </button>
                </div>
              </div>
            );
          })() : (
            <>
              {/* Progress bar */}
              <div className="w-full max-w-xs mb-2">
                <div className="w-full h-1.5 bg-slate-800 rounded-full cursor-pointer relative overflow-hidden" onClick={seek}>
                  <div className="h-full rounded-full transition-all relative"
                    style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${currentTrack.color}, ${accentColor})` }}>
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-lg" />
                  </div>
                </div>
                <div className="flex justify-between mt-1.5 text-[10px] text-slate-600">
                  <span>{fmt(elapsed)}</span>
                  <span>{fmt(total)}</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-6 mb-6">
                <button onClick={() => setIsShuffle(s => !s)}
                  className="transition" style={isShuffle ? { color: accentColor } : { color: "#94a3b8", opacity: 0.35 }}>
                  <Shuffle className="w-5 h-5" />
                </button>
                <button onClick={skipPrev}
                  className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition active:scale-90 border border-slate-700">
                  <SkipBack className="w-5 h-5 text-slate-200" fill="currentColor" />
                </button>
                <button onClick={togglePlay}
                  className="w-16 h-16 rounded-full flex items-center justify-center transition active:scale-90 shadow-xl"
                  style={{ background: `linear-gradient(135deg, ${currentTrack.color}, ${accentColor})`, boxShadow: `0 0 30px ${currentTrack.color}55` }}>
                  {isPlaying
                    ? <Pause className="w-7 h-7 text-white" fill="white" />
                    : <Play  className="w-7 h-7 text-white ml-0.5" fill="white" />}
                </button>
                <button onClick={skipNext}
                  className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition active:scale-90 border border-slate-700">
                  <SkipForward className="w-5 h-5 text-slate-200" fill="currentColor" />
                </button>
                <button onClick={() => setIsRepeat(r => !r)}
                  className="transition" style={isRepeat ? { color: accentColor } : { color: "#94a3b8", opacity: 0.35 }}>
                  <Repeat className="w-5 h-5" />
                </button>
              </div>

              {/* Volume */}
              <div className="flex items-center gap-3 w-full max-w-xs">
                <button onClick={() => setIsMuted(m => !m)}>
                  {isMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-slate-500" />}
                </button>
                <input type="range" min="0" max="1" step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={e => { setVolume(Number(e.target.value)); setIsMuted(false); }}
                  className="flex-1" style={{ accentColor }} />
                <span className="text-[10px] text-slate-600 w-6">{Math.round((isMuted ? 0 : volume) * 100)}</span>
              </div>
            </>
          )}
        </div>
      )}

      {/* ── PLAYLIST VIEW ── */}
      {view === "playlist" && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="px-4 pb-3 flex-shrink-0">
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
              {genres.map(g => (
                <button key={g} onClick={() => setGenre(g)}
                  className="flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition"
                  style={genre === g
                    ? { background: accentColor + "33", color: accentColor, border: `1px solid ${accentColor}55` }
                    : { background: "#1e293b", color: "#64748b", border: "1px solid #334155" }}>
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-4 pb-6 space-y-1">
            {filtered.length === 0 && (
              <p className="text-center text-slate-600 py-8 text-sm">Bu janrda trek yo'q</p>
            )}
            {filtered.map((track, i) => {
              const isCur  = track.id === currentId;
              const isLiked = liked.includes(track.id);
              return (
                <button key={track.id} onClick={() => playTrack(track)}
                  className={`w-full flex items-center gap-3 p-3 rounded-2xl transition active:scale-[0.99] ${isCur ? "border" : "hover:bg-slate-900/40"}`}
                  style={isCur ? { background: track.color + "11", borderColor: track.color + "33", animationDelay: `${i * 25}ms` } : {}}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                    style={{ background: track.color + "22", border: `1px solid ${track.color}33` }}>
                    {isCur && isPlaying ? (
                      <div className="flex items-end gap-0.5 h-5">
                        {[0,1,2].map(j => (
                          <div key={j} className="w-1 rounded-full"
                            style={{ background: track.color, animation: `typing-dot 0.8s ease-in-out infinite ${j * 0.15}s`, height: "60%" }} />
                        ))}
                      </div>
                    ) : <span>{track.emoji}</span>}
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <p className="font-bold text-sm truncate"
                      style={isCur ? { color: track.color } : { color: "#e2e8f0" }}>
                      {track.title}
                    </p>
                    <p className="text-xs text-slate-500">{track.artist || "Noma'lum"} · {track.genre}</p>
                  </div>
                  <button onClick={e => { e.stopPropagation(); toggleLike(track.id); }} className="p-1 flex-shrink-0">
                    <Heart className={`w-4 h-4 transition ${isLiked ? "fill-rose-500 text-rose-500" : "text-slate-700"}`} />
                  </button>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ── LIKED VIEW ── */}
      {view === "liked" && (
        <div className="flex-1 flex flex-col overflow-hidden">
          {liked.length === 0 ? (
            <div className="flex flex-col items-center justify-center flex-1 gap-4 px-6 text-center">
              <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-5xl" style={{ background: "#f43f5e22" }}>💔</div>
              <div>
                <p className="text-white font-black text-lg">Sevimli treklaringiz yo'q</p>
                <p className="text-slate-500 text-sm mt-1">Playlist yoki Plyer ko'rinishida ❤️ bosing</p>
              </div>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto px-4 pt-2 pb-6 space-y-1">
              <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold py-2">❤️ {liked.length} ta sevimli trek</p>
              {tracks.filter(t => liked.includes(t.id)).map((track, i) => {
                const isCur = track.id === currentId;
                return (
                  <button key={track.id} onClick={() => playTrack(track)}
                    className={`w-full flex items-center gap-3 p-3 rounded-2xl transition active:scale-[0.99] ${isCur ? "border" : "hover:bg-slate-900/40"}`}
                    style={isCur ? { background: track.color + "11", borderColor: track.color + "33" } : {}}>
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                      style={{ background: track.color + "22", border: `1px solid ${track.color}33` }}>
                      {isCur && isPlaying ? (
                        <div className="flex items-end gap-0.5 h-5">
                          {[0,1,2].map(j => (
                            <div key={j} className="w-1 rounded-full"
                              style={{ background: track.color, animation: `typing-dot 0.8s ease-in-out infinite ${j * 0.15}s`, height: "60%" }} />
                          ))}
                        </div>
                      ) : <span>{track.emoji}</span>}
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <p className="font-bold text-sm truncate" style={isCur ? { color: track.color } : { color: "#e2e8f0" }}>
                        {track.title}
                      </p>
                      <p className="text-xs text-slate-500">{track.artist || "Noma'lum"} · {track.genre}</p>
                    </div>
                    <button onClick={e => { e.stopPropagation(); toggleLike(track.id); }} className="p-1 flex-shrink-0">
                      <Heart className="w-4 h-4 fill-rose-500 text-rose-500 transition" />
                    </button>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ── Mini player ── */}
      {view === "playlist" && isPlaying && currentTrack && (
        <div className="px-4 pb-4 pt-2 flex-shrink-0 border-t border-slate-800/60 drop-in">
          <div className="flex items-center gap-3 p-3 rounded-2xl"
            style={{ background: currentTrack.color + "11", border: `1px solid ${currentTrack.color}33` }}>
            <span className="text-2xl badge-float">{currentTrack.emoji}</span>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm truncate" style={{ color: currentTrack.color }}>{currentTrack.title}</p>
              <div className="w-full h-0.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: currentTrack.color }} />
              </div>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button onClick={skipPrev} className="w-7 h-7 rounded-lg bg-slate-800/80 flex items-center justify-center">
                <SkipBack className="w-3.5 h-3.5 text-slate-300" fill="currentColor" />
              </button>
              <button onClick={togglePlay} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: currentTrack.color }}>
                {isPlaying ? <Pause className="w-4 h-4 text-white" fill="white" /> : <Play className="w-4 h-4 text-white ml-0.5" fill="white" />}
              </button>
              <button onClick={skipNext} className="w-7 h-7 rounded-lg bg-slate-800/80 flex items-center justify-center">
                <SkipForward className="w-3.5 h-3.5 text-slate-300" fill="currentColor" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
