import { useState, useEffect } from "react";
import { ref, set, get, onValue, push, update, remove } from "firebase/database";
import { db } from "../firebase";

interface Props {
  username: string;
  accentColor: string;
  isPremium: boolean;
}

type KTab = "calendar" | "tasks" | "mood" | "stats";
type MoodType = "😄" | "🙂" | "😐" | "😔" | "😢";

interface WorkDay {
  date: string;
  worked: boolean;
  earned: number;
  spent: number;
  note: string;
}

interface DailyTask {
  id: string;
  text: string;
  done: boolean;
  ts: number;
}

interface MoodEntry {
  date: string;
  mood: MoodType;
  note: string;
  ts: number;
}

interface Currency {
  code: string;
  name: string;
  symbol: string;
  flag: string;
}

// ─── CURRENCIES ─────────────────────────────────────────────
const CURRENCIES: Currency[] = [
  { code: "UZS", name: "So'm",         symbol: "so'm",  flag: "🇺🇿" },
  { code: "USD", name: "Dollar",       symbol: "$",     flag: "🇺🇸" },
  { code: "EUR", name: "Euro",         symbol: "€",     flag: "🇪🇺" },
  { code: "RUB", name: "Rubl",         symbol: "₽",     flag: "🇷🇺" },
  { code: "GBP", name: "Funt",         symbol: "£",     flag: "🇬🇧" },
  { code: "CNY", name: "Yuan",         symbol: "¥",     flag: "🇨🇳" },
  { code: "KZT", name: "Tenge",        symbol: "₸",     flag: "🇰🇿" },
  { code: "TRY", name: "Lira",         symbol: "₺",     flag: "🇹🇷" },
  { code: "AED", name: "Dirham",       symbol: "د.إ",   flag: "🇦🇪" },
  { code: "JPY", name: "Yen",          symbol: "¥",     flag: "🇯🇵" },
  { code: "KRW", name: "Von",          symbol: "₩",     flag: "🇰🇷" },
  { code: "SAR", name: "Riyal",        symbol: "﷼",     flag: "🇸🇦" },
];

const MOODS: { emoji: MoodType; label: string; color: string }[] = [
  { emoji: "😄", label: "Ajoyib",  color: "#22c55e" },
  { emoji: "🙂", label: "Yaxshi",  color: "#86efac" },
  { emoji: "😐", label: "Oddiy",   color: "#fbbf24" },
  { emoji: "😔", label: "Yomon",   color: "#f97316" },
  { emoji: "😢", label: "Qiyin",   color: "#ef4444" },
];

function pad2(n: number) { return String(n).padStart(2, "0"); }
function toDateStr(d: Date) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }

function formatMoney(n: number, currency: Currency): string {
  let formatted: string;
  if (Math.abs(n) >= 1_000_000) formatted = `${(n / 1_000_000).toFixed(1)}M`;
  else if (Math.abs(n) >= 1_000) formatted = `${(n / 1_000).toFixed(0)}K`;
  else formatted = String(Math.round(n));
  // prefix symbols go before the number
  const prefix = ["$", "€", "£", "¥", "₽", "₸", "₺", "₩"].includes(currency.symbol);
  return prefix ? `${currency.symbol}${formatted}` : `${formatted} ${currency.symbol}`;
}

const MONTH_NAMES_UZ = ["Yanvar","Fevral","Mart","Aprel","May","Iyun","Iyul","Avgust","Sentabr","Oktabr","Noyabr","Dekabr"];
const DAY_NAMES_UZ   = ["Du","Se","Ch","Pa","Ju","Sh","Ya"];

export default function KundalikSection({ username, accentColor, isPremium }: Props) {
  const [kTab, setKTab]     = useState<KTab>("calendar");
  const today               = toDateStr(new Date());

  // ─── CURRENCY ────────────────────────────────────────────────
  const [currency, setCurrency]         = useState<Currency>(CURRENCIES[0]);
  const [showCurrPicker, setShowCurrPicker] = useState(false);

  // load saved currency from Firebase
  useEffect(() => {
    get(ref(db, `kundalik/${username}/settings/currency`)).then(snap => {
      if (snap.exists()) {
        const saved = CURRENCIES.find(c => c.code === snap.val());
        if (saved) setCurrency(saved);
      }
    });
  }, [username]);

  async function saveCurrency(c: Currency) {
    setCurrency(c);
    setShowCurrPicker(false);
    await set(ref(db, `kundalik/${username}/settings/currency`), c.code);
  }

  // ─── CALENDAR STATE ──────────────────────────────────────────
  const [viewDate, setViewDate] = useState(new Date());
  const [workDays, setWorkDays] = useState<Record<string, WorkDay>>({});
  const [editDay,  setEditDay]  = useState<string | null>(null);
  const [editEarned, setEditEarned] = useState("");
  const [editSpent,  setEditSpent]  = useState("");
  const [editNote,   setEditNote]   = useState("");
  const [editWorked, setEditWorked] = useState(true);
  const [saving, setSaving] = useState(false);

  // ─── TASKS STATE ─────────────────────────────────────────────
  const [tasks, setTasks]         = useState<DailyTask[]>([]);
  const [newTask, setNewTask]     = useState("");
  const [taskFilter, setTaskFilter] = useState<"all" | "active" | "done">("all");

  // ─── MOOD STATE ──────────────────────────────────────────────
  const [moods, setMoods]             = useState<MoodEntry[]>([]);
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [moodNote, setMoodNote]       = useState("");
  const [todayMood, setTodayMood]     = useState<MoodEntry | null>(null);

  // ─── FIREBASE LISTENERS ──────────────────────────────────────
  useEffect(() => {
    const y = viewDate.getFullYear();
    const m = pad2(viewDate.getMonth() + 1);
    const u = onValue(ref(db, `kundalik/${username}/calendar/${y}/${m}`), snap => {
      setWorkDays(snap.exists() ? (snap.val() as Record<string, WorkDay>) : {});
    });
    return () => u();
  }, [username, viewDate]);

  useEffect(() => {
    const u = onValue(ref(db, `kundalik/${username}/tasks`), snap => {
      if (!snap.exists()) { setTasks([]); return; }
      const list: DailyTask[] = [];
      snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => b.ts - a.ts);
      setTasks(list);
    });
    return () => u();
  }, [username]);

  useEffect(() => {
    const u = onValue(ref(db, `kundalik/${username}/moods`), snap => {
      if (!snap.exists()) { setMoods([]); return; }
      const list: MoodEntry[] = [];
      snap.forEach(c => { list.push(c.val() as MoodEntry); });
      list.sort((a, b) => b.ts - a.ts);
      setMoods(list);
      const tm = list.find(m => m.date === today);
      setTodayMood(tm || null);
      if (tm) setSelectedMood(tm.mood);
    });
    return () => u();
  }, [username, today]);

  // ─── CALENDAR HELPERS ────────────────────────────────────────
  const year       = viewDate.getFullYear();
  const month      = viewDate.getMonth();
  const offset     = (new Date(year, month, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const monthStats = Object.values(workDays).reduce(
    (acc, d) => ({
      workedDays:  acc.workedDays  + (d.worked ? 1 : 0),
      totalEarned: acc.totalEarned + (d.earned || 0),
      totalSpent:  acc.totalSpent  + (d.spent  || 0),
    }),
    { workedDays: 0, totalEarned: 0, totalSpent: 0 }
  );

  function openEdit(dateStr: string) {
    const ex = workDays[dateStr.split("-")[2]];
    setEditDay(dateStr);
    setEditEarned(ex?.earned ? String(ex.earned) : "");
    setEditSpent(ex?.spent   ? String(ex.spent)  : "");
    setEditNote(ex?.note  || "");
    setEditWorked(ex?.worked ?? true);
  }

  async function saveDay() {
    if (!editDay) return;
    setSaving(true);
    const [y, m, d] = editDay.split("-");
    await set(ref(db, `kundalik/${username}/calendar/${y}/${m}/${d}`), {
      date: editDay,
      worked: editWorked,
      earned: parseFloat(editEarned) || 0,
      spent:  parseFloat(editSpent)  || 0,
      note:   editNote,
    } as WorkDay);
    setSaving(false);
    setEditDay(null);
  }

  async function deleteDay() {
    if (!editDay) return;
    const [y, m, d] = editDay.split("-");
    await remove(ref(db, `kundalik/${username}/calendar/${y}/${m}/${d}`));
    setEditDay(null);
  }

  // ─── TASKS HELPERS ───────────────────────────────────────────
  async function addTask() {
    if (!newTask.trim()) return;
    if (!isPremium && tasks.length >= 10) {
      alert("Oddiy foydalanuvchilar uchun max 10 ta vazifa. Premium oling!");
      return;
    }
    await push(ref(db, `kundalik/${username}/tasks`), { text: newTask.trim(), done: false, ts: Date.now() });
    setNewTask("");
  }

  async function toggleTask(id: string, done: boolean) {
    await update(ref(db, `kundalik/${username}/tasks/${id}`), { done: !done });
  }

  async function deleteTask(id: string) {
    await remove(ref(db, `kundalik/${username}/tasks/${id}`));
  }

  // ─── MOOD HELPERS ────────────────────────────────────────────
  async function saveMood() {
    if (!selectedMood) return;
    const entry: MoodEntry = { date: today, mood: selectedMood, note: moodNote, ts: Date.now() };
    const snap = await get(ref(db, `kundalik/${username}/moods`));
    if (snap.exists()) {
      let found = false;
      snap.forEach(c => { if (c.val().date === today) { update(ref(db, `kundalik/${username}/moods/${c.key}`), entry); found = true; } });
      if (!found) await push(ref(db, `kundalik/${username}/moods`), entry);
    } else {
      await push(ref(db, `kundalik/${username}/moods`), entry);
    }
    setMoodNote("");
  }

  const filteredTasks = tasks.filter(t =>
    taskFilter === "all" ? true : taskFilter === "done" ? t.done : !t.done
  );
  const ac = accentColor;

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 overflow-hidden">

      {/* ── Header ── */}
      <div className="flex-shrink-0 px-4 pt-4 pb-3 border-b border-slate-800/40 relative overflow-hidden" style={{ background: "rgba(8,12,25,0.98)", backdropFilter: "blur(20px)" }}>
        <div className="absolute top-0 left-0 right-0 h-px pointer-events-none" style={{ background: `linear-gradient(90deg,transparent,${ac}55,transparent)` }} />
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl" style={{ background: `${ac}20`, border: `1px solid ${ac}35` }}>📅</div>
            <div>
              <h1 className="text-sm font-black tracking-tight text-white">Kundalik</h1>
              <p className="text-[10px] text-slate-500 font-mono">Shaxsiy planer · @{username}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Today mood badge */}
            {todayMood && (
              <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-xl">
                <span className="text-base">{todayMood.mood}</span>
                <span className="text-[9px] text-slate-500 hidden sm:block">Kayfiyat</span>
              </div>
            )}
            {/* Currency picker button */}
            <button
              onClick={() => setShowCurrPicker(true)}
              className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 hover:border-slate-500 px-3 py-1.5 rounded-xl transition active:scale-95"
              title="Valyutani tanlash"
            >
              <span className="text-base">{currency.flag}</span>
              <span className="text-xs font-bold" style={{ color: ac }}>{currency.code}</span>
              <span className="text-slate-600 text-[10px]">▾</span>
            </button>
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex gap-1">
          {([
            { id: "calendar", icon: "💰", label: "Kalendar" },
            { id: "tasks",    icon: "✅", label: "Vazifalar" },
            { id: "mood",     icon: "😊", label: "Kayfiyat"  },
            { id: "stats",    icon: "📊", label: "Statistika"},
          ] as { id: KTab; icon: string; label: string }[]).map(t => (
            <button key={t.id} onClick={() => setKTab(t.id)}
              className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-xl text-xs font-bold transition ${
                kTab === t.id ? "text-white" : "text-slate-500 hover:text-slate-300 bg-slate-900/60 hover:bg-slate-900"
              }`}
              style={kTab === t.id ? { background: `linear-gradient(135deg,${ac}33,${ac}22)`, border: `1px solid ${ac}44`, color: ac } : {}}>
              <span>{t.icon}</span>
              <span className="hidden sm:inline">{t.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 overflow-y-auto">

        {/* ══ MONEY CALENDAR ══ */}
        {kTab === "calendar" && (
          <div className="p-4 space-y-4">
            {/* Month nav */}
            <div className="flex items-center justify-between">
              <button onClick={() => setViewDate(d => new Date(d.getFullYear(), d.getMonth()-1, 1))}
                className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-lg hover:bg-slate-800 transition active:scale-95">‹</button>
              <h2 className="text-base font-black text-white">{MONTH_NAMES_UZ[month]} {year}</h2>
              <button onClick={() => setViewDate(d => new Date(d.getFullYear(), d.getMonth()+1, 1))}
                className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-lg hover:bg-slate-800 transition active:scale-95">›</button>
            </div>

            {/* Month summary cards */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "Ish kunlar", value: monthStats.workedDays,                              icon: "📆", color: "#22d3ee" },
                { label: "Daromad",    value: formatMoney(monthStats.totalEarned, currency),       icon: "💵", color: "#22c55e" },
                { label: "Xarajat",   value: formatMoney(monthStats.totalSpent,  currency),       icon: "💸", color: "#f97316" },
              ].map(s => (
                <div key={s.label} className="rounded-2xl p-3 text-center border border-slate-800/60" style={{ background: `${s.color}11` }}>
                  <p className="text-xl">{s.icon}</p>
                  <p className="text-sm font-black" style={{ color: s.color }}>{s.value}</p>
                  <p className="text-[9px] text-slate-500 mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Net savings */}
            {(monthStats.totalEarned > 0 || monthStats.totalSpent > 0) && (() => {
              const net = monthStats.totalEarned - monthStats.totalSpent;
              return (
                <div className="rounded-2xl p-3 border border-slate-700/40 flex items-center justify-between"
                  style={{ background: net >= 0 ? "#15803d22" : "#dc262622" }}>
                  <span className="text-sm text-slate-400">Net tejash:</span>
                  <span className={`text-base font-black ${net >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {net >= 0 ? "+" : ""}{formatMoney(net, currency)}
                  </span>
                </div>
              );
            })()}

            {/* Calendar grid */}
            <div className="rounded-2xl border border-slate-800/60 overflow-hidden" style={{ background: "#0a0f1e" }}>
              <div className="grid grid-cols-7 border-b border-slate-800/60">
                {DAY_NAMES_UZ.map(d => (
                  <div key={d} className="py-2 text-center text-[10px] font-bold text-slate-600">{d}</div>
                ))}
              </div>
              <div className="grid grid-cols-7">
                {Array.from({ length: offset }).map((_, i) => (
                  <div key={`e${i}`} className="border border-slate-800/20 min-h-[52px]" />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day     = i + 1;
                  const dateStr = `${year}-${pad2(month+1)}-${pad2(day)}`;
                  const data    = workDays[pad2(day)];
                  const isToday = dateStr === today;
                  const isFuture = dateStr > today;
                  return (
                    <button key={day} onClick={() => !isFuture && openEdit(dateStr)} disabled={isFuture}
                      className={`relative border border-slate-800/20 min-h-[52px] p-1 flex flex-col items-center transition hover:bg-slate-800/40 active:scale-95 ${isFuture ? "opacity-25 cursor-default" : "cursor-pointer"}`}
                      style={isToday ? { background: `${ac}18`, borderColor: `${ac}44` } : data?.worked ? { background: "#15803d18" } : {}}>
                      <span className="text-[11px] font-bold mb-0.5" style={isToday ? { color: ac } : { color: "#64748b" }}>{day}</span>
                      {data?.worked && (
                        <span className="text-[8px] font-bold text-green-400 leading-none">
                          {data.earned > 0 ? `+${formatMoney(data.earned, currency)}` : "✓"}
                        </span>
                      )}
                      {(data?.spent ?? 0) > 0 && (
                        <span className="text-[8px] text-orange-400 leading-none">-{formatMoney(data.spent, currency)}</span>
                      )}
                      {data?.note && <span className="text-[8px] text-slate-600 leading-none">📝</span>}
                    </button>
                  );
                })}
              </div>
            </div>
            <p className="text-[10px] text-slate-600 text-center">Kunni bosing → ma'lumot kiriting</p>
          </div>
        )}

        {/* ══ TASKS ══ */}
        {kTab === "tasks" && (
          <div className="p-4 space-y-4">
            <div className="flex gap-2">
              <input value={newTask} onChange={e => setNewTask(e.target.value)}
                onKeyDown={e => e.key === "Enter" && addTask()}
                placeholder="Yangi vazifa qo'shish..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-slate-500 placeholder-slate-600 transition" />
              <button onClick={addTask} className="px-4 py-2 rounded-xl font-bold text-sm text-white active:scale-95 transition"
                style={{ background: `linear-gradient(135deg,${ac},#6366f1)` }}>+</button>
            </div>
            <div className="flex gap-1">
              {(["all","active","done"] as const).map(f => (
                <button key={f} onClick={() => setTaskFilter(f)}
                  className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition ${taskFilter===f ? "text-white" : "text-slate-500 bg-slate-900/60 hover:text-slate-300"}`}
                  style={taskFilter===f ? { background:`${ac}33`, color:ac, border:`1px solid ${ac}44` } : {}}>
                  {f==="all" ? "Hammasi" : f==="active" ? "Faol" : "Bajarildi"}
                  <span className="ml-1 text-[9px]">({f==="all" ? tasks.length : f==="done" ? tasks.filter(t=>t.done).length : tasks.filter(t=>!t.done).length})</span>
                </button>
              ))}
            </div>
            {tasks.length > 0 && (
              <div>
                <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                  <span>Bajarildi: {tasks.filter(t=>t.done).length}/{tasks.length}</span>
                  <span>{Math.round((tasks.filter(t=>t.done).length/tasks.length)*100)}%</span>
                </div>
                <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-500"
                    style={{ width:`${(tasks.filter(t=>t.done).length/tasks.length)*100}%`, background:`linear-gradient(90deg,${ac},#22c55e)` }} />
                </div>
              </div>
            )}
            <div className="space-y-2">
              {filteredTasks.length === 0 && (
                <div className="text-center py-12 text-slate-600"><p className="text-3xl mb-2">📝</p><p className="text-sm">Vazifalar yo'q</p></div>
              )}
              {filteredTasks.map(task => (
                <div key={task.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition ${task.done ? "border-slate-800/30 opacity-60" : "border-slate-800/60"}`}
                  style={{ background: task.done ? "#0a0f1e" : "#0d1226" }}>
                  <button onClick={() => toggleTask(task.id, task.done)}
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition active:scale-95 ${task.done ? "border-green-500 bg-green-500" : "border-slate-600 hover:border-slate-400"}`}>
                    {task.done && <span className="text-[10px] text-white font-bold">✓</span>}
                  </button>
                  <p className={`flex-1 text-sm ${task.done ? "line-through text-slate-500" : "text-slate-200"}`}>{task.text}</p>
                  <button onClick={() => deleteTask(task.id)} className="text-slate-700 hover:text-red-400 text-xs transition px-1">✕</button>
                </div>
              ))}
            </div>
            {!isPremium && tasks.length >= 8 && (
              <div className="text-center py-3 px-4 rounded-xl border border-amber-800/40 bg-amber-950/20">
                <p className="text-xs text-amber-400">👑 Premium olsangiz 50 ta vazifa qo'sha olasiz (hozir max 10)</p>
              </div>
            )}
          </div>
        )}

        {/* ══ MOOD ══ */}
        {kTab === "mood" && (
          <div className="p-4 space-y-4">
            <div className="rounded-2xl border border-slate-800/60 p-5" style={{ background: "#0a0f1e" }}>
              <p className="text-sm font-bold text-slate-300 mb-4 text-center">Bugun kayfiyatingiz qanday?</p>
              <div className="flex justify-center gap-3 mb-4">
                {MOODS.map(m => (
                  <button key={m.emoji} onClick={() => setSelectedMood(m.emoji)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-2xl transition active:scale-95 ${selectedMood===m.emoji ? "scale-110" : "opacity-60 hover:opacity-90"}`}
                    style={selectedMood===m.emoji ? { background:`${m.color}22`, border:`2px solid ${m.color}66` } : { border:"2px solid transparent" }}>
                    <span className="text-3xl">{m.emoji}</span>
                    <span className="text-[9px] text-slate-400">{m.label}</span>
                  </button>
                ))}
              </div>
              <input value={moodNote} onChange={e => setMoodNote(e.target.value)}
                placeholder="Izoh qoldiring (ixtiyoriy)..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-300 outline-none focus:border-slate-500 mb-3 placeholder-slate-600" />
              <button onClick={saveMood} disabled={!selectedMood}
                className="w-full py-2.5 rounded-xl font-bold text-sm text-white transition active:scale-95 disabled:opacity-40"
                style={{ background: selectedMood ? `linear-gradient(135deg,${ac},#6366f1)` : "#1e293b" }}>
                {todayMood ? "✏️ Yangilash" : "✅ Saqlash"}
              </button>
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Kayfiyat tarixi</h3>
              <div className="space-y-2">
                {moods.length === 0 && <p className="text-center text-slate-600 text-sm py-6">Hali yozuv yo'q</p>}
                {moods.slice(0, isPremium ? 30 : 7).map((m, i) => {
                  const def = MOODS.find(x => x.emoji === m.mood)!;
                  return (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-xl border border-slate-800/40" style={{ background: "#0a0f1e" }}>
                      <span className="text-2xl">{m.mood}</span>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold" style={{ color: def.color }}>{def.label}</span>
                          <span className="text-[10px] text-slate-600">{m.date}</span>
                        </div>
                        {m.note && <p className="text-[11px] text-slate-400 mt-0.5">{m.note}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ══ STATS ══ */}
        {kTab === "stats" && (
          <StatsTab username={username} accentColor={accentColor} isPremium={isPremium} currency={currency} />
        )}
      </div>

      {/* ══ EDIT DAY MODAL ══ */}
      {editDay && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(16px)" }}
          onClick={() => setEditDay(null)}>
          <div className="w-full max-w-sm rounded-3xl border border-slate-700/60 overflow-hidden"
            style={{ background: "linear-gradient(180deg,#0f172a,#070d1a)" }}
            onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-slate-800/60 flex items-center justify-between">
              <div>
                <p className="text-lg font-black text-white">{editDay}</p>
                <p className="text-[11px] text-slate-500 font-mono">Kun ma'lumotini kiriting</p>
              </div>
              <div className="flex items-center gap-2">
                {/* inline currency badge */}
                <span className="flex items-center gap-1 text-[11px] text-slate-400 bg-slate-800 px-2 py-1 rounded-lg">
                  {currency.flag} {currency.code}
                </span>
                <button onClick={() => setEditDay(null)} className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 text-sm">✕</button>
              </div>
            </div>
            <div className="p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-300">Bugun ishga chiqdimmi?</span>
                <button onClick={() => setEditWorked(w => !w)}
                  className={`w-12 h-6 rounded-full transition-all relative ${editWorked ? "bg-green-500" : "bg-slate-700"}`}>
                  <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${editWorked ? "left-6" : "left-0.5"}`} />
                </button>
              </div>
              {editWorked && (
                <>
                  <div>
                    <label className="text-xs text-slate-400 font-mono mb-1 block">
                      Daromad ({currency.flag} {currency.name})
                    </label>
                    <input type="number" value={editEarned} onChange={e => setEditEarned(e.target.value)} placeholder="0"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-green-500 transition" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400 font-mono mb-1 block">
                      Xarajat ({currency.flag} {currency.name})
                    </label>
                    <input type="number" value={editSpent} onChange={e => setEditSpent(e.target.value)} placeholder="0"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-orange-500 transition" />
                  </div>
                </>
              )}
              <div>
                <label className="text-xs text-slate-400 font-mono mb-1 block">Izoh (ixtiyoriy)</label>
                <textarea value={editNote} onChange={e => setEditNote(e.target.value)}
                  placeholder="Bugun haqida yozing..." rows={2}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-300 outline-none focus:border-slate-500 transition resize-none placeholder-slate-600" />
              </div>
              <div className="flex gap-2">
                <button onClick={saveDay} disabled={saving}
                  className="flex-1 py-3 rounded-xl font-bold text-sm text-white transition active:scale-95"
                  style={{ background: `linear-gradient(135deg,${accentColor},#6366f1)` }}>
                  {saving ? "Saqlanmoqda..." : "✅ Saqlash"}
                </button>
                {workDays[editDay.split("-")[2]] && (
                  <button onClick={deleteDay}
                    className="px-4 py-3 rounded-xl font-bold text-sm text-red-400 bg-red-950/30 border border-red-900/40 hover:bg-red-950/50 transition active:scale-95">
                    🗑️
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══ CURRENCY PICKER MODAL ══ */}
      {showCurrPicker && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(16px)" }}
          onClick={() => setShowCurrPicker(false)}>
          <div className="w-full max-w-xs rounded-3xl border border-slate-700/60 overflow-hidden"
            style={{ background: "linear-gradient(180deg,#0f172a,#070d1a)" }}
            onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-slate-800/60 flex items-center justify-between">
              <div>
                <p className="text-base font-black text-white">Valyutani tanlang</p>
                <p className="text-[10px] text-slate-500 font-mono">Barcha hisoblar shu valyutada</p>
              </div>
              <button onClick={() => setShowCurrPicker(false)} className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 text-sm">✕</button>
            </div>
            <div className="p-3 space-y-1 max-h-[60vh] overflow-y-auto">
              {CURRENCIES.map(c => {
                const active = c.code === currency.code;
                return (
                  <button key={c.code} onClick={() => saveCurrency(c)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition active:scale-95 ${active ? "border" : "hover:bg-slate-800/60"}`}
                    style={active ? { background: `${ac}22`, borderColor: `${ac}55` } : {}}>
                    <span className="text-2xl">{c.flag}</span>
                    <div className="flex-1 text-left">
                      <p className="text-sm font-bold text-white">{c.name}</p>
                      <p className="text-[10px] text-slate-500">{c.code} · {c.symbol}</p>
                    </div>
                    {active && (
                      <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black text-white"
                        style={{ background: ac }}>✓</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════ STATS TAB ═══════
function StatsTab({ username, accentColor, isPremium, currency }: {
  username: string; accentColor: string; isPremium: boolean; currency: Currency;
}) {
  const [allCalendar, setAllCalendar] = useState<WorkDay[]>([]);
  const [allMoods,    setAllMoods]    = useState<MoodEntry[]>([]);
  const [loading,     setLoading]     = useState(true);

  useEffect(() => {
    const now = new Date();
    const promises: Promise<void>[] = [];
    const days: WorkDay[] = [];
    const moods: MoodEntry[] = [];
    for (let i = 0; i < 6; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const y = d.getFullYear();
      const m = pad2(d.getMonth() + 1);
      promises.push(get(ref(db, `kundalik/${username}/calendar/${y}/${m}`)).then(snap => {
        if (snap.exists()) snap.forEach(c => { days.push(c.val() as WorkDay); });
      }));
    }
    promises.push(get(ref(db, `kundalik/${username}/moods`)).then(snap => {
      if (snap.exists()) snap.forEach(c => { moods.push(c.val() as MoodEntry); });
    }));
    Promise.all(promises).then(() => { setAllCalendar(days); setAllMoods(moods); setLoading(false); });
  }, [username]);

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <div className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: accentColor, borderTopColor: "transparent" }} />
    </div>
  );

  const totalEarned    = allCalendar.reduce((a, d) => a + (d.earned || 0), 0);
  const totalSpent     = allCalendar.reduce((a, d) => a + (d.spent  || 0), 0);
  const totalWorked    = allCalendar.filter(d => d.worked).length;
  const avgPerDay      = totalWorked > 0 ? totalEarned / totalWorked : 0;
  const moodCounts     = allMoods.reduce<Record<string, number>>((acc, m) => { acc[m.mood] = (acc[m.mood] || 0) + 1; return acc; }, {});
  const bestMood       = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0];

  const now = new Date();
  const monthlyData = Array.from({ length: 5 }, (_, i) => {
    const d  = new Date(now.getFullYear(), now.getMonth() - (4-i), 1);
    const y  = d.getFullYear();
    const m  = pad2(d.getMonth() + 1);
    const md = allCalendar.filter(wd => { const [wy, wm] = wd.date.split("-"); return wy===String(y) && wm===m; });
    return {
      label:  MONTH_NAMES_UZ[d.getMonth()].slice(0, 3),
      earned: md.reduce((a, d) => a + (d.earned || 0), 0),
      spent:  md.reduce((a, d) => a + (d.spent  || 0), 0),
      days:   md.filter(d => d.worked).length,
    };
  });
  const maxEarned = Math.max(...monthlyData.map(m => m.earned), 1);

  return (
    <div className="p-4 space-y-5">
      {/* Currency badge */}
      <div className="flex items-center gap-2 bg-slate-900/60 border border-slate-800/50 rounded-xl px-3 py-2 w-fit">
        <span className="text-sm">{currency.flag}</span>
        <span className="text-xs text-slate-400">Valyuta: <span className="font-bold text-white">{currency.name} ({currency.symbol})</span></span>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Jami daromad (6 oy)", value: formatMoney(totalEarned, currency), icon: "💵", color: "#22c55e" },
          { label: "Jami xarajat (6 oy)", value: formatMoney(totalSpent,  currency), icon: "💸", color: "#f97316" },
          { label: "Ish kunlar soni",      value: `${totalWorked} kun`,              icon: "📆", color: "#22d3ee" },
          { label: "Kunlik o'rtacha",      value: formatMoney(avgPerDay,  currency), icon: "📈", color: "#a855f7" },
        ].map(s => (
          <div key={s.label} className="rounded-2xl p-4 border border-slate-800/40" style={{ background: `${s.color}11` }}>
            <p className="text-2xl mb-1">{s.icon}</p>
            <p className="text-base font-black" style={{ color: s.color }}>{s.value}</p>
            <p className="text-[9px] text-slate-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Net savings */}
      <div className="rounded-2xl p-4 border border-slate-700/40 flex items-center justify-between"
        style={{ background: totalEarned-totalSpent >= 0 ? "#15803d18" : "#dc262618" }}>
        <div>
          <p className="text-xs text-slate-400">Jami tejash</p>
          <p className={`text-xl font-black ${totalEarned-totalSpent >= 0 ? "text-green-400" : "text-red-400"}`}>
            {totalEarned-totalSpent >= 0 ? "+" : ""}{formatMoney(totalEarned-totalSpent, currency)}
          </p>
        </div>
        <span className="text-4xl">{totalEarned-totalSpent >= 0 ? "🎉" : "📉"}</span>
      </div>

      {/* Monthly bar chart */}
      <div>
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Oylik daromad</h3>
        <div className="rounded-2xl border border-slate-800/40 p-4" style={{ background: "#0a0f1e" }}>
          <div className="flex items-end gap-2 h-28">
            {monthlyData.map((m, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col justify-end" style={{ height: "80px" }}>
                  <div className="w-full rounded-t-md transition-all duration-500"
                    style={{ height: `${(m.earned/maxEarned)*76}px`, background: `linear-gradient(180deg,${accentColor},${accentColor}88)`, minHeight: m.earned > 0 ? "4px" : "0px" }} />
                </div>
                <span className="text-[8px] text-slate-500 font-mono">{m.label}</span>
                {m.earned > 0 && <span className="text-[7px] text-green-400">{formatMoney(m.earned, currency)}</span>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Mood stats */}
      {allMoods.length > 0 && (
        <div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Kayfiyat statistikasi</h3>
          <div className="rounded-2xl border border-slate-800/40 p-4 space-y-2" style={{ background: "#0a0f1e" }}>
            {MOODS.map(mood => {
              const count = moodCounts[mood.emoji] || 0;
              const pct   = allMoods.length > 0 ? (count / allMoods.length) * 100 : 0;
              return (
                <div key={mood.emoji} className="flex items-center gap-3">
                  <span className="text-xl w-7 text-center">{mood.emoji}</span>
                  <div className="flex-1">
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: mood.color }} />
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 w-8 text-right">{count}x</span>
                </div>
              );
            })}
            {bestMood && (
              <p className="text-[10px] text-slate-500 text-center pt-1">Ko'p kayfiyat: {bestMood[0]} ({bestMood[1]} marta)</p>
            )}
          </div>
        </div>
      )}

      {!isPremium && (
        <div className="text-center py-3 px-4 rounded-xl border border-amber-800/40 bg-amber-950/20">
          <p className="text-xs text-amber-400">👑 Premium: Ko'proq statistika, 1 yillik tarix va eksport funksiyasi</p>
        </div>
      )}
    </div>
  );
}
