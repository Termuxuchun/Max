import { useState, useEffect } from "react";
import { ref, push, onValue, update, remove, get, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import { ShoppingBag, Plus, Star, Search, Tag, X, CheckCircle2, Filter, Flame, Clock, TrendingUp, ChevronLeft, Trash2, Heart, Eye, AlertCircle } from "lucide-react";

interface MarketItem {
  id: string;
  seller: string;
  title: string;
  desc: string;
  category: string;
  price: number;
  icon: string;
  ts: number;
  likes?: Record<string, boolean>;
  views?: number;
  sold?: boolean;
}

interface Props {
  username: string;
  accentColor: string;
  starsBalance: number;
}

const CATEGORIES = [
  { id: "all",      icon: "🌐", label: "Barchasi" },
  { id: "digital",  icon: "💾", label: "Raqamli" },
  { id: "service",  icon: "🛠️", label: "Xizmat" },
  { id: "account",  icon: "👤", label: "Akkaunt" },
  { id: "game",     icon: "🎮", label: "O'yin" },
  { id: "art",      icon: "🎨", label: "San'at" },
  { id: "lesson",   icon: "📚", label: "Dars" },
  { id: "other",    icon: "📦", label: "Boshqa" },
];

const SORT_OPTIONS = [
  { id: "new",    icon: <Clock className="w-3.5 h-3.5" />,    label: "Yangi" },
  { id: "cheap",  icon: <Tag className="w-3.5 h-3.5" />,      label: "Arzon" },
  { id: "hot",    icon: <Flame className="w-3.5 h-3.5" />,    label: "Mashhur" },
];

export default function MarketplaceSection({ username, accentColor, starsBalance }: Props) {
  const [items, setItems] = useState<MarketItem[]>([]);
  const [tab, setTab] = useState<"browse" | "sell" | "myitems">("browse");
  const [selectedCat, setSelectedCat] = useState("all");
  const [sort, setSort] = useState("new");
  const [search, setSearch] = useState("");
  const [selectedItem, setSelectedItem] = useState<MarketItem | null>(null);
  const [buying, setBuying] = useState(false);
  const [buySuccess, setBuySuccess] = useState(false);
  const [buyError, setBuyError] = useState("");

  // Sell form
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [price, setPrice] = useState("10");
  const [category, setCategory] = useState("digital");
  const [icon, setIcon] = useState("💾");
  const [posting, setPosting] = useState(false);
  const [postSuccess, setPostSuccess] = useState(false);

  const ICONS = ["💾","🎮","🎨","📚","🛠️","👤","📦","🎵","🎬","💡","🔧","🌟","💎","🚀","🎯","📱"];

  useEffect(() => {
    const unsub = onValue(ref(db, "marketplace"), snap => {
      const list: MarketItem[] = [];
      if (snap.exists()) {
        snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      }
      setItems(list.reverse());
    });
    return unsub;
  }, []);

  async function postItem() {
    if (!title.trim() || !desc.trim() || !price || posting) return;
    const p = parseInt(price);
    if (isNaN(p) || p < 1) return;
    setPosting(true);
    await push(ref(db, "marketplace"), {
      seller: username, title: title.trim(), desc: desc.trim(),
      category, price: p, icon, ts: Date.now(), sold: false
    });
    setTitle(""); setDesc(""); setPrice("10"); setCategory("digital"); setIcon("💾");
    setPosting(false);
    setPostSuccess(true);
    setTimeout(() => setPostSuccess(false), 3000);
  }

  async function buyItem(item: MarketItem) {
    if (starsBalance < item.price) { setBuyError("Yetarli yulduz yo'q!"); return; }
    if (item.seller === username) { setBuyError("O'z mahsulotingizni sotib ololmaysiz!"); return; }
    setBuying(true);
    setBuyError("");
    try {
      await update(ref(db, `stars/${username}`), { balance: starsBalance - item.price });
      await update(ref(db, `stars/${item.seller}`), { balance: 0 });
      const sellerSnap = await get(ref(db, `stars/${item.seller}/balance`));
      const sellerBal = sellerSnap.val() || 0;
      await update(ref(db, `stars/${item.seller}`), { balance: sellerBal + item.price });
      await push(ref(db, `stars/${username}/transactions`), {
        type: "purchase", amount: -item.price, from: username, to: item.seller,
        note: `Bozor: ${item.title}`, ts: Date.now()
      });
      await push(ref(db, `stars/${item.seller}/transactions`), {
        type: "receive", amount: item.price, from: username, to: item.seller,
        note: `Bozor sotish: ${item.title}`, ts: Date.now()
      });
      setBuySuccess(true);
      setTimeout(() => { setBuySuccess(false); setSelectedItem(null); }, 2500);
    } catch {
      setBuyError("Xatolik yuz berdi.");
    }
    setBuying(false);
  }

  async function toggleLike(item: MarketItem) {
    const liked = item.likes?.[username];
    await update(ref(db, `marketplace/${item.id}/likes`), { [username]: liked ? null : true });
  }

  async function deleteItem(id: string) {
    await remove(ref(db, `marketplace/${id}`));
  }

  function getFiltered() {
    let res = items.filter(i => !i.sold);
    if (selectedCat !== "all") res = res.filter(i => i.category === selectedCat);
    if (search) res = res.filter(i =>
      i.title.toLowerCase().includes(search.toLowerCase()) ||
      i.seller.toLowerCase().includes(search.toLowerCase())
    );
    if (sort === "cheap") res = [...res].sort((a, b) => a.price - b.price);
    if (sort === "hot") res = [...res].sort((a, b) => Object.keys(b.likes || {}).length - Object.keys(a.likes || {}).length);
    return res;
  }

  const myItems = items.filter(i => i.seller === username);
  const filtered = getFiltered();

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      {/* Header */}
      <div className="flex-shrink-0 px-4 py-3 border-b border-slate-800/60 flex items-center justify-between"
        style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(12px)" }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xl"
            style={{ background: `linear-gradient(135deg,${accentColor}44,#4f46e544)`, border: `1px solid ${accentColor}33` }}>
            🛍️
          </div>
          <div>
            <p className="text-sm font-bold text-white">Bozor</p>
            <p className="text-[10px] text-slate-500">{items.filter(i=>!i.sold).length} ta mahsulot</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl" style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.2)" }}>
          <Star className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-sm font-bold text-amber-300">{starsBalance}</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex-shrink-0 flex px-4 pt-3 gap-1.5">
        {[
          { id: "browse", label: "Barchasi", icon: "🌐" },
          { id: "sell",   label: "Sotish",   icon: "➕" },
          { id: "myitems",label: "Menim",    icon: "📦" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition"
            style={{
              background: tab === t.id ? `linear-gradient(135deg,${accentColor}33,#4f46e533)` : "rgba(30,41,59,0.4)",
              color: tab === t.id ? accentColor : "#64748b",
              border: tab === t.id ? `1px solid ${accentColor}44` : "1px solid transparent"
            }}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* Browse Tab */}
      {tab === "browse" && (
        <div className="flex-1 overflow-y-auto">
          {/* Search */}
          <div className="px-4 py-2.5">
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800">
              <Search className="w-3.5 h-3.5 text-slate-500" />
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Mahsulot qidiring..." className="flex-1 bg-transparent text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none" />
            </div>
          </div>

          {/* Categories */}
          <div className="flex gap-2 px-4 pb-2 overflow-x-auto scrollbar-none">
            {CATEGORIES.map(cat => (
              <button key={cat.id} onClick={() => setSelectedCat(cat.id)}
                className="flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition"
                style={{
                  background: selectedCat === cat.id ? accentColor + "22" : "rgba(30,41,59,0.4)",
                  color: selectedCat === cat.id ? accentColor : "#64748b",
                  border: selectedCat === cat.id ? `1px solid ${accentColor}44` : "1px solid transparent"
                }}>
                {cat.icon} {cat.label}
              </button>
            ))}
          </div>

          {/* Sort */}
          <div className="flex gap-2 px-4 pb-3">
            {SORT_OPTIONS.map(s => (
              <button key={s.id} onClick={() => setSort(s.id)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium transition"
                style={{
                  background: sort === s.id ? "#1e293b" : "transparent",
                  color: sort === s.id ? "#e2e8f0" : "#475569"
                }}>
                {s.icon} {s.label}
              </button>
            ))}
          </div>

          {/* Items grid */}
          <div className="px-3 pb-6 grid grid-cols-2 gap-2.5">
            {filtered.length === 0 && (
              <div className="col-span-2 text-center py-16">
                <div className="text-5xl mb-3">🛒</div>
                <p className="text-slate-500 text-sm">Hali mahsulot yo'q</p>
                <p className="text-slate-600 text-xs mt-1">Birinchi bo'lib nimadir soting!</p>
              </div>
            )}
            {filtered.map(item => {
              const likeCount = Object.keys(item.likes || {}).length;
              const liked = !!item.likes?.[username];
              return (
                <button key={item.id} onClick={() => setSelectedItem(item)}
                  className="flex flex-col gap-2 p-3 rounded-2xl border text-left transition hover:border-slate-600 active:scale-95"
                  style={{ background: "rgba(15,23,42,0.8)", borderColor: "rgba(51,65,85,0.6)" }}>
                  <div className="flex items-start justify-between">
                    <div className="text-2xl">{item.icon}</div>
                    <button onClick={e => { e.stopPropagation(); toggleLike(item); }}
                      className="text-xs flex items-center gap-0.5 transition"
                      style={{ color: liked ? "#f43f5e" : "#475569" }}>
                      <Heart className="w-3.5 h-3.5" fill={liked ? "currentColor" : "none"} />
                      {likeCount > 0 && <span>{likeCount}</span>}
                    </button>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-100 line-clamp-1">{item.title}</p>
                    <p className="text-[10px] text-slate-500 line-clamp-2 mt-0.5">{item.desc}</p>
                  </div>
                  <div className="flex items-center justify-between mt-auto pt-1">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-400" />
                      <span className="text-xs font-bold text-amber-300">{item.price}</span>
                    </div>
                    <span className="text-[9px] text-slate-600">@{item.seller}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Sell Tab */}
      {tab === "sell" && (
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {postSuccess && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-green-950/40 border border-green-800/40 text-green-400 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4" /> Mahsulot muvaffaqiyatli joylandi!
            </div>
          )}
          <div className="p-4 rounded-2xl border border-slate-800/60 space-y-3" style={{ background: "rgba(15,23,42,0.6)" }}>
            <p className="text-sm font-bold text-slate-200">Yangi mahsulot joylash</p>

            <div className="grid grid-cols-4 gap-2">
              {ICONS.map(ic => (
                <button key={ic} onClick={() => setIcon(ic)}
                  className="text-xl py-2 rounded-xl transition"
                  style={{ background: icon === ic ? accentColor + "22" : "rgba(30,41,59,0.4)", border: icon === ic ? `1px solid ${accentColor}44` : "1px solid transparent" }}>
                  {ic}
                </button>
              ))}
            </div>

            <input value={title} onChange={e => setTitle(e.target.value)} maxLength={60}
              placeholder="Sarlavha (60 belgi)"
              className="w-full px-3 py-2.5 rounded-xl text-sm bg-slate-900/60 border border-slate-800 text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-600" />

            <textarea value={desc} onChange={e => setDesc(e.target.value)} maxLength={200} rows={3}
              placeholder="Tavsif (200 belgi)"
              className="w-full px-3 py-2.5 rounded-xl text-sm bg-slate-900/60 border border-slate-800 text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-600 resize-none" />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-[10px] text-slate-500 mb-1.5">Kategoriya</p>
                <div className="flex flex-col gap-1 max-h-28 overflow-y-auto">
                  {CATEGORIES.filter(c => c.id !== "all").map(cat => (
                    <button key={cat.id} onClick={() => setCategory(cat.id)}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-left transition"
                      style={{ background: category === cat.id ? accentColor + "22" : "rgba(30,41,59,0.4)", color: category === cat.id ? accentColor : "#64748b" }}>
                      {cat.icon} {cat.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-[10px] text-slate-500 mb-1.5">Narx (⭐ Yulduz)</p>
                <input type="number" value={price} onChange={e => setPrice(e.target.value)} min="1" max="10000"
                  className="w-full px-3 py-2.5 rounded-xl text-sm bg-slate-900/60 border border-slate-800 text-white focus:outline-none focus:border-violet-600" />
                <p className="text-[9px] text-slate-600 mt-1">Min: 1 · Max: 10,000</p>
              </div>
            </div>

            <button onClick={postItem} disabled={posting || !title.trim() || !desc.trim()}
              className="w-full py-3 rounded-xl text-sm font-bold text-white transition disabled:opacity-40"
              style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}>
              {posting ? "Joylanyapti..." : "📤 Joylash"}
            </button>
          </div>

          <div className="p-3 rounded-xl border border-amber-900/30 bg-amber-950/20 text-xs text-amber-400/80 space-y-1">
            <p className="font-bold">📋 Qoidalar:</p>
            <p>• Haqiqiy va foydali mahsulotlar joylashtiring</p>
            <p>• Aldamchi e'lonlar bloklash sababiga olib keladi</p>
            <p>• Xaridor to'liq xizmatni olishidan so'ng pul o'tadi</p>
          </div>
        </div>
      )}

      {/* My Items Tab */}
      {tab === "myitems" && (
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-2">
          {myItems.length === 0 && (
            <div className="text-center py-16">
              <div className="text-5xl mb-3">📦</div>
              <p className="text-slate-500 text-sm">Hali mahsulot joylamadingiz</p>
            </div>
          )}
          {myItems.map(item => (
            <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl border border-slate-800/60" style={{ background: "rgba(15,23,42,0.6)" }}>
              <div className="text-2xl">{item.icon}</div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-slate-100 truncate">{item.title}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[10px] text-amber-400 flex items-center gap-0.5"><Star className="w-2.5 h-2.5" />{item.price}</span>
                  <span className="text-[10px] text-slate-500">{Object.keys(item.likes||{}).length} ❤️</span>
                  <span className={`text-[10px] font-bold ${item.sold ? "text-green-400" : "text-slate-500"}`}>{item.sold ? "✅ Sotildi" : "🟡 Faol"}</span>
                </div>
              </div>
              <button onClick={() => deleteItem(item.id)} className="p-1.5 rounded-lg hover:bg-rose-950/40 text-slate-600 hover:text-rose-400 transition">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Item Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70" style={{ backdropFilter: "blur(8px)" }}
          onClick={() => { setSelectedItem(null); setBuyError(""); setBuySuccess(false); }}>
          <div className="w-full max-w-md rounded-t-3xl p-6 space-y-4" style={{ background: "#0f172a", border: "1px solid #1e293b" }}
            onClick={e => e.stopPropagation()}>
            <div className="flex items-start gap-4">
              <div className="text-4xl">{selectedItem.icon}</div>
              <div className="flex-1">
                <p className="font-bold text-white text-base">{selectedItem.title}</p>
                <p className="text-xs text-slate-500 mt-0.5">Sotuvchi: @{selectedItem.seller}</p>
              </div>
              <button onClick={() => { setSelectedItem(null); setBuyError(""); setBuySuccess(false); }}
                className="p-1 text-slate-500 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">{selectedItem.desc}</p>
            <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-slate-900/60">
              <span className="text-xs text-slate-500">Narx</span>
              <div className="flex items-center gap-1.5">
                <Star className="w-4 h-4 text-amber-400" />
                <span className="text-lg font-black text-amber-300">{selectedItem.price}</span>
                <span className="text-xs text-slate-500">yulduz</span>
              </div>
            </div>
            {buyError && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-rose-950/40 border border-rose-800/40 text-rose-400 text-xs">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{buyError}
              </div>
            )}
            {buySuccess ? (
              <div className="flex items-center justify-center gap-2 py-3 rounded-xl bg-green-950/40 border border-green-800/40 text-green-400 font-bold text-sm">
                <CheckCircle2 className="w-4 h-4" /> Muvaffaqiyatli sotib olindi!
              </div>
            ) : selectedItem.seller === username ? (
              <div className="py-3 text-center text-xs text-slate-500">Bu siz joylagan mahsulot</div>
            ) : (
              <button onClick={() => buyItem(selectedItem)} disabled={buying || starsBalance < selectedItem.price}
                className="w-full py-3 rounded-xl font-bold text-white transition disabled:opacity-50"
                style={{ background: `linear-gradient(135deg,${accentColor},#4f46e5)` }}>
                {buying ? "Sotib olinmoqda..." : starsBalance < selectedItem.price ? "Yetarli yulduz yo'q" : `⭐ ${selectedItem.price} ga sotib ol`}
              </button>
            )}
            <p className="text-[9px] text-slate-700 text-center">Sizning balansingiz: ⭐ {starsBalance}</p>
          </div>
        </div>
      )}
    </div>
  );
}
