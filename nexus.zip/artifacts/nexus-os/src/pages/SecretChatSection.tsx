import { useEffect, useRef, useState, useCallback } from "react";
import {
  ref, set, push, get, onValue, onChildAdded, remove, update, serverTimestamp
} from "firebase/database";
import { db } from "../firebase";
import { uploadToStorage } from "../lib/uploadMedia";
import {
  Lock, Send, ChevronLeft, ShieldAlert, Trash2, Eye, Shield,
  Clock, Mic, MicOff, X, Check, CheckCheck, Flame, Timer,
  AlertTriangle, Camera, EyeOff, Key, MessageSquare, Settings2,
  StopCircle, Play, Volume2
} from "lucide-react";

interface SecretMessage {
  id: string;
  sender: string;
  text: string;
  type: "text" | "voice";
  timestamp: number;
  expiresAt?: number;
  read?: boolean;
  voiceUrl?: string;
  voiceDuration?: number;
}

interface SecretChatSectionProps {
  username: string;
  accentColor: string;
  onBack?: () => void;
}

type TimerOption = 0 | 30 | 60 | 300 | 3600;

const TIMER_LABELS: Record<TimerOption, string> = {
  0: "O'chmaslik",
  30: "30 soniya",
  60: "1 daqiqa",
  300: "5 daqiqa",
  3600: "1 soat",
};

function chatId(a: string, b: string) {
  return [a, b].sort().join("___secret___");
}

// ─── PIN Lock Screen ───────────────────────────────────────────────────────────
function PinScreen({ onUnlock }: { onUnlock: () => void }) {
  const PIN_KEY = "nexus_secret_pin";
  const storedPin = localStorage.getItem(PIN_KEY);
  const [mode, setMode] = useState<"enter" | "set" | "confirm">(storedPin ? "enter" : "set");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);

  function triggerShake() {
    setShake(true); setTimeout(() => setShake(false), 500);
  }

  function handleDigit(d: string) {
    if (mode === "enter") {
      const next = pin + d;
      setPin(next);
      if (next.length === 4) {
        if (next === storedPin) { setPin(""); onUnlock(); }
        else { setError("Noto'g'ri PIN!"); triggerShake(); setTimeout(() => { setPin(""); setError(""); }, 700); }
      }
    } else if (mode === "set") {
      const next = pin + d;
      setPin(next);
      if (next.length === 4) { setMode("confirm"); }
    } else {
      const next = confirmPin + d;
      setConfirmPin(next);
      if (next.length === 4) {
        if (next === pin) { localStorage.setItem(PIN_KEY, pin); setPin(""); setConfirmPin(""); onUnlock(); }
        else { setError("PIN mos kelmadi!"); triggerShake(); setTimeout(() => { setConfirmPin(""); setError(""); setMode("set"); setPin(""); }, 700); }
      }
    }
  }

  function handleDelete() {
    if (mode === "confirm") setConfirmPin(p => p.slice(0, -1));
    else setPin(p => p.slice(0, -1));
  }

  const current = mode === "confirm" ? confirmPin : pin;
  const digits = ["1","2","3","4","5","6","7","8","9","","0","⌫"];

  return (
    <div className="flex flex-col items-center justify-center h-full bg-[#030712] px-6 select-none">
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
        style={{ background: "linear-gradient(135deg,#7c3aed,#4f46e5)", boxShadow: "0 0 30px rgba(124,58,237,0.4)" }}>
        <Key className="w-8 h-8 text-white" />
      </div>
      <p className="text-xl font-black text-slate-100 mb-1">
        {mode === "enter" ? "PIN Kiriting" : mode === "set" ? "PIN Yarating" : "Tasdiqlang"}
      </p>
      <p className="text-xs text-slate-500 mb-8">
        {mode === "enter" ? "Maxfiy chatga kirish uchun" : mode === "set" ? "4 raqamli PIN" : "PINni qayta kiriting"}
      </p>

      <div className={`flex gap-4 mb-8 transition-all ${shake ? "translate-x-2" : ""}`}>
        {[0,1,2,3].map(i => (
          <div key={i} className="w-4 h-4 rounded-full border-2 transition-all duration-200"
            style={{ background: i < current.length ? "#7c3aed" : "transparent", borderColor: i < current.length ? "#7c3aed" : "#334155" }} />
        ))}
      </div>

      {error && <p className="text-xs text-rose-400 mb-4 font-bold">{error}</p>}

      <div className="grid grid-cols-3 gap-3 w-64">
        {digits.map((d, i) => (
          <button key={i}
            onClick={() => { if (d === "⌫") handleDelete(); else if (d) handleDigit(d); }}
            disabled={!d}
            className={`h-14 rounded-2xl text-lg font-bold transition active:scale-95 ${
              d === "⌫" ? "text-slate-400 bg-slate-900 border border-slate-800 hover:bg-slate-800" :
              d ? "text-white bg-slate-900 border border-slate-800 hover:bg-slate-800 hover:border-purple-700" :
              "opacity-0 cursor-default"
            }`}
            style={d && d !== "⌫" ? { boxShadow: "0 2px 8px rgba(0,0,0,0.4)" } : undefined}>
            {d}
          </button>
        ))}
      </div>

      {mode === "enter" && (
        <button onClick={() => { localStorage.removeItem("nexus_secret_pin"); setMode("set"); setPin(""); }}
          className="mt-6 text-[11px] text-slate-600 hover:text-purple-400 transition">
          PINni unutdingizmi? Qayta o'rnating
        </button>
      )}
    </div>
  );
}

// ─── Voice Message Recorder ────────────────────────────────────────────────────
function useVoiceRecorder() {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  async function startRecording(): Promise<boolean> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      mediaRef.current = mr;
      chunksRef.current = [];
      mr.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mr.start();
      setRecording(true);
      setDuration(0);
      timerRef.current = setInterval(() => setDuration(d => d + 1), 1000);
      return true;
    } catch { return false; }
  }

  function stopRecording(): Promise<Blob | null> {
    return new Promise(resolve => {
      if (!mediaRef.current) { resolve(null); return; }
      mediaRef.current.onstop = () => {
        const blob = chunksRef.current.length ? new Blob(chunksRef.current, { type: "audio/webm" }) : null;
        mediaRef.current?.stream.getTracks().forEach(t => t.stop());
        resolve(blob);
      };
      mediaRef.current.stop();
      if (timerRef.current) clearInterval(timerRef.current);
      setRecording(false);
      setDuration(0);
    });
  }

  function cancelRecording() {
    if (!mediaRef.current) return;
    mediaRef.current.stream.getTracks().forEach(t => t.stop());
    mediaRef.current = null;
    if (timerRef.current) clearInterval(timerRef.current);
    setRecording(false);
    setDuration(0);
  }

  return { recording, duration, startRecording, stopRecording, cancelRecording };
}

// ─── Main Component ─────────────────────────────────────────────────────────
export default function SecretChatSection({ username, accentColor, onBack }: SecretChatSectionProps) {
  const [unlocked, setUnlocked] = useState(false);
  const [allUsers, setAllUsers] = useState<string[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [selectedPeer, setSelectedPeer] = useState<string | null>(null);
  const [messages, setMessages] = useState<SecretMessage[]>([]);
  const [input, setInput] = useState("");
  const [screenWhite, setScreenWhite] = useState(false);
  const [screenshotAlert, setScreenshotAlert] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [timerOption, setTimerOption] = useState<TimerOption>(0);
  const [showTimerPicker, setShowTimerPicker] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [peerTyping, setPeerTyping] = useState(false);
  const [autoDelete, setAutoDelete] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const peerRef = useRef<string | null>(null);
  const overlayTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioRefs = useRef<Record<string, HTMLAudioElement>>({});
  const msgTimersRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const { recording, duration: recDuration, startRecording, stopRecording, cancelRecording } = useVoiceRecorder();

  useEffect(() => { peerRef.current = selectedPeer; }, [selectedPeer]);

  useEffect(() => {
    return onValue(ref(db, "status"), snap => {
      if (!snap.exists()) return;
      const online = new Set<string>();
      snap.forEach(c => { if (c.key && c.key !== username && c.val()?.state === "online") online.add(c.key); });
      setOnlineUsers(online);
    });
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, "users"), snap => {
      if (!snap.exists()) return;
      const list: string[] = [];
      snap.forEach(c => { if (c.key && c.key !== username) list.push(c.key); });
      setAllUsers(list);
    });
  }, [username]);

  // Message subscription
  useEffect(() => {
    if (!selectedPeer || !unlocked) return;
    const cid = chatId(username, selectedPeer);
    setMessages([]);

    const unsub = onValue(ref(db, `secret_messages/${cid}`), snap => {
      if (!snap.exists()) { setMessages([]); return; }
      const msgs: SecretMessage[] = [];
      snap.forEach(child => {
        const d = child.val();
        if (d) msgs.push({ id: child.key!, ...d });
      });
      msgs.sort((a, b) => a.timestamp - b.timestamp);
      setMessages(msgs);
      setUnreadCount(0);

      // Mark unread as read
      msgs.forEach(m => {
        if (m.sender !== username && !m.read) {
          update(ref(db, `secret_messages/${cid}/${m.id}`), { read: true });
        }
        // Schedule auto-delete if timer set
        if (m.expiresAt && !msgTimersRef.current[m.id]) {
          const delay = m.expiresAt - Date.now();
          if (delay > 0) {
            msgTimersRef.current[m.id] = setTimeout(() => {
              remove(ref(db, `secret_messages/${cid}/${m.id}`));
              delete msgTimersRef.current[m.id];
            }, delay);
          } else {
            remove(ref(db, `secret_messages/${cid}/${m.id}`));
          }
        }
      });
    });

    return () => { unsub(); Object.values(msgTimersRef.current).forEach(clearTimeout); msgTimersRef.current = {}; };
  }, [selectedPeer, username, unlocked]);

  // Peer typing listener
  useEffect(() => {
    if (!selectedPeer || !unlocked) return;
    const cid = chatId(username, selectedPeer);
    return onValue(ref(db, `secret_typing/${cid}/${selectedPeer}`), snap => {
      setPeerTyping(!!(snap.exists() && snap.val() && Date.now() - snap.val() < 4000));
    });
  }, [selectedPeer, username, unlocked]);

  // Scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, peerTyping]);

  // Alert listener
  useEffect(() => {
    if (!unlocked) return;
    const alertRef = ref(db, `secret_alerts/${username}`);
    return onChildAdded(alertRef, async snap => {
      const d = snap.val();
      if (!d) return;
      const now = Date.now();
      if (now - d.timestamp < 15000) {
        setScreenshotAlert(`⚠️ @${d.from} ekranni yozib olishga urindi! Chat xavfsizlik uchun o'chirildi.`);
        setScreenWhite(true);
        setTimeout(() => setScreenWhite(false), 3000);
        if (peerRef.current && peerRef.current === d.from) {
          const cid = chatId(username, d.from);
          try { await remove(ref(db, `secret_messages/${cid}`)); } catch {}
          setMessages([]);
        }
        setTimeout(() => setScreenshotAlert(null), 8000);
      }
      try { await remove(snap.ref); } catch {}
    });
  }, [username, unlocked]);

  const triggerScreenWhite = useCallback(async (reason: string) => {
    const peer = peerRef.current;
    if (!peer) return;
    setScreenWhite(true);
    if (overlayTimerRef.current) clearTimeout(overlayTimerRef.current);
    overlayTimerRef.current = setTimeout(() => setScreenWhite(false), 3500);

    try {
      await push(ref(db, `secret_alerts/${peer}`), { from: username, reason, timestamp: Date.now() });
      const cid = chatId(username, peer);
      await remove(ref(db, `secret_messages/${cid}`));
      setMessages([]);
      setScreenshotAlert(`⚠️ Screenshot aniqlandi! Chat xavfsizlik uchun o'chirildi.`);
      setTimeout(() => setScreenshotAlert(null), 6000);
    } catch {}
  }, [username]);

  // Screenshot detection
  useEffect(() => {
    if (!selectedPeer || !unlocked) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const isShot = e.key === "PrintScreen" ||
        (e.metaKey && e.shiftKey && ["3","4","5","s","S"].includes(e.key)) ||
        (e.ctrlKey && e.shiftKey && ["s","S"].includes(e.key)) ||
        (e.ctrlKey && e.key === "p");
      if (isShot) { e.preventDefault(); triggerScreenWhite("keyboard"); }
    };

    const handleVisibility = () => {
      if (document.visibilityState === "hidden") triggerScreenWhite("app_switch");
    };

    document.addEventListener("keydown", handleKeyDown, true);
    document.addEventListener("visibilitychange", handleVisibility);
    return () => {
      document.removeEventListener("keydown", handleKeyDown, true);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [selectedPeer, unlocked, triggerScreenWhite]);

  // Typing handler
  const handleInputChange = (val: string) => {
    setInput(val);
    if (!selectedPeer) return;
    const cid = chatId(username, selectedPeer);
    if (!isTyping) {
      setIsTyping(true);
      set(ref(db, `secret_typing/${cid}/${username}`), Date.now());
    }
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      setIsTyping(false);
      if (selectedPeer) remove(ref(db, `secret_typing/${chatId(username, selectedPeer)}/${username}`));
    }, 3000);
  };

  async function sendMessage(text: string, type: "text" | "voice" = "text", extra: any = {}) {
    if (!selectedPeer) return;
    const cid = chatId(username, selectedPeer);
    const expiresAt = timerOption > 0 ? Date.now() + timerOption * 1000 : undefined;
    await push(ref(db, `secret_messages/${cid}`), {
      sender: username, text, type, timestamp: Date.now(),
      read: false, ...(expiresAt ? { expiresAt } : {}), ...extra,
    });
    remove(ref(db, `secret_typing/${cid}/${username}`));
    setIsTyping(false);
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
  }

  async function handleSendText() {
    if (!input.trim()) return;
    const text = input.trim();
    setInput("");
    await sendMessage(text);
    inputRef.current?.focus();
  }

  async function handleVoiceSend() {
    const blob = await stopRecording();
    if (!blob) return;
    try {
      const cid = chatId(username, selectedPeer!);
      const url = await uploadToStorage(`secret/${cid}/voice_${Date.now()}.webm`, blob);
      await sendMessage("🎙 Ovozli xabar", "voice", { voiceUrl: url, voiceDuration: recDuration });
    } catch (err) {
      alert("Ovoz yuborishda xato: " + (err instanceof Error ? err.message : String(err)));
    }
  }

  async function deleteChat() {
    if (!selectedPeer) return;
    const cid = chatId(username, selectedPeer);
    await remove(ref(db, `secret_messages/${cid}`));
    await remove(ref(db, `secret_typing/${cid}`));
    setMessages([]);
    setDeleteConfirm(false);
  }

  function playVoice(id: string, url: string) {
    if (playingVoice === id) {
      audioRefs.current[id]?.pause();
      setPlayingVoice(null);
      return;
    }
    if (playingVoice && audioRefs.current[playingVoice]) {
      audioRefs.current[playingVoice].pause();
    }
    if (!audioRefs.current[id]) {
      audioRefs.current[id] = new Audio(url);
      audioRefs.current[id].onended = () => setPlayingVoice(null);
    }
    audioRefs.current[id].play();
    setPlayingVoice(id);
  }

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
  };

  const formatDuration = (s: number) => `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;

  // ─── PIN LOCK ───────────────────────────────────────────────────────────────
  if (!unlocked) return <PinScreen onUnlock={() => setUnlocked(true)} />;

  // ─── USER PICKER ────────────────────────────────────────────────────────────
  if (!selectedPeer) {
    return (
      <div className="flex flex-col h-full" style={{ background: "linear-gradient(180deg,#0a0118 0%,#030712 100%)" }}>
        {screenshotAlert && (
          <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[999] max-w-sm w-full px-4 py-3 rounded-xl text-sm font-bold text-rose-100 shadow-2xl flex items-center gap-2 mx-4"
            style={{ background: "linear-gradient(135deg,#7f1d1d,#991b1b)", border:"1px solid #ef4444" }}>
            <ShieldAlert className="w-4 h-4 flex-shrink-0" />{screenshotAlert}
          </div>
        )}

        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-purple-900/30 flex-shrink-0"
          style={{ background: "rgba(10,1,24,0.95)", backdropFilter: "blur(20px)" }}>
          {onBack && (
            <button onClick={onBack} className="p-2 rounded-xl hover:bg-purple-900/30 transition text-purple-400">
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "linear-gradient(135deg,#7c3aed,#4f46e5)", boxShadow: "0 0 16px rgba(124,58,237,0.5)" }}>
            <Lock className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-black text-slate-100 tracking-wide">MAXFIY CHAT</p>
            <p className="text-[10px] text-purple-500">End-to-end himoyalangan · Screenshot taqiqlangan</p>
          </div>
          <button onClick={() => setShowSettings(s => !s)}
            className="p-2 rounded-xl hover:bg-purple-900/30 transition text-slate-500 hover:text-purple-400">
            <Settings2 className="w-4 h-4" />
          </button>
        </div>

        {showSettings && (
          <div className="p-4 border-b border-purple-900/20 space-y-3"
            style={{ background: "rgba(15,3,30,0.9)" }}>
            <p className="text-[10px] font-bold uppercase tracking-widest text-purple-500">Sozlamalar</p>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-slate-300">
                  <Timer className="w-3.5 h-3.5 text-purple-400" />
                  Xabarlar o'chirish vaqti
                </div>
                <button onClick={() => setShowTimerPicker(s => !s)}
                  className="text-xs font-bold px-2.5 py-1 rounded-lg text-purple-300"
                  style={{ background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.3)" }}>
                  {TIMER_LABELS[timerOption]}
                </button>
              </div>
              {showTimerPicker && (
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  {(Object.entries(TIMER_LABELS) as [string, string][]).map(([k, v]) => (
                    <button key={k}
                      onClick={() => { setTimerOption(Number(k) as TimerOption); setShowTimerPicker(false); }}
                      className="py-1.5 px-2 rounded-lg text-xs font-bold transition"
                      style={{
                        background: timerOption === Number(k) ? "rgba(124,58,237,0.3)" : "rgba(30,10,60,0.8)",
                        border: `1px solid ${timerOption === Number(k) ? "rgba(124,58,237,0.6)" : "rgba(124,58,237,0.15)"}`,
                        color: timerOption === Number(k) ? "#c4b5fd" : "#64748b"
                      }}>
                      {v}
                    </button>
                  ))}
                </div>
              )}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-slate-300">
                  <Flame className="w-3.5 h-3.5 text-orange-400" />
                  Chatdan chiqishda o'chirish
                </div>
                <button onClick={() => setAutoDelete(s => !s)}
                  className={`w-10 h-6 rounded-full transition-all flex items-center px-0.5 ${autoDelete ? "justify-end" : "justify-start"}`}
                  style={{ background: autoDelete ? "#7c3aed" : "#1e293b", border: `1px solid ${autoDelete ? "#9333ea" : "#334155"}` }}>
                  <div className="w-5 h-5 rounded-full bg-white shadow" />
                </button>
              </div>
              <button onClick={() => { localStorage.removeItem("nexus_secret_pin"); setUnlocked(false); }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-rose-400 hover:bg-rose-950/30 transition border border-rose-900/30">
                <Key className="w-3 h-3" /> PIN ni o'zgartirish
              </button>
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          <div className="mb-3 p-3.5 rounded-2xl border border-purple-800/25"
            style={{ background: "linear-gradient(135deg,rgba(124,58,237,0.08),rgba(79,70,229,0.05))" }}>
            <div className="flex items-center gap-2 text-purple-200 font-bold text-sm mb-2">
              <Shield className="w-4 h-4" /> Maxfiy Chat himoyasi
            </div>
            <div className="space-y-1.5">
              {[
                ["🔒", "End-to-end shifrlash — faqat siz o'qiysiz"],
                ["📵", "Screenshot aniqlansa — ekran oq bo'lib, chat o'chadi"],
                ["🔔", "Suhbatdoshingizga bildiruv yuboriladi"],
                ["⏱️", "Xabarlar uchun avtomatik o'chirish vaqti"],
                ["🔑", "PIN himoya — kirish faqat sizga"],
              ].map(([icon, text], i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-400">
                  <span>{icon}</span><span>{text}</span>
                </div>
              ))}
            </div>
          </div>

          <p className="text-[9px] font-bold uppercase tracking-widest text-slate-600 px-1 pb-1">Foydalanuvchini tanlang</p>
          {allUsers.length === 0 && (
            <p className="text-xs text-slate-600 text-center py-10">Hech kim ro'yxatdan o'tmagan</p>
          )}
          {allUsers.map(u => (
            <button key={u} onClick={() => setSelectedPeer(u)}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-2xl transition group"
              style={{ background: "rgba(15,3,30,0.6)", border: "1px solid rgba(124,58,237,0.15)" }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(124,58,237,0.4)")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(124,58,237,0.15)")}>
              <div className="relative flex-shrink-0">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center text-base font-black"
                  style={{ background: "linear-gradient(135deg,rgba(124,58,237,0.3),rgba(79,70,229,0.2))", border: "1px solid rgba(124,58,237,0.3)" }}>
                  {u[0]?.toUpperCase()}
                </div>
                <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2`}
                  style={{ background: onlineUsers.has(u) ? "#4ade80" : "#475569", borderColor: "#0a0118" }} />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-bold text-slate-200">@{u}</p>
                <p className="text-[10px] text-purple-500 flex items-center gap-1">
                  <Lock className="w-2.5 h-2.5" />
                  {onlineUsers.has(u) ? "Onlayn · Maxfiy chat boshlash" : "Oflayn · Maxfiy chat boshlash"}
                </p>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: "rgba(124,58,237,0.2)", border: "1px solid rgba(124,58,237,0.3)" }}>
                  <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // ─── CHAT VIEW ─────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-full relative select-none"
      style={{ background: "linear-gradient(180deg,#0a0118 0%,#030712 100%)", userSelect:"none", WebkitUserSelect:"none" }}>

      {/* White Screen Overlay */}
      {screenWhite && (
        <div className="fixed inset-0 z-[9999] bg-white animate-pulse" />
      )}

      {/* Screenshot Alert */}
      {screenshotAlert && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[999] max-w-sm w-full px-4 py-3 rounded-xl text-sm font-bold text-rose-100 shadow-2xl flex items-center gap-2 mx-4"
          style={{ background: "linear-gradient(135deg,#7f1d1d,#991b1b)", border:"1px solid #ef4444" }}>
          <ShieldAlert className="w-4 h-4 flex-shrink-0" />
          <span className="flex-1">{screenshotAlert}</span>
          <button onClick={() => setScreenshotAlert(null)}><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80" style={{ backdropFilter:"blur(12px)" }}>
          <div className="w-72 p-6 rounded-3xl border space-y-4"
            style={{ background:"rgba(15,3,30,0.99)", borderColor:"rgba(124,58,237,0.3)" }}>
            <div className="text-center space-y-2">
              <div className="text-4xl">🗑️</div>
              <p className="font-black text-slate-100">Chatni o'chirish</p>
              <p className="text-xs text-slate-500">Barcha xabarlar ikki tomondan ham butunlay o'chib ketadi.</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(false)}
                className="flex-1 py-2.5 rounded-xl text-sm font-medium text-slate-400 border border-slate-800 hover:bg-slate-900 transition">
                Bekor
              </button>
              <button onClick={deleteChat}
                className="flex-1 py-2.5 rounded-xl text-sm font-black text-white transition"
                style={{ background:"linear-gradient(135deg,#be123c,#9f1239)" }}>
                O'chirish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Timer Picker Modal */}
      {showTimerPicker && (
        <div className="absolute top-14 left-0 right-0 z-40 p-3" style={{ background:"rgba(10,1,24,0.98)", borderBottom:"1px solid rgba(124,58,237,0.25)" }}>
          <p className="text-[10px] font-bold text-purple-400 uppercase tracking-widest mb-2">Xabar o'chirish vaqti</p>
          <div className="flex flex-wrap gap-2">
            {(Object.entries(TIMER_LABELS) as [string, string][]).map(([k, v]) => (
              <button key={k}
                onClick={() => { setTimerOption(Number(k) as TimerOption); setShowTimerPicker(false); }}
                className="py-1.5 px-3 rounded-lg text-xs font-bold transition"
                style={{
                  background: timerOption === Number(k) ? "rgba(124,58,237,0.4)" : "rgba(30,10,60,0.8)",
                  border: `1px solid ${timerOption === Number(k) ? "#7c3aed" : "rgba(124,58,237,0.2)"}`,
                  color: timerOption === Number(k) ? "#e9d5ff" : "#64748b"
                }}>
                {v}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Chat Header */}
      <div className="flex items-center gap-2.5 px-3 py-2.5 border-b flex-shrink-0 z-30"
        style={{ background:"rgba(10,1,24,0.97)", borderColor:"rgba(124,58,237,0.25)", backdropFilter:"blur(20px)" }}>
        <button onClick={() => { if (autoDelete) deleteChat(); setSelectedPeer(null); setMessages([]); }}
          className="p-2 rounded-xl hover:bg-purple-900/30 transition text-purple-400 flex-shrink-0">
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="relative flex-shrink-0">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-black"
            style={{ background:"linear-gradient(135deg,rgba(124,58,237,0.4),rgba(79,70,229,0.3))", border:"1px solid rgba(124,58,237,0.4)" }}>
            {selectedPeer[0]?.toUpperCase()}
          </div>
          <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2`}
            style={{ background: onlineUsers.has(selectedPeer) ? "#4ade80" : "#475569", borderColor:"#0a0118" }} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="text-sm font-black text-slate-100">@{selectedPeer}</p>
            <Lock className="w-3 h-3 text-purple-400" />
          </div>
          <p className="text-[10px] flex items-center gap-1"
            style={{ color: peerTyping ? "#a78bfa" : onlineUsers.has(selectedPeer) ? "#4ade80" : "#475569" }}>
            {peerTyping ? (
              <><span className="animate-pulse">●</span> yozmoqda...</>
            ) : onlineUsers.has(selectedPeer) ? (
              <><EyeOff className="w-2.5 h-2.5" /> Maxfiy · Onlayn</>
            ) : "Oflayn"}
          </p>
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          {timerOption > 0 && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-lg text-[9px] font-bold text-orange-300"
              style={{ background:"rgba(234,88,12,0.15)", border:"1px solid rgba(234,88,12,0.3)" }}>
              <Timer className="w-2.5 h-2.5" />{TIMER_LABELS[timerOption]}
            </div>
          )}
          <button onClick={() => setShowTimerPicker(s => !s)}
            className={`p-2 rounded-xl transition ${timerOption > 0 ? "text-orange-400" : "text-slate-600"} hover:text-orange-400 hover:bg-orange-900/20`}
            title="Xabar vaqti">
            <Timer className="w-4 h-4" />
          </button>
          <button onClick={() => setDeleteConfirm(true)}
            className="p-2 rounded-xl hover:bg-rose-900/20 transition text-slate-600 hover:text-rose-400">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2" onContextMenu={e => e.preventDefault()}>
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full gap-4 text-center px-6">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center"
              style={{ background:"linear-gradient(135deg,rgba(124,58,237,0.15),rgba(79,70,229,0.1))", border:"1px solid rgba(124,58,237,0.25)" }}>
              <Lock className="w-9 h-9 text-purple-400" />
            </div>
            <div className="space-y-1.5">
              <p className="text-base font-black text-slate-200">Maxfiy suhbat boshlandi</p>
              <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                Xabarlar shifrlangan. Screenshot aniqlansa — ekran oq bo'ladi, suhbatdoshingizga bildiriladi va chat o'chiriladi.
              </p>
              {timerOption > 0 && (
                <p className="text-[11px] font-bold text-orange-400 flex items-center justify-center gap-1">
                  <Timer className="w-3 h-3" />
                  Xabarlar {TIMER_LABELS[timerOption]}dan keyin o'chadi
                </p>
              )}
            </div>
          </div>
        )}

        {messages.map(msg => {
          const isMe = msg.sender === username;
          const expiresIn = msg.expiresAt ? Math.max(0, Math.round((msg.expiresAt - Date.now()) / 1000)) : null;

          return (
            <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"} group`}>
              <div className="max-w-[78%] space-y-0.5">
                {!isMe && (
                  <p className="text-[9px] font-bold ml-1" style={{ color: "#9333ea" }}>@{msg.sender}</p>
                )}
                <div className="px-3.5 py-2.5 rounded-2xl relative"
                  style={{
                    background: isMe
                      ? "linear-gradient(135deg,rgba(124,58,237,0.85),rgba(79,70,229,0.75))"
                      : "rgba(20,8,45,0.9)",
                    border: isMe ? "1px solid rgba(167,139,250,0.25)" : "1px solid rgba(124,58,237,0.2)",
                    boxShadow: isMe ? "0 2px 16px rgba(124,58,237,0.25)" : "none"
                  }}>
                  {msg.type === "voice" && msg.voiceUrl ? (
                    <div className="flex items-center gap-2.5 min-w-[140px]">
                      <button onClick={() => playVoice(msg.id, msg.voiceUrl!)}
                        className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition hover:scale-110"
                        style={{ background: isMe ? "rgba(255,255,255,0.2)" : "rgba(124,58,237,0.3)" }}>
                        {playingVoice === msg.id
                          ? <StopCircle className="w-4 h-4 text-white" />
                          : <Play className="w-4 h-4 text-white" />}
                      </button>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-0.5 h-4">
                          {Array.from({length:16}).map((_,i)=>(
                            <div key={i} className="w-0.5 rounded-full bg-purple-400/60 animate-pulse"
                              style={{ height:`${6+Math.sin(i*0.6)*5}px`, animationDelay:`${i*50}ms` }} />
                          ))}
                        </div>
                        <p className="text-[10px] text-purple-300/70 flex items-center gap-1">
                          <Volume2 className="w-2.5 h-2.5" />
                          {msg.voiceDuration ? formatDuration(msg.voiceDuration) : "0:00"}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-slate-100 leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>
                  )}

                  <div className="flex items-center justify-between gap-2 mt-1">
                    <div className="flex items-center gap-1">
                      <Lock className="w-2 h-2 text-purple-400/50" />
                      {expiresIn !== null && expiresIn < 60 && (
                        <span className="text-[9px] text-orange-400 font-bold animate-pulse">
                          {expiresIn}s
                        </span>
                      )}
                      {expiresIn !== null && expiresIn >= 60 && (
                        <span className="text-[9px] text-orange-400/70">⏱ {formatDuration(expiresIn)}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-purple-300/50">{formatTime(msg.timestamp)}</span>
                      {isMe && (
                        msg.read
                          ? <CheckCheck className="w-3 h-3 text-purple-300/70" />
                          : <Check className="w-3 h-3 text-purple-300/40" />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Typing indicator */}
        {peerTyping && (
          <div className="flex justify-start">
            <div className="px-4 py-3 rounded-2xl flex items-center gap-1.5"
              style={{ background:"rgba(20,8,45,0.9)", border:"1px solid rgba(124,58,237,0.2)" }}>
              {[0,1,2].map(i => (
                <div key={i} className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce"
                  style={{ animationDelay:`${i*100}ms` }} />
              ))}
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex-shrink-0 border-t px-3 py-2.5"
        style={{ background:"rgba(10,1,24,0.97)", borderColor:"rgba(124,58,237,0.2)", backdropFilter:"blur(20px)" }}>
        {recording && (
          <div className="flex items-center gap-3 mb-2 px-3 py-2 rounded-xl"
            style={{ background:"rgba(124,58,237,0.1)", border:"1px solid rgba(124,58,237,0.3)" }}>
            <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-sm text-purple-300 flex-1">Ovoz yozilmoqda... {formatDuration(recDuration)}</span>
            <button onClick={cancelRecording} className="text-slate-500 hover:text-rose-400 transition">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="flex items-end gap-2">
          {!recording && (
            <button onClick={() => setShowTimerPicker(s => !s)}
              className={`p-2.5 rounded-xl transition flex-shrink-0 ${timerOption > 0 ? "text-orange-400" : "text-slate-600"} hover:text-orange-400 hover:bg-orange-900/20`}>
              <Timer className="w-4 h-4" />
            </button>
          )}

          {recording ? (
            <button onClick={handleVoiceSend}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-sm text-white transition"
              style={{ background:"linear-gradient(135deg,#7c3aed,#4f46e5)" }}>
              <Send className="w-4 h-4" /> Yuborish
            </button>
          ) : (
            <input
              ref={inputRef}
              value={input}
              onChange={e => handleInputChange(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSendText(); }}}
              placeholder="Maxfiy xabar..."
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              className="flex-1 bg-transparent border rounded-xl px-4 py-2.5 text-sm text-slate-200 outline-none transition placeholder-slate-600"
              style={{ borderColor:"rgba(124,58,237,0.3)", caretColor:"#9333ea" }}
              onFocus={e => (e.target.style.borderColor = "rgba(124,58,237,0.6)")}
              onBlur={e => (e.target.style.borderColor = "rgba(124,58,237,0.3)")}
            />
          )}

          {!input.trim() && !recording ? (
            <button
              onMouseDown={async () => { const ok = await startRecording(); if (!ok) alert("Mikrofon ruxsati kerak!"); }}
              className="p-2.5 rounded-xl transition flex-shrink-0 text-slate-500 hover:text-purple-400 hover:bg-purple-900/20">
              <Mic className="w-4 h-4" />
            </button>
          ) : !recording ? (
            <button onClick={handleSendText}
              disabled={!input.trim()}
              className="p-2.5 rounded-xl transition flex-shrink-0 active:scale-95 disabled:opacity-40"
              style={{ background:input.trim() ? "linear-gradient(135deg,#7c3aed,#4f46e5)" : "#1e1b4b" }}>
              <Send className="w-4 h-4 text-white" />
            </button>
          ) : null}
        </div>

        <div className="flex items-center justify-between mt-1.5">
          <p className="text-[9px] text-slate-700 flex items-center gap-1">
            <Camera className="w-2.5 h-2.5" />
            Screenshot aniqlansa — chat o'chiriladi
          </p>
          {autoDelete && (
            <p className="text-[9px] text-orange-500/70 flex items-center gap-1">
              <Flame className="w-2.5 h-2.5" /> Chiqishda o'chadi
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
