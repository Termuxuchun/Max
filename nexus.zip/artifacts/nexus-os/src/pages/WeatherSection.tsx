import { useState, useEffect, useCallback } from "react";
import { MapPin, Wind, Droplets, Eye, Thermometer, Navigation, RefreshCw, Search, Sun, Cloud, CloudRain, CloudSnow, Zap, ArrowUp, ArrowDown, CloudLightning } from "lucide-react";

const UZ_CITIES: Record<string, { lat: number; lon: number; name: string; region: string }> = {
  toshkent:  { lat: 41.299,  lon: 69.24,  name: "Toshkent",  region: "Toshkent viloyati" },
  samarqand: { lat: 39.654,  lon: 66.96,  name: "Samarqand", region: "Samarqand viloyati" },
  namangan:  { lat: 40.999,  lon: 71.67,  name: "Namangan",  region: "Namangan viloyati" },
  andijon:   { lat: 40.782,  lon: 72.34,  name: "Andijon",   region: "Andijon viloyati" },
  fargona:   { lat: 40.374,  lon: 71.78,  name: "Farg'ona",  region: "Farg'ona viloyati" },
  buxoro:    { lat: 39.773,  lon: 64.43,  name: "Buxoro",    region: "Buxoro viloyati" },
  nukus:     { lat: 42.461,  lon: 59.61,  name: "Nukus",     region: "Qoraqalpog'iston" },
  qarshi:    { lat: 38.857,  lon: 65.79,  name: "Qarshi",    region: "Qashqadaryo viloyati" },
  navoiy:    { lat: 40.1,    lon: 65.37,  name: "Navoiy",    region: "Navoiy viloyati" },
  jizzax:    { lat: 40.119,  lon: 67.84,  name: "Jizzax",    region: "Jizzax viloyati" },
  termiz:    { lat: 37.224,  lon: 67.27,  name: "Termiz",    region: "Surxondaryo viloyati" },
  urgench:   { lat: 41.547,  lon: 60.64,  name: "Urganch",   region: "Xorazm viloyati" },
};

const WMO_CODES: Record<number, { label: string; icon: string; bg: string }> = {
  0:  { label: "Aniq",              icon: "☀️", bg: "from-amber-500/20 to-orange-500/10" },
  1:  { label: "Ko'pincha aniq",    icon: "🌤️", bg: "from-amber-400/20 to-sky-500/10" },
  2:  { label: "Qisman bulutli",    icon: "⛅", bg: "from-sky-400/20 to-slate-500/10" },
  3:  { label: "Bulutli",           icon: "☁️", bg: "from-slate-400/20 to-slate-600/10" },
  45: { label: "Tuman",             icon: "🌫️", bg: "from-slate-400/20 to-slate-600/10" },
  48: { label: "Muzli tuman",       icon: "🌫️", bg: "from-blue-400/20 to-slate-500/10" },
  51: { label: "Engil yomg'ir",     icon: "🌦️", bg: "from-blue-400/20 to-teal-500/10" },
  53: { label: "Yomg'ir",           icon: "🌧️", bg: "from-blue-500/20 to-slate-500/10" },
  55: { label: "Kuchli yomg'ir",    icon: "🌧️", bg: "from-blue-600/20 to-slate-600/10" },
  61: { label: "Engil yomg'ir",     icon: "🌦️", bg: "from-blue-400/20 to-teal-500/10" },
  63: { label: "Yomg'ir",           icon: "🌧️", bg: "from-blue-500/20 to-slate-500/10" },
  65: { label: "Kuchli yomg'ir",    icon: "🌧️", bg: "from-blue-600/20 to-slate-600/10" },
  71: { label: "Engil qor",         icon: "🌨️", bg: "from-sky-300/20 to-slate-300/10" },
  73: { label: "Qor",               icon: "❄️", bg: "from-sky-200/20 to-slate-200/10" },
  75: { label: "Kuchli qor",        icon: "⛄", bg: "from-sky-100/20 to-white/10" },
  80: { label: "Yomg'ir yog'moqda", icon: "🌧️", bg: "from-blue-500/20 to-teal-500/10" },
  95: { label: "Momaqaldiroq",      icon: "⛈️", bg: "from-violet-500/20 to-slate-600/10" },
  99: { label: "Do'l bilan momaqaldiroq", icon: "🌩️", bg: "from-violet-600/20 to-slate-700/10" },
};

interface WeatherData {
  temp: number;
  feels_like: number;
  humidity: number;
  windspeed: number;
  weathercode: number;
  is_day: number;
  temp_max: number;
  temp_min: number;
  hourly: { time: string; temp: number; code: number }[];
  daily: { date: string; max: number; min: number; code: number }[];
}

interface Props { accentColor: string; }

export default function WeatherSection({ accentColor }: Props) {
  const [data, setData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [cityKey, setCityKey] = useState<string>("toshkent");
  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const city = UZ_CITIES[cityKey];

  const fetchWeather = useCallback(async (lat: number, lon: number) => {
    setLoading(true);
    setError("");
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,relativehumidity_2m,apparent_temperature,weathercode&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=Asia%2FTashkent&forecast_days=7`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("API xatosi");
      const json = await res.json();
      const cur = json.current_weather;
      const now = new Date();
      const hourIdx = json.hourly.time.findIndex((t: string) => new Date(t) >= now) - 1;
      const idx = Math.max(0, hourIdx);
      const humidity = json.hourly.relativehumidity_2m?.[idx] ?? 50;
      const feelsLike = json.hourly.apparent_temperature?.[idx] ?? cur.temperature;
      const todayMax = json.daily.temperature_2m_max[0];
      const todayMin = json.daily.temperature_2m_min[0];

      const hourly = json.hourly.time.slice(idx, idx + 12).map((t: string, i: number) => ({
        time: new Date(t).toLocaleTimeString("uz-UZ", { hour: "2-digit", minute: "2-digit" }),
        temp: Math.round(json.hourly.temperature_2m[idx + i]),
        code: json.hourly.weathercode[idx + i],
      }));

      const daily = json.daily.time.map((t: string, i: number) => ({
        date: t,
        max: Math.round(json.daily.temperature_2m_max[i]),
        min: Math.round(json.daily.temperature_2m_min[i]),
        code: json.daily.weathercode[i],
      }));

      setData({ temp: Math.round(cur.temperature), feels_like: Math.round(feelsLike), humidity, windspeed: Math.round(cur.windspeed), weathercode: cur.weathercode, is_day: cur.is_day, temp_max: Math.round(todayMax), temp_min: Math.round(todayMin), hourly, daily });
      setLastUpdated(new Date());
    } catch {
      setError("Ma'lumot yuklanmadi. Internet aloqasini tekshiring.");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchWeather(city.lat, city.lon);
  }, [cityKey, fetchWeather]);

  function getWmo(code: number) {
    return WMO_CODES[code] || { label: "Noma'lum", icon: "🌡️", bg: "from-slate-500/20 to-slate-600/10" };
  }

  function getDayName(dateStr: string, i: number) {
    if (i === 0) return "Bugun";
    if (i === 1) return "Ertaga";
    const days = ["Yak", "Dush", "Sesh", "Chor", "Pay", "Juma", "Shan"];
    return days[new Date(dateStr).getDay()];
  }

  const filteredCities = Object.entries(UZ_CITIES).filter(([k, v]) =>
    search ? v.name.toLowerCase().includes(search.toLowerCase()) : true
  );

  const wmo = data ? getWmo(data.weathercode) : null;

  return (
    <div className="flex flex-col h-full bg-[#030712] overflow-y-auto">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b border-slate-800/60"
        style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(12px)" }}>
        <div className="flex items-center gap-3">
          <div className="text-2xl">🌤️</div>
          <div>
            <p className="text-sm font-bold text-white">Ob-Havo</p>
            <p className="text-[10px] text-slate-500">Real-vaqt · Open-Meteo</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowSearch(!showSearch)}
            className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition">
            <Search className="w-4 h-4" />
          </button>
          <button onClick={() => fetchWeather(city.lat, city.lon)} disabled={loading}
            className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* City Search */}
      {showSearch && (
        <div className="px-4 py-3 border-b border-slate-800/40 space-y-2">
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Shahar qidiring..."
            className="w-full px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-violet-600" />
          <div className="grid grid-cols-3 gap-1.5">
            {filteredCities.map(([k, v]) => (
              <button key={k} onClick={() => { setCityKey(k); setShowSearch(false); setSearch(""); }}
                className={`px-2 py-2 rounded-xl text-xs font-medium transition text-left ${cityKey === k ? "text-white border" : "text-slate-400 hover:text-white hover:bg-slate-800/60"}`}
                style={cityKey === k ? { background: accentColor + "22", borderColor: accentColor + "44" } : {}}>
                <p className="font-bold truncate">{v.name}</p>
                <p className="text-[9px] text-slate-600 truncate">{v.region}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="px-4 py-4 space-y-4">
        {error && (
          <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-800/40 text-rose-400 text-sm text-center">{error}</div>
        )}

        {loading && !data && (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <RefreshCw className="w-8 h-8 text-slate-500 animate-spin" />
            <p className="text-slate-500 text-sm">Ob-havo ma'lumotlari yuklanmoqda...</p>
          </div>
        )}

        {data && wmo && (
          <>
            {/* Main card */}
            <div className={`relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br ${wmo.bg}`}
              style={{ border: "1px solid rgba(255,255,255,0.08)" }}>
              <div className="absolute inset-0 opacity-10" style={{
                backgroundImage: "radial-gradient(circle at 80% 20%, rgba(255,255,255,0.3) 0%, transparent 60%)"
              }} />
              <div className="relative z-10">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <MapPin className="w-3.5 h-3.5" style={{ color: accentColor }} />
                      <p className="text-sm font-bold text-white">{city.name}</p>
                    </div>
                    <p className="text-[10px] text-slate-400">{city.region}</p>
                  </div>
                  <div className="text-5xl">{wmo.icon}</div>
                </div>

                <div className="mt-4">
                  <div className="flex items-end gap-2">
                    <span className="text-7xl font-black text-white leading-none">{data.temp}°</span>
                    <div className="mb-2">
                      <p className="text-sm text-slate-300 font-medium">{wmo.label}</p>
                      <p className="text-xs text-slate-500">His qilinadi: {data.feels_like}°C</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="flex items-center gap-1 text-xs text-rose-400">
                      <ArrowUp className="w-3 h-3" />{data.temp_max}°
                    </span>
                    <span className="flex items-center gap-1 text-xs text-sky-400">
                      <ArrowDown className="w-3 h-3" />{data.temp_min}°
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-5">
                  {[
                    { icon: <Droplets className="w-3.5 h-3.5" />, label: "Namlik", val: `${data.humidity}%` },
                    { icon: <Wind className="w-3.5 h-3.5" />, label: "Shamol", val: `${data.windspeed} km/s` },
                    { icon: <Eye className="w-3.5 h-3.5" />, label: "Ko'rinish", val: "Yaxshi" },
                  ].map((s, i) => (
                    <div key={i} className="flex flex-col gap-1 px-2 py-2 rounded-xl" style={{ background: "rgba(0,0,0,0.2)" }}>
                      <div className="flex items-center gap-1 text-slate-400">{s.icon}<span className="text-[9px]">{s.label}</span></div>
                      <p className="text-sm font-bold text-white">{s.val}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Hourly forecast */}
            <div className="rounded-2xl border border-slate-800/60 p-4" style={{ background: "rgba(15,23,42,0.6)" }}>
              <p className="text-xs font-bold text-slate-400 mb-3">⏰ Soatlik prognoz</p>
              <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-none">
                {data.hourly.map((h, i) => (
                  <div key={i} className="flex flex-col items-center gap-1.5 flex-shrink-0 px-2 py-2 rounded-xl min-w-[52px]"
                    style={{ background: i === 0 ? accentColor + "22" : "rgba(30,41,59,0.4)" }}>
                    <p className="text-[9px] text-slate-500">{i === 0 ? "Hozir" : h.time}</p>
                    <span className="text-lg">{getWmo(h.code).icon}</span>
                    <p className="text-xs font-bold text-white">{h.temp}°</p>
                  </div>
                ))}
              </div>
            </div>

            {/* 7-day forecast */}
            <div className="rounded-2xl border border-slate-800/60 p-4" style={{ background: "rgba(15,23,42,0.6)" }}>
              <p className="text-xs font-bold text-slate-400 mb-3">📅 7 kunlik prognoz</p>
              <div className="space-y-2">
                {data.daily.map((d, i) => (
                  <div key={i} className="flex items-center gap-3 py-1.5 px-2 rounded-xl hover:bg-slate-800/30 transition">
                    <p className="text-xs font-medium text-slate-300 w-12 flex-shrink-0">{getDayName(d.date, i)}</p>
                    <span className="text-base flex-shrink-0">{getWmo(d.code).icon}</span>
                    <p className="text-[10px] text-slate-500 flex-1 truncate">{getWmo(d.code).label}</p>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs text-rose-400 font-bold">{d.max}°</span>
                      <span className="text-xs text-slate-600">/</span>
                      <span className="text-xs text-sky-400">{d.min}°</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Cities quick nav */}
            <div className="rounded-2xl border border-slate-800/60 p-4" style={{ background: "rgba(15,23,42,0.6)" }}>
              <p className="text-xs font-bold text-slate-400 mb-3">🏙️ Boshqa shaharlar</p>
              <div className="grid grid-cols-3 gap-2">
                {Object.entries(UZ_CITIES).filter(([k]) => k !== cityKey).slice(0, 6).map(([k, v]) => (
                  <button key={k} onClick={() => setCityKey(k)}
                    className="text-left px-2.5 py-2 rounded-xl hover:bg-slate-800/60 transition border border-transparent hover:border-slate-700">
                    <p className="text-xs font-bold text-slate-300">{v.name}</p>
                    <p className="text-[9px] text-slate-600 truncate">{v.region.split(" ")[0]}</p>
                  </button>
                ))}
              </div>
            </div>

            {lastUpdated && (
              <p className="text-[9px] text-slate-700 text-center pb-2">
                Yangilandi: {lastUpdated.toLocaleTimeString("uz-UZ")} · Open-Meteo
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
