import { useState, useEffect, useRef } from "react";
import { ref, set, onValue, remove, update, push, get } from "firebase/database";
import { db } from "../firebase";
import { uploadToStorage } from "../lib/uploadMedia";

const STORY_REACTIONS = ["❤️", "🔥", "😂", "😮", "👏", "💎"];

interface StoryEntry {
  text: string;
  emoji: string;
  bg: string;
  image?: string;
  createdAt: number;
  expiresAt: number;
  views: string[];
}

interface UserStory {
  username: string;
  data: StoryEntry;
}

interface Post {
  id: string;
  username: string;
  text: string;
  emoji: string;
  bg: string;
  image?: string;
  createdAt: number;
  likes: Record<string, boolean>;
  comments: { username: string; text: string; createdAt: number }[];
  location?: string;
  audio?: string;
}

const STORY_BGS = [
  { bg: "linear-gradient(135deg,#0f0c29,#302b63,#24243e)", label: "Galaxi" },
  { bg: "linear-gradient(135deg,#f7971e,#ffd200)", label: "Oltin" },
  { bg: "linear-gradient(135deg,#1e3c72,#2a5298)", label: "Ko'k" },
  { bg: "linear-gradient(135deg,#134e5e,#71b280)", label: "Yashil" },
  { bg: "linear-gradient(135deg,#c62a87,#9733ee)", label: "Pushti" },
  { bg: "linear-gradient(135deg,#fc4a1a,#f7b733)", label: "Olov" },
  { bg: "linear-gradient(135deg,#0f2027,#203a43,#2c5364)", label: "Qoʻngʻir" },
  { bg: "linear-gradient(135deg,#1a1a1a,#222)", label: "Qora" },
];

const POST_BGS = [
  { bg: "#f3f0e8", label: "Krem", dark: false },
  { bg: "#1a1a2e", label: "Qoʻngʻir", dark: true },
  { bg: "#0d1117", label: "Qora", dark: true },
  { bg: "#fff", label: "Oq", dark: false },
  { bg: "linear-gradient(135deg,#667eea,#764ba2)", label: "Binafsha", dark: true },
  { bg: "linear-gradient(135deg,#f093fb,#f5576c)", label: "Pushti", dark: true },
];

const EMOJIS = ["🌟","🔥","❤️","😎","🚀","💎","👑","⚡","🎯","🌈","🎉","💪","🦋","🌙","☀️","🎵","🏆","🐉","🦁","🌊","💫","🎭","🌺","🦄","✨","🥰","😂","🤯","👀","🙌"];

interface Props {
  username: string;
  accentColor: string;
}

function timeAgo(ts: number) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s/60)}d`;
  if (s < 86400) return `${Math.floor(s/3600)}s`;
  return `${Math.floor(s/86400)} kun`;
}

function timeLeft(expiresAt: number) {
  const ms = expiresAt - Date.now();
  if (ms <= 0) return "Tugadi";
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return h > 0 ? `${h}s ${m}d` : `${m}d`;
}

export default function StatusSection({ username, accentColor }: Props) {
  const [stories, setStories] = useState<UserStory[]>([]);
  const [myStory, setMyStory] = useState<StoryEntry | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [viewIdx, setViewIdx] = useState<number>(-1);
  const [viewProgress, setViewProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const imageRef = useRef<HTMLInputElement>(null);
  const postImageRef = useRef<HTMLInputElement>(null);

  const [mode, setMode] = useState<"feed" | "story_compose" | "post_compose">("feed");
  const [storyText, setStoryText] = useState("");
  const [storyEmoji, setStoryEmoji] = useState("🌟");
  const [storyBg, setStoryBg] = useState(STORY_BGS[0].bg);
  const [storyImage, setStoryImage] = useState<string | null>(null);

  const [postText, setPostText] = useState("");
  const [postEmoji, setPostEmoji] = useState("✨");
  const [postBg, setPostBg] = useState(POST_BGS[0].bg);
  const [postImage, setPostImage] = useState<string | null>(null);
  const [postLocation, setPostLocation] = useState("");
  const [postAudio, setPostAudio] = useState("");

  const [commentInput, setCommentInput] = useState<Record<string, string>>({});
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const unsub = onValue(ref(db, "statuses"), snap => {
      if (!snap.exists()) { setStories([]); setMyStory(null); return; }
      const now = Date.now();
      const list: UserStory[] = [];
      snap.forEach(child => {
        const d = child.val() as StoryEntry;
        if (d.expiresAt > now) {
          if (child.key === username) setMyStory(d);
          else list.push({ username: child.key!, data: d });
        } else if (child.key === username) {
          remove(ref(db, `statuses/${username}`));
        }
      });
      setStories(list);
    });
    return () => unsub();
  }, [username]);

  useEffect(() => {
    const unsub = onValue(ref(db, "posts"), snap => {
      if (!snap.exists()) { setPosts([]); return; }
      const list: Post[] = [];
      snap.forEach(userSnap => {
        userSnap.forEach(postSnap => {
          const d = postSnap.val();
          list.push({ id: postSnap.key!, username: userSnap.key!, ...d, likes: d.likes || {}, comments: d.comments || [] });
        });
      });
      list.sort((a, b) => b.createdAt - a.createdAt);
      setPosts(list);
    });
    return () => unsub();
  }, []);

  const allStoriesWithMe = myStory ? [{ username, data: myStory }, ...stories] : stories;

  useEffect(() => {
    if (viewIdx < 0 || viewIdx >= allStoriesWithMe.length || isPaused) {
      if (progressRef.current) clearInterval(progressRef.current);
      return;
    }
    setViewProgress(0);
    if (progressRef.current) clearInterval(progressRef.current);
    const s = allStoriesWithMe[viewIdx];
    if (s.username !== username) {
      const views = s.data.views || [];
      if (!views.includes(username)) {
        set(ref(db, `statuses/${s.username}/views`), [...views, username]);
      }
    }
    progressRef.current = setInterval(() => {
      setViewProgress(p => {
        if (p >= 100) {
          clearInterval(progressRef.current!);
          if (viewIdx < allStoriesWithMe.length - 1) setViewIdx(v => v + 1);
          else setViewIdx(-1);
          return 0;
        }
        return p + 1;
      });
    }, 50);
    return () => { if (progressRef.current) clearInterval(progressRef.current); };
  }, [viewIdx, isPaused]);

  async function postStory() {
    if (!storyText.trim() && !storyImage) return;
    setUploadingMedia(true);
    try {
      let imageUrl = storyImage;
      if (storyImageFile) {
        imageUrl = await uploadToStorage(`statuses/${username}/story_${Date.now()}.jpg`, storyImageFile);
      }
      const entry: StoryEntry = {
        text: storyText.trim(),
        emoji: storyEmoji,
        bg: storyBg,
        image: imageUrl || undefined,
        createdAt: Date.now(),
        expiresAt: Date.now() + 24 * 3600000,
        views: [],
      };
      set(ref(db, `statuses/${username}`), entry);
      setMode("feed"); setStoryText(""); setStoryImage(null); setStoryImageFile(null);
    } catch (err) {
      alert("Story joylashtirishda xato: " + (err instanceof Error ? err.message : String(err)));
    }
    setUploadingMedia(false);
  }

  async function publishPost() {
    if (!postText.trim() && !postImage) return;
    setUploadingMedia(true);
    try {
      let imageUrl = postImage;
      if (postImageFile) {
        imageUrl = await uploadToStorage(`posts_status/${username}/post_${Date.now()}.jpg`, postImageFile);
      }
      const postRef = push(ref(db, `posts/${username}`));
      set(postRef, {
        text: postText.trim(),
        emoji: postEmoji,
        bg: postBg,
        image: imageUrl || null,
        location: postLocation || null,
        audio: postAudio || null,
        createdAt: Date.now(),
        likes: {},
        comments: [],
      });
      setMode("feed"); setPostText(""); setPostImage(null); setPostLocation(""); setPostAudio(""); setPostImageFile(null);
    } catch (err) {
      alert("Post joylashtirishda xato: " + (err instanceof Error ? err.message : String(err)));
    }
    setUploadingMedia(false);
  }

  async function toggleLike(post: Post) {
    const likeRef = ref(db, `posts/${post.username}/${post.id}/likes/${username}`);
    if (post.likes[username]) {
      remove(likeRef);
    } else {
      set(likeRef, true);
    }
  }

  async function sendComment(post: Post) {
    const txt = commentInput[post.id]?.trim();
    if (!txt) return;
    const snap = await get(ref(db, `posts/${post.username}/${post.id}/comments`));
    const existing = snap.exists() ? snap.val() : [];
    const newComments = [...(Array.isArray(existing) ? existing : []), { username, text: txt, createdAt: Date.now() }];
    update(ref(db, `posts/${post.username}/${post.id}`), { comments: newComments });
    setCommentInput(prev => ({ ...prev, [post.id]: "" }));
  }

  async function deletePost(post: Post) {
    if (post.username !== username) return;
    remove(ref(db, `posts/${post.username}/${post.id}`));
  }

  const [storyImageFile, setStoryImageFile] = useState<File | null>(null);
  const [postImageFile, setPostImageFile] = useState<File | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  function handleImagePick(e: React.ChangeEvent<HTMLInputElement>, type: "story" | "post") {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 30 * 1024 * 1024) { alert("Fayl 30MB dan kichik bo'lishi kerak"); return; }
    if (type === "story") setStoryImageFile(file);
    else setPostImageFile(file);
    const reader = new FileReader();
    reader.onload = ev => {
      if (type === "story") setStoryImage(ev.target?.result as string);
      else setPostImage(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  }

  async function resolveMediaUrl(file: File | null, previewBase64: string | null, storagePath: string): Promise<string | null> {
    if (!file) return previewBase64;
    try {
      return await uploadToStorage(storagePath, file);
    } catch {
      return previewBase64;
    }
  }

  const viewing = viewIdx >= 0 ? allStoriesWithMe[viewIdx] : null;

  /* ──────────────────────────────── STORY VIEWER ─────────────────────── */
  if (viewing) {
    return (
      <div
        className="fixed inset-0 z-[100] flex flex-col select-none"
        style={{ background: viewing.data.image ? "#000" : viewing.data.bg }}
        onMouseDown={() => setIsPaused(true)}
        onMouseUp={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        {/* Progress bars */}
        <div className="absolute top-0 left-0 right-0 flex gap-1 px-3 pt-3 z-10">
          {allStoriesWithMe.map((_, i) => (
            <div key={i} className="flex-1 h-0.5 rounded-full overflow-hidden bg-white/25">
              <div className="h-full bg-white transition-none rounded-full"
                style={{ width: i < viewIdx ? "100%" : i === viewIdx ? `${viewProgress}%` : "0%" }} />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 pt-8 pb-2 z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-base font-black bg-white/20 border-2 border-white/40 overflow-hidden">
              {viewing.data.image ? <span className="text-xs font-black">{viewing.username[0].toUpperCase()}</span> : <span>{viewing.data.emoji}</span>}
            </div>
            <div>
              <p className="font-bold text-white text-sm leading-none">@{viewing.username}</p>
              <p className="text-white/50 text-[10px]">{timeLeft(viewing.data.expiresAt)} qoldi</p>
            </div>
          </div>
          <button onClick={() => { setViewIdx(-1); setViewProgress(0); }}
            className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center text-white text-lg">✕</button>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center gap-4 relative">
          {viewing.data.image ? (
            <img src={viewing.data.image} alt="" className="max-h-[70vh] max-w-full rounded-2xl object-contain" />
          ) : (
            <>
              <div className="text-7xl" style={{ filter: "drop-shadow(0 0 20px rgba(255,255,255,0.4))" }}>{viewing.data.emoji}</div>
              <p className="text-2xl font-black text-white leading-tight" style={{ textShadow: "0 2px 20px rgba(0,0,0,0.6)" }}>{viewing.data.text}</p>
            </>
          )}
          {viewing.data.image && viewing.data.text && (
            <div className="absolute bottom-16 left-4 right-4 bg-black/50 backdrop-blur-sm rounded-2xl px-4 py-3">
              <p className="text-white font-semibold text-sm">{viewing.data.text}</p>
            </div>
          )}
        </div>

        {/* Reaction bar */}
        <div className="px-3 pb-6 flex flex-col gap-2">
          <div className="flex gap-2 justify-center">
            {STORY_REACTIONS.map(emoji => (
              <button key={emoji}
                onClick={async (e) => {
                  e.stopPropagation();
                  if (viewing.username === username) return;
                  const reactRef = ref(db, `story_reactions/${viewing.username}/${username}`);
                  await set(reactRef, { emoji, from: username, ts: Date.now() });
                }}
                className="w-11 h-11 rounded-full bg-white/15 backdrop-blur-sm border border-white/20 flex items-center justify-center text-2xl transition active:scale-110 hover:bg-white/25">
                {emoji}
              </button>
            ))}
          </div>
          {viewing.username !== username && (
            <input placeholder={`@${viewing.username}ga javob yozing...`}
              className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2.5 text-white text-sm placeholder-white/40 outline-none" />
          )}
        </div>

        {/* Tap navigation zones */}
        <div className="absolute inset-0 flex" style={{ pointerEvents: "none" }}>
          <div style={{ width: "35%", pointerEvents: "auto", cursor: "pointer" }}
            onClick={() => { if (viewIdx > 0) setViewIdx(v => v - 1); }} />
          <div style={{ flex: 1 }} />
          <div style={{ width: "35%", pointerEvents: "auto", cursor: "pointer" }}
            onClick={() => { if (viewIdx < allStoriesWithMe.length - 1) setViewIdx(v => v + 1); else setViewIdx(-1); }} />
        </div>
      </div>
    );
  }

  /* ──────────────────────────────── STORY COMPOSER ─────────────────────── */
  if (mode === "story_compose") {
    return (
      <div className="fixed inset-0 z-[90] flex flex-col" style={{ background: storyImage ? "#000" : storyBg }}>
        {/* Top bar */}
        <div className="flex items-center justify-between px-4 pt-5 pb-3">
          <button onClick={() => setMode("feed")} className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center text-white text-xl">✕</button>
          <p className="font-black text-white">Story qo'shish</p>
          <button onClick={() => imageRef.current?.click()} className="text-white text-sm font-bold bg-white/15 px-3 py-1.5 rounded-full">📷 Rasm</button>
        </div>
        <input ref={imageRef} type="file" accept="image/*" className="hidden" onChange={e => handleImagePick(e, "story")} />

        {/* Preview */}
        <div className="flex-1 flex flex-col items-center justify-center px-8 gap-5">
          {storyImage ? (
            <div className="relative">
              <img src={storyImage} alt="" className="max-h-[55vh] max-w-full rounded-2xl object-contain" />
              <button onClick={() => setStoryImage(null)} className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/50 flex items-center justify-center text-white text-sm">✕</button>
            </div>
          ) : (
            <div className="text-8xl animate-pulse">{storyEmoji}</div>
          )}
          <input value={storyText} onChange={e => setStoryText(e.target.value)} placeholder="Matn yozing..." maxLength={100}
            className="w-full max-w-sm bg-transparent border-b-2 border-white/40 focus:border-white outline-none text-white text-xl text-center font-bold placeholder-white/40 py-2" autoFocus />
          <p className="text-white/30 text-xs">{storyText.length}/100</p>
        </div>

        {/* Emoji row */}
        <div className="px-4 pb-2">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {EMOJIS.slice(0, 16).map(e => (
              <button key={e} onClick={() => setStoryEmoji(e)}
                className={`flex-shrink-0 text-2xl w-10 h-10 rounded-xl flex items-center justify-center transition ${storyEmoji === e ? "bg-white/30 scale-110" : "bg-white/10"}`}>{e}</button>
            ))}
          </div>
        </div>

        {/* BG row */}
        <div className="px-4 pb-4">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {STORY_BGS.map((c, i) => (
              <button key={i} onClick={() => setStoryBg(c.bg)}
                className={`flex-shrink-0 w-10 h-10 rounded-xl border-2 transition ${storyBg === c.bg ? "border-white scale-110" : "border-transparent"}`}
                style={{ background: c.bg }} />
            ))}
          </div>
        </div>

        <div className="px-4 pb-6">
          <button onClick={postStory} disabled={!storyText.trim() && !storyImage}
            className="w-full py-4 rounded-2xl font-black text-base bg-white text-slate-900 disabled:opacity-40 transition active:scale-[0.98]">
            ✨ 24 soatlik story joylashtirish
          </button>
        </div>
      </div>
    );
  }

  /* ──────────────────────────────── POST COMPOSER ─────────────────────── */
  if (mode === "post_compose") {
    const isDark = POST_BGS.find(b => b.bg === postBg)?.dark ?? true;
    return (
      <div className="fixed inset-0 z-[90] flex flex-col overflow-y-auto" style={{ background: "#0f172a" }}>
        <div className="flex items-center justify-between px-4 pt-5 pb-3 border-b border-slate-800">
          <button onClick={() => setMode("feed")} className="text-slate-400 font-bold">Bekor</button>
          <p className="font-black text-white text-sm">Yangi post</p>
          <button onClick={publishPost} disabled={!postText.trim() && !postImage}
            className="font-black text-sm px-4 py-1.5 rounded-full disabled:opacity-40" style={{ background: accentColor, color: "#000" }}>
            Ulash
          </button>
        </div>
        <input ref={postImageRef} type="file" accept="image/*" className="hidden" onChange={e => handleImagePick(e, "post")} />

        {/* Post preview card */}
        <div className="mx-4 mt-4 rounded-2xl overflow-hidden border border-slate-700" style={{ background: postBg }}>
          {postImage ? (
            <div className="relative">
              <img src={postImage} alt="" className="w-full max-h-64 object-cover" />
              <button onClick={() => setPostImage(null)} className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center text-white text-sm">✕</button>
            </div>
          ) : (
            <div className="h-12" />
          )}
          <div className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{postEmoji}</span>
              <span className="text-sm font-bold" style={{ color: isDark ? "#fff" : "#1a1a1a" }}>@{username}</span>
            </div>
            <textarea value={postText} onChange={e => setPostText(e.target.value)} placeholder="Nima haqida yozyapsiz?" maxLength={300}
              rows={3}
              className="w-full bg-transparent outline-none resize-none text-sm font-medium"
              style={{ color: isDark ? "#fff" : "#1a1a1a" }} />
            {postLocation && (
              <p className="text-xs mt-1" style={{ color: isDark ? "#a8a29e" : "#6b7280" }}>📍 {postLocation}</p>
            )}
            {postAudio && (
              <p className="text-xs mt-1" style={{ color: isDark ? "#a8a29e" : "#6b7280" }}>🎵 {postAudio}</p>
            )}
          </div>
        </div>

        {/* Tools */}
        <div className="px-4 mt-4 space-y-3">
          <button onClick={() => postImageRef.current?.click()}
            className="w-full py-3 rounded-xl border border-slate-700 text-slate-300 text-sm font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition">
            📷 Rasm qo'shish
          </button>

          {/* Emoji */}
          <div>
            <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Emoji</p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {EMOJIS.slice(0, 15).map(e => (
                <button key={e} onClick={() => setPostEmoji(e)}
                  className={`flex-shrink-0 text-xl w-9 h-9 rounded-xl flex items-center justify-center transition ${postEmoji === e ? "ring-2 scale-110" : "bg-slate-800"}`}
                  style={postEmoji === e ? { outline: `2px solid ${accentColor}`, background: `${accentColor}22` } : {}}>
                  {e}
                </button>
              ))}
            </div>
          </div>

          {/* BG */}
          <div>
            <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Fon</p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {POST_BGS.map((c, i) => (
                <button key={i} onClick={() => setPostBg(c.bg)}
                  className={`flex-shrink-0 w-9 h-9 rounded-xl border-2 transition ${postBg === c.bg ? "border-white scale-110" : "border-slate-700"}`}
                  style={{ background: c.bg }} />
              ))}
            </div>
          </div>

          <input value={postLocation} onChange={e => setPostLocation(e.target.value)}
            placeholder="📍 Joylashuv (ixtiyoriy)"
            className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
          <input value={postAudio} onChange={e => setPostAudio(e.target.value)}
            placeholder="🎵 Musiqa (ixtiyoriy, masalan: Drake - God's Plan)"
            className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition" />
        </div>
        <div className="h-10" />
      </div>
    );
  }

  /* ──────────────────────────────── MAIN FEED ─────────────────────── */
  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#030712]">

      {/* ── Top bar ── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 pt-4 pb-3 border-b border-slate-800/60">
        <h1 className="text-lg font-black text-white">NEXUS <span style={{ color: accentColor }}>Feed</span></h1>
        <div className="flex gap-2">
          <button onClick={() => setMode("story_compose")}
            className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full transition"
            style={{ background: `${accentColor}20`, color: accentColor, border: `1px solid ${accentColor}40` }}>
            ⚡ Story
          </button>
          <button onClick={() => setMode("post_compose")}
            className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full bg-slate-800 text-slate-300 hover:bg-slate-700 transition">
            ✏️ Post
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* ── Stories row ── */}
        <div className="px-3 py-3 border-b border-slate-800/40">
          <div className="flex gap-3 overflow-x-auto pb-1 no-scrollbar">
            {/* My story bubble */}
            <div className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer"
              onClick={() => myStory ? setViewIdx(allStoriesWithMe.findIndex(s => s.username === username)) : setMode("story_compose")}>
              <div className="relative">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl font-black border-3 overflow-hidden ${myStory ? "" : "border-dashed"}`}
                  style={{
                    background: myStory ? myStory.bg : "linear-gradient(135deg,#1e293b,#334155)",
                    border: myStory ? `3px solid ${accentColor}` : "3px dashed #334155"
                  }}>
                  {myStory?.image ? <img src={myStory.image} alt="" className="w-full h-full object-cover" /> : myStory ? <span>{myStory.emoji}</span> : <span className="text-slate-500 text-2xl">+</span>}
                </div>
                {!myStory && (
                  <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full flex items-center justify-center text-black text-xs font-black"
                    style={{ background: accentColor }}>+</div>
                )}
              </div>
              <p className="text-[10px] text-slate-400 font-medium w-16 text-center truncate">Mening</p>
            </div>

            {/* Other stories */}
            {stories.map((s, i) => {
              const viewed = s.data.views?.includes(username);
              return (
                <div key={s.username} className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer"
                  onClick={() => setViewIdx(allStoriesWithMe.findIndex(st => st.username === s.username))}>
                  <div className="relative w-16 h-16">
                    {/* Gradient ring */}
                    <div className="absolute inset-0 rounded-full p-0.5"
                      style={{ background: viewed ? "#1e293b" : `linear-gradient(45deg, ${accentColor}, #ec4899, #f97316, ${accentColor})`, padding: "2px" }}>
                      <div className="w-full h-full rounded-full flex items-center justify-center text-2xl overflow-hidden border-2 border-[#030712]"
                        style={{ background: s.data.bg }}>
                        {s.data.image ? <img src={s.data.image} alt="" className="w-full h-full object-cover" /> : <span>{s.data.emoji}</span>}
                      </div>
                    </div>
                    {/* Animated ring if unseen */}
                    {!viewed && (
                      <div className="absolute inset-[-2px] rounded-full animate-spin pointer-events-none"
                        style={{ background: `conic-gradient(${accentColor} 0deg, transparent 120deg, #ec4899 180deg, transparent 300deg)`, animationDuration: "3s" }} />
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium w-16 text-center truncate">@{s.username}</p>
                </div>
              );
            })}

            {stories.length === 0 && !myStory && (
              <div className="flex items-center gap-2 text-slate-600 text-xs py-4 px-2">
                Hozircha story yo'q
              </div>
            )}
          </div>
        </div>

        {/* ── Posts feed ── */}
        <div className="space-y-0">
          {posts.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
              <div className="text-6xl animate-pulse">📸</div>
              <p className="text-slate-400 font-bold">Hozircha post yo'q</p>
              <p className="text-slate-600 text-sm">Birinchi bo'lib ulashing!</p>
              <button onClick={() => setMode("post_compose")}
                className="px-5 py-2.5 rounded-2xl font-bold text-sm text-white" style={{ background: accentColor }}>
                + Yangi post
              </button>
            </div>
          )}

          {posts.map(post => {
            const liked = !!post.likes[username];
            const likeCount = Object.keys(post.likes).length;
            const comments = Array.isArray(post.comments) ? post.comments : [];
            const showComments = expandedComments[post.id];
            const isDark = post.bg?.includes("gradient") ? true : POST_BGS.find(b => b.bg === post.bg)?.dark ?? true;
            const textColor = isDark ? "#fff" : "#1a1a1a";
            const subColor = isDark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.5)";

            return (
              <article key={post.id} className="border-b border-slate-800/50">
                {/* Post header */}
                <div className="flex items-center justify-between px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center font-black text-sm"
                      style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, color: "#000" }}>
                      {post.username[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="font-bold text-sm text-white">@{post.username}</p>
                      {post.location && <p className="text-[10px] text-slate-500">📍 {post.location}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-600">{timeAgo(post.createdAt)}</span>
                    {post.username === username && (
                      <button onClick={() => deletePost(post)} className="text-slate-600 hover:text-rose-400 transition text-sm p-1">🗑️</button>
                    )}
                    <button className="text-slate-600 text-sm p-1">⋯</button>
                  </div>
                </div>

                {/* Post image */}
                {post.image && (
                  <div className="w-full">
                    <img src={post.image} alt="" className="w-full object-cover" style={{ maxHeight: "480px" }} />
                  </div>
                )}

                {/* Post content card */}
                {(post.text || !post.image) && (
                  <div className="mx-4 my-1 rounded-2xl overflow-hidden" style={{ background: post.bg }}>
                    <div className="px-5 py-5">
                      <div className="flex items-start gap-3">
                        <span className="text-3xl flex-shrink-0">{post.emoji}</span>
                        <p className="text-base font-semibold leading-relaxed" style={{ color: textColor }}>{post.text}</p>
                      </div>
                      {post.audio && (
                        <div className="mt-3 flex items-center gap-2 text-xs font-medium" style={{ color: subColor }}>
                          <span>🎵</span>
                          <span>{post.audio}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Action bar */}
                <div className="px-4 pt-2 pb-1">
                  <div className="flex items-center gap-4">
                    <button onClick={() => toggleLike(post)}
                      className="flex items-center gap-1.5 transition active:scale-90"
                      style={{ color: liked ? "#f43f5e" : "#64748b" }}>
                      <span className="text-xl">{liked ? "❤️" : "🤍"}</span>
                      <span className="text-sm font-bold">{likeCount || ""}</span>
                    </button>
                    <button onClick={() => setExpandedComments(prev => ({ ...prev, [post.id]: !showComments }))}
                      className="flex items-center gap-1.5 text-slate-500 hover:text-slate-300 transition">
                      <span className="text-xl">💬</span>
                      <span className="text-sm font-bold">{comments.length || ""}</span>
                    </button>
                    <button className="flex items-center gap-1.5 text-slate-500 hover:text-slate-300 transition">
                      <span className="text-xl">↗️</span>
                    </button>
                    <button className="ml-auto text-slate-500 hover:text-slate-300 transition">
                      <span className="text-xl">🔖</span>
                    </button>
                  </div>

                  {/* Likes summary */}
                  {likeCount > 0 && (
                    <p className="text-xs font-bold text-slate-300 mt-1">
                      {likeCount} ta yoqdi
                    </p>
                  )}

                  {/* Audio tag */}
                  {post.audio && !post.text && (
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1.5 bg-slate-800/50 px-2.5 py-1 rounded-full inline-flex">
                      <span>🎵</span> {post.audio}
                    </div>
                  )}
                </div>

                {/* Comments */}
                {showComments && (
                  <div className="px-4 pb-2 space-y-2">
                    {comments.slice(0, 5).map((c, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black flex-shrink-0"
                          style={{ background: accentColor, color: "#000" }}>
                          {c.username[0].toUpperCase()}
                        </div>
                        <div className="flex-1 bg-slate-900/60 rounded-xl px-3 py-1.5">
                          <span className="text-[10px] font-bold" style={{ color: accentColor }}>@{c.username} </span>
                          <span className="text-xs text-slate-300">{c.text}</span>
                        </div>
                      </div>
                    ))}
                    {comments.length > 5 && (
                      <p className="text-xs text-slate-600 pl-8">{comments.length - 5} ta izoh ko'proq...</p>
                    )}
                    {/* Comment input */}
                    <div className="flex items-center gap-2 pt-1">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0"
                        style={{ background: accentColor, color: "#000" }}>
                        {username[0].toUpperCase()}
                      </div>
                      <input value={commentInput[post.id] || ""}
                        onChange={e => setCommentInput(prev => ({ ...prev, [post.id]: e.target.value }))}
                        onKeyDown={e => e.key === "Enter" && sendComment(post)}
                        placeholder="Izoh yozing..."
                        className="flex-1 bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-full text-xs text-white outline-none focus:border-cyan-500 transition" />
                      <button onClick={() => sendComment(post)}
                        className="text-xs font-bold px-2 py-1.5" style={{ color: accentColor }}>Joyla</button>
                    </div>
                  </div>
                )}
                <div className="h-2" />
              </article>
            );
          })}
          <div className="h-6" />
        </div>
      </div>
    </div>
  );
}
