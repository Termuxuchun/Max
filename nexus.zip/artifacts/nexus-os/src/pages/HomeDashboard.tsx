import { useEffect, useState, useRef } from "react";
import { ref, onValue, get, query, orderByChild, limitToLast } from "firebase/database";
import { db } from "../firebase";
import { Zap, TrendingUp, Users, Star, ChevronRight, Flame, Crown, Gift, Target, Clock, Sparkles, ArrowUp } from "lucide-react";
import type { ActivityEntry } from "../utils/activityLog";

interface Props {
  username: string;
  accentColor: string;
  starsBalance: number;
  onNavigate: (tab: string) => void;
  isPremium?: boolean;
}

const QUICK_APPS: { tab: string; icon: string; label: string; color: string; badge?: string }[] = [
  { tab: "chats",       icon: "💬", label: "Chatlar",       color: "#22d3ee" },
  { tab: "feed",        icon: "📰", label: "Lenta",          color: "#a855f7" },
  { tab: "calls",       icon: "📞", label: "Qo'ng'iroq",    color: "#22c55e" },
  { tab: "ai",          icon: "🤖", label: "AI Bot",        color: "#7c3aed", badge: "NEW" },
  { tab: "market",      icon: "🛍️", label: "Bozor",         color: "#f59e0b", badge: "HOT" },
  { tab: "voicerooms",  icon: "🎙️", label: "Ovoz Xona",    color: "#ef4444", badge: "LIVE" },
  { tab: "weather",     icon: "🌤️", label: "Ob-Havo",       color: "#38bdf8" },
  { tab: "crypto",      icon: "₿",  label: "Kripto",        color: "#f97316" },
  { tab: "flashcard",   icon: "🧠", label: "Til O'rganish", color: "#8b5cf6" },
  { tab: "leaderboard", icon: "🏆", label: "Reyting",       color: "#f59e0b", badge: "HOT" },
  { tab: "events",      icon: "🎉", label: "Tadbirlar",     color: "#f59e0b", badge: "NEW" },
  { tab: "clubs",       icon: "🏘️", label: "Klublar",        color: "#a855f7", badge: "NEW" },
  { tab: "activity",    icon: "⚡", label: "Faollik",        color: "#22d3ee", badge: "LIVE" },
  { tab: "friends",     icon: "🤝", label: "Do'stlar",       color: "#4ade80", badge: "NEW" },
  { tab: "games",       icon: "🎮", label: "O'yinlar",      color: "#ec4899" },
  { tab: "wallet",      icon: "⭐", label: "Hamyon",         color: "#f59e0b" },
  { tab: "music",       icon: "🎵", label: "Musiqa",         color: "#14b8a6" },
  { tab: "polls",       icon: "📊", label: "So'rovnoma",    color: "#06b6d4" },
  { tab: "todo",        icon: "✅", label: "Vazifalar",      color: "#4ade80" },
  { tab: "qr",          icon: "📱", label: "QR Kod",        color: "#06b6d4" },
  { tab: "kundalik",    icon: "📖", label: "Kundalik",       color: "#94a3b8" },
  { tab: "analytics",   icon: "📈", label: "Analitika",      color: "#818cf8" },
];

const FEATURED = [
  { tab: "ai",         icon: "🤖", title: "AI Yordamchi",     desc: "GPT-4o & Gemini bilan muloqot qiling",   color: "#7c3aed", badge: "NEW" },
  { tab: "market",     icon: "🛍️", title: "Bozor",            desc: "Yulduzlar bilan savdo qiling",           color: "#f59e0b", badge: "HOT" },
  { tab: "games",      icon: "🎮", title: "17 ta O'yin",      desc: "Mafia, 2048, GTA 3D va ko'p o'yinlar",  color: "#ec4899", badge: null  },
  { tab: "voicerooms", icon: "🎙️", title: "Ovoz Xonalari",   desc: "Do'stlar bilan real-vaqt gaplashuv",     color: "#ef4444", badge: "LIVE" },
];

const DAILY_TIPS = [
  "💡 Kunlik bonusni olishni unutmang!",
  "🎯 Reyting jadvalidagi o'rningizni ko'taring",
  "🤖 AI bot yangi imkoniyatlar bilan yangilandi",
  "🎮 Yangi o'yinlar qo'shildi — sinab ko'ring!",
  "⭐ Do'stlarga yulduz yuboring va XP oling",
  "📰 Lentada yangi postlar sizni kutmoqda",
];

function useCountUp(target: number, duration = 1200) {
  const [val, setVal] = useState(0);
  const start = useRef<number | null>(null);
  const prev  = useRef(0);
  useEffect(() => {
    if (target === prev.current) return;
    const from = prev.current;
    prev.current = target;
    start.current = null;
    const diff = target - from;
    const tick = (ts: number) => {
      if (!start.current) start.current = ts;
      const pct = Math.min((ts - start.current) / duration, 1);
      const ease = 1 - Math.pow(1 - pct, 3);
      setVal(Math.round(from + diff * ease));
      if (pct < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [target, duration]);
  return val;
}

interface StatCardProps { icon: React.ReactNode; label: string; value: string | number; color: string; onClick?: () => void; trend?: number; }
function StatCard({ icon, label, value, color, onClick, trend }: StatCardProps) {
  const num = typeof value === "number" ? value : 0;
  const counted = useCountUp(num);
  const displayed = typeof value === "number" ? counted : value;
  return (
    <button onClick={onClick}
      className={`flex flex-col gap-2 p-4 rounded-2xl border transition-all duration-200 text-left w-full relative overflow-hidden group ${onClick ? "hover:scale-[1.02] active:scale-[0.98] cursor-pointer" : "cursor-default"}`}
      style={{ background: `linear-gradient(135deg, ${color}12, ${color}06)`, borderColor: `${color}30`, boxShadow: `0 0 20px ${color}08` }}>
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: `radial-gradient(ellipse at 80% 20%, ${color}15, transparent 60%)` }} />
      <div className="flex items-center justify-between relative">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: `${color}22`, color }}>{icon}</div>
        <div className="flex items-center gap-1">
          {trend !== undefined && trend > 0 && (
            <div className="flex items-center gap-0.5 text-[9px] font-bold text-green-400">
              <ArrowUp className="w-2.5 h-2.5" />+{trend}
            </div>
          )}
          {onClick && <ChevronRight className="w-3.5 h-3.5 opacity-30" style={{ color }} />}
        </div>
      </div>
      <div className="relative">
        <p className="text-xl font-black tabular-nums" style={{ color }}>
          {typeof displayed === "number" ? displayed.toLocaleString() : displayed}
        </p>
        <p className="text-[10px] text-slate-500 mt-0.5 leading-tight">{label}</p>
      </div>
    </button>
  );
}

function GreetingText({ username }: { username: string }) {
  const h = new Date().getHours();
  const greeting = h < 6 ? "Kechqurun xayrli" : h < 12 ? "Xayrli tong" : h < 17 ? "Xayrli kun" : h < 21 ? "Xayrli kech" : "Kechqurun xayrli";
  return <>{greeting}, <span className="text-white">@{username}</span>!</>;
}

export default function HomeDashboard({ username, accentColor, starsBalance, onNavigate, isPremium }: Props) {
  const [onlineCount, setOnlineCount] = useState(0);
  const [userCount,   setUserCount]   = useState(0);
  const [channelCount,setChannelCount]= useState(0);
  const [featIdx,     setFeatIdx]     = useState(0);
  const [visible,     setVisible]     = useState(false);
  const [onlineUsers, setOnlineUsers] = useState<string[]>([]);
  const [tipIdx,      setTipIdx]      = useState(0);
  const [canBonus,    setCanBonus]    = useState(false);
  const [myRank,      setMyRank]      = useState<number | null>(null);
  const [pulse,       setPulse]       = useState(false);
  const [recentActivity, setRecentActivity] = useState<ActivityEntry[]>([]);

  useEffect(() => { setTimeout(() => setVisible(true), 60); }, []);
  useEffect(() => {
    const t = setInterval(() => setFeatIdx(i => (i + 1) % FEATURED.length), 4000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    const t = setInterval(() => setTipIdx(i => (i + 1) % DAILY_TIPS.length), 5000);
    return () => clearInterval(t);
  }, []);
  // Pulse animation for online count
  useEffect(() => {
    const t = setInterval(() => { setPulse(true); setTimeout(() => setPulse(false), 600); }, 8000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const u1 = onValue(ref(db, "status"), snap => {
      const online: string[] = [];
      snap.forEach(c => { if (c.val()?.state === "online" && c.key !== username) online.push(c.key!); });
      setOnlineCount(online.length + 1);
      setOnlineUsers(online.slice(0, 8));
    });
    const u2 = onValue(ref(db, "users"), snap => setUserCount(snap.size));
    const u3 = onValue(ref(db, "channels"), snap => setChannelCount(snap.size));
    return () => { u1(); u2(); u3(); };
  }, [username]);

  // Recent activity
  useEffect(() => {
    const q = query(ref(db, "activity_feed"), orderByChild("ts"), limitToLast(6));
    return onValue(q, snap => {
      const list: ActivityEntry[] = [];
      if (snap.exists()) snap.forEach(c => { list.push(c.val() as ActivityEntry); });
      list.sort((a, b) => b.ts - a.ts);
      setRecentActivity(list);
    });
  }, []);

  // Check daily bonus
  useEffect(() => {
    get(ref(db, `stars/${username}`)).then(snap => {
      const last = snap.val()?.lastBonus || 0;
      setCanBonus(Date.now() - last >= 24 * 60 * 60 * 1000);
    });
  }, [username]);

  // Get rank
  useEffect(() => {
    get(ref(db, "stars")).then(snap => {
      if (!snap.exists()) return;
      const list: { u: string; bal: number }[] = [];
      snap.forEach(c => { list.push({ u: c.key!, bal: c.val()?.balance || 0 }); });
      list.sort((a, b) => b.bal - a.bal);
      const idx = list.findIndex(x => x.u === username);
      if (idx >= 0) setMyRank(idx + 1);
    });
  }, [username, starsBalance]);

  const feat = FEATURED[featIdx];

  return (
    <div className="flex flex-col h-full bg-[#030712] overflow-y-auto">
      <style>{`
        @keyframes home-slide-up { from { opacity:0;transform:translateY(18px); } to { opacity:1;transform:translateY(0); } }
        @keyframes home-hero-glow { 0%,100%{opacity:0.4;}50%{opacity:0.7;} }
        @keyframes ticker-move { 0%{transform:translateX(0);}100%{transform:translateX(-50%);} }
        @keyframes feat-in { from{opacity:0;transform:translateX(16px) scale(0.98);}to{opacity:1;transform:translateX(0) scale(1);} }
        @keyframes online-bounce { 0%,100%{transform:scale(1);}50%{transform:scale(1.15);} }
        @keyframes tip-slide { from{opacity:0;transform:translateY(6px);}to{opacity:1;transform:translateY(0);} }
        @keyframes badge-glow { 0%,100%{box-shadow:0 0 8px rgba(245,158,11,0.3);}50%{box-shadow:0 0 18px rgba(245,158,11,0.6);} }
        @keyframes bonus-pulse { 0%,100%{box-shadow:0 0 0 0 rgba(245,158,11,0.4);}70%{box-shadow:0 0 0 8px rgba(245,158,11,0);} }
        .home-card-hover { transition:all 0.2s cubic-bezier(0.4,0,0.2,1); }
        .home-card-hover:hover { transform:translateY(-2px) scale(1.02); box-shadow:0 8px 24px rgba(0,0,0,0.4); }
        .home-card-hover:active { transform:scale(0.97); }
      `}</style>

      {/* ── HERO ── */}
      <div className="relative overflow-hidden flex-shrink-0"
        style={{ background: "linear-gradient(160deg,rgba(15,23,42,0.98) 0%,rgba(10,15,30,0.95) 100%)" }}>
        <div className="absolute -top-8 -right-8 w-48 h-48 rounded-full pointer-events-none"
          style={{ background:`radial-gradient(circle,${accentColor}30 0%,transparent 70%)`,animation:"home-hero-glow 3s ease-in-out infinite" }}/>
        <div className="absolute -bottom-4 -left-4 w-32 h-32 rounded-full pointer-events-none"
          style={{ background:"radial-gradient(circle,#a855f720 0%,transparent 70%)",animation:"home-hero-glow 4s ease-in-out infinite 1.5s" }}/>
        <div className="absolute inset-0 pointer-events-none opacity-[0.025]"
          style={{ backgroundImage:`linear-gradient(${accentColor} 1px,transparent 1px),linear-gradient(90deg,${accentColor} 1px,transparent 1px)`,backgroundSize:"28px 28px" }}/>

        <div className="relative z-10 px-5 pt-5 pb-4">
          <div className="flex items-start justify-between gap-3">
            <div style={{ animation:visible?"home-slide-up 0.5s ease forwards":"none",opacity:visible?1:0 }}>
              <div className="flex items-center gap-2 mb-1">
                <div className={`w-1.5 h-1.5 rounded-full bg-green-400 ${pulse?"animate-ping":"animate-pulse"}`}/>
                <span className="text-[10px] text-slate-500 font-mono tracking-widest uppercase">NEXUS_OS v5.7</span>
              </div>
              <h1 className="text-xl font-black text-slate-100 leading-tight">
                <GreetingText username={username}/>
              </h1>
              <p className="text-[11px] text-slate-500 mt-1">
                {new Date().toLocaleDateString("uz-UZ",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1.5">
              {isPremium && (
                <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border flex-shrink-0"
                  style={{ background:"rgba(245,158,11,0.1)",borderColor:"rgba(245,158,11,0.3)",animation:"badge-glow 2s ease-in-out infinite" }}>
                  <Crown className="w-3.5 h-3.5 text-amber-400"/>
                  <span className="text-[10px] font-black text-amber-400 tracking-widest">PREMIUM</span>
                </div>
              )}
              {myRank !== null && (
                <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border flex-shrink-0"
                  style={{ background:`${accentColor}10`,borderColor:`${accentColor}30` }}>
                  <span className="text-base">🏆</span>
                  <span className="text-[10px] font-black" style={{ color:accentColor }}>#{myRank}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── DAILY BONUS BANNER (agar mavjud bo'lsa) ── */}
      {canBonus && (
        <div className="mx-4 mt-3 flex-shrink-0" style={{ animation:visible?"home-slide-up 0.4s ease both":"none" }}>
          <button onClick={() => onNavigate("wallet")}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition active:scale-95"
            style={{ background:"linear-gradient(135deg,#451a03,#78350f,#92400e)",border:"1px solid #d97706",animation:"bonus-pulse 2s ease-in-out infinite" }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl bg-amber-900/50 flex-shrink-0">🎁</div>
            <div className="flex-1 text-left">
              <p className="text-amber-300 font-black text-sm">Kunlik Bonus tayyor!</p>
              <p className="text-amber-600 text-[10px]">Hamyonga o'ting va yulduzlarni oling</p>
            </div>
            <div className="flex-shrink-0 flex items-center gap-1 text-amber-400 font-black">
              <Star className="w-4 h-4"/>+15
            </div>
          </button>
        </div>
      )}

      {/* ── LIVE STATS ── */}
      <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.08s ease both":"none" }}>
        <div className="grid grid-cols-2 gap-2.5">
          <StatCard icon={<Users className="w-4 h-4"/>} label="Online foydalanuvchi" value={onlineCount} color="#22c55e" onClick={() => onNavigate("contacts")} trend={onlineCount > 1 ? 1 : undefined}/>
          <StatCard icon={<Star className="w-4 h-4"/>} label="Yulduz balansi" value={starsBalance} color="#f59e0b" onClick={() => onNavigate("wallet")}/>
          <StatCard icon={<TrendingUp className="w-4 h-4"/>} label="Jami a'zo" value={userCount} color={accentColor}/>
          <StatCard icon={<Zap className="w-4 h-4"/>} label="Kanallar" value={channelCount} color="#a855f7" onClick={() => onNavigate("channels")}/>
        </div>
      </div>

      {/* ── ONLINE USERS STRIP ── */}
      {onlineUsers.length > 0 && (
        <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.4s 0.12s ease both":"none" }}>
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-2xl overflow-hidden"
            style={{ background:"rgba(34,197,94,0.05)",border:"1px solid rgba(34,197,94,0.15)" }}>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"/>
              <span className="text-[9px] font-black text-green-500 uppercase tracking-widest">LIVE</span>
            </div>
            <div className="flex gap-1.5 overflow-x-auto scroll-hidden flex-1">
              {onlineUsers.map(u => (
                <button key={u} onClick={() => onNavigate("chats")}
                  className="flex-shrink-0 flex items-center gap-1 px-2 py-1 rounded-lg bg-green-950/30 border border-green-900/40 transition hover:bg-green-900/30"
                  style={{ animation:"online-bounce 0.5s ease" }}>
                  <span className="text-base">{u[0]?.toUpperCase()}</span>
                  <span className="text-[9px] text-green-400 font-mono">@{u}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── SOCIAL PULSE ── */}
      {recentActivity.length > 0 && (
        <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.13s ease both":"none" }}>
          <div className="rounded-2xl overflow-hidden" style={{ background:"rgba(10,15,30,0.85)",border:"1px solid rgba(255,255,255,0.06)" }}>
            <div className="flex items-center justify-between px-4 pt-3 pb-2">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"/>
                <span className="text-[9px] font-black text-cyan-400 uppercase tracking-widest">⚡ JONLI FAOLLIK</span>
              </div>
              <button onClick={() => onNavigate("activity")}
                className="text-[9px] font-bold text-slate-500 hover:text-slate-300 transition">
                Barchasi →
              </button>
            </div>
            <div className="divide-y divide-slate-800/40">
              {recentActivity.slice(0,4).map((entry, i) => {
                const icons: Record<string,string> = { friend_accept:"🤝",event_created:"🎉",event_rsvp:"✅",club_created:"🏘️",club_joined:"🚀",club_post:"💬",feed_post:"📝",went_online:"🟢" };
                const colors: Record<string,string> = { friend_accept:"#4ade80",event_created:"#f59e0b",event_rsvp:"#22c55e",club_created:"#a855f7",club_joined:"#06b6d4",club_post:"#818cf8",feed_post:"#f472b6",went_online:"#4ade80" };
                const labels: Record<string, (e: ActivityEntry)=>string> = {
                  friend_accept: e => `@${e.actor} va @${e.targetUser} do'st bo'ldi`,
                  event_created: e => `@${e.actor} tadbir yaratdi`,
                  event_rsvp:    e => `@${e.actor} tadbirga boradi`,
                  club_created:  e => `@${e.actor} klub yaratdi`,
                  club_joined:   e => `@${e.actor} klubga qo'shildi`,
                  club_post:     e => `@${e.actor} post yozdi`,
                  feed_post:     e => `@${e.actor} lentaga post qo'ydi`,
                  went_online:   e => `@${e.actor} onlayn bo'ldi`,
                };
                const icon  = icons[entry.type]  || "⚡";
                const color = colors[entry.type] || accentColor;
                const labelFn = labels[entry.type];
                const labelText = labelFn ? labelFn(entry) : `@${entry.actor}`;
                const d = Date.now() - entry.ts;
                const ago = d < 60000 ? "hozir" : d < 3600000 ? `${Math.floor(d/60000)}d` : `${Math.floor(d/3600000)}s`;
                return (
                  <div key={i} className="flex items-center gap-3 px-4 py-2.5">
                    <span className="text-base flex-shrink-0">{icon}</span>
                    <p className="text-[10px] text-slate-400 flex-1 min-w-0 truncate"
                      style={{ "--c":color } as React.CSSProperties}>
                      <span className="font-bold" style={{ color }}>{labelText.split(" ").slice(0,2).join(" ")}</span>
                      {" "}{labelText.split(" ").slice(2).join(" ")}
                      {entry.entityName && <span className="text-slate-500"> · {entry.entityName}</span>}
                    </p>
                    <span className="text-[9px] text-slate-700 font-mono flex-shrink-0">{ago}</span>
                  </div>
                );
              })}
            </div>
            <div className="px-4 py-2">
              <button onClick={() => onNavigate("activity")}
                className="w-full py-2 rounded-xl text-[10px] font-bold transition active:scale-95"
                style={{ background:`${accentColor}10`,color:accentColor,border:`1px solid ${accentColor}20` }}>
                ⚡ Faollik lentasini ko'rish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── FEATURED CAROUSEL ── */}
      <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.14s ease both":"none" }}>
        <div className="relative overflow-hidden rounded-2xl cursor-pointer" onClick={() => onNavigate(feat.tab)}
          style={{ background:`linear-gradient(135deg,${feat.color}20,${feat.color}08)`,border:`1px solid ${feat.color}30`,minHeight:80 }}>
          <div className="absolute inset-0 pointer-events-none"
            style={{ background:`radial-gradient(ellipse at 80% 50%,${feat.color}15,transparent 60%)` }}/>
          <div key={feat.tab} className="relative z-10 flex items-center gap-4 px-4 py-3.5"
            style={{ animation:"feat-in 0.35s cubic-bezier(0.34,1.2,0.64,1) forwards" }}>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
              style={{ background:`${feat.color}25`,border:`1px solid ${feat.color}40` }}>
              {feat.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <p className="font-black text-white text-sm">{feat.title}</p>
                {feat.badge && (
                  <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full"
                    style={{ background:feat.color,color:"#fff",opacity:0.9 }}>{feat.badge}</span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">{feat.desc}</p>
            </div>
            <ChevronRight className="w-4 h-4 flex-shrink-0 opacity-40" style={{ color:feat.color }}/>
          </div>
          <div className="absolute bottom-2 right-3 flex gap-1">
            {FEATURED.map((_,i) => (
              <div key={i} className="rounded-full transition-all duration-300"
                style={{ width:i===featIdx?14:4,height:4,background:i===featIdx?feat.color:`${feat.color}40` }}/>
            ))}
          </div>
        </div>
      </div>

      {/* ── TODAY'S CHALLENGES ── */}
      <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.18s ease both":"none" }}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Target className="w-3.5 h-3.5 text-rose-400"/>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Bugungi Vazifalar</p>
          </div>
          <button onClick={() => onNavigate("wallet")} className="text-[9px] font-bold text-rose-400 hover:text-rose-300 transition">
            Barchasi →
          </button>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { icon:"💬", label:"3 xabar",   reward:5,  tab:"chats",  done:false },
            { icon:"🎮", label:"O'yin",      reward:7,  tab:"games",  done:false },
            { icon:"❤️", label:"5 layk",    reward:6,  tab:"feed",   done:false },
          ].map((ch,i) => (
            <button key={i} onClick={() => onNavigate(ch.tab)}
              className="home-card-hover flex flex-col items-center gap-1.5 p-3 rounded-2xl border relative"
              style={{ background:ch.done?"rgba(34,197,94,0.08)":"rgba(15,23,42,0.8)",borderColor:ch.done?"rgba(34,197,94,0.3)":"rgba(51,65,85,0.4)" }}>
              <span className={`text-xl ${ch.done?"":"animate-bounce"}`}>{ch.icon}</span>
              <p className="text-[10px] text-slate-300 font-bold">{ch.label}</p>
              <div className="flex items-center gap-0.5 text-amber-400">
                <Star className="w-2.5 h-2.5"/>
                <span className="text-[9px] font-bold">+{ch.reward}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ── APP GRID ── */}
      <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.22s ease both":"none" }}>
        <div className="flex items-center justify-between mb-2.5">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ilovalar</p>
          <span className="text-[9px] text-slate-600">{QUICK_APPS.length} ta</span>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {QUICK_APPS.map(app => (
            <button key={app.tab} onClick={() => onNavigate(app.tab)}
              className="home-card-hover flex flex-col items-center gap-1.5 p-2.5 rounded-2xl relative group"
              style={{ background:`${app.color}0A`,border:`1px solid ${app.color}20` }}>
              {app.badge && (
                <span className="absolute -top-1 -right-1 z-10 text-[7px] font-black px-1.5 py-0.5 rounded-full leading-none"
                  style={{ background:app.badge==="LIVE"?"#ef4444":app.badge==="HOT"?"#f97316":"#7c3aed",color:"#fff" }}>
                  {app.badge}
                </span>
              )}
              <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl transition-transform duration-200 group-hover:scale-110"
                style={{ background:`${app.color}18` }}>
                {app.icon}
              </div>
              <p className="text-[9px] font-medium text-center leading-tight" style={{ color:`${app.color}cc` }}>
                {app.label}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* ── QUICK ACTIONS ── */}
      <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.26s ease both":"none" }}>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5">Tezkor amallar</p>
        <div className="grid grid-cols-2 gap-2">
          {[
            { label:"🎰 Kunlik bonus",   tab:"wallet",      color:"#f59e0b", sub:"Yulduz yutib ol",     hot:canBonus },
            { label:"🎮 O'yin o'ynash",  tab:"games",       color:"#ec4899", sub:"17 ta o'yin",         hot:false },
            { label:"📡 Kanallar",        tab:"channels",    color:accentColor, sub:"Yangi postlar",     hot:false },
            { label:"🏆 Reyting",         tab:"leaderboard", color:"#f59e0b", sub:`#${myRank??""} o'rin`, hot:false },
          ].map((a,i) => (
            <button key={i} onClick={() => onNavigate(a.tab)}
              className="home-card-hover flex items-center gap-3 px-3 py-3 rounded-2xl text-left relative overflow-hidden"
              style={{ background:`${a.color}0A`,border:`1px solid ${a.color}${a.hot?"50":"20"}` }}>
              {a.hot && <div className="absolute inset-0" style={{ background:`${a.color}08`,animation:"badge-glow 1.5s ease-in-out infinite" }}/>}
              <div className="relative">
                <p className="text-xs font-bold text-slate-200">{a.label}</p>
                <p className="text-[9px] mt-0.5" style={{ color:`${a.color}99` }}>{a.sub}</p>
              </div>
              {a.hot && <Sparkles className="w-3.5 h-3.5 text-amber-400 absolute right-2 top-2 animate-pulse"/>}
            </button>
          ))}
        </div>
      </div>

      {/* ── DAILY TIP ── */}
      <div className="px-4 pt-3" style={{ animation:visible?"home-slide-up 0.5s 0.30s ease both":"none" }}>
        <div className="flex items-center gap-3 px-4 py-3 rounded-2xl overflow-hidden"
          style={{ background:"rgba(99,102,241,0.08)",border:"1px solid rgba(99,102,241,0.2)" }}>
          <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background:"rgba(99,102,241,0.2)" }}>
            <Sparkles className="w-4 h-4 text-indigo-400"/>
          </div>
          <p key={tipIdx} className="text-[11px] text-slate-300 font-medium flex-1"
            style={{ animation:"tip-slide 0.4s ease" }}>
            {DAILY_TIPS[tipIdx]}
          </p>
        </div>
      </div>

      {/* ── LIVE TICKER ── */}
      <div className="px-4 pt-3 pb-6" style={{ animation:visible?"home-slide-up 0.5s 0.34s ease both":"none" }}>
        <div className="flex items-center gap-2 px-3 py-2.5 rounded-2xl overflow-hidden"
          style={{ background:"rgba(15,23,42,0.8)",border:"1px solid rgba(255,255,255,0.05)" }}>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <Flame className="w-3.5 h-3.5 text-orange-400"/>
            <span className="text-[9px] font-black text-orange-400 uppercase tracking-widest">LIVE</span>
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="whitespace-nowrap text-[10px] text-slate-400 font-mono"
              style={{ animation:"ticker-move 20s linear infinite" }}>
              🟢 {onlineCount} kishi onlayn &nbsp;·&nbsp; ⭐ {starsBalance} yulduz &nbsp;·&nbsp; 🎮 17 ta o'yin &nbsp;·&nbsp; 🤖 AI ishlayapti &nbsp;·&nbsp; 🛍️ Bozorda yangi &nbsp;·&nbsp; 📡 {channelCount} kanal &nbsp;·&nbsp; 🏆 Reyting yangilandi &nbsp;·&nbsp; 🟢 {onlineCount} kishi onlayn &nbsp;·&nbsp; ⭐ {starsBalance} yulduz &nbsp;·&nbsp; 🎮 17 ta o'yin &nbsp;·&nbsp; 🤖 AI ishlayapti &nbsp;·&nbsp; 🛍️ Bozorda yangi &nbsp;·&nbsp; 📡 {channelCount} kanal
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
