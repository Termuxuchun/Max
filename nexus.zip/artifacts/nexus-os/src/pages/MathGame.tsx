import { useState, useEffect, useRef } from "react";

interface Props {
  accentColor: string;
}

type Level = "oson" | "urtacha" | "qiyin";

interface Equation {
  question: string;
  answer: number;
  steps: string[];
  explanation: string;
  type: string;
}

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function nonZero(min: number, max: number): number {
  let v = rand(min, max);
  while (v === 0) v = rand(min, max);
  return v;
}

function generateEasy(): Equation {
  const type = rand(1, 4);

  if (type === 1) {
    // x + a = b  →  x = b - a
    const a = rand(1, 20);
    const x = rand(1, 20);
    const b = x + a;
    return {
      question: `x + ${a} = ${b}`,
      answer: x,
      type: "Qo'shish",
      explanation: "x ning qiymatini topish uchun, ikki tomondan bir xil son ayiramiz",
      steps: [
        `x + ${a} = ${b}`,
        `x + ${a} − ${a} = ${b} − ${a}`,
        `x = ${x}`,
      ],
    };
  }

  if (type === 2) {
    // x - a = b  →  x = b + a
    const a = rand(1, 20);
    const x = rand(1, 20);
    const b = x - a;
    return {
      question: `x − ${a} = ${b}`,
      answer: x,
      type: "Ayirish",
      explanation: "x ning qiymatini topish uchun ikki tomondan bir xil son qo'shamiz",
      steps: [
        `x − ${a} = ${b}`,
        `x − ${a} + ${a} = ${b} + ${a}`,
        `x = ${x}`,
      ],
    };
  }

  if (type === 3) {
    // a·x = b  →  x = b / a
    const a = nonZero(2, 10);
    const x = rand(1, 12);
    const b = a * x;
    return {
      question: `${a}x = ${b}`,
      answer: x,
      type: "Ko'paytirish",
      explanation: "x ni topish uchun ikki tomonni koeffitsiyentga bo'lamiz",
      steps: [
        `${a}x = ${b}`,
        `${a}x ÷ ${a} = ${b} ÷ ${a}`,
        `x = ${x}`,
      ],
    };
  }

  // x / a = b  →  x = a * b
  const a = nonZero(2, 9);
  const x = rand(1, 12);
  const b = x; // x/a=b means x=b*a but for display: x = a*rand
  const bVal = rand(1, 10);
  const ans = a * bVal;
  return {
    question: `x ÷ ${a} = ${bVal}`,
    answer: ans,
    type: "Bo'lish",
    explanation: "x ni topish uchun ikki tomonni shu songa ko'paytiramiz",
    steps: [
      `x ÷ ${a} = ${bVal}`,
      `x ÷ ${a} × ${a} = ${bVal} × ${a}`,
      `x = ${ans}`,
    ],
  };
}

function generateMedium(): Equation {
  const type = rand(1, 4);

  if (type === 1) {
    // ax + b = c
    const a = nonZero(2, 8);
    const b = rand(-15, 15);
    const x = rand(1, 10);
    const c = a * x + b;
    const bSign = b >= 0 ? `+ ${b}` : `− ${Math.abs(b)}`;
    return {
      question: `${a}x ${bSign} = ${c}`,
      answer: x,
      type: "Ikki bosqichli",
      explanation: "Avval erkin had (son)ni ko'chiramiz, keyin koeffitsiyentga bo'lamiz",
      steps: [
        `${a}x ${bSign} = ${c}`,
        `${a}x = ${c} ${b >= 0 ? `− ${b}` : `+ ${Math.abs(b)}`}`,
        `${a}x = ${a * x}`,
        `x = ${a * x} ÷ ${a}`,
        `x = ${x}`,
      ],
    };
  }

  if (type === 2) {
    // a(x + b) = c
    const a = nonZero(2, 6);
    const b = rand(1, 8);
    const x = rand(1, 10);
    const c = a * (x + b);
    return {
      question: `${a}(x + ${b}) = ${c}`,
      answer: x,
      type: "Qavs ochish",
      explanation: "Avval ikkala tomonni koeffitsiyentga bo'lamiz, keyin sonni ko'chiramiz",
      steps: [
        `${a}(x + ${b}) = ${c}`,
        `x + ${b} = ${c} ÷ ${a}`,
        `x + ${b} = ${x + b}`,
        `x = ${x + b} − ${b}`,
        `x = ${x}`,
      ],
    };
  }

  if (type === 3) {
    // (x + a) / b = c
    const b = nonZero(2, 7);
    const a = rand(1, 10);
    const x = rand(1, 15);
    const c = Math.floor((x + a) / b);
    const actualX = c * b - a;
    if (actualX <= 0) return generateMedium();
    return {
      question: `(x + ${a}) ÷ ${b} = ${c}`,
      answer: actualX,
      type: "Kasrli",
      explanation: "Avval bo'luvchiga ko'paytiramiz, keyin sonni ko'chiramiz",
      steps: [
        `(x + ${a}) ÷ ${b} = ${c}`,
        `x + ${a} = ${c} × ${b}`,
        `x + ${a} = ${c * b}`,
        `x = ${c * b} − ${a}`,
        `x = ${actualX}`,
      ],
    };
  }

  // ax - bx = c  →  (a-b)x = c
  const a = nonZero(5, 12);
  const b = rand(1, a - 1);
  const x = rand(1, 10);
  const c = (a - b) * x;
  return {
    question: `${a}x − ${b}x = ${c}`,
    answer: x,
    type: "O'xshash hadlar",
    explanation: "x li hadlarni bir tomonga to'playiz, keyin bo'lamiz",
    steps: [
      `${a}x − ${b}x = ${c}`,
      `(${a} − ${b})x = ${c}`,
      `${a - b}x = ${c}`,
      `x = ${c} ÷ ${a - b}`,
      `x = ${x}`,
    ],
  };
}

function generateHard(): Equation {
  const type = rand(1, 4);

  if (type === 1) {
    // ax + b = cx + d  →  (a-c)x = d-b
    const a = nonZero(3, 10);
    const c = rand(1, a - 1);
    const x = rand(1, 10);
    const b = rand(-10, 10);
    const d = (a - c) * x + b;
    const bSign = b >= 0 ? `+ ${b}` : `− ${Math.abs(b)}`;
    const dSign = d >= 0 ? `+ ${d}` : `− ${Math.abs(d)}`;
    return {
      question: `${a}x ${bSign} = ${c}x ${dSign}`,
      answer: x,
      type: "Ikki tomonlama",
      explanation: "x li hadlarni chap, sonlarni o'ng tomonga ko'chiramiz",
      steps: [
        `${a}x ${bSign} = ${c}x ${dSign}`,
        `${a}x − ${c}x = ${d} − ${b}`,
        `${a - c}x = ${d - b}`,
        `x = ${d - b} ÷ ${a - c}`,
        `x = ${x}`,
      ],
    };
  }

  if (type === 2) {
    // a/(x) = b  →  x = a/b (whole)
    const b = nonZero(2, 8);
    const x = nonZero(2, 10);
    const a = b * x;
    return {
      question: `${a} ÷ x = ${b}`,
      answer: x,
      type: "Noma'lum maxrajda",
      explanation: "Ikki tomonni x ga ko'paytirib, keyin b ga bo'lamiz",
      steps: [
        `${a} ÷ x = ${b}`,
        `${a} = ${b} × x`,
        `x = ${a} ÷ ${b}`,
        `x = ${x}`,
      ],
    };
  }

  if (type === 3) {
    // a(bx + c) = d
    const a = nonZero(2, 5);
    const b = nonZero(2, 6);
    const c = rand(1, 8);
    const x = rand(1, 8);
    const d = a * (b * x + c);
    return {
      question: `${a}(${b}x + ${c}) = ${d}`,
      answer: x,
      type: "W'chtib ochish",
      explanation: "Avval qavs ichidagini topamiz, keyin x ni topamiz",
      steps: [
        `${a}(${b}x + ${c}) = ${d}`,
        `${b}x + ${c} = ${d} ÷ ${a}`,
        `${b}x + ${c} = ${d / a}`,
        `${b}x = ${d / a} − ${c}`,
        `${b}x = ${b * x}`,
        `x = ${b * x} ÷ ${b}`,
        `x = ${x}`,
      ],
    };
  }

  // System: x + y = a, x - y = b
  const x = rand(2, 15);
  const y = rand(1, x - 1);
  const a = x + y;
  const b = x - y;
  return {
    question: `x + y = ${a}\nx − y = ${b}\n(x = ?)`,
    answer: x,
    type: "Tenglama sistemasi",
    explanation: "Ikkala tenglamani qo'shamiz: 2x = ? dan x ni topamiz",
    steps: [
      `  x + y = ${a}`,
      `+ x − y = ${b}`,
      `─────────────`,
      `  2x     = ${a + b}`,
      `  x      = ${(a + b)} ÷ 2`,
      `  x      = ${x}`,
      `  y      = ${a} − ${x} = ${y}`,
    ],
  };
}

function generate(level: Level): Equation {
  if (level === "oson") return generateEasy();
  if (level === "urtacha") return generateMedium();
  return generateHard();
}

const LEVEL_CONFIG = {
  oson:    { label: "Oson",    emoji: "🟢", color: "#22c55e", timeLimit: 30 },
  urtacha: { label: "O'rtacha", emoji: "🟡", color: "#f59e0b", timeLimit: 45 },
  qiyin:   { label: "Qiyin",   emoji: "🔴", color: "#ef4444", timeLimit: 60 },
};

export default function MathGame({ accentColor }: Props) {
  const [level, setLevel] = useState<Level | null>(null);
  const [eq, setEq] = useState<Equation | null>(null);
  const [input, setInput] = useState("");
  const [phase, setPhase] = useState<"question" | "correct" | "wrong">("question");
  const [showSteps, setShowSteps] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [total, setTotal] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [timerOn, setTimerOn] = useState(true);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function startLevel(lv: Level) {
    setLevel(lv);
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    setTotal(0);
    nextQuestion(lv);
  }

  function nextQuestion(lv: Level = level!) {
    const e = generate(lv);
    setEq(e);
    setInput("");
    setPhase("question");
    setShowSteps(false);
    setTimeLeft(LEVEL_CONFIG[lv].timeLimit);
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  useEffect(() => {
    if (!level || !timerOn) return;
    if (timerRef.current) clearInterval(timerRef.current);
    if (phase !== "question") return;
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          handleWrong();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [eq, phase, level, timerOn]);

  function handleSubmit() {
    if (!eq || phase !== "question") return;
    const val = parseInt(input.trim(), 10);
    if (isNaN(val)) return;
    if (timerRef.current) clearInterval(timerRef.current);
    setTotal(t => t + 1);
    if (val === eq.answer) {
      const pts = level === "oson" ? 10 : level === "urtacha" ? 20 : 35;
      const bonus = timerOn ? Math.floor(timeLeft / 5) : 0;
      setScore(s => s + pts + bonus);
      const ns = streak + 1;
      setStreak(ns);
      setMaxStreak(m => Math.max(m, ns));
      setPhase("correct");
    } else {
      handleWrong();
    }
  }

  function handleWrong() {
    setStreak(0);
    setPhase("wrong");
    setShowSteps(true);
  }

  if (!level) {
    return (
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <p className="text-4xl">🧮</p>
          <h2 className="text-xl font-black text-white">Matematika O'yini</h2>
          <p className="text-sm text-slate-400">Tenglamalarni yechishni o'rganing va mashq qiling!</p>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {(["oson", "urtacha", "qiyin"] as Level[]).map(lv => {
            const cfg = LEVEL_CONFIG[lv];
            const descs: Record<Level, string> = {
              oson:    "x + a = b,  ax = b,  x − a = b  kabi oddiy tenglamalar",
              urtacha: "2x + 3 = 11,  a(x+b) = c  kabi ikki bosqichli tenglamalar",
              qiyin:   "Ikki tomonlama tenglamalar va tenglama sistemasi",
            };
            return (
              <button key={lv} onClick={() => startLevel(lv)}
                className="p-5 rounded-2xl border-2 text-left transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ borderColor: `${cfg.color}60`, background: `${cfg.color}10` }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-2xl">{cfg.emoji}</span>
                  <div>
                    <p className="font-black text-white text-base">{cfg.label}</p>
                    <p className="text-[10px] font-mono" style={{ color: cfg.color }}>
                      {lv === "oson" ? "+10 ball" : lv === "urtacha" ? "+20 ball" : "+35 ball"} · {cfg.timeLimit}s limit
                    </p>
                  </div>
                </div>
                <p className="text-xs text-slate-400 font-mono">{descs[lv]}</p>
              </button>
            );
          })}
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
          <p className="text-xs font-bold text-slate-300">📚 Qanday ishlaydi?</p>
          <p className="text-[11px] text-slate-500 leading-relaxed">
            Har bir savolda <span className="text-cyan-400 font-mono">x = ?</span> qiymatini toping.
            Noto'g'ri javob berganda yechish bosqichlari ko'rsatiladi.
            Ketma-ket to'g'ri javoblar bonus ball beradi! ⚡
          </p>
        </div>
      </div>
    );
  }

  const cfg = LEVEL_CONFIG[level];
  const timerPct = eq ? (timeLeft / cfg.timeLimit) * 100 : 100;
  const timerColor = timerPct > 50 ? "#22c55e" : timerPct > 25 ? "#f59e0b" : "#ef4444";
  const correctRate = total > 0 ? Math.round((score / (total * (level === "oson" ? 10 : level === "urtacha" ? 20 : 35))) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Header stats */}
      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={() => setLevel(null)} className="text-slate-400 hover:text-white text-lg p-1">←</button>
        <span className="text-lg">{cfg.emoji}</span>
        <span className="font-black text-white text-sm">{cfg.label} daraja</span>
        <div className="ml-auto flex items-center gap-2">
          {streak >= 3 && (
            <span className="text-[10px] font-black px-2 py-1 rounded-full bg-amber-900/40 text-amber-400 animate-pulse">
              🔥 {streak}
            </span>
          )}
          <span className="text-[10px] font-mono px-2 py-1 rounded-lg bg-slate-800 text-slate-300">
            ✅ {total > 0 ? Math.round((score / (total * (level === "oson" ? 10 : level === "urtacha" ? 20 : 35))) * 100) : 0}%
          </span>
          <span className="text-sm font-black" style={{ color: accentColor }}>⭐ {score}</span>
        </div>
      </div>

      {/* Timer bar */}
      {timerOn && phase === "question" && (
        <div className="space-y-1">
          <div className="flex justify-between text-[10px] font-mono text-slate-500">
            <span>Vaqt</span>
            <span style={{ color: timerColor }}>{timeLeft}s</span>
          </div>
          <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
            <div className="h-full rounded-full transition-all duration-1000"
              style={{ width: `${timerPct}%`, background: timerColor }} />
          </div>
        </div>
      )}

      {/* Equation card */}
      {eq && (
        <div className="p-6 rounded-2xl border-2 text-center space-y-2"
          style={{
            borderColor: phase === "correct" ? "#22c55e60" : phase === "wrong" ? "#ef444460" : `${accentColor}40`,
            background: phase === "correct" ? "#052e1620" : phase === "wrong" ? "#2d051020" : "rgba(15,23,42,0.7)",
          }}
        >
          <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{eq.type}</p>
          <pre className="text-2xl sm:text-3xl font-black text-white tracking-wide whitespace-pre-wrap font-mono leading-tight">
            {eq.question}
          </pre>
          {phase === "question" && (
            <p className="text-xs text-slate-500 italic">{eq.explanation}</p>
          )}
          {phase === "correct" && (
            <p className="text-green-400 font-bold text-sm animate-bounce">✅ To'g'ri! x = {eq.answer}</p>
          )}
          {phase === "wrong" && (
            <p className="text-rose-400 font-bold text-sm">❌ Noto'g'ri. To'g'ri javob: <span className="font-black">{eq.answer}</span></p>
          )}
        </div>
      )}

      {/* Input & submit */}
      {phase === "question" && eq && (
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-slate-400 text-sm select-none">x =</span>
            <input
              ref={inputRef}
              type="number"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSubmit()}
              placeholder="?"
              className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-950 border-2 border-slate-700 focus:border-cyan-500 text-white text-xl font-black outline-none transition text-center"
            />
          </div>
          <button
            onClick={handleSubmit}
            disabled={!input.trim()}
            className="px-6 py-4 rounded-2xl font-black text-white text-sm transition active:scale-95 disabled:opacity-40"
            style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}
          >
            ✓
          </button>
        </div>
      )}

      {/* Step-by-step solution */}
      {showSteps && eq && (
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700 space-y-2">
          <p className="text-xs font-black text-slate-300 flex items-center gap-2">
            📐 Yechish bosqichlari
            <span className="text-[9px] text-slate-500 font-normal">— diqqat bilan o'qing!</span>
          </p>
          <div className="space-y-1 font-mono">
            {eq.steps.map((step, i) => (
              <div key={i} className={`flex items-center gap-2 py-1 px-2 rounded-lg transition-all ${i === eq.steps.length - 1 ? "bg-green-950/40 border border-green-900/40" : ""}`}>
                {i < eq.steps.length - 1
                  ? <span className="text-slate-600 text-[10px] w-4 flex-shrink-0">{i + 1}.</span>
                  : <span className="text-green-400 text-[10px] w-4 flex-shrink-0">✓</span>
                }
                <span className={`text-sm ${i === eq.steps.length - 1 ? "text-green-300 font-black" : "text-slate-300"}`}>
                  {step}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Next button */}
      {(phase === "correct" || phase === "wrong") && (
        <button
          onClick={() => nextQuestion()}
          className="w-full py-4 rounded-2xl font-black text-white text-sm transition active:scale-95"
          style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}
        >
          ➡️ Keyingi tenglama
        </button>
      )}

      {/* Progress summary */}
      {total > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Ball", val: score, icon: "⭐" },
            { label: "Jami", val: total, icon: "📊" },
            { label: "Rekord zanjir", val: maxStreak, icon: "🔥" },
          ].map(s => (
            <div key={s.label} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
              <p className="text-base">{s.icon}</p>
              <p className="text-lg font-black text-white">{s.val}</p>
              <p className="text-[9px] text-slate-500 font-mono uppercase">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Timer toggle */}
      <div className="flex items-center justify-between px-1">
        <p className="text-[11px] text-slate-500">Vaqt limiti</p>
        <button
          onClick={() => setTimerOn(v => !v)}
          className="flex items-center gap-1.5 text-[11px] font-bold transition"
          style={{ color: timerOn ? "#22c55e" : "#64748b" }}
        >
          <div className="w-8 h-4 rounded-full relative transition" style={{ background: timerOn ? "#22c55e" : "#1e293b" }}>
            <div className={`w-3 h-3 rounded-full bg-white absolute top-0.5 transition-all ${timerOn ? "translate-x-4" : "translate-x-0.5"}`} />
          </div>
          {timerOn ? "Yoqilgan" : "O'chirilgan"}
        </button>
      </div>
    </div>
  );
}
