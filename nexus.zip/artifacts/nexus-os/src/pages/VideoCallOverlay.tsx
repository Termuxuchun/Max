import { useEffect, useRef, useState, useCallback } from "react";
import {
  Mic, MicOff, Video, VideoOff, PhoneOff, Volume2, VolumeX,
  RotateCcw, Monitor, MonitorOff, Maximize2, Minimize2, Signal
} from "lucide-react";

interface VideoCallOverlayProps {
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  peer: string;
  callStatus: "calling" | "in-call" | "connecting";
  callType: "audio" | "video";
  isMuted: boolean;
  isCameraOff: boolean;
  callDuration: number;
  onMute: () => void;
  onCameraToggle: () => void;
  onEnd: () => void;
}

function formatDuration(secs: number) {
  const m = Math.floor(secs / 60).toString().padStart(2, "0");
  const s = (secs % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function getAvatarGradient(name: string) {
  const gradients = [
    ["#22d3ee", "#3b82f6"],
    ["#8b5cf6", "#ec4899"],
    ["#10b981", "#22d3ee"],
    ["#f59e0b", "#ef4444"],
    ["#6366f1", "#8b5cf6"],
    ["#14b8a6", "#3b82f6"],
  ];
  const idx = (name.charCodeAt(0) || 0) % gradients.length;
  return gradients[idx];
}

function SoundWave({ active }: { active: boolean }) {
  return (
    <div className="flex items-end gap-[3px] h-6">
      {[14, 20, 10, 22, 8, 18, 12, 24, 10, 16].map((h, i) => (
        <div
          key={i}
          className="w-[3px] rounded-full"
          style={{
            height: active ? h : 4,
            background: active ? "linear-gradient(to top, #22d3ee, #6366f1)" : "rgba(255,255,255,0.15)",
            animation: active ? `sound-wave ${0.6 + i * 0.08}s ease-in-out infinite alternate` : "none",
            animationDelay: `${i * 0.07}s`,
            transition: "height 0.3s ease",
          }}
        />
      ))}
    </div>
  );
}

function NetworkQuality({ quality }: { quality: "good" | "fair" | "poor" | "unknown" }) {
  const colors = { good: "#22c55e", fair: "#f59e0b", poor: "#ef4444", unknown: "#64748b" };
  const labels = { good: "Yaxshi", fair: "O'rtacha", poor: "Yomon", unknown: "..." };
  return (
    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
      <Signal className="w-3 h-3" style={{ color: colors[quality] }} />
      <span className="text-[10px] font-mono" style={{ color: colors[quality] }}>{labels[quality]}</span>
    </div>
  );
}

function CtrlBtn({
  icon, label, onClick, danger, active, large
}: {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  danger?: boolean;
  active?: boolean;
  large?: boolean;
}) {
  const size = large ? 72 : 54;
  return (
    <div className="flex flex-col items-center gap-2">
      <button
        onClick={onClick}
        style={{
          width: size, height: size,
          boxShadow: danger
            ? "0 0 30px rgba(239,68,68,0.5), 0 4px 20px rgba(239,68,68,0.3)"
            : active
              ? "0 0 20px rgba(239,68,68,0.2)"
              : "0 4px 20px rgba(0,0,0,0.3)"
        }}
        className={`rounded-full flex items-center justify-center transition-all duration-200 active:scale-90 select-none ${
          danger
            ? "bg-gradient-to-br from-red-500 to-rose-600"
            : active
              ? "bg-red-500/20 border border-red-500/40 text-red-400"
              : "bg-white/10 border border-white/12 text-white hover:bg-white/20"
        }`}
      >
        {icon}
      </button>
      <span className="text-[10px] text-white/40 font-medium tracking-wide">{label}</span>
    </div>
  );
}

export default function VideoCallOverlay({
  localStream, remoteStream, peer, callStatus, callType,
  isMuted, isCameraOff, callDuration, onMute, onCameraToggle, onEnd
}: VideoCallOverlayProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const [pipPos, setPipPos] = useState({ x: 16, y: 80 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [showControls, setShowControls] = useState(true);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [grad] = useState(() => getAvatarGradient(peer));
  const [isSpeakerOff, setIsSpeakerOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [networkQuality, setNetworkQuality] = useState<"good" | "fair" | "poor" | "unknown">("unknown");
  const containerRef = useRef<HTMLDivElement>(null);

  // Attach local video
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Attach remote video + audio (separate audio element avoids autoplay policy issues)
  useEffect(() => {
    if (remoteStream) {
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
      }
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = remoteStream;
        remoteAudioRef.current.muted = isSpeakerOff;
        remoteAudioRef.current.play().catch(() => {});
      }
    }
  }, [remoteStream]);

  // Sync speaker mute
  useEffect(() => {
    if (remoteAudioRef.current) {
      remoteAudioRef.current.muted = isSpeakerOff;
    }
  }, [isSpeakerOff]);

  // Network quality estimation via RTCPeerConnection stats
  useEffect(() => {
    if (callStatus !== "in-call") { setNetworkQuality("unknown"); return; }
    let cancelled = false;
    const check = async () => {
      if (cancelled) return;
      try {
        const pc = (window as any).__nexus_pc as RTCPeerConnection | undefined;
        if (!pc) return;
        const stats = await pc.getStats();
        let rtt = 0;
        stats.forEach((r: RTCStats) => {
          if (r.type === "candidate-pair" && (r as any).state === "succeeded") {
            rtt = (r as any).currentRoundTripTime || 0;
          }
        });
        if (rtt === 0) setNetworkQuality("unknown");
        else if (rtt < 0.15) setNetworkQuality("good");
        else if (rtt < 0.35) setNetworkQuality("fair");
        else setNetworkQuality("poor");
      } catch {}
    };
    const iv = setInterval(check, 3000);
    check();
    return () => { cancelled = true; clearInterval(iv); };
  }, [callStatus]);

  // Auto-hide controls on video in-call
  useEffect(() => {
    if (callType !== "video" || callStatus !== "in-call") return;
    const reset = () => {
      setShowControls(true);
      clearTimeout(hideTimer.current);
      hideTimer.current = setTimeout(() => setShowControls(false), 5000);
    };
    reset();
    window.addEventListener("mousemove", reset);
    window.addEventListener("touchstart", reset);
    return () => {
      clearTimeout(hideTimer.current);
      window.removeEventListener("mousemove", reset);
      window.removeEventListener("touchstart", reset);
    };
  }, [callType, callStatus]);

  // PiP drag (mouse)
  const onPipDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    setDragStart({ x: e.clientX - pipPos.x, y: e.clientY - pipPos.y });
  };
  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => setPipPos({
      x: Math.max(8, Math.min(window.innerWidth - 136, e.clientX - dragStart.x)),
      y: Math.max(8, Math.min(window.innerHeight - 200, e.clientY - dragStart.y)),
    });
    const onUp = () => setIsDragging(false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
  }, [isDragging, dragStart]);

  // PiP drag (touch)
  const onPipTouch = (e: React.TouchEvent) => {
    e.stopPropagation();
    const touch = e.touches[0];
    let sx = touch.clientX - pipPos.x;
    let sy = touch.clientY - pipPos.y;
    const onMove = (ev: TouchEvent) => {
      const t = ev.touches[0];
      setPipPos({
        x: Math.max(8, Math.min(window.innerWidth - 136, t.clientX - sx)),
        y: Math.max(8, Math.min(window.innerHeight - 200, t.clientY - sy)),
      });
    };
    const onEnd = () => {
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onEnd);
    };
    window.addEventListener("touchmove", onMove, { passive: true });
    window.addEventListener("touchend", onEnd);
  };

  // Screen share
  const toggleScreenShare = useCallback(async () => {
    if (isScreenSharing && screenStream) {
      screenStream.getTracks().forEach(t => t.stop());
      setScreenStream(null);
      setIsScreenSharing(false);
      return;
    }
    try {
      const stream = await (navigator.mediaDevices as any).getDisplayMedia({ video: true, audio: false });
      setScreenStream(stream);
      setIsScreenSharing(true);
      stream.getVideoTracks()[0].onended = () => {
        setScreenStream(null);
        setIsScreenSharing(false);
      };
      // Show screen share in local PiP
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
    } catch {}
  }, [isScreenSharing, screenStream]);

  // Fullscreen
  const toggleFullscreen = useCallback(() => {
    if (!isFullscreen) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
    setIsFullscreen(f => !f);
  }, [isFullscreen]);

  // Camera flip (mobile)
  const flipCamera = useCallback(() => {
    if (!localStream) return;
    const track = localStream.getVideoTracks()[0];
    if (!track) return;
    const cur = track.getConstraints().facingMode;
    track.applyConstraints({ facingMode: cur === "environment" ? "user" : "environment" }).catch(() => {});
  }, [localStream]);

  const statusText = callStatus === "calling" ? "Qo'ng'iroq qilinmoqda..." : callStatus === "connecting" ? "Ulanmoqda..." : formatDuration(callDuration);

  /* ── AUDIO CALL ───────────────────────────────────────────────── */
  if (callType === "audio") {
    return (
      <div
        className="fixed inset-0 z-[80] flex items-center justify-center overflow-hidden"
        style={{ background: "rgba(2,6,23,0.97)", backdropFilter: "blur(40px)" }}
      >
        {/* Hidden audio element for remote stream */}
        <audio ref={remoteAudioRef} autoPlay playsInline />

        {/* Animated gradient background */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1/2 opacity-10"
            style={{ background: `radial-gradient(ellipse at 50% 0%, ${grad[0]}, transparent 70%)` }} />
          <div className="absolute bottom-0 left-0 right-0 h-1/3 opacity-8"
            style={{ background: `radial-gradient(ellipse at 50% 100%, ${grad[1]}, transparent 70%)` }} />
          <div className="absolute top-1/4 left-1/3 w-80 h-80 rounded-full opacity-12 blur-3xl"
            style={{ background: `radial-gradient(circle, ${grad[0]}, transparent)`, animation: "float-orb 9s ease-in-out infinite" }} />
          <div className="absolute bottom-1/4 right-1/3 w-64 h-64 rounded-full opacity-8 blur-3xl"
            style={{ background: `radial-gradient(circle, ${grad[1]}, transparent)`, animation: "float-orb 11s ease-in-out infinite 3s" }} />
        </div>

        <div className="relative flex flex-col items-center w-full max-w-xs px-6">
          {/* Avatar with ripples */}
          <div className="relative flex items-center justify-center mb-7">
            {callStatus === "in-call" && (
              <>
                <div className="absolute w-44 h-44 rounded-full call-ripple" style={{ background: `${grad[0]}18` }} />
                <div className="absolute w-44 h-44 rounded-full call-ripple-2" style={{ background: `${grad[0]}12` }} />
                <div className="absolute w-44 h-44 rounded-full call-ripple-3" style={{ background: `${grad[0]}08` }} />
              </>
            )}
            {callStatus === "calling" && (
              <>
                <div className="absolute w-40 h-40 rounded-full border border-yellow-400/30 animate-ping" />
                <div className="absolute w-52 h-52 rounded-full border border-yellow-400/15 animate-ping" style={{ animationDelay: "0.6s" }} />
              </>
            )}
            <div
              className="relative w-32 h-32 rounded-full flex items-center justify-center text-4xl font-black text-white select-none"
              style={{ background: `linear-gradient(135deg, ${grad[0]}, ${grad[1]})`, boxShadow: `0 0 70px ${grad[0]}55, 0 0 30px ${grad[0]}30` }}
            >
              {peer.slice(0, 2).toUpperCase()}
              {callStatus === "in-call" && (
                <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full border-2 border-slate-900 flex items-center justify-center"
                  style={{ background: isMuted ? "#ef4444" : "#22c55e" }}>
                  {isMuted ? <MicOff className="w-3.5 h-3.5 text-white" /> : <Mic className="w-3.5 h-3.5 text-white" />}
                </div>
              )}
            </div>
          </div>

          {/* Name */}
          <p className="text-2xl font-black text-white tracking-tight mb-2">@{peer}</p>

          {/* Status + network */}
          <div className="flex items-center gap-3 mb-3">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${callStatus === "in-call" ? "bg-green-400" : "bg-yellow-400"} animate-pulse`} />
              <span className={`text-sm font-mono font-semibold ${callStatus === "in-call" ? "text-green-400" : "text-yellow-400"}`}>
                {statusText}
              </span>
            </div>
            {callStatus === "in-call" && <NetworkQuality quality={networkQuality} />}
          </div>

          {/* Sound wave */}
          <div className="flex justify-center mb-6">
            <SoundWave active={callStatus === "in-call" && !isMuted} />
          </div>

          {/* Protocol badge */}
          <div className="flex items-center gap-2 px-4 py-1.5 rounded-full mb-8" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs text-slate-300 font-medium">WebRTC + STUN/TURN · E2E</span>
          </div>

          {/* Controls */}
          <div className="flex items-end justify-center gap-5 w-full">
            <CtrlBtn
              icon={isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              label={isMuted ? "O'chiq" : "Mikrofon"}
              onClick={onMute}
              active={isMuted}
            />
            <CtrlBtn
              icon={<PhoneOff className="w-7 h-7 text-white" />}
              label="Tugatish"
              onClick={onEnd}
              danger
              large
            />
            <CtrlBtn
              icon={isSpeakerOff ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              label={isSpeakerOff ? "Jim" : "Dinamik"}
              onClick={() => setIsSpeakerOff(s => !s)}
              active={isSpeakerOff}
            />
          </div>
        </div>
      </div>
    );
  }

  /* ── VIDEO CALL ──────────────────────────────────────────────── */
  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[80] bg-black"
      onClick={() => {
        clearTimeout(hideTimer.current);
        setShowControls(v => !v);
      }}
    >
      {/* Hidden audio for remote audio (video element has muted=false but this helps on mobile) */}
      <audio ref={remoteAudioRef} autoPlay playsInline />

      {/* Remote stream / avatar */}
      {remoteStream && callStatus === "in-call" ? (
        <video ref={remoteVideoRef} autoPlay playsInline
          className="w-full h-full object-cover"
          style={{ background: "#000" }}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #0f172a, #1e293b)" }}>
          <div className="flex flex-col items-center gap-5">
            <div className="relative">
              <div className="absolute inset-0 rounded-full blur-2xl opacity-40 scale-125"
                style={{ background: `linear-gradient(135deg, ${grad[0]}, ${grad[1]})` }} />
              <div className="relative w-32 h-32 rounded-full flex items-center justify-center text-5xl font-black text-white"
                style={{ background: `linear-gradient(135deg, ${grad[0]}, ${grad[1]})` }}>
                {peer.slice(0, 2).toUpperCase()}
              </div>
              <div className="absolute inset-0 rounded-full border-2 border-cyan-400/40 animate-ping" />
            </div>
            <div className="text-center">
              <p className="text-2xl font-black text-white">@{peer}</p>
              <p className="text-yellow-400 text-sm mt-1 animate-pulse">{statusText}</p>
              <p className="text-slate-600 text-xs mt-1 font-mono">Video kutilmoqda...</p>
            </div>
          </div>
        </div>
      )}

      {/* PiP: local video / screen share */}
      {(localStream || screenStream) && (
        <div
          className="absolute rounded-2xl overflow-hidden shadow-2xl select-none"
          style={{
            width: 120, height: 180,
            left: pipPos.x, top: pipPos.y,
            zIndex: 90,
            border: isScreenSharing ? "2px solid #22d3ee" : "2px solid rgba(255,255,255,0.2)",
            background: "#0f172a",
            cursor: isDragging ? "grabbing" : "grab",
          }}
          onMouseDown={onPipDown}
          onTouchStart={onPipTouch}
        >
          {(!isCameraOff && !isScreenSharing) || isScreenSharing ? (
            <video
              ref={localVideoRef}
              autoPlay playsInline muted
              className="w-full h-full object-cover"
              style={{ transform: isScreenSharing ? "none" : "scaleX(-1)" }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <VideoOff className="w-8 h-8 text-slate-600" />
            </div>
          )}
          <div className="absolute bottom-1 left-0 right-0 text-center">
            <span className="text-[9px] text-white/80 px-1.5 py-0.5 rounded font-mono"
              style={{ background: "rgba(0,0,0,0.6)" }}>
              {isScreenSharing ? "🖥 Ekran" : "Siz"}
            </span>
          </div>
          {isScreenSharing && (
            <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-cyan-400/80 animate-pulse" />
          )}
        </div>
      )}

      {/* Top bar */}
      <div
        className={`absolute top-0 left-0 right-0 z-50 transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)", padding: "14px 18px 48px" }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white"
            style={{ background: `linear-gradient(135deg, ${grad[0]}, ${grad[1]})` }}>
            {peer.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <p className="text-white text-sm font-bold">@{peer}</p>
            <div className="flex items-center gap-2 mt-0.5">
              <span className={`w-1.5 h-1.5 rounded-full ${callStatus === "in-call" ? "bg-green-400 animate-pulse" : "bg-yellow-400"}`} />
              <span className={`text-xs font-mono ${callStatus === "in-call" ? "text-green-400" : "text-yellow-400 animate-pulse"}`}>{statusText}</span>
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {callStatus === "in-call" && <NetworkQuality quality={networkQuality} />}
            <button
              onClick={toggleFullscreen}
              className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition"
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5 text-white" /> : <Maximize2 className="w-3.5 h-3.5 text-white" />}
            </button>
          </div>
        </div>
      </div>

      {/* Bottom controls */}
      <div
        className={`absolute bottom-0 left-0 right-0 z-50 transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        style={{ background: "linear-gradient(to top, rgba(0,0,0,0.9), transparent)", padding: "48px 20px 28px" }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-end justify-center gap-4">
          <CtrlBtn
            icon={isCameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            label={isCameraOff ? "Kamera off" : "Kamera"}
            onClick={onCameraToggle}
            active={isCameraOff}
          />
          <CtrlBtn
            icon={isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            label={isMuted ? "Mikrofon off" : "Mikrofon"}
            onClick={onMute}
            active={isMuted}
          />
          <CtrlBtn
            icon={<PhoneOff className="w-7 h-7 text-white" />}
            label="Tugatish"
            onClick={onEnd}
            danger
            large
          />
          <CtrlBtn
            icon={isScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
            label={isScreenSharing ? "Ekran off" : "Ekran"}
            onClick={toggleScreenShare}
            active={isScreenSharing}
          />
          <CtrlBtn
            icon={<RotateCcw className="w-5 h-5" />}
            label="Aylantir"
            onClick={flipCamera}
          />
        </div>
      </div>
    </div>
  );
}
