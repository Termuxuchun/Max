import { useState, useEffect } from "react";
import { ref, onValue, update, get, set, increment } from "firebase/database";
import { db } from "../firebase";
import {
  Edit3, Save, X, Camera, Star, MessageSquare, Zap, Trophy, Shield,
  Copy, Check, TrendingUp, Eye, Flame, Award, Target, Clock,
  Music2, Smile, ChevronDown, Lock, Unlock, Palette, Users
} from "lucide-react";
import { BADGES } from "./SettingsSection";

interface MyProfileProps {
  username: string;
  accentColor: string;
  isPremium: boolean;
  starsBalance: number;
  onOpenChat: (peer: string) => void;
}

const AVATAR_EMOJIS = ["😎","🤖","👑","🔥","💎","🚀","🐉","🦄","🌟","⚡","🎯","👻","🥷","🦁","🐼","🦋","🌊","🎭","🦅","🔮","😈","😇","🤴","🧙","🦈","🃏","⚔️","🌌","🎵","🏆","💫","🌙","☀️","🎨","🧪","🦊","🐺","🎸","🎹","🏄"];

const MOODS = [
  { emoji: "💻", label: "Kod yozyapman" },
  { emoji: "🎮", label: "O'yin o'ynayapman" },
  { emoji: "🎵", label: "Musiqa tinglayman" },
  { emoji: "📚", label: "O'qiyapman" },
  { emoji: "🌙", label: "Dam olyapman" },
  { emoji: "🏃", label: "Faolman" },
  { emoji: "🔥", label: "Ishda" },
  { emoji: "😴", label: "Uxlamoqchiman" },
  { emoji: "🌊", label: "Sayohatda" },
  { emoji: "🍔", label: "Ovqatlanmoqdaman" },
  { emoji: "🎯", label: "Maqsadga intilmoqdaman" },
  { emoji: "💪", label: "Mashg'ulotda" },
];

const COVER_GRADIENTS = [
  { label: "Cyan", value: "from-cyan-900 via-slate-900 to-indigo-900", colors: ["#164e63","#0f172a","#1e1b4b"] },
  { label: "Rose", value: "from-rose-900 via-slate-900 to-pink-900", colors: ["#4c0519","#0f172a","#500724"] },
  { label: "Amber", value: "from-amber-900 via-slate-900 to-orange-900", colors: ["#451a03","#0f172a","#431407"] },
  { label: "Emerald", value: "from-emerald-900 via-slate-900 to-teal-900", colors: ["#064e3b","#0f172a","#042f2e"] },
  { label: "Purple", value: "from-purple-900 via-slate-900 to-violet-900", colors: ["#3b0764","#0f172a","#2e1065"] },
  { label: "Sky", value: "from-sky-900 via-slate-900 to-blue-900", colors: ["#0c4a6e","#0f172a","#1e3a5f"] },
];

interface ProfileData {
  bio: string;
  avatarEmoji: string;
  socialLinks: { telegram?: string; instagram?: string; twitter?: string; website?: string };
  badge: string;
  mood?: string;
  moodEmoji?: string;
  coverGradient?: number;
  profilePrivate?: boolean;
  joinedAt?: number;
}

function getLevelFromXP(xp: number) {
  const level = Math.floor(Math.sqrt(xp / 100)) + 1;
  const currentLevelXP = Math.pow(level - 1, 2) * 100;
  const nextLevelXP = Math.pow(level, 2) * 100;
  const progress = ((xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
  return { level, progress: Math.min(progress, 100), nextLevelXP, currentXP: xp };
}

const ACHIEVEMENTS = [
  { id: "first_msg",    icon: "💬", label: "Birinchi xabar",   desc: "1 ta xabar yubording",    req: (s: any) => s.messages >= 1 },
  { id: "chatter",     icon: "🗨️", label: "Suhbatchi",         desc: "100 ta xabar yubording",   req: (s: any) => s.messages >= 100 },
  { id: "talker",      icon: "📣", label: "Notiq",              desc: "500 ta xabar yubording",   req: (s: any) => s.messages >= 500 },
  { id: "caller",      icon: "📞", label: "Muloqotchi",         desc: "1 ta qo'ng'iroq qilding",  req: (s: any) => s.calls >= 1 },
  { id: "popular",     icon: "⭐", label: "Mashhur",            desc: "50 ta yulduz toplading",   req: (s: any) => s.stars >= 50 },
  { id: "rich",        icon: "💎", label: "Boy",                desc: "500 ta yulduz toplading",  req: (s: any) => s.stars >= 500 },
  { id: "author",      icon: "✍️", label: "Muallif",            desc: "Birinchi post yozdingiz",  req: (s: any) => s.posts >= 1 },
  { id: "blogger",     icon: "📰", label: "Bloger",             desc: "10 ta post yozdingiz",     req: (s: any) => s.posts >= 10 },
  { id: "premium_fan", icon: "👑", label: "Premium",            desc: "Premium obuna oldingiz",   req: (_s: any, isPrem: boolean) => isPrem },
  { id: "social",      icon: "🌐", label: "Ijtimoiy",           desc: "Ijtimoiy tarmoq qo'shdingiz", req: (s: any) => s.hasSocial },
];

export default function MyProfile({ username, accentColor, isPremium, starsBalance, onOpenChat }: MyProfileProps) {
  const [profile, setProfile] = useState<ProfileData>({
    bio: "",
    avatarEmoji: "😎",
    socialLinks: {},
    badge: "star",
  });
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<ProfileData>(profile);
  const [stats, setStats] = useState({ messages: 0, calls: 0, posts: 0, stars: starsBalance, hasSocial: false });
  const [copied, setCopied] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const [showBadgePicker, setShowBadgePicker] = useState(false);
  const [showMoodPicker, setShowMoodPicker] = useState(false);
  const [showCoverPicker, setShowCoverPicker] = useState(false);
  const [activeTab, setActiveTab] = useState<"info" | "badges" | "stats" | "achievements">("info");
  const [profileViews, setProfileViews] = useState(0);
  const [nowPlaying, setNowPlaying] = useState<{ title: string; artist: string; emoji: string } | null>(null);
  const [friendCount, setFriendCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [activityDays, setActivityDays] = useState<number[]>([]);

  useEffect(() => {
    return onValue(ref(db, `profiles/${username}`), snap => {
      if (snap.exists()) {
        const d = snap.val() as ProfileData;
        setProfile(d);
        setDraft(d);
      }
    });
  }, [username]);

  useEffect(() => {
    // Increment profile views
    const viewKey = `nexus_viewed_${username}`;
    if (!sessionStorage.getItem(viewKey)) {
      sessionStorage.setItem(viewKey, "1");
      update(ref(db, `profile_views/${username}`), { count: increment(1), lastViewed: Date.now() });
    }
    return onValue(ref(db, `profile_views/${username}`), snap => {
      setProfileViews(snap.val()?.count || 0);
    });
  }, [username]);

  useEffect(() => {
    // Stats
    let msgs = 0, calls = 0, posts = 0;
    get(ref(db, "messages")).then(snap => {
      if (!snap.exists()) return;
      snap.forEach(chat => {
        chat.forEach(msg => { if (msg.val()?.sender === username) msgs++; });
      });
      setStats(s => ({ ...s, messages: msgs }));
    });
    get(ref(db, `call_logs/${username}`)).then(snap => {
      if (snap.exists()) setStats(s => ({ ...s, calls: snap.size }));
    });
    get(ref(db, "feed")).then(snap => {
      if (!snap.exists()) return;
      snap.forEach(p => { if (p.val()?.author === username) posts++; });
      setStats(s => ({ ...s, posts }));
    });
    // Friend count from contacts
    get(ref(db, `contacts/${username}`)).then(snap => {
      setFriendCount(snap.exists() ? snap.size : 0);
    });
    // Activity days simulation (based on random seeded from username)
    const seed = username.charCodeAt(0) + username.charCodeAt(username.length - 1);
    const days = Array.from({ length: 14 }, (_, i) => {
      const base = Math.sin((seed + i) * 2.5) * 0.5 + 0.5;
      return Math.floor(base * 40 + 5);
    });
    setActivityDays(days);
    setStreak(Math.floor(seed % 7) + 1);
  }, [username]);

  useEffect(() => {
    setStats(s => ({ ...s, stars: starsBalance }));
  }, [starsBalance]);

  useEffect(() => {
    // Check social links
    const hasSocial = Object.values(profile.socialLinks || {}).some(v => !!v);
    setStats(s => ({ ...s, hasSocial }));
  }, [profile.socialLinks]);

  useEffect(() => {
    // Listen to now playing
    return onValue(ref(db, `now_playing/${username}`), snap => {
      if (snap.exists()) setNowPlaying(snap.val());
      else setNowPlaying(null);
    });
  }, [username]);

  function save() {
    update(ref(db, `profiles/${username}`), draft);
    setProfile(draft);
    setEditing(false);
    setShowAvatarPicker(false);
    setShowBadgePicker(false);
    setShowMoodPicker(false);
    setShowCoverPicker(false);
  }

  function copyLink() {
    navigator.clipboard.writeText(`nexus://user/${username}`).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function clearMood() {
    update(ref(db, `profiles/${username}`), { mood: "", moodEmoji: "" });
    setProfile(p => ({ ...p, mood: "", moodEmoji: "" }));
  }

  const activeBadge = BADGES.find(b => b.id === (editing ? draft.badge : profile.badge));
  const xp = stats.messages * 5 + stats.posts * 20 + stats.calls * 15 + Math.floor(starsBalance / 10);
  const { level, progress, nextLevelXP, currentXP } = getLevelFromXP(xp);
  const coverIdx = (editing ? (draft.coverGradient ?? 0) : (profile.coverGradient ?? 0));
  const coverGrad = COVER_GRADIENTS[coverIdx] || COVER_GRADIENTS[0];
  const unlockedAchievements = ACHIEVEMENTS.filter(a => a.req(stats, isPremium));
  const completionFields = [!!profile.bio, !!profile.avatarEmoji, Object.values(profile.socialLinks || {}).some(Boolean), !!profile.badge, !!profile.mood];
  const completion = Math.round((completionFields.filter(Boolean).length / completionFields.length) * 100);

  const STAT_CARDS = [
    { label: "Xabarlar",   value: stats.messages, icon: <MessageSquare className="w-4 h-4" />, color: accentColor },
    { label: "Yulduzlar",  value: starsBalance,    icon: <Star className="w-4 h-4" />,          color: "#f59e0b" },
    { label: "Qo'ng'iroq", value: stats.calls,     icon: <Zap className="w-4 h-4" />,           color: "#22c55e" },
    { label: "Postlar",    value: stats.posts,     icon: <Trophy className="w-4 h-4" />,         color: "#a855f7" },
    { label: "Ko'rishlar", value: profileViews,    icon: <Eye className="w-4 h-4" />,            color: "#38bdf8" },
    { label: "Do'stlar",   value: friendCount,     icon: <Users className="w-4 h-4" />,          color: "#ec4899" },
  ];

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 page-enter overflow-hidden">

      {/* ── Hero Banner ── */}
      <div className="relative flex-shrink-0">
        <div className="h-32 w-full relative overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${coverGrad.colors[0]}, ${coverGrad.colors[1]}, ${coverGrad.colors[2]})` }}>
          <div className="absolute inset-0 card-shimmer opacity-30" />
          {/* Level badge in banner */}
          <div className="absolute top-3 left-3">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full backdrop-blur-sm border border-white/10 bg-black/30">
              <span className="text-[10px] font-black text-white/70">LVL</span>
              <span className="text-sm font-black text-white">{level}</span>
            </div>
          </div>
          {/* Streak */}
          {streak > 0 && (
            <div className="absolute top-3 right-3">
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full backdrop-blur-sm border border-orange-500/30 bg-orange-950/40">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-[10px] font-black text-orange-300">{streak} kun</span>
              </div>
            </div>
          )}
        </div>

        {/* Avatar */}
        <div className="absolute left-4 -bottom-10 z-10">
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl border-4 border-[#030712] shadow-2xl cursor-pointer transition-all active:scale-95"
              style={{ background: `linear-gradient(135deg, ${accentColor}55, #6366f133)` }}
              onClick={() => editing && setShowAvatarPicker(s => !s)}>
              {editing ? (draft.avatarEmoji || "😎") : (profile.avatarEmoji || "😎")}
              {editing && (
                <div className="absolute inset-0 rounded-2xl bg-black/50 flex items-center justify-center">
                  <Camera className="w-5 h-5 text-white" />
                </div>
              )}
            </div>
            {activeBadge && (
              <div className="absolute -bottom-1 -right-1 text-lg" title={activeBadge.label}>
                <span className={activeBadge.anim}>{activeBadge.emoji}</span>
              </div>
            )}
          </div>
        </div>

        {/* Action buttons */}
        <div className="absolute right-3 bottom-3 flex gap-2">
          {editing ? (
            <>
              {/* Cover picker toggle */}
              <button onClick={() => setShowCoverPicker(s => !s)}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-black/40 backdrop-blur-sm text-slate-300 text-[10px] font-bold hover:bg-black/60 transition border border-white/10">
                <Palette className="w-3 h-3" /> Cover
              </button>
              <button onClick={() => { setEditing(false); setDraft(profile); setShowAvatarPicker(false); setShowCoverPicker(false); }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition">
                <X className="w-3.5 h-3.5" /> Bekor
              </button>
              <button onClick={save}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-white text-xs font-bold transition active:scale-95"
                style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
                <Save className="w-3.5 h-3.5" /> Saqlash
              </button>
            </>
          ) : (
            <button onClick={() => setEditing(true)}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-black/40 backdrop-blur-sm text-white text-xs font-bold hover:bg-black/60 transition border border-white/10">
              <Edit3 className="w-3.5 h-3.5" /> Tahrirlash
            </button>
          )}
        </div>
      </div>

      {/* Cover gradient picker */}
      {showCoverPicker && editing && (
        <div className="mx-4 mt-2 p-3 rounded-2xl bg-slate-900 border border-slate-800 drop-in flex-shrink-0">
          <p className="text-[9px] text-slate-500 uppercase tracking-widest font-bold mb-2">Cover rangi</p>
          <div className="flex gap-2 flex-wrap">
            {COVER_GRADIENTS.map((g, idx) => (
              <button key={idx} onClick={() => { setDraft(d => ({ ...d, coverGradient: idx })); }}
                className={`w-10 h-7 rounded-lg transition border-2 ${(draft.coverGradient ?? 0) === idx ? "border-white scale-110" : "border-transparent"}`}
                style={{ background: `linear-gradient(135deg, ${g.colors[0]}, ${g.colors[2]})` }}
                title={g.label} />
            ))}
          </div>
        </div>
      )}

      {/* Avatar picker */}
      {showAvatarPicker && editing && (
        <div className="mx-4 mt-2 p-3 rounded-2xl bg-slate-900 border border-slate-800 drop-in flex-shrink-0">
          <div className="flex flex-wrap gap-2">
            {AVATAR_EMOJIS.map(e => (
              <button key={e} onClick={() => { setDraft(d => ({ ...d, avatarEmoji: e })); setShowAvatarPicker(false); }}
                className={`text-2xl w-10 h-10 rounded-xl flex items-center justify-center transition ${draft.avatarEmoji === e ? "scale-110" : "hover:scale-105"}`}
                style={{ background: draft.avatarEmoji === e ? accentColor + "44" : "#1e293b" }}>
                {e}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── User info ── */}
      <div className="pt-12 px-4 pb-3 flex-shrink-0">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="font-black text-xl text-white">@{username}</p>
              {isPremium && <span className="text-xs font-black text-amber-400 bg-amber-950/40 border border-amber-800/50 px-2 py-0.5 rounded-full">👑 PREMIUM</span>}
              {username === "Max" && <span className="text-[10px] font-black px-2 py-0.5 rounded-full" style={{ background: accentColor + "22", color: accentColor }}>✓ ADMIN</span>}
            </div>

            {/* Mood badge */}
            {(profile.moodEmoji || profile.mood) && !editing && (
              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-base">{profile.moodEmoji}</span>
                <span className="text-xs text-slate-400 italic">{profile.mood}</span>
                <button onClick={clearMood} className="text-slate-700 hover:text-slate-500 transition">
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}

            {profile.bio && !editing && (
              <p className="text-slate-400 text-sm mt-1 max-w-xs leading-relaxed">{profile.bio}</p>
            )}
          </div>

          <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
            <button onClick={copyLink}
              className="flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-xl transition"
              style={{ background: accentColor + "11", color: accentColor, border: `1px solid ${accentColor}33` }}>
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copied ? "Nusxalandi!" : "Havola"}
            </button>
            <div className="flex items-center gap-1 text-[10px] text-slate-600">
              <Eye className="w-3 h-3" /> {profileViews} ko'rish
            </div>
          </div>
        </div>

        {/* Bio edit */}
        {editing && (
          <textarea value={draft.bio} onChange={e => setDraft(d => ({ ...d, bio: e.target.value }))} rows={2}
            placeholder="O'zingiz haqingizda yozing..."
            maxLength={200}
            className="w-full mt-2 bg-slate-900/60 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-600 resize-none transition" />
        )}

        {/* Mood picker (edit mode) */}
        {editing && (
          <button onClick={() => setShowMoodPicker(s => !s)}
            className="mt-2 flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition w-full">
            <Smile className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">{draft.moodEmoji || "🎭"} {draft.mood || "Kayfiyat tanlash..."}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-600 ml-auto" />
          </button>
        )}
        {showMoodPicker && editing && (
          <div className="mt-1 p-3 rounded-2xl bg-slate-900 border border-slate-800 drop-in grid grid-cols-3 gap-1.5">
            {MOODS.map(m => (
              <button key={m.emoji} onClick={() => { setDraft(d => ({ ...d, mood: m.label, moodEmoji: m.emoji })); setShowMoodPicker(false); }}
                className="flex items-center gap-1.5 px-2 py-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 transition text-left">
                <span className="text-base">{m.emoji}</span>
                <span className="text-[10px] text-slate-300 truncate">{m.label}</span>
              </button>
            ))}
          </div>
        )}

        {/* XP / Level bar */}
        <div className="mt-3 p-3 rounded-2xl bg-slate-900/50 border border-slate-800/50">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black text-white"
                style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>{level}</div>
              <span className="text-xs font-bold text-white">Daraja {level}</span>
            </div>
            <span className="text-[10px] text-slate-500">{currentXP.toLocaleString()} / {nextLevelXP.toLocaleString()} XP</span>
          </div>
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full rounded-full transition-all duration-1000"
              style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${accentColor}, #6366f1)` }} />
          </div>
          {/* Profile completion */}
          {completion < 100 && (
            <div className="mt-2 flex items-center justify-between">
              <span className="text-[10px] text-slate-600">Profil to'ldirilishi: {completion}%</span>
              <div className="flex gap-0.5">
                {completionFields.map((f, i) => (
                  <div key={i} className={`w-4 h-1 rounded-full transition ${f ? "bg-green-500" : "bg-slate-700"}`} />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Now playing */}
        {nowPlaying && (
          <div className="mt-2 flex items-center gap-2.5 px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800/50">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center text-base flex-shrink-0 animate-pulse"
              style={{ background: accentColor + "22" }}>
              {nowPlaying.emoji || "🎵"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-white truncate">{nowPlaying.title}</p>
              <p className="text-[10px] text-slate-500 truncate">{nowPlaying.artist}</p>
            </div>
            <Music2 className="w-3.5 h-3.5 flex-shrink-0 animate-pulse" style={{ color: accentColor }} />
          </div>
        )}
      </div>

      {/* ── Tabs ── */}
      <div className="px-4 pb-2 flex-shrink-0">
        <div className="flex gap-0.5 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60">
          {([
            { key: "info",         label: "Ma'lumot",    icon: "👤" },
            { key: "badges",       label: "Nishonlar",   icon: "🏅" },
            { key: "stats",        label: "Statistika",  icon: "📊" },
            { key: "achievements", label: "Yutuqlar",    icon: "🏆" },
          ] as const).map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className="flex-1 flex items-center justify-center gap-1 py-2 rounded-xl font-bold text-[10px] transition"
              style={activeTab === t.key ? { background: accentColor + "22", color: accentColor } : { color: "#64748b" }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 overflow-y-auto px-4 pb-6">

        {/* INFO */}
        {activeTab === "info" && (
          <div className="space-y-3 tab-slide-in">
            {/* Privacy toggle */}
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                {profile.profilePrivate ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                {profile.profilePrivate ? "Profil yopiq" : "Profil ochiq"}
              </div>
              {editing && (
                <button onClick={() => setDraft(d => ({ ...d, profilePrivate: !d.profilePrivate }))}
                  className={`relative w-10 h-5 rounded-full transition-colors ${draft.profilePrivate ? "bg-rose-600" : "bg-slate-700"}`}>
                  <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${draft.profilePrivate ? "translate-x-5" : "translate-x-0.5"}`} />
                </button>
              )}
            </div>

            {/* Social links */}
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800/50 space-y-3">
              <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">Ijtimoiy tarmoqlar</p>
              {editing ? (
                <div className="space-y-2">
                  {[
                    { key: "telegram",  icon: "✈️",  placeholder: "Telegram @username" },
                    { key: "instagram", icon: "📷",  placeholder: "Instagram @username" },
                    { key: "twitter",   icon: "🐦",  placeholder: "Twitter @username" },
                    { key: "website",   icon: "🌐",  placeholder: "https://yoursite.com" },
                  ].map(s => (
                    <div key={s.key} className="flex items-center gap-2">
                      <span className="text-lg w-7 text-center">{s.icon}</span>
                      <input
                        value={(draft.socialLinks as any)?.[s.key] || ""}
                        onChange={e => setDraft(d => ({ ...d, socialLinks: { ...d.socialLinks, [s.key]: e.target.value } }))}
                        placeholder={s.placeholder}
                        className="flex-1 bg-slate-800/60 border border-slate-700/50 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-slate-500 placeholder-slate-600 transition" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {Object.entries(profile.socialLinks || {}).filter(([, v]) => v).length === 0 && (
                    <div className="flex items-center gap-2">
                      <p className="text-xs text-slate-600">Ijtimoiy havolalar qo'shilmagan</p>
                      {!editing && <button onClick={() => setEditing(true)} className="text-[10px]" style={{ color: accentColor }}>+ Qo'shish</button>}
                    </div>
                  )}
                  {profile.socialLinks?.telegram && (
                    <div className="flex items-center gap-2 text-sm"><span>✈️</span><span className="text-slate-300">@{profile.socialLinks.telegram}</span></div>
                  )}
                  {profile.socialLinks?.instagram && (
                    <div className="flex items-center gap-2 text-sm"><span>📷</span><span className="text-slate-300">@{profile.socialLinks.instagram}</span></div>
                  )}
                  {profile.socialLinks?.twitter && (
                    <div className="flex items-center gap-2 text-sm"><span>🐦</span><span className="text-slate-300">@{profile.socialLinks.twitter}</span></div>
                  )}
                  {profile.socialLinks?.website && (
                    <div className="flex items-center gap-2 text-sm"><span>🌐</span><a href={profile.socialLinks.website} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline truncate">{profile.socialLinks.website}</a></div>
                  )}
                </div>
              )}
            </div>

            {/* Active badge */}
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800/50">
              <div className="flex items-center justify-between mb-3">
                <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">Faol nishon</p>
                {editing && (
                  <button onClick={() => setShowBadgePicker(s => !s)}
                    className="text-[10px] font-bold transition" style={{ color: accentColor }}>
                    O'zgartirish
                  </button>
                )}
              </div>
              {activeBadge ? (
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{activeBadge.emoji}</span>
                  <div>
                    <p className="font-bold text-white">{activeBadge.label}</p>
                    <p className="text-xs text-slate-500">Profilingizda ko'rinadi</p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-slate-500">Nishon tanlanmagan</p>
              )}
              {showBadgePicker && editing && (
                <div className="mt-3 pt-3 border-t border-slate-800/60 drop-in">
                  <div className="grid grid-cols-8 gap-2">
                    {BADGES.map(b => (
                      <button key={b.id} onClick={() => { setDraft(d => ({ ...d, badge: b.id })); setShowBadgePicker(false); }}
                        title={b.label}
                        className="text-2xl w-9 h-9 rounded-xl flex items-center justify-center transition"
                        style={{ background: (draft.badge === b.id ? b.color + "33" : "#1e293b"), border: draft.badge === b.id ? `1px solid ${b.color}55` : "1px solid transparent" }}>
                        {b.emoji}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* BADGES */}
        {activeTab === "badges" && (
          <div className="tab-slide-in">
            <p className="text-[10px] uppercase tracking-widest text-slate-600 mb-3 font-bold">Barcha nishonlar · {BADGES.length} ta</p>
            <div className="grid grid-cols-5 gap-2">
              {BADGES.map((b, i) => (
                <button key={b.id}
                  onClick={() => { update(ref(db, `profiles/${username}`), { badge: b.id }); }}
                  title={b.label}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-2xl border transition active:scale-95"
                  style={{
                    animationDelay: `${i * 20}ms`,
                    background: profile.badge === b.id ? b.color + "22" : "#0a0f1e",
                    borderColor: profile.badge === b.id ? b.color + "66" : "#1e293b",
                  }}>
                  <span className={`text-2xl ${profile.badge === b.id ? b.anim : ""}`}>{b.emoji}</span>
                  <span className="text-[9px] text-slate-500 font-bold truncate w-full text-center">{b.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* STATS */}
        {activeTab === "stats" && (
          <div className="space-y-3 tab-slide-in">
            <div className="grid grid-cols-3 gap-2">
              {STAT_CARDS.map((s, i) => (
                <div key={i} className="p-3 rounded-2xl border"
                  style={{ background: s.color + "0f", borderColor: s.color + "33" }}>
                  <div className="flex items-center gap-1.5 mb-1.5" style={{ color: s.color }}>{s.icon}</div>
                  <p className="text-xl font-black text-white">{s.value.toLocaleString()}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Activity heatmap (14 days) */}
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800/50">
              <div className="flex items-center justify-between mb-3">
                <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">Faollik (2 hafta)</p>
                <div className="flex items-center gap-1 text-[10px] text-orange-400">
                  <Flame className="w-3 h-3" /> {streak} kunlik streak
                </div>
              </div>
              <div className="flex items-end gap-1 h-16">
                {activityDays.map((h, i) => {
                  const days14 = ["Du","Se","Ch","Pa","Ju","Sh","Ya","Du","Se","Ch","Pa","Ju","Sh","Ya"];
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full rounded-t-md transition-all duration-700"
                        style={{ height: `${(h / 45) * 100}%`, background: `linear-gradient(to top, ${accentColor}cc, ${accentColor}44)`, minHeight: "3px" }} />
                      <span className="text-[7px] text-slate-700">{days14[i]}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* XP breakdown */}
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800/50 space-y-2">
              <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">XP Taqsimoti</p>
              {[
                { label: "Xabarlar", xp: stats.messages * 5, color: accentColor },
                { label: "Postlar", xp: stats.posts * 20, color: "#a855f7" },
                { label: "Qo'ng'iroqlar", xp: stats.calls * 15, color: "#22c55e" },
                { label: "Yulduzlar", xp: Math.floor(starsBalance / 10), color: "#f59e0b" },
              ].map(item => (
                <div key={item.label} className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-500 w-24">{item.label}</span>
                  <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${Math.min((item.xp / Math.max(xp, 1)) * 100, 100)}%`, background: item.color }} />
                  </div>
                  <span className="text-[10px] text-slate-500 w-12 text-right">{item.xp} XP</span>
                </div>
              ))}
            </div>

            {/* Premium CTA */}
            {!isPremium && (
              <div className="p-4 rounded-2xl text-center"
                style={{ background: "linear-gradient(135deg, #451a03, #78350f)", border: "1px solid #92400e" }}>
                <p className="text-amber-300 font-black text-base mb-1">⭐ PREMIUM</p>
                <p className="text-amber-600 text-xs mb-3">Kengaytirilgan statistika va nishonlar uchun</p>
                <button className="px-6 py-2 rounded-xl font-bold text-sm text-white"
                  style={{ background: "linear-gradient(135deg, #d97706, #f59e0b)" }}>
                  Premium olish
                </button>
              </div>
            )}
          </div>
        )}

        {/* ACHIEVEMENTS */}
        {activeTab === "achievements" && (
          <div className="tab-slide-in space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">Yutuqlar</p>
              <span className="text-[10px] font-bold" style={{ color: accentColor }}>
                {unlockedAchievements.length}/{ACHIEVEMENTS.length} olindi
              </span>
            </div>

            {/* Progress */}
            <div className="p-3 rounded-2xl bg-slate-900/50 border border-slate-800/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-white">Umumiy progress</span>
                <span className="text-xs text-slate-500">{Math.round((unlockedAchievements.length / ACHIEVEMENTS.length) * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${(unlockedAchievements.length / ACHIEVEMENTS.length) * 100}%`, background: `linear-gradient(90deg, #f59e0b, #f97316)` }} />
              </div>
            </div>

            <div className="space-y-2">
              {ACHIEVEMENTS.map((a, i) => {
                const unlocked = a.req(stats, isPremium);
                return (
                  <div key={a.id}
                    className="flex items-center gap-3 p-3 rounded-2xl border transition"
                    style={{
                      background: unlocked ? "#0f172a" : "#0a0f1e",
                      borderColor: unlocked ? accentColor + "33" : "#1e293b",
                      opacity: unlocked ? 1 : 0.5,
                    }}>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${unlocked ? "" : "grayscale"}`}
                      style={{ background: unlocked ? accentColor + "22" : "#1e293b" }}>
                      {a.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-white">{a.label}</p>
                      <p className="text-[10px] text-slate-500">{a.desc}</p>
                    </div>
                    {unlocked ? (
                      <div className="w-6 h-6 rounded-full bg-green-900/40 border border-green-700 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3.5 h-3.5 text-green-400" />
                      </div>
                    ) : (
                      <Lock className="w-4 h-4 text-slate-700 flex-shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
