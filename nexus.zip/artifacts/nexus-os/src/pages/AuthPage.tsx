import { useState, useEffect, useRef } from "react";
import { ref, get, set, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import { SessionManager } from "../session";
import { User, Lock, Eye, EyeOff, Zap, MessageSquare, Shield, Globe, ChevronRight } from "lucide-react";

interface AuthPageProps {
  onLogin: (username: string) => void;
}

type AuthMode = "login" | "register";

function FloatingOrb({ x, y, size, color, delay, duration }: {
  x: number; y: number; size: number; color: string; delay: number; duration: number;
}) {
  return (
    <div
      className="absolute rounded-full pointer-events-none"
      style={{
        left: `${x}%`, top: `${y}%`,
        width: size, height: size,
        background: `radial-gradient(circle at 30% 30%, ${color}66, ${color}11)`,
        filter: `blur(${size / 3}px)`,
        animation: `float-orb ${duration}s ease-in-out ${delay}s infinite alternate`,
      }}
    />
  );
}

function ParticleField() {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 2 + 1,
    delay: Math.random() * 4,
    duration: Math.random() * 3 + 3,
  }));
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute rounded-full bg-cyan-400/20"
          style={{
            left: `${p.x}%`, top: `${p.y}%`,
            width: p.size, height: p.size,
            animation: `float-particle ${p.duration}s ease-in-out ${p.delay}s infinite alternate`,
          }}
        />
      ))}
    </div>
  );
}

const FEATURES = [
  { icon: <MessageSquare className="w-3.5 h-3.5" />, label: "Xavfsiz suhbatlar" },
  { icon: <Shield className="w-3.5 h-3.5" />,        label: "Maxfiy chatlar" },
  { icon: <Globe className="w-3.5 h-3.5" />,         label: "Ochiq kanallar" },
  { icon: <Zap className="w-3.5 h-3.5" />,           label: "Real-vaqt" },
];

export default function AuthPage({ onLogin }: AuthPageProps) {
  const [mode, setMode]         = useState<AuthMode>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [success, setSuccess]   = useState("");
  const [showPw, setShowPw]     = useState(false);
  const [focusUser, setFocusUser] = useState(false);
  const [focusPw,   setFocusPw]   = useState(false);
  const [mounted, setMounted]   = useState(false);
  const [loadPct, setLoadPct]   = useState(0);
  const userRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 50);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!loading) { setLoadPct(0); return; }
    const t = setInterval(() => setLoadPct(p => Math.min(p + Math.random() * 15, 90)), 200);
    return () => clearInterval(t);
  }, [loading]);

  async function handleLogin() {
    const uname = username.trim().toLowerCase();
    const pass  = password.trim();
    if (!uname || !pass)    { setError("⚠️ ID va Parolni kiriting!"); return; }
    if (pass.length < 4)    { setError("⚠️ Parol kamida 4 ta belgi bo'lishi shart!"); return; }
    setError(""); setLoading(true);
    try {
      const snap = await get(ref(db, `users/${uname}`));
      if (!snap.exists())                           { setError("🛑 Bu ID tizimda yo'q. Avval ro'yxatdan o'ting!"); setLoading(false); return; }
      const data = snap.val();
      if (String(data.password).trim() !== pass)   { setError("🛑 Parol noto'g'ri!"); setLoading(false); return; }
      setLoadPct(100);
      setSuccess("✅ Tizimga kirilmoqda...");
      setTimeout(() => { SessionManager.save(uname); onLogin(uname); }, 600);
    } catch (err: any) {
      setError("🚨 Xatolik: " + err.message);
      setLoading(false);
    }
  }

  async function handleRegister() {
    const uname = username.trim().toLowerCase();
    const pass  = password.trim();
    if (!uname || !pass)                       { setError("⚠️ ID va Parolni kiriting!"); return; }
    if (pass.length < 4)                       { setError("⚠️ Parol kamida 4 ta belgi bo'lishi shart!"); return; }
    if (!/^[a-z0-9_]+$/.test(uname))          { setError("⚠️ ID faqat harf, raqam va _ dan iborat bo'lishi kerak!"); return; }
    if (uname.length < 3)                      { setError("⚠️ ID kamida 3 ta belgi bo'lishi kerak!"); return; }
    setError(""); setLoading(true);
    try {
      const snap = await get(ref(db, `users/${uname}`));
      if (snap.exists()) { setError("🛑 Bu ID allaqachon band! Boshqa ID tanlang."); setLoading(false); return; }
      await set(ref(db, `users/${uname}`), {
        username: uname,
        password: pass,
        createdAt: serverTimestamp(),
        status: "online",
      });
      setLoadPct(100);
      setSuccess("🎉 Profil yaratildi! Xush kelibsiz!");
      setTimeout(() => { SessionManager.save(uname); onLogin(uname); }, 700);
    } catch (err: any) {
      setError("🚨 Xatolik: " + err.message);
      setLoading(false);
    }
  }

  function switchMode(m: AuthMode) {
    setMode(m);
    setError("");
    setSuccess("");
    setUsername("");
    setPassword("");
    setTimeout(() => userRef.current?.focus(), 100);
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#030712] z-50 overflow-hidden">
      {/* ===== animated background ===== */}
      <style>{`
        @keyframes float-orb {
          from { transform: translate(0,0) scale(1); }
          to   { transform: translate(15px,20px) scale(1.08); }
        }
        @keyframes auth-card-in {
          from { transform: translateY(24px) scale(0.97); opacity: 0; }
          to   { transform: translateY(0) scale(1); opacity: 1; }
        }
        @keyframes shimmer-line {
          0%   { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes pulse-ring {
          0%   { transform: scale(1); opacity: 0.7; }
          100% { transform: scale(1.5); opacity: 0; }
        }
        .auth-input-label {
          transition: all 0.2s ease;
        }
      `}</style>

      <FloatingOrb x={10}  y={15}  size={300} color="#22d3ee" delay={0}   duration={6} />
      <FloatingOrb x={75}  y={5}   size={200} color="#6366f1" delay={1}   duration={8} />
      <FloatingOrb x={60}  y={70}  size={250} color="#a855f7" delay={2}   duration={7} />
      <FloatingOrb x={5}   y={65}  size={180} color="#22c55e" delay={0.5} duration={9} />
      <FloatingOrb x={85}  y={50}  size={220} color="#f59e0b" delay={1.5} duration={5} />
      <ParticleField />

      {/* grid overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{backgroundImage:"linear-gradient(#22d3ee 1px,transparent 1px),linear-gradient(90deg,#22d3ee 1px,transparent 1px)", backgroundSize:"40px 40px"}} />

      {/* ===== card ===== */}
      <div
        className="relative w-full max-w-sm mx-4"
        style={{
          animation: mounted ? "auth-card-in 0.5s cubic-bezier(0.34,1.56,0.64,1) forwards" : "none",
          opacity: mounted ? 1 : 0,
        }}
      >
        {/* glow ring behind card */}
        <div className="absolute -inset-px rounded-3xl pointer-events-none"
          style={{background:"linear-gradient(135deg,#22d3ee33,#6366f133,#a855f733)", filter:"blur(1px)"}} />

        <div className="relative rounded-3xl overflow-hidden"
          style={{
            background:"rgba(9,14,30,0.92)",
            backdropFilter:"blur(24px)",
            border:"1px solid rgba(255,255,255,0.06)",
            boxShadow:"0 32px 80px rgba(0,0,0,0.7), 0 0 60px rgba(34,211,238,0.08)",
          }}>

          {/* top accent bar */}
          <div className="h-0.5 w-full"
            style={{background:"linear-gradient(90deg,transparent,#22d3ee,#6366f1,#a855f7,transparent)"}} />

          <div className="p-7 space-y-5">
            {/* logo */}
            <div className="text-center space-y-2">
              <div className="relative inline-flex items-center justify-center">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center relative"
                  style={{background:"linear-gradient(135deg,#0f172a,#1e293b)", border:"1px solid rgba(34,211,238,0.2)", boxShadow:"0 0 30px rgba(34,211,238,0.15)"}}>
                  <Zap className="w-7 h-7" style={{color:"#22d3ee", filter:"drop-shadow(0 0 8px #22d3ee88)"}} />
                </div>
                {/* spinning ring */}
                <div className="absolute -inset-1 rounded-[18px] border border-dashed border-cyan-500/20 animate-[spin-slow_12s_linear_infinite]" style={{animationName:"spin-slow"}} />
              </div>
              <div>
                <h1 className="text-2xl font-black tracking-[0.15em]"
                  style={{
                    background:"linear-gradient(to right,#22d3ee,#818cf8,#c084fc)",
                    WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
                  }}>
                  NEXUS_OS
                </h1>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5 tracking-widest">CONNECTUZ TIZIMI v5.6</p>
              </div>
            </div>

            {/* tab switcher */}
            <div className="relative flex rounded-2xl overflow-hidden p-0.5"
              style={{background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.06)"}}>
              <div
                className="absolute top-0.5 bottom-0.5 w-[calc(50%-2px)] rounded-xl transition-all duration-300 ease-out"
                style={{
                  left: mode === "login" ? "2px" : "calc(50% + 0px)",
                  background: mode === "login"
                    ? "linear-gradient(135deg,#0e7490,#1d4ed8)"
                    : "linear-gradient(135deg,#6d28d9,#4338ca)",
                  boxShadow: mode === "login" ? "0 2px 12px #0e749066" : "0 2px 12px #6d28d966",
                }}
              />
              {(["login","register"] as const).map(m => (
                <button key={m} onClick={() => switchMode(m)}
                  className="relative flex-1 py-2.5 text-xs font-bold transition-colors duration-200 rounded-xl"
                  style={{color: mode === m ? "white" : "#64748b"}}>
                  {m === "login" ? "🔑 KIRISH" : "📝 RO'YXAT"}
                </button>
              ))}
            </div>

            {/* fields */}
            <div className="space-y-3">
              {/* username */}
              <div className="relative">
                <div
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors duration-200"
                  style={{color: focusUser ? "#22d3ee" : "#475569"}}>
                  <User className="w-4 h-4" />
                </div>
                <input
                  ref={userRef}
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  onFocus={() => setFocusUser(true)}
                  onBlur={() => setFocusUser(false)}
                  autoComplete="off"
                  autoCorrect="off"
                  spellCheck={false}
                  placeholder="Foydalanuvchi ID"
                  className="w-full pl-10 pr-4 py-3.5 rounded-xl text-sm text-white outline-none transition-all duration-200 bg-slate-900/80"
                  style={{
                    border: `1px solid ${focusUser ? "#22d3ee55" : "rgba(255,255,255,0.07)"}`,
                    boxShadow: focusUser ? "0 0 0 3px rgba(34,211,238,0.08), inset 0 1px 0 rgba(255,255,255,0.05)" : "none",
                    background: focusUser ? "rgba(14,116,144,0.08)" : "rgba(15,23,42,0.6)",
                  }}
                />
                {username.length >= 3 && !focusUser && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-green-400" />
                )}
              </div>

              {/* password */}
              <div className="relative">
                <div
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors duration-200"
                  style={{color: focusPw ? "#22d3ee" : "#475569"}}>
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  onFocus={() => setFocusPw(true)}
                  onBlur={() => setFocusPw(false)}
                  autoComplete="new-password"
                  placeholder="Maxfiy kalit"
                  onKeyDown={e => e.key === "Enter" && (mode === "login" ? handleLogin() : handleRegister())}
                  className="w-full pl-10 pr-11 py-3.5 rounded-xl text-sm text-white outline-none transition-all duration-200"
                  style={{
                    border: `1px solid ${focusPw ? "#22d3ee55" : "rgba(255,255,255,0.07)"}`,
                    boxShadow: focusPw ? "0 0 0 3px rgba(34,211,238,0.08), inset 0 1px 0 rgba(255,255,255,0.05)" : "none",
                    background: focusPw ? "rgba(14,116,144,0.08)" : "rgba(15,23,42,0.6)",
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                  tabIndex={-1}
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* password strength (register only) */}
            {mode === "register" && password.length > 0 && (
              <div className="space-y-1.5 -mt-1">
                <div className="flex gap-1">
                  {[4,7,10].map((thresh, i) => (
                    <div key={i} className="flex-1 h-1 rounded-full transition-all duration-300"
                      style={{background: password.length >= thresh ? ["#ef4444","#f59e0b","#22c55e"][i] : "#1e293b"}} />
                  ))}
                </div>
                <p className="text-[10px] font-mono"
                  style={{color: password.length < 4 ? "#ef4444" : password.length < 7 ? "#f59e0b" : "#22c55e"}}>
                  {password.length < 4 ? "Zaif parol" : password.length < 7 ? "O'rtacha parol" : "Kuchli parol ✓"}
                </p>
              </div>
            )}

            {/* error / success */}
            {error && (
              <div className="flex items-start gap-2.5 px-3.5 py-3 rounded-xl text-xs font-mono"
                style={{background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.2)", color:"#fca5a5"}}>
                <span className="mt-0.5 flex-shrink-0">⚠️</span>
                <span>{error}</span>
              </div>
            )}
            {success && (
              <div className="flex items-center gap-2.5 px-3.5 py-3 rounded-xl text-xs font-mono"
                style={{background:"rgba(34,197,94,0.08)", border:"1px solid rgba(34,197,94,0.2)", color:"#86efac"}}>
                {success}
              </div>
            )}

            {/* loading bar */}
            {loading && (
              <div className="h-0.5 rounded-full overflow-hidden bg-slate-800">
                <div className="h-full rounded-full transition-all duration-300 ease-out"
                  style={{width:`${loadPct}%`, background:"linear-gradient(90deg,#22d3ee,#6366f1)"}} />
              </div>
            )}

            {/* submit */}
            <button
              onClick={mode === "login" ? handleLogin : handleRegister}
              disabled={loading || !!success}
              className="w-full py-3.5 rounded-xl font-black text-sm text-white transition-all duration-200 relative overflow-hidden active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                background: mode === "login"
                  ? "linear-gradient(135deg, #0891b2, #1d4ed8)"
                  : "linear-gradient(135deg, #7c3aed, #4338ca)",
                boxShadow: mode === "login"
                  ? "0 4px 20px rgba(8,145,178,0.35)"
                  : "0 4px 20px rgba(124,58,237,0.35)",
              }}
            >
              {/* shimmer overlay */}
              <div className="absolute inset-0 pointer-events-none"
                style={{
                  background:"linear-gradient(90deg,transparent 0%,rgba(255,255,255,0.12) 50%,transparent 100%)",
                  backgroundSize:"200% 100%",
                  animation:"shimmer-line 2.5s linear infinite",
                }} />
              <span className="relative flex items-center justify-center gap-2">
                {loading ? (
                  <>
                    <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    <span>{mode === "login" ? "ULANMOQDA..." : "YARATILMOQDA..."}</span>
                  </>
                ) : (
                  <>
                    {mode === "login" ? "🔑 TIZIMGA KIRISH" : "📝 PROFIL OCHISH"}
                    <ChevronRight className="w-4 h-4 opacity-70" />
                  </>
                )}
              </span>
            </button>

            {/* hint */}
            <p className="text-center text-[11px] text-slate-600 font-mono">
              {mode === "login"
                ? <>Profilingiz yo'qmi? <button onClick={() => switchMode("register")} className="text-cyan-500 hover:text-cyan-400 transition">Ro'yxatdan o'ting</button></>
                : <>Hisobingiz bormi? <button onClick={() => switchMode("login")} className="text-indigo-400 hover:text-indigo-300 transition">Kiring</button></>
              }
            </p>

            {/* feature badges */}
            <div className="flex flex-wrap gap-1.5 justify-center pt-1">
              {FEATURES.map((f, i) => (
                <div key={i} className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-mono text-slate-500"
                  style={{background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.05)"}}>
                  <span className="text-slate-600">{f.icon}</span>
                  {f.label}
                </div>
              ))}
            </div>
          </div>

          {/* bottom bar */}
          <div className="px-7 py-3 flex items-center justify-center border-t border-slate-800/40">
            <p className="text-[9px] font-mono text-slate-700 tracking-widest">NEXUS_OS · CONNECTUZ · v5.6</p>
          </div>
        </div>
      </div>
    </div>
  );
}
