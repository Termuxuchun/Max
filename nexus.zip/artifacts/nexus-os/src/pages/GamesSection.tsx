import { useState, useEffect, useRef } from "react";
import MafiaGame from "./MafiaGame";
import MathGame from "./MathGame";
import GTA3DGame from "./GTA3DGame";

interface Props {
  username: string;
  accentColor: string;
}

type GameId = "mafia" | "tictactoe" | "snake" | "memory" | "rps" | "wordle" | "numguess" | "hangman" | "dice" | "reflex" | "blackjack2" | "shashka2" | "math" | "gta3d" | "connect4" | "g2048" | "battleship";

const GAMES: { id: GameId; icon: string; name: string; desc: string; players: string; bg: string; isNew?: boolean }[] = [
  { id: "connect4",    icon: "🔴", name: "To'rt Kettachi",  desc: "4 tani ketma-ket tizing — AI bot yoki 2 o'yinchi", players: "AI Bot / 2 o'yinchi", bg: "#0a0f1a", isNew: true },
  { id: "g2048",       icon: "🔢", name: "2048",             desc: "Plitalarni qo'shib 2048 ga yeting!", players: "1 o'yinchi", bg: "#1a1205", isNew: true },
  { id: "battleship",  icon: "⚓", name: "Dengiz Jangi",     desc: "10×10 dengizda kemalarni yuk qiling — AI vs Siz", players: "AI Bot / 2 o'yinchi", bg: "#051015", isNew: true },
  { id: "mafia", icon: "🕵️", name: "Mafia", desc: "Klassik psixologik o'yin. Kim mafia?", players: "5-12 o'yinchi", bg: "#1a0a0a" },
  { id: "tictactoe", icon: "⭕", name: "Tic-Tac-Toe", desc: "3x3 da uch qatorni to'ldiring", players: "2 o'yinchi", bg: "#0a0a1a" },
  { id: "rps", icon: "✊", name: "Tosh-Qaychi-Qog'oz", desc: "Klassik 3 tanlov o'yini", players: "1-2 o'yinchi", bg: "#0a1a0a" },
  { id: "memory", icon: "🧠", name: "Xotira", desc: "Juft kartalarni toping", players: "1 o'yinchi", bg: "#1a0a1a" },
  { id: "numguess", icon: "🔢", name: "Raqam Topish", desc: "1-100 oralig'idagi raqamni top", players: "1 o'yinchi", bg: "#0a1a1a" },
  { id: "wordle", icon: "📝", name: "So'z Topish", desc: "5 harfli so'zni 6 urinishda top", players: "1 o'yinchi", bg: "#1a1a0a" },
  { id: "hangman", icon: "🪢", name: "Hangman", desc: "So'zning harflarini bil", players: "1 o'yinchi", bg: "#0a0a0a" },
  { id: "dice", icon: "🎲", name: "Zar O'yini", desc: "Zarni uloqtir, yuqori ball to'pla", players: "2 o'yinchi", bg: "#1a1a1a" },
  { id: "reflex", icon: "⚡", name: "Reflex Test", desc: "Yashil signal chiqganda bosing!", players: "1 o'yinchi", bg: "#0a0a1a" },
  { id: "snake", icon: "🐍", name: "Snake", desc: "Ilonni boshqar, ovqat ye, o'sib bor", players: "1 o'yinchi", bg: "#0a1a0a" },
  { id: "math", icon: "🧮", name: "Matematika", desc: "Tenglamalar yeching: oson, o'rtacha, qiyin", players: "1 o'yinchi", bg: "#0a1a15" },
  { id: "gta3d", icon: "🏃", name: "NEXUS RUNNER 3D", desc: "Subway Surfers uslubi — cheksiz yugurish, to'siqlardan o'ting", players: "1 o'yinchi", bg: "#050510" },
];

function TicTacToe({ accentColor }: { accentColor: string }) {
  const [board, setBoard] = useState<("X" | "O" | null)[]>(Array(9).fill(null));
  const [xTurn, setXTurn] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);

  function checkWinner(b: ("X" | "O" | null)[]) {
    const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for (const [a,b2,c] of lines) {
      if (b[a] && b[a] === b[b2] && b[a] === b[c]) return b[a];
    }
    return null;
  }

  function click(i: number) {
    if (board[i] || winner) return;
    const nb = [...board];
    nb[i] = xTurn ? "X" : "O";
    setBoard(nb);
    const w = checkWinner(nb);
    if (w) setWinner(w);
    else if (nb.every(Boolean)) setWinner("Draw");
    else setXTurn(!xTurn);
  }

  function reset() { setBoard(Array(9).fill(null)); setXTurn(true); setWinner(null); }

  return (
    <div className="flex flex-col items-center gap-6">
      <p className="text-sm font-bold" style={{color: accentColor}}>
        {winner ? (winner === "Draw" ? "🤝 Durang!" : `🏆 ${winner} g'alaba!`) : `Navbat: ${xTurn ? "❌ X" : "⭕ O"}`}
      </p>
      <div className="grid grid-cols-3 gap-2">
        {board.map((cell, i) => (
          <button key={i} onClick={() => click(i)}
            className="w-20 h-20 rounded-2xl text-3xl font-black border-2 border-slate-700 bg-slate-900 hover:bg-slate-800 transition"
            style={{color: cell === "X" ? "#f43f5e" : accentColor}}>
            {cell === "X" ? "❌" : cell === "O" ? "⭕" : ""}
          </button>
        ))}
      </div>
      {winner && (
        <button onClick={reset} className="px-6 py-2.5 rounded-xl font-bold text-sm" style={{background: accentColor}}>
          Qayta o'ynash
        </button>
      )}
    </div>
  );
}

function RockPaperScissors({ accentColor }: { accentColor: string }) {
  const choices = ["✊", "✌️", "🖐️"];
  const names = ["Tosh", "Qaychi", "Qog'oz"];
  const [player, setPlayer] = useState<number | null>(null);
  const [computer, setComputer] = useState<number | null>(null);
  const [result, setResult] = useState<string>("");
  const [scores, setScores] = useState({ p: 0, c: 0 });

  function play(choice: number) {
    const comp = Math.floor(Math.random() * 3);
    setPlayer(choice);
    setComputer(comp);
    if (choice === comp) { setResult("🤝 Durang!"); }
    else if ((choice - comp + 3) % 3 === 1) { setResult("🏆 Siz yutdingiz!"); setScores(s => ({...s, p: s.p+1})); }
    else { setResult("💻 Kompyuter yutdi!"); setScores(s => ({...s, c: s.c+1})); }
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-6 text-center">
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-700">
          <p className="text-xs text-slate-500 mb-1">Siz</p>
          <p className="text-2xl font-black" style={{color: accentColor}}>{scores.p}</p>
        </div>
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-700">
          <p className="text-xs text-slate-500 mb-1">Kompyuter</p>
          <p className="text-2xl font-black text-rose-400">{scores.c}</p>
        </div>
      </div>
      {player !== null && (
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900 border border-slate-700">
          <div className="text-center">
            <p className="text-4xl">{choices[player!]}</p>
            <p className="text-[10px] text-slate-500">{names[player!]}</p>
          </div>
          <p className="text-xl text-slate-500">VS</p>
          <div className="text-center">
            <p className="text-4xl">{choices[computer!]}</p>
            <p className="text-[10px] text-slate-500">{names[computer!]}</p>
          </div>
        </div>
      )}
      {result && <p className="text-base font-bold" style={{color: accentColor}}>{result}</p>}
      <div className="flex gap-3">
        {choices.map((c, i) => (
          <button key={i} onClick={() => play(i)}
            className="w-16 h-16 rounded-2xl text-3xl bg-slate-900 border-2 border-slate-700 hover:border-slate-500 hover:bg-slate-800 transition active:scale-95">
            {c}
          </button>
        ))}
      </div>
    </div>
  );
}

function MemoryGame({ accentColor }: { accentColor: string }) {
  const emojis = ["🎮","🎯","🎲","🎸","🎺","🎻","🎹","🥁"];
  const [cards, setCards] = useState(() => {
    const c = [...emojis,...emojis].map((e,i) => ({id:i, emoji:e, flipped:false, matched:false}));
    return c.sort(() => Math.random()-0.5);
  });
  const [sel, setSel] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const matched = cards.filter(c => c.matched).length / 2;

  function flip(id: number) {
    const card = cards.find(c => c.id === id);
    if (!card || card.flipped || card.matched || sel.length >= 2) return;
    const ns = [...sel, id];
    setCards(prev => prev.map(c => c.id === id ? {...c, flipped:true} : c));
    if (ns.length === 2) {
      setMoves(m => m+1);
      const [a, b] = ns.map(id => cards.find(c => c.id === id)!);
      if (a.emoji === b.emoji) {
        setTimeout(() => setCards(prev => prev.map(c => ns.includes(c.id) ? {...c, matched:true} : c)), 600);
      } else {
        setTimeout(() => setCards(prev => prev.map(c => ns.includes(c.id) ? {...c, flipped:false} : c)), 900);
      }
      setSel([]);
    } else setSel(ns);
  }

  function reset() {
    setCards([...emojis,...emojis].map((e,i) => ({id:i, emoji:e, flipped:false, matched:false})).sort(() => Math.random()-0.5));
    setSel([]); setMoves(0);
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-4 text-sm">
        <span className="text-slate-400">Harakatlar: <span style={{color: accentColor}} className="font-bold">{moves}</span></span>
        <span className="text-slate-400">Topilgan: <span style={{color: accentColor}} className="font-bold">{matched}/{emojis.length}</span></span>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {cards.map(c => (
          <button key={c.id} onClick={() => flip(c.id)}
            className={`w-14 h-14 rounded-xl text-2xl border-2 transition ${c.matched ? "border-green-700 bg-green-950/40" : c.flipped ? "border-slate-500 bg-slate-800" : "border-slate-700 bg-slate-900 hover:bg-slate-800"}`}>
            {c.flipped || c.matched ? c.emoji : "❓"}
          </button>
        ))}
      </div>
      {matched === emojis.length && (
        <div className="text-center space-y-2">
          <p className="text-lg font-black text-green-400">🏆 Barakallo! {moves} harakatda!</p>
          <button onClick={reset} className="px-6 py-2 rounded-xl font-bold text-sm" style={{background: accentColor}}>Qayta</button>
        </div>
      )}
    </div>
  );
}

function NumberGuess({ accentColor }: { accentColor: string }) {
  const [secret] = useState(() => Math.floor(Math.random()*100)+1);
  const [input, setInput] = useState("");
  const [attempts, setAttempts] = useState<{n:number;hint:string}[]>([]);
  const [won, setWon] = useState(false);

  function guess() {
    const n = parseInt(input);
    if (!n || n<1 || n>100) return;
    const hint = n === secret ? "🎉 To'g'ri!" : n < secret ? "⬆️ Kattaroq" : "⬇️ Kichikroq";
    setAttempts(a => [...a, {n, hint}]);
    if (n === secret) setWon(true);
    setInput("");
  }

  if (won) return (
    <div className="text-center space-y-4">
      <p className="text-4xl">🏆</p>
      <p className="text-lg font-black text-green-400">{secret} raqamini {attempts.length} urinishda topdingiz!</p>
      <button onClick={() => window.location.reload()} className="px-6 py-2.5 rounded-xl font-bold text-sm" style={{background: accentColor}}>Qayta</button>
    </div>
  );

  return (
    <div className="flex flex-col gap-4 max-w-xs mx-auto w-full">
      <p className="text-center text-sm text-slate-400">1 dan 100 gacha raqam o'ylandi ({attempts.length} ta urinish)</p>
      <div className="flex gap-2">
        <input type="number" min={1} max={100} value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && guess()}
          className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-slate-500"
          placeholder="Raqamni kiriting..." />
        <button onClick={guess} className="px-4 py-2.5 rounded-xl font-bold text-sm" style={{background: accentColor}}>↵</button>
      </div>
      <div className="space-y-1.5 max-h-48 overflow-y-auto">
        {[...attempts].reverse().map((a, i) => (
          <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-bold text-white">{a.n}</span>
            <span className="text-sm">{a.hint}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const WORDS = ["OLMA","KITOB","SUPUR","MAKTAB","GULOB","TARVUZ","QOZON","RAQAM","DAVON","YULDUZ"];
function WordleGame({ accentColor }: { accentColor: string }) {
  const [secret] = useState(() => WORDS[Math.floor(Math.random()*WORDS.length)]);
  const [guesses, setGuesses] = useState<string[]>([]);
  const [current, setCurrent] = useState("");
  const [won, setWon] = useState(false);
  const MAX = 6;

  function submit() {
    if (current.length !== 5 || guesses.length >= MAX) return;
    const ng = [...guesses, current.toUpperCase()];
    setGuesses(ng);
    if (current.toUpperCase() === secret) setWon(true);
    setCurrent("");
  }

  function getCellStyle(g: string, i: number) {
    const ch = g[i];
    if (ch === secret[i]) return {background:"#166534",borderColor:"#16a34a"};
    if (secret.includes(ch)) return {background:"#78350f",borderColor:"#d97706"};
    return {background:"#1e293b",borderColor:"#334155"};
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <p className="text-xs text-slate-500">5 harfli O'zbek so'zini 6 urinishda toping</p>
      <div className="grid gap-1.5">
        {Array.from({length:MAX}).map((_,r) => (
          <div key={r} className="flex gap-1.5">
            {Array.from({length:5}).map((_,c) => {
              const g = guesses[r];
              const ch = g ? g[c] : (r === guesses.length ? current[c] : "");
              return (
                <div key={c} className="w-10 h-10 rounded-lg border-2 flex items-center justify-center text-sm font-black text-white"
                  style={g ? getCellStyle(g, c) : {background:"#0f172a",borderColor:"#1e293b"}}>
                  {ch || ""}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      {won ? (
        <p className="text-green-400 font-bold">🏆 Barakallo! {guesses.length}. urinishda!</p>
      ) : guesses.length >= MAX ? (
        <p className="text-rose-400 font-bold">😔 So'z: {secret}</p>
      ) : (
        <div className="flex gap-2">
          <input maxLength={5} value={current} onChange={e => setCurrent(e.target.value.toUpperCase())}
            onKeyDown={e => e.key === "Enter" && submit()}
            className="w-36 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none uppercase tracking-widest text-center"
            placeholder="SO'Z" />
          <button onClick={submit} className="px-4 py-2 rounded-xl font-bold text-sm" style={{background: accentColor}}>↵</button>
        </div>
      )}
    </div>
  );
}

const HANGMAN_WORDS = ["KOMPYUTER","DASTURLASH","INTERNET","TELEFON","KAMERA","MUZLATGICH","TELEVIZOR","KITOBXON","MAKTAB","KUTUBXONA"];
function HangmanGame({ accentColor }: { accentColor: string }) {
  const [word] = useState(() => HANGMAN_WORDS[Math.floor(Math.random()*HANGMAN_WORDS.length)]);
  const [guessed, setGuessed] = useState<Set<string>>(new Set());
  const wrongs = [...guessed].filter(l => !word.includes(l)).length;
  const won = [...word].every(l => guessed.has(l));
  const lost = wrongs >= 6;

  const ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="text-6xl font-mono">
        {"🧍🏻‍♂️"[0]}
        {["😵","😨","😰","😟","😕","🙁","😀"][Math.min(wrongs,6)]}
      </div>
      <p className="text-xs text-slate-500">Xato: {wrongs}/6</p>
      <div className="flex gap-2 flex-wrap justify-center">
        {[...word].map((ch, i) => (
          <div key={i} className="w-8 h-8 border-b-2 flex items-center justify-center font-bold text-base"
            style={{borderColor: accentColor, color: guessed.has(ch) ? "white" : "transparent"}}>
            {guessed.has(ch) ? ch : "_"}
          </div>
        ))}
      </div>
      {won && <p className="text-green-400 font-bold text-lg">🏆 Yutdingiz!</p>}
      {lost && <p className="text-rose-400 font-bold text-lg">😔 Kalima: {word}</p>}
      {!won && !lost && (
        <div className="flex flex-wrap gap-1.5 justify-center max-w-xs">
          {ALPHA.map(l => (
            <button key={l} onClick={() => setGuessed(s => new Set([...s, l]))}
              disabled={guessed.has(l)}
              className="w-8 h-8 rounded-lg text-xs font-bold border transition disabled:opacity-30"
              style={{
                borderColor: guessed.has(l) ? (word.includes(l) ? "#16a34a" : "#7f1d1d") : "#334155",
                background: guessed.has(l) ? (word.includes(l) ? "#052e16" : "#450a0a") : "#0f172a",
                color: "white"
              }}>
              {l}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function DiceGame({ accentColor }: { accentColor: string }) {
  const [dice, setDice] = useState([1, 1]);
  const [scores, setScores] = useState({ p1: 0, p2: 0 });
  const [turn, setTurn] = useState(0);
  const [rolling, setRolling] = useState(false);

  function roll() {
    setRolling(true);
    setTimeout(() => {
      const d = [Math.ceil(Math.random()*6), Math.ceil(Math.random()*6)];
      setDice(d);
      const sum = d[0]+d[1];
      if (turn === 0) setScores(s => ({...s, p1: s.p1+sum}));
      else setScores(s => ({...s, p2: s.p2+sum}));
      setTurn(t => 1-t);
      setRolling(false);
    }, 600);
  }

  const FACES = ["","⚀","⚁","⚂","⚃","⚄","⚅"];

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-8 text-center">
        <div className={`p-4 rounded-xl border-2 ${turn===0 ? "border-cyan-500 bg-cyan-950/20" : "border-slate-700 bg-slate-900"}`}>
          <p className="text-xs text-slate-400">O'yinchi 1</p>
          <p className="text-2xl font-black" style={{color: accentColor}}>{scores.p1}</p>
        </div>
        <div className={`p-4 rounded-xl border-2 ${turn===1 ? "border-rose-500 bg-rose-950/20" : "border-slate-700 bg-slate-900"}`}>
          <p className="text-xs text-slate-400">O'yinchi 2</p>
          <p className="text-2xl font-black text-rose-400">{scores.p2}</p>
        </div>
      </div>
      <div className="flex gap-4">
        {dice.map((d, i) => (
          <div key={i} className={`text-6xl ${rolling ? "animate-spin" : ""}`}>{FACES[d]}</div>
        ))}
      </div>
      <p className="text-sm text-slate-400">O'yinchi {turn+1} navbatida</p>
      <button onClick={roll} disabled={rolling}
        className="px-8 py-3 rounded-2xl font-black text-base disabled:opacity-50"
        style={{background: accentColor}}>
        {rolling ? "🎲 Aylanmoqda..." : "🎲 Tashlash!"}
      </button>
      {(scores.p1 >= 50 || scores.p2 >= 50) && (
        <p className="font-black text-lg" style={{color: accentColor}}>
          🏆 O'yinchi {scores.p1 >= 50 ? 1 : 2} 50 ga yetdi!
        </p>
      )}
    </div>
  );
}

function ReflexGame({ accentColor }: { accentColor: string }) {
  const [state, setState] = useState<"idle"|"wait"|"ready"|"done">("idle");
  const [startTime, setStartTime] = useState(0);
  const [result, setResult] = useState<number|null>(null);
  const [best, setBest] = useState<number|null>(null);
  const timerRef = { current: 0 as any };

  function start() {
    setState("wait");
    const delay = 2000 + Math.random()*3000;
    timerRef.current = setTimeout(() => { setState("ready"); setStartTime(Date.now()); }, delay);
  }

  function tap() {
    if (state === "wait") { clearTimeout(timerRef.current); setState("idle"); alert("Tez bosding! Yashil rangni kuting."); return; }
    if (state === "ready") {
      const ms = Date.now() - startTime;
      setResult(ms);
      setBest(b => b === null ? ms : Math.min(b, ms));
      setState("done");
    } else start();
  }

  const bgColor = state === "ready" ? "#16a34a" : state === "wait" ? "#dc2626" : "#0f172a";
  const label = state === "idle" ? "Boshlash uchun bosing" : state === "wait" ? "🔴 Kuting..." : state === "ready" ? "⚡ BOSING!" : `${result}ms — Yana o'ynash`;

  return (
    <div className="flex flex-col items-center gap-4">
      {best && <p className="text-xs text-slate-400">Eng yaxshi: <span style={{color: accentColor}} className="font-bold">{best}ms</span></p>}
      <button onClick={tap} className="w-56 h-56 rounded-3xl text-center font-black text-lg transition-colors duration-200 flex items-center justify-center"
        style={{background: bgColor, color: "white"}}>
        {label}
      </button>
      {result && state === "done" && (
        <p className="text-sm text-slate-400">
          {result < 200 ? "🚀 Ajoyib!" : result < 350 ? "⚡ Yaxshi!" : result < 500 ? "👍 Normal!" : "🐌 Sekin!"}
        </p>
      )}
    </div>
  );
}

function SnakeGame({ accentColor }: { accentColor: string }) {
  const COLS = 15, ROWS = 15, SIZE = 22;

  function mkFood(s: number[][]): number[] {
    let nx = Math.floor(Math.random()*COLS), ny = Math.floor(Math.random()*ROWS);
    while (s.some(([x,y]) => x===nx && y===ny)) {
      nx = Math.floor(Math.random()*COLS); ny = Math.floor(Math.random()*ROWS);
    }
    return [nx, ny];
  }

  const INIT: number[][] = [[7,7],[7,6],[7,5]];
  const [snake, setSnake] = useState<number[][]>(INIT);
  const [food, setFood] = useState<number[]>([3,3]);
  const [score, setScore] = useState(0);
  const [dead, setDead] = useState(false);
  const [running, setRunning] = useState(false);
  const dirRef = useRef<number[]>([0,1]);

  useEffect(() => {
    if (!running || dead) return;
    const iv = setInterval(() => {
      setSnake(prev => {
        const d = dirRef.current;
        const head = [prev[0][0]+d[0], prev[0][1]+d[1]];
        if (head[0]<0||head[0]>=ROWS||head[1]<0||head[1]>=COLS||prev.some(([x,y])=>x===head[0]&&y===head[1])) {
          setDead(true); setRunning(false); return prev;
        }
        const ns = [head, ...prev];
        setFood(f => {
          if (f[0]===head[0] && f[1]===head[1]) { setScore(s => s+1); return mkFood(ns); }
          ns.pop(); return f;
        });
        return ns;
      });
    }, 200);
    return () => clearInterval(iv);
  }, [running, dead]);

  function reset() {
    setSnake(INIT); setFood([3,3]); setScore(0); setDead(false); setRunning(false); dirRef.current=[0,1];
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <p className="text-sm font-bold" style={{color: accentColor}}>Ball: {score}</p>
      <div className="relative bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden"
        style={{width:COLS*SIZE, height:ROWS*SIZE}}>
        {snake.map(([r,c],i) => (
          <div key={i} className="absolute rounded-sm" style={{left:c*SIZE,top:r*SIZE,width:SIZE-2,height:SIZE-2,background:i===0?accentColor:`${accentColor}77`}} />
        ))}
        <div className="absolute rounded-full" style={{left:food[1]*SIZE+2,top:food[0]*SIZE+2,width:SIZE-4,height:SIZE-4,background:"#f43f5e"}} />
        {!running && !dead && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60">
            <button onClick={() => setRunning(true)} className="px-6 py-3 rounded-2xl font-black text-white text-sm" style={{background:accentColor}}>🐍 Boshlash</button>
          </div>
        )}
      </div>
      {dead ? (
        <div className="text-center space-y-2">
          <p className="text-rose-400 font-bold">😵 Tugadi! Ball: {score}</p>
          <button onClick={reset} className="px-6 py-2 rounded-xl font-bold text-sm" style={{background:accentColor}}>Qayta</button>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2 mt-1">
          <div/>
          <button onClick={() => { dirRef.current=[-1,0]; }} className="p-2 rounded-xl bg-slate-800 text-xl">⬆️</button>
          <div/>
          <button onClick={() => { dirRef.current=[0,-1]; }} className="p-2 rounded-xl bg-slate-800 text-xl">⬅️</button>
          <button onClick={() => { dirRef.current=[1,0]; }} className="p-2 rounded-xl bg-slate-800 text-xl">⬇️</button>
          <button onClick={() => { dirRef.current=[0,1]; }} className="p-2 rounded-xl bg-slate-800 text-xl">➡️</button>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════ CONNECT FOUR ═══════════════════════ */
const C4_ROWS = 6, C4_COLS = 7;
function makeC4Board() { return Array.from({length: C4_ROWS}, () => Array(C4_COLS).fill(0)); }

function checkC4(board: number[][], p: number) {
  const dirs = [[0,1],[1,0],[1,1],[1,-1]];
  for (let r=0;r<C4_ROWS;r++) for (let c=0;c<C4_COLS;c++) {
    for (const [dr,dc] of dirs) {
      let ok = true;
      for (let k=0;k<4;k++) {
        const nr=r+dr*k, nc=c+dc*k;
        if (nr<0||nr>=C4_ROWS||nc<0||nc>=C4_COLS||board[nr][nc]!==p) { ok=false; break; }
      }
      if (ok) return true;
    }
  }
  return false;
}

function c4Score(board: number[][], p: number) {
  let score = 0;
  const opp = p===1?2:1;
  function window4(cells: number[]) {
    const pc = cells.filter(x=>x===p).length, oc = cells.filter(x=>x===opp).length, ec = cells.filter(x=>x===0).length;
    if (pc===4) return 100;
    if (pc===3&&ec===1) return 5;
    if (pc===2&&ec===2) return 2;
    if (oc===3&&ec===1) return -4;
    return 0;
  }
  for (let r=0;r<C4_ROWS;r++) for (let c=0;c<=C4_COLS-4;c++) score+=window4([board[r][c],board[r][c+1],board[r][c+2],board[r][c+3]]);
  for (let r=0;r<=C4_ROWS-4;r++) for (let c=0;c<C4_COLS;c++) score+=window4([board[r][c],board[r+1][c],board[r+2][c],board[r+3][c]]);
  for (let r=0;r<=C4_ROWS-4;r++) for (let c=0;c<=C4_COLS-4;c++) score+=window4([board[r][c],board[r+1][c+1],board[r+2][c+2],board[r+3][c+3]]);
  for (let r=3;r<C4_ROWS;r++) for (let c=0;c<=C4_COLS-4;c++) score+=window4([board[r][c],board[r-1][c+1],board[r-2][c+2],board[r-3][c+3]]);
  return score;
}

function c4Drop(board: number[][], col: number, p: number): number[][] | null {
  const nb = board.map(r=>[...r]);
  for (let r=C4_ROWS-1;r>=0;r--) { if (nb[r][col]===0) { nb[r][col]=p; return nb; } }
  return null;
}

function minimax(board: number[][], depth: number, alpha: number, beta: number, maximizing: boolean): number {
  if (checkC4(board,2)) return 1000+depth;
  if (checkC4(board,1)) return -1000-depth;
  const cols = Array.from({length:C4_COLS},(_,i)=>i).filter(c=>board[0][c]===0);
  if (!cols.length||depth===0) return c4Score(board,2);
  if (maximizing) {
    let val = -Infinity;
    for (const c of cols) {
      const nb = c4Drop(board,c,2); if (!nb) continue;
      val = Math.max(val, minimax(nb,depth-1,alpha,beta,false));
      alpha = Math.max(alpha,val);
      if (alpha>=beta) break;
    }
    return val;
  } else {
    let val = Infinity;
    for (const c of cols) {
      const nb = c4Drop(board,c,1); if (!nb) continue;
      val = Math.min(val, minimax(nb,depth-1,alpha,beta,true));
      beta = Math.min(beta,val);
      if (alpha>=beta) break;
    }
    return val;
  }
}

function bestC4Move(board: number[][]): number {
  const cols = Array.from({length:C4_COLS},(_,i)=>i).filter(c=>board[0][c]===0);
  let best = -Infinity, bestCol = cols[0];
  for (const c of cols) {
    const nb = c4Drop(board,c,2); if (!nb) continue;
    const val = minimax(nb,4,-Infinity,Infinity,false);
    if (val>best) { best=val; bestCol=c; }
  }
  return bestCol;
}

function ConnectFour({ accentColor }: { accentColor: string }) {
  const [mode, setMode] = useState<"menu"|"local"|"ai">("menu");
  const [board, setBoard] = useState(makeC4Board());
  const [turn, setTurn] = useState(1);
  const [winner, setWinner] = useState(0);
  const [aiThinking, setAiThinking] = useState(false);
  const [winningCells, setWinningCells] = useState<string[]>([]);

  function findWinCells(b: number[][], p: number): string[] {
    const dirs = [[0,1],[1,0],[1,1],[1,-1]];
    for (let r=0;r<C4_ROWS;r++) for (let c=0;c<C4_COLS;c++) {
      for (const [dr,dc] of dirs) {
        const cells: string[] = [];
        for (let k=0;k<4;k++) {
          const nr=r+dr*k, nc=c+dc*k;
          if (nr<0||nr>=C4_ROWS||nc<0||nc>=C4_COLS||b[nr][nc]!==p) break;
          cells.push(`${nr},${nc}`);
        }
        if (cells.length===4) return cells;
      }
    }
    return [];
  }

  function drop(col: number) {
    if (winner || aiThinking) return;
    const nb = c4Drop(board, col, turn);
    if (!nb) return;
    setBoard(nb);
    if (checkC4(nb, turn)) { setWinner(turn); setWinningCells(findWinCells(nb,turn)); return; }
    const allFull = nb[0].every(c=>c!==0);
    if (allFull) { setWinner(-1); return; }
    if (mode === "ai") {
      setTurn(2);
      setAiThinking(true);
      setTimeout(() => {
        const ac = bestC4Move(nb);
        const nb2 = c4Drop(nb, ac, 2)!;
        setBoard(nb2);
        if (checkC4(nb2,2)) { setWinner(2); setWinningCells(findWinCells(nb2,2)); }
        else if (nb2[0].every(c=>c!==0)) setWinner(-1);
        else setTurn(1);
        setAiThinking(false);
      }, 300);
    } else {
      setTurn(t => t===1?2:1);
    }
  }

  function reset() { setBoard(makeC4Board()); setTurn(1); setWinner(0); setAiThinking(false); setWinningCells([]); }

  const p1Color = accentColor;
  const p2Color = "#f43f5e";

  if (mode === "menu") return (
    <div className="flex flex-col items-center gap-5 pt-4">
      <div className="text-6xl">🔴🟡</div>
      <p className="text-xl font-black text-white">To'rt Kettachi</p>
      <p className="text-sm text-slate-400 text-center max-w-xs">4 ta toshni ketma-ket tizing. Gorizontal, vertikal yoki diagonal!</p>
      <div className="flex flex-col gap-3 w-full max-w-xs">
        <button onClick={() => { setMode("ai"); reset(); }} className="w-full py-4 rounded-2xl font-black text-base flex items-center justify-center gap-3"
          style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, color: "#000" }}>
          🤖 AI Bot bilan o'ynash
        </button>
        <button onClick={() => { setMode("local"); reset(); }} className="w-full py-4 rounded-2xl font-black text-base flex items-center justify-center gap-3 bg-slate-800 text-white hover:bg-slate-700 transition">
          👥 2 o'yinchi (bir ekranda)
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-4 text-sm font-bold">
        {winner === 0 && (
          <span style={{ color: turn===1 ? p1Color : p2Color }}>
            {aiThinking ? "🤖 AI o'ylayapti..." : `Navbat: ${turn===1 ? "🟡 Siz" : (mode==="ai"?"🔴 AI":"🔴 2-o'yinchi")}`}
          </span>
        )}
        {winner === -1 && <span className="text-slate-400">🤝 Durang!</span>}
        {winner > 0 && (
          <span style={{ color: winner===1 ? p1Color : p2Color }}>
            🏆 {winner===1 ? "Siz yutdingiz!" : (mode==="ai"?"AI yutdi!":"2-o'yinchi yutdi!")}
          </span>
        )}
      </div>

      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${C4_COLS}, 1fr)` }}>
        {Array.from({length:C4_COLS},(_,c)=>(
          <button key={c} onClick={() => drop(c)} disabled={!!winner||aiThinking||board[0][c]!==0}
            className="h-7 rounded-t-xl text-sm transition hover:opacity-70 disabled:cursor-not-allowed font-black"
            style={{ width: 44, background: turn===1?`${p1Color}30`:`${p2Color}30`, color: turn===1?p1Color:p2Color }}>
            ↓
          </button>
        ))}
      </div>

      <div className="rounded-2xl overflow-hidden border-2 border-slate-700 bg-[#0f2044]"
        style={{ display: "grid", gridTemplateColumns: `repeat(${C4_COLS}, 44px)`, gap: 4, padding: 8 }}>
        {board.map((row, r) => row.map((cell, c) => {
          const isWin = winningCells.includes(`${r},${c}`);
          return (
            <div key={`${r},${c}`} className="w-11 h-11 rounded-full flex items-center justify-center transition-all"
              style={{
                background: cell===0 ? "#1e293b" : cell===1 ? p1Color : p2Color,
                boxShadow: isWin ? `0 0 12px 3px ${cell===1?p1Color:p2Color}` : cell===0 ? "inset 0 2px 6px rgba(0,0,0,0.5)" : "none",
                transform: isWin ? "scale(1.08)" : "scale(1)",
              }} />
          );
        }))}
      </div>

      <div className="flex gap-3">
        <button onClick={reset} className="px-5 py-2 rounded-xl font-bold text-sm bg-slate-800 text-slate-300 hover:bg-slate-700 transition">↺ Qayta</button>
        <button onClick={() => { reset(); setMode("menu"); }} className="px-5 py-2 rounded-xl font-bold text-sm text-slate-500 hover:text-slate-300 transition">← Menu</button>
      </div>
    </div>
  );
}

/* ═══════════════════════ 2048 ═══════════════════════ */
function Game2048({ accentColor }: { accentColor: string }) {
  const SIZE = 4;
  function emptyBoard2048() { return Array.from({length:SIZE}, ()=>Array(SIZE).fill(0)); }
  function addRandom(b: number[][]): number[][] {
    const empty: [number,number][] = [];
    b.forEach((row,r)=>row.forEach((v,c)=>{ if(!v) empty.push([r,c]); }));
    if (!empty.length) return b;
    const [r,c] = empty[Math.floor(Math.random()*empty.length)];
    const nb = b.map(row=>[...row]);
    nb[r][c] = Math.random()<0.9?2:4;
    return nb;
  }
  function initBoard2048() { return addRandom(addRandom(emptyBoard2048())); }

  const [board, setBoard] = useState<number[][]>(initBoard2048);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [over, setOver] = useState(false);
  const [won, setWon] = useState(false);
  const touchStart = useRef<{x:number,y:number}|null>(null);

  function slideRow(row: number[]): [number[], number] {
    let pts = 0;
    const nonZero = row.filter(v=>v>0);
    const merged: number[] = [];
    let i = 0;
    while (i < nonZero.length) {
      if (i+1<nonZero.length && nonZero[i]===nonZero[i+1]) {
        merged.push(nonZero[i]*2); pts+=nonZero[i]*2; i+=2;
      } else { merged.push(nonZero[i]); i++; }
    }
    while (merged.length<SIZE) merged.push(0);
    return [merged, pts];
  }

  function move(dir: "up"|"down"|"left"|"right") {
    if (over) return;
    let b = board.map(r=>[...r]);
    let pts = 0;
    let changed = false;

    function rotCW(m: number[][]): number[][] {
      return Array.from({length:SIZE},(_,r)=>Array.from({length:SIZE},(_,c)=>m[SIZE-1-c][r]));
    }
    function rotCCW(m: number[][]): number[][] {
      return Array.from({length:SIZE},(_,r)=>Array.from({length:SIZE},(_,c)=>m[c][SIZE-1-r]));
    }

    if (dir==="up") b = rotCCW(b);
    if (dir==="right") { b=b.map(r=>[...r].reverse()); }
    if (dir==="down") b = rotCW(b);

    b = b.map(row => {
      const [nr, p] = slideRow(row);
      if (nr.join(",")!==row.join(",")) changed = true;
      pts += p;
      return nr;
    });

    if (dir==="up") b = rotCW(b);
    if (dir==="right") b = b.map(r=>[...r].reverse());
    if (dir==="down") b = rotCCW(b);

    if (!changed) return;
    const nb = addRandom(b);
    setBoard(nb);
    const ns = score+pts;
    setScore(ns);
    if (ns>best) setBest(ns);
    if (nb.some(row=>row.some(v=>v>=2048)) && !won) setWon(true);
    const hasMoves = nb.some((row,r)=>row.some((v,c)=>{
      if(!v) return true;
      if(c<SIZE-1&&row[c+1]===v) return true;
      if(r<SIZE-1&&nb[r+1][c]===v) return true;
      return false;
    }));
    if (!hasMoves) setOver(true);
  }

  function tileColor(v: number) {
    if (v===0) return "#1e293b";
    const colors: Record<number,string> = { 2:"#eee4da",4:"#ede0c8",8:"#f2b179",16:"#f59563",32:"#f67c5f",64:"#f65e3b",128:"#edcf72",256:"#edcc61",512:"#edc850",1024:"#edc53f",2048:"#edc22e" };
    return colors[v] ?? "#3c3a32";
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key==="ArrowUp") { e.preventDefault(); move("up"); }
      if (e.key==="ArrowDown") { e.preventDefault(); move("down"); }
      if (e.key==="ArrowLeft") { e.preventDefault(); move("left"); }
      if (e.key==="ArrowRight") { e.preventDefault(); move("right"); }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [board, over]);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex gap-3">
        <div className="px-4 py-2 rounded-xl bg-slate-800 text-center">
          <p className="text-[10px] text-slate-500 uppercase">Ball</p>
          <p className="font-black text-base text-white">{score}</p>
        </div>
        <div className="px-4 py-2 rounded-xl bg-slate-800 text-center">
          <p className="text-[10px] text-slate-500 uppercase">Rekord</p>
          <p className="font-black text-base" style={{color:accentColor}}>{best}</p>
        </div>
        <button onClick={() => { setBoard(initBoard2048()); setScore(0); setOver(false); setWon(false); }}
          className="px-4 py-2 rounded-xl bg-slate-700 text-white text-sm font-bold hover:bg-slate-600 transition">Yangi</button>
      </div>

      {(over||won) && (
        <div className="p-3 rounded-xl text-center" style={{ background: won?"#16a34a22":"#dc262622", border:`1px solid ${won?"#16a34a":"#dc2626"}` }}>
          <p className="font-black text-lg" style={{ color: won?"#4ade80":"#f87171" }}>{won?"🏆 2048 ga yetdingiz!":"😵 O'yin tugadi!"}</p>
        </div>
      )}

      <div className="rounded-2xl p-2 bg-[#bbada0] touch-none"
        style={{ display:"grid", gridTemplateColumns:`repeat(${SIZE},1fr)`, gap:6 }}
        onTouchStart={e => { const t=e.touches[0]; touchStart.current={x:t.clientX,y:t.clientY}; }}
        onTouchEnd={e => {
          if (!touchStart.current) return;
          const t=e.changedTouches[0];
          const dx=t.clientX-touchStart.current.x, dy=t.clientY-touchStart.current.y;
          if (Math.abs(dx)>Math.abs(dy)) move(dx>0?"right":"left");
          else move(dy>0?"down":"up");
          touchStart.current=null;
        }}>
        {board.map((row,r)=>row.map((v,c)=>(
          <div key={`${r},${c}`} className="w-16 h-16 rounded-xl flex items-center justify-center font-black transition-all"
            style={{ background:tileColor(v), color:v<=4?"#776e65":"#f9fafb", fontSize: v>=1000?"13px":v>=100?"16px":"20px" }}>
            {v||""}
          </div>
        )))}
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div /><button onClick={()=>move("up")} className="p-3 rounded-xl bg-slate-800 text-xl font-black text-white hover:bg-slate-700 transition">⬆</button><div/>
        <button onClick={()=>move("left")} className="p-3 rounded-xl bg-slate-800 text-xl font-black text-white hover:bg-slate-700 transition">⬅</button>
        <button onClick={()=>move("down")} className="p-3 rounded-xl bg-slate-800 text-xl font-black text-white hover:bg-slate-700 transition">⬇</button>
        <button onClick={()=>move("right")} className="p-3 rounded-xl bg-slate-800 text-xl font-black text-white hover:bg-slate-700 transition">➡</button>
      </div>
      <p className="text-[10px] text-slate-600">Ok tugmalari yoki slayd ishlaydi</p>
    </div>
  );
}

/* ═══════════════════════ BATTLESHIP ═══════════════════════ */
const BS_SIZE = 10;
type BSCell = "empty"|"ship"|"hit"|"miss"|"sunk";
const BS_SHIPS = [
  { name:"Avianosets", size:5 },
  { name:"Kreyser",    size:4 },
  { name:"Esminets",   size:3 },
  { name:"Podlodka",   size:3 },
  { name:"Kater",      size:2 },
];

function bsEmptyGrid(): BSCell[][] { return Array.from({length:BS_SIZE},()=>Array(BS_SIZE).fill("empty")); }

function bsPlaceShips(): { grid: BSCell[][], ships: {r:number,c:number}[][] } {
  const grid = bsEmptyGrid();
  const ships: {r:number,c:number}[][] = [];
  for (const s of BS_SHIPS) {
    let placed = false, attempts = 0;
    while (!placed && attempts<500) {
      attempts++;
      const horiz = Math.random()<0.5;
      const r = Math.floor(Math.random()*(BS_SIZE-(horiz?0:s.size)));
      const c = Math.floor(Math.random()*(BS_SIZE-(horiz?s.size:0)));
      const cells: {r:number,c:number}[] = [];
      let ok = true;
      for (let k=0;k<s.size;k++) {
        const nr=r+(horiz?0:k), nc=c+(horiz?k:0);
        if (nr>=BS_SIZE||nc>=BS_SIZE||grid[nr][nc]!=="empty") { ok=false; break; }
        cells.push({r:nr,c:nc});
      }
      if (ok) { cells.forEach(({r,c})=>{ grid[r][c]="ship"; }); ships.push(cells); placed=true; }
    }
  }
  return { grid, ships };
}

function BattleshipGame({ accentColor }: { accentColor: string }) {
  const [phase, setPhase] = useState<"menu"|"game"|"over">("menu");
  const [playerGrid, setPlayerGrid] = useState<BSCell[][]>(bsEmptyGrid());
  const [enemyGrid, setEnemyGrid] = useState<BSCell[][]>(bsEmptyGrid());
  const [playerShips, setPlayerShips] = useState<{r:number,c:number}[][]>([]);
  const [enemyShips, setEnemyShips] = useState<{r:number,c:number}[][]>([]);
  const [playerTurn, setPlayerTurn] = useState(true);
  const [aiThinking, setAiThinking] = useState(false);
  const [message, setMessage] = useState("");
  const [pHits, setPHits] = useState(0);
  const [eHits, setEHits] = useState(0);
  const aiShotSet = useRef<Set<string>>(new Set());
  const aiHits = useRef<[number,number][]>([]);

  function startGame() {
    const p = bsPlaceShips();
    const e = bsPlaceShips();
    setPlayerGrid(p.grid.map(row=>row.map(v=>v==="ship"?"ship":"empty" as BSCell)));
    setEnemyGrid(e.grid.map(row=>row.map(v=>v==="ship"?"ship":"empty" as BSCell)));
    setPlayerShips(p.ships);
    setEnemyShips(e.ships);
    setPlayerTurn(true); setAiThinking(false);
    setPHits(0); setEHits(0);
    aiShotSet.current = new Set();
    aiHits.current = [];
    setMessage("🎯 Raqib kemalarini toping!");
    setPhase("game");
  }

  function checkSunk(grid: BSCell[][], ships: {r:number,c:number}[][]): BSCell[][] {
    const ng = grid.map(r=>[...r]) as BSCell[][];
    for (const ship of ships) {
      const allHit = ship.every(({r,c})=>ng[r][c]==="hit"||ng[r][c]==="sunk");
      if (allHit) ship.forEach(({r,c})=>{ ng[r][c]="sunk"; });
    }
    return ng;
  }

  function playerShoot(r: number, c: number) {
    if (!playerTurn || aiThinking || phase!=="game") return;
    const cell = enemyGrid[r][c];
    if (cell==="hit"||cell==="miss"||cell==="sunk") return;
    const ng = enemyGrid.map(row=>[...row]) as BSCell[][];
    const hit = ng[r][c]==="ship";
    ng[r][c] = hit?"hit":"miss";
    const ng2 = checkSunk(ng, enemyShips);
    setEnemyGrid(ng2);
    const hits = ng2.flat().filter(c=>c==="hit"||c==="sunk").length;
    setPHits(hits);
    const total = BS_SHIPS.reduce((s,sh)=>s+sh.size,0);
    if (hits>=total || ng2.every(row=>row.every(v=>v!=="ship"))) {
      setMessage("🏆 Siz yutdingiz! Barcha kemalar cho'ktirildi!"); setPhase("over"); return;
    }
    setMessage(hit?"💥 Tegdi! Yana o'q uzish mumkin...":"💧 O'tkazib yubordingiz. Raqib navbati.");
    if (!hit) { setPlayerTurn(false); setAiThinking(true); setTimeout(aiMove,800); }
  }

  function aiMove() {
    let r: number, c: number;
    if (aiHits.current.length > 0) {
      const [lr, lc] = aiHits.current[aiHits.current.length-1];
      const dirs = [[-1,0],[1,0],[0,-1],[0,1]];
      let found = false;
      for (const [dr,dc] of dirs) {
        const nr=lr+dr, nc=lc+dc;
        if (nr>=0&&nr<BS_SIZE&&nc>=0&&nc<BS_SIZE&&!aiShotSet.current.has(`${nr},${nc}`)) {
          r=nr; c=nc; found=true; break;
        }
      }
      if (!found) { aiHits.current=[]; r=Math.floor(Math.random()*BS_SIZE); c=Math.floor(Math.random()*BS_SIZE); while(aiShotSet.current.has(`${r},${c}`)){r=Math.floor(Math.random()*BS_SIZE);c=Math.floor(Math.random()*BS_SIZE);} }
    } else {
      r=Math.floor(Math.random()*BS_SIZE); c=Math.floor(Math.random()*BS_SIZE);
      while(aiShotSet.current.has(`${r!},${c!}`)){ r=Math.floor(Math.random()*BS_SIZE); c=Math.floor(Math.random()*BS_SIZE); }
    }
    aiShotSet.current.add(`${r!},${c!}`);
    const ng = playerGrid.map(row=>[...row]) as BSCell[][];
    const hit = ng[r!][c!]==="ship";
    ng[r!][c!] = hit?"hit":"miss";
    if (hit) aiHits.current.push([r!,c!]);
    else if (!hit && aiHits.current.length>0) aiHits.current=[];
    const ng2 = checkSunk(ng, playerShips);
    setPlayerGrid(ng2);
    const hits = ng2.flat().filter(v=>v==="hit"||v==="sunk").length;
    setEHits(hits);
    const total = BS_SHIPS.reduce((s,sh)=>s+sh.size,0);
    if (hits>=total || ng2.every(row=>row.every(v=>v!=="ship"))) {
      setMessage("💀 AI yutdi! Kemalaringiz cho'ktirildi."); setPhase("over"); setAiThinking(false); return;
    }
    setMessage(hit?"🔴 AI kemangizga tegdi!":"AI o'tkazdi. Sizning navbatingiz!");
    setPlayerTurn(true); setAiThinking(false);
  }

  function BSGrid({ grid, isEnemy, onClick }: { grid: BSCell[][], isEnemy: boolean, onClick?: (r:number,c:number)=>void }) {
    const CELL = 26;
    return (
      <div style={{ display:"grid", gridTemplateColumns:`repeat(${BS_SIZE},${CELL}px)`, gap:2 }}>
        {grid.map((row,r)=>row.map((cell,c)=>(
          <button key={`${r},${c}`} onClick={()=>onClick?.(r,c)} disabled={!onClick}
            className="rounded-sm transition-all flex items-center justify-center"
            style={{
              width:CELL, height:CELL,
              background: cell==="hit"?"#ef4444": cell==="sunk"?"#7f1d1d": cell==="miss"?"#1e3a5f": cell==="ship"&&!isEnemy?`${accentColor}55`: "#0f172a",
              border:"1px solid #1e293b",
              cursor:isEnemy&&onClick?"crosshair":"default",
              boxShadow:cell==="hit"?"0 0 5px #ef4444":cell==="sunk"?"0 0 7px #7f1d1d":"",
            }}>
            {cell==="hit"&&<span style={{fontSize:10}}>💥</span>}
            {cell==="miss"&&<span style={{fontSize:10,color:"#475569"}}>·</span>}
            {cell==="sunk"&&<span style={{fontSize:10}}>☠</span>}
          </button>
        )))}
      </div>
    );
  }

  const total = BS_SHIPS.reduce((s,sh)=>s+sh.size,0);

  if (phase==="menu") return (
    <div className="flex flex-col items-center gap-5 pt-4">
      <div className="text-6xl">⚓</div>
      <p className="text-xl font-black text-white">Dengiz Jangi</p>
      <p className="text-sm text-slate-400 text-center max-w-xs">10×10 dengizda kemalarni joylashtiring va raqibni toping. Kemalar avtomatik joylashtiriladi.</p>
      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 max-w-xs space-y-1">
        {BS_SHIPS.map(s=><div key={s.name}>{"■".repeat(s.size)} — {s.name} ({s.size} katak)</div>)}
      </div>
      <button onClick={startGame} className="w-full max-w-xs py-4 rounded-2xl font-black text-base flex items-center justify-center gap-3"
        style={{ background: `linear-gradient(135deg, ${accentColor}, #0891b2)`, color: "#000" }}>
        🤖 AI Bot bilan boshlash
      </button>
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex gap-3 text-xs">
        <div className="px-3 py-1.5 rounded-xl bg-slate-800 text-center">
          <p className="text-slate-500">Siz: {pHits}/{total}</p>
        </div>
        <div className="flex-1 p-2 rounded-xl bg-slate-900 border border-slate-800 text-center">
          <p className="text-slate-300 font-semibold">{message}</p>
          {aiThinking&&<p className="text-slate-500 animate-pulse text-[10px]">AI o'ylayapti...</p>}
        </div>
        <div className="px-3 py-1.5 rounded-xl bg-slate-800 text-center">
          <p className="text-slate-500">AI: {eHits}/{total}</p>
        </div>
      </div>

      <div className="overflow-x-auto flex flex-col gap-4 items-center">
        <div>
          <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1 text-center">🎯 Raqib dengizi</p>
          <BSGrid grid={enemyGrid} isEnemy={true} onClick={playerTurn?playerShoot:undefined} />
        </div>
        <div>
          <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1 text-center">🛳️ Sizning dengizingiz</p>
          <BSGrid grid={playerGrid} isEnemy={false} />
        </div>
      </div>

      {phase==="over" && (
        <button onClick={()=>setPhase("menu")} className="px-6 py-3 rounded-2xl font-black text-sm"
          style={{ background: accentColor, color: "#000" }}>← Qayta o'ynash</button>
      )}
    </div>
  );
}

/* ═══════════════════════ MAIN SECTION ═══════════════════════ */
export default function GamesSection({ username, accentColor }: Props) {
  const [activeGame, setActiveGame] = useState<GameId | null>(null);

  if (activeGame === "mafia") {
    return <MafiaGame username={username} accentColor={accentColor} onBack={() => setActiveGame(null)} />;
  }

  if (activeGame) {
    const game = GAMES.find(g => g.id === activeGame)!;
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3.5 border-b border-slate-800/40 flex items-center gap-3" style={{background:"rgba(5,8,18,0.97)", backdropFilter:"blur(24px)", boxShadow:"0 1px 0 rgba(255,255,255,0.04)"}}>
          <button onClick={() => setActiveGame(null)} className="text-slate-400 hover:text-white p-1.5 text-lg">←</button>
          <span className="text-xl">{game.icon}</span>
          <p className="font-bold text-sm text-white">{game.name}</p>
          {game.isNew && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full" style={{background:`${accentColor}30`,color:accentColor}}>NEW</span>}
        </header>
        <div className="flex-1 overflow-y-auto flex items-start justify-center p-4 sm:p-6">
          <div className="w-full max-w-lg">
            {activeGame === "connect4"   && <ConnectFour accentColor={accentColor} />}
            {activeGame === "g2048"      && <Game2048 accentColor={accentColor} />}
            {activeGame === "battleship" && <BattleshipGame accentColor={accentColor} />}
            {activeGame === "tictactoe" && <TicTacToe accentColor={accentColor} />}
            {activeGame === "rps"       && <RockPaperScissors accentColor={accentColor} />}
            {activeGame === "memory"    && <MemoryGame accentColor={accentColor} />}
            {activeGame === "numguess"  && <NumberGuess accentColor={accentColor} />}
            {activeGame === "wordle"    && <WordleGame accentColor={accentColor} />}
            {activeGame === "hangman"   && <HangmanGame accentColor={accentColor} />}
            {activeGame === "dice"      && <DiceGame accentColor={accentColor} />}
            {activeGame === "reflex"    && <ReflexGame accentColor={accentColor} />}
            {activeGame === "snake"     && <SnakeGame accentColor={accentColor} />}
            {activeGame === "math"      && <MathGame accentColor={accentColor} />}
            {activeGame === "gta3d"     && <GTA3DGame accentColor={accentColor} />}
          </div>
        </div>
      </div>
    );
  }

  const newGames = GAMES.filter(g => g.isNew);
  const oldGames = GAMES.filter(g => !g.isNew);

  return (
    <div className="flex-1 overflow-y-auto bg-[#030712]">
      {/* Header */}
      <div
        className="sticky top-0 z-10 flex items-center justify-between px-4 py-4 border-b border-slate-800/40 overflow-hidden"
        style={{ background: "rgba(8,12,25,0.98)", backdropFilter: "blur(24px)" }}
      >
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg,transparent,${accentColor}55,#9333ea55,transparent)` }} />
          <div className="absolute bottom-0 left-20 w-32 h-12 rounded-full blur-2xl opacity-10" style={{ background: `linear-gradient(90deg,${accentColor},#9333ea)` }} />
        </div>
        <div className="flex items-center gap-3 relative">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl"
            style={{ background: `linear-gradient(135deg, ${accentColor}cc, #9333eacc)`, boxShadow: `0 0 20px ${accentColor}40` }}
          >
            🎮
          </div>
          <div>
            <h2 className="text-sm font-black text-white tracking-tight">O'yinlar</h2>
            <p className="text-[10px] text-slate-500">{GAMES.length} ta o'yin mavjud</p>
          </div>
        </div>
      </div>

      {/* NEW games — featured cards */}
      <div className="px-3 pt-3 pb-1">
        <div className="flex items-center gap-2 mb-3 px-1">
          <div
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black"
            style={{ background: `${accentColor}20`, color: accentColor, border: `1px solid ${accentColor}30` }}
          >
            ✨ YANGI
          </div>
          <span className="text-[10px] text-slate-600">Multiplayer + AI Bot</span>
        </div>
        <div className="space-y-2.5">
          {newGames.map(g => {
            const gColor = accentColor;
            return (
              <button
                key={g.id}
                onClick={() => setActiveGame(g.id)}
                className="w-full text-left transition-all duration-200 active:scale-[0.98] group"
              >
                <div
                  className="relative rounded-2xl overflow-hidden p-4"
                  style={{ background: g.bg, border: `1px solid ${gColor}25` }}
                >
                  {/* Gradient top accent */}
                  <div
                    className="absolute top-0 left-0 right-0 h-0.5"
                    style={{ background: `linear-gradient(90deg, ${gColor}, #9333ea)` }}
                  />
                  <div className="flex items-start gap-4">
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0"
                      style={{ background: `${gColor}12`, border: `1px solid ${gColor}25` }}
                    >
                      {g.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-black text-white text-sm">{g.name}</span>
                        <span
                          className="text-[9px] font-black px-1.5 py-0.5 rounded-full"
                          style={{ background: `${gColor}30`, color: gColor }}
                        >
                          NEW
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-tight mb-2">{g.desc}</p>
                      <div className="flex items-center gap-2">
                        <span
                          className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                          style={{ background: `${gColor}15`, color: gColor }}
                        >
                          👥 {g.players}
                        </span>
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-500">
                          🤖 AI Bot
                        </span>
                      </div>
                    </div>
                    <div
                      className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform"
                      style={{ background: `${gColor}15`, border: `1px solid ${gColor}30` }}
                    >
                      <span className="text-slate-400 group-hover:text-white transition-colors text-lg">›</span>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Classic games — 2-column grid */}
      <div className="px-3 pt-3 pb-6">
        <div className="flex items-center gap-2 mb-3 px-1">
          <div className="flex-1 h-px bg-slate-800" />
          <span className="text-[10px] text-slate-600 uppercase tracking-widest font-bold px-2">Klassik o'yinlar</span>
          <div className="flex-1 h-px bg-slate-800" />
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          {oldGames.map(g => (
            <button
              key={g.id}
              onClick={() => setActiveGame(g.id)}
              className="p-4 rounded-2xl text-left transition-all duration-200 active:scale-[0.97] group relative overflow-hidden"
              style={{ background: g.bg, border: "1px solid rgba(255,255,255,0.06)" }}
            >
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                style={{ background: "rgba(255,255,255,0.02)" }} />
              <div className="text-3xl mb-2.5">{g.icon}</div>
              <p className="font-black text-white text-sm leading-tight mb-1">{g.name}</p>
              <p className="text-[10px] text-slate-500 leading-tight mb-2.5">{g.desc}</p>
              <span
                className="text-[9px] font-bold px-2 py-0.5 rounded-full inline-block"
                style={{ background: `${accentColor}15`, color: accentColor }}
              >
                {g.players}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
