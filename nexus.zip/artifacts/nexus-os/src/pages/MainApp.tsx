import React, { useEffect, useState, useRef, useCallback } from "react";
import { ref, set, get, onValue, onChildAdded, onChildChanged, serverTimestamp, push, update, remove } from "firebase/database";
import { db } from "../firebase";
import { useLang } from "../lib/LangContext";
import {
  MessageSquare, Newspaper, Users, Radio, Phone, Gamepad2,
  BookOpen, Settings, ShieldAlert, Menu, Star, Pin, PinOff,
  LogOut, Bot, ChevronRight, Activity, Wallet, Music2, BarChart2, CheckSquare,
  Search, UserCircle2, Bookmark, Lock, Zap
} from "lucide-react";
import ChatSection from "./ChatSection";
import StarShop from "../components/StarShop";
import AdminPanel from "./AdminPanel";
import StatusSection from "./StatusSection";
import WalletSection from "./WalletSection";
import MusicSection from "./MusicSection";
import PollsSection from "./PollsSection";
import TodoSection from "./TodoSection";
import MyProfile from "./MyProfile";
import SavedSection from "./SavedSection";
import GlobalSearch from "../components/GlobalSearch";
import NotificationCenter from "../components/NotificationCenter";
import ShashkaGame from "./ShashkaGame";
import BlackjackGame from "./BlackjackGame";
import GamesSection from "./GamesSection";
import KundalikSection from "./KundalikSection";
import SettingsSection from "./SettingsSection";
import CallsSection from "./CallsSection";
import VideoCallOverlay from "./VideoCallOverlay";
import IncomingCallModal from "../components/IncomingCallModal";
import ContactsSection from "./ContactsSection";
import ChannelsSection from "./ChannelsSection";
import ChannelView from "./ChannelView";
import UserProfileModal from "../components/UserProfileModal";
import FeedSection from "./FeedSection";
import ChatsList from "../components/ChatsList";
import AnimatedBackground from "../components/AnimatedBackground";
import SecretChatSection from "./SecretChatSection";
import AnalyticsSection from "./AnalyticsSection";
import AiAssistantSection from "./AiAssistantSection";
import MarketplaceSection from "./MarketplaceSection";
import VoiceRoomsSection from "./VoiceRoomsSection";
import WeatherSection from "./WeatherSection";
import CryptoSection from "./CryptoSection";
import FlashcardSection from "./FlashcardSection";
import HomeDashboard from "./HomeDashboard";
import LeaderboardSection from "./LeaderboardSection";
import QrSection from "./QrSection";
import FriendsSection from "./FriendsSection";
import EventsSection from "./EventsSection";
import ClubsSection from "./ClubsSection";
import ActivityFeedSection from "./ActivityFeedSection";
import StoriesSection from "./StoriesSection";
import {
  startRingTone, startRingbackTone, playConnectingSound,
  playHangupSound, playConnectedSound, stopAllSounds
} from "../sounds";

interface OnlineUser { key: string; state: string; typingTo?: string; }
interface Group { id: string; name: string; type: string; createdBy: string; isOfficialMax?: boolean; }
type Tab = "home" | "chats" | "feed" | "calls" | "contacts" | "channels" | "settings" | "admin" | "shashka" | "blackjack" | "games" | "kundalik" | "status" | "wallet" | "music" | "polls" | "todo" | "profile" | "saved" | "secretchat" | "analytics" | "ai" | "market" | "voicerooms" | "weather" | "crypto" | "flashcard" | "leaderboard" | "qr" | "friends" | "events" | "clubs" | "activity" | "stories";
interface MainAppProps { username: string; onLogout: () => void; }

// ICE config: Google STUN + free OpenRelay TURN (Metered) so calls work
// across NAT/firewalls (different countries, mobile networks, corporate WiFi).
const STUN: RTCConfiguration = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:stun2.l.google.com:19302" },
    { urls: "stun:global.stun.twilio.com:3478" },
    // Free public TURN — relays media when direct P2P fails (Russia↔Uzbekistan etc.)
    { urls: "turn:openrelay.metered.ca:80", username: "openrelayproject", credential: "openrelayproject" },
    { urls: "turn:openrelay.metered.ca:443", username: "openrelayproject", credential: "openrelayproject" },
    { urls: "turn:openrelay.metered.ca:443?transport=tcp", username: "openrelayproject", credential: "openrelayproject" },
    { urls: "turns:openrelay.metered.ca:443?transport=tcp", username: "openrelayproject", credential: "openrelayproject" },
  ],
  iceCandidatePoolSize: 10,
};

const AUDIO_CONSTRAINTS: MediaTrackConstraints = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
  sampleRate: 48000,
  channelCount: 1,
};
const VIDEO_CONSTRAINTS: MediaTrackConstraints = {
  width: { ideal: 1280, max: 1920 },
  height: { ideal: 720, max: 1080 },
  frameRate: { ideal: 30, max: 30 },
  facingMode: "user",
};

export default function MainApp({ username, onLogout }: MainAppProps) {
  const { t } = useLang();
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth >= 768);
  const [navExpanded, setNavExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [allUsers, setAllUsers] = useState<string[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [selectedIsGroup, setSelectedIsGroup] = useState(false);
  const [selectedGroupMeta, setSelectedGroupMeta] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [accentColor, setAccentColor] = useState(localStorage.getItem("nexus_theme") || "#22d3ee");
  const [unreadMap, setUnreadMap] = useState<Record<string, number>>({});
  const [lastMessageMap, setLastMessageMap] = useState<Record<string, { text: string; ts: number; fromMe: boolean; type: string; deleted?: boolean; edited?: boolean }>>({});
  const [backupPeers, setBackupPeers] = useState<Set<string>>(new Set());

  // Call state
  const [incomingCall, setIncomingCall] = useState<{ caller: string; callType: "audio" | "video"; offer: any } | null>(null);
  const [activeCall, setActiveCall] = useState<{ peer: string; type: "audio" | "video" } | null>(null);
  const [callStatus, setCallStatus] = useState<"idle" | "calling" | "connecting" | "in-call">("idle");
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [userSearch, setUserSearch] = useState("");
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [announcement, setAnnouncement] = useState<string | null>(null);
  const [premiumData, setPremiumData] = useState<any>(null);

  const [showSearch, setShowSearch] = useState(false);
  const [selectedChannelId, setSelectedChannelId] = useState<string | null>(null);
  const [profileModalUser, setProfileModalUser] = useState<string | null>(null);
  const [starsBalance, setStarsBalance] = useState(0);
  const [showStarShop, setShowStarShop] = useState(false);
  const [pinnedChats, setPinnedChats] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(`nexus_pinned_${username}`) || "[]"); } catch { return []; }
  });

  function togglePinChat(peer: string, e: React.MouseEvent) {
    e.stopPropagation();
    const key = `nexus_pinned_${username}`;
    const next = pinnedChats.includes(peer)
      ? pinnedChats.filter(p => p !== peer)
      : [peer, ...pinnedChats];
    setPinnedChats(next);
    localStorage.setItem(key, JSON.stringify(next));
  }

  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const callDurationRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const callStatusRef = useRef<string>("idle");
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);

  // Keep callStatusRef in sync
  useEffect(() => { callStatusRef.current = callStatus; }, [callStatus]);

  useEffect(() => {
    const handleResize = () => setSidebarOpen(window.innerWidth >= 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Deep link handler: nexus-navigate events from QR codes / link clicks
  useEffect(() => {
    function handleNexusNav(e: Event) {
      const detail = (e as CustomEvent).detail;
      if (!detail) return;
      if (detail.type === "channel" && detail.channelId) {
        setActiveTab("channels");
        setSelectedChannelId(detail.channelId);
        if (window.innerWidth < 768) setSidebarOpen(false);
      } else if (detail.type === "user" && detail.username) {
        setProfileModalUser(detail.username);
      }
    }
    window.addEventListener("nexus-navigate", handleNexusNav);
    return () => window.removeEventListener("nexus-navigate", handleNexusNav);
  }, []);

  // Online status
  useEffect(() => {
    const statusRef = ref(db, `status/${username}`);
    set(statusRef, { state: "online", lastSeen: serverTimestamp(), typingTo: "none" });
    const cleanup = () => set(statusRef, { state: "offline", lastSeen: serverTimestamp(), typingTo: "none" });
    window.addEventListener("beforeunload", cleanup);
    return () => { window.removeEventListener("beforeunload", cleanup); cleanup(); };
  }, [username]);

  useEffect(() => {
    get(ref(db, `admins/${username}`)).then(snap => setIsAdmin(snap.exists() && snap.val() === true));
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, `premium/${username}`), snap => setPremiumData(snap.val()));
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, `stars/${username}`), snap => {
      setStarsBalance(snap.val()?.balance || 0);
    });
  }, [username]);

  useEffect(() => {
    document.documentElement.style.setProperty("--theme-accent", accentColor);
  }, [accentColor]);

  useEffect(() => {
    return onValue(ref(db, "status"), snap => {
      if (!snap.exists()) { setOnlineUsers([]); return; }
      const users: OnlineUser[] = [];
      snap.forEach(child => {
        if (child.key !== username) {
          const d = child.val();
          users.push({ key: child.key!, state: d?.state || "offline", typingTo: d?.typingTo });
        }
      });
      setOnlineUsers(users);
    });
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, "users"), snap => {
      if (!snap.exists()) return;
      const list: string[] = [];
      snap.forEach(c => { if (c.key !== username) list.push(c.key!); });
      setAllUsers(list);
    });
  }, [username]);

  useEffect(() => {
    return onValue(ref(db, "groups"), snap => {
      if (!snap.exists()) { setGroups([]); return; }
      const gs: Group[] = [];
      snap.forEach(c => {
        const d = c.val();
        gs.push({ id: c.key!, name: d.name, type: d.type || "group", createdBy: d.createdBy, isOfficialMax: d.isOfficialMax });
      });
      setGroups(gs);
    });
  }, []);

  // Unread + last message tracking per DM peer
  useEffect(() => {
    const unsubs: (() => void)[] = [];
    allUsers.forEach(peer => {
      const chatId = [username, peer].sort().join("_");
      const addUnsub = onChildAdded(ref(db, `messages/${chatId}`), snap => {
        const d = snap.val();
        if (!d) return;
        const fromMe = d.sender === username;
        if (!fromMe && d?.status === "sent" && selectedTarget !== peer) {
          setUnreadMap(prev => ({ ...prev, [peer]: (prev[peer] || 0) + 1 }));
        }
        const preview = d.type === "image" ? "📷 Rasm" : d.type === "voice" ? "🎙 Ovozli xabar" : (d.text || "");
        setLastMessageMap(prev => {
          const cur = prev[peer];
          const ts = typeof d.timestamp === "number" ? d.timestamp : Date.now();
          if (cur && cur.ts > ts) return prev;
          return { ...prev, [peer]: { text: String(preview).slice(0, 80), ts, fromMe, type: d.type || "text", deleted: !!d.deleted, edited: !!d.edited } };
        });
      });
      const changeUnsub = onChildChanged(ref(db, `messages/${chatId}`), snap => {
        const d = snap.val();
        if (!d) return;
        const fromMe = d.sender === username;
        const ts = typeof d.timestamp === "number" ? d.timestamp : 0;
        setLastMessageMap(prev => {
          const cur = prev[peer];
          if (!cur || (ts && cur.ts !== ts)) return prev;
          const preview = d.type === "image" ? "📷 Rasm" : d.type === "voice" ? "🎙 Ovozli xabar" : (d.text || "");
          return { ...prev, [peer]: { text: String(preview).slice(0, 80), ts: cur.ts, fromMe, type: d.type || "text", deleted: !!d.deleted, edited: !!d.edited } };
        });
      });
      unsubs.push(addUnsub, changeUnsub);
    });
    return () => unsubs.forEach(f => f());
  }, [allUsers, username, selectedTarget]);

  // Track chat backups
  useEffect(() => {
    if (!username) return;
    const unsubBackup = onValue(ref(db, "chat_backup"), snap => {
      if (!snap.exists()) { setBackupPeers(new Set()); return; }
      const peers = new Set<string>();
      snap.forEach(c => { peers.add(c.key!); });
      setBackupPeers(peers);
    });
    return () => unsubBackup();
  }, [username]);

  // ==================== CALL SYSTEM ====================

  const cleanupCall = useCallback((peer?: string) => {
    stopAllSounds();
    clearInterval(callDurationRef.current);
    localStreamRef.current?.getTracks().forEach(t => t.stop());
    peerConnectionRef.current?.close();
    localStreamRef.current = null;
    peerConnectionRef.current = null;
    pendingCandidatesRef.current = [];
    setRemoteStream(null);
    setCallDuration(0);
    setCallStatus("idle");
    setActiveCall(null);
    setIncomingCall(null);
    setIsMuted(false);
    setIsCameraOff(false);
    callStatusRef.current = "idle";
  }, []);

  // Helper: add ICE candidate or buffer if remote description not set yet
  const addOrQueueIce = useCallback(async (pc: RTCPeerConnection, cand: RTCIceCandidateInit) => {
    try {
      if (pc.remoteDescription && pc.remoteDescription.type) {
        await pc.addIceCandidate(new RTCIceCandidate(cand));
      } else {
        pendingCandidatesRef.current.push(cand);
      }
    } catch (e) { console.warn("ICE add failed", e); }
  }, []);

  const flushPendingIce = useCallback(async (pc: RTCPeerConnection) => {
    while (pendingCandidatesRef.current.length > 0) {
      const c = pendingCandidatesRef.current.shift()!;
      try { await pc.addIceCandidate(new RTCIceCandidate(c)); } catch (e) { console.warn("flush ice", e); }
    }
  }, []);

  // INCOMING CALL LISTENER
  useEffect(() => {
    const unsub = onValue(ref(db, `calls/${username}/incoming`), snap => {
      if (!snap.exists()) {
        // Call was cancelled by caller
        if (callStatusRef.current === "idle" && incomingCall) {
          setIncomingCall(null);
          stopAllSounds();
        }
        return;
      }
      const data = snap.val();
      if (data?.status === "ringing" && callStatusRef.current === "idle") {
        setIncomingCall({ caller: data.caller, callType: data.callType || "audio", offer: data.offer });
        startRingTone();
      }
    });
    return () => unsub();
  }, [username]);

  // HANGUP LISTENER — when peer hangs up
  useEffect(() => {
    const unsub = onValue(ref(db, `calls/${username}/hangup`), snap => {
      if (snap.exists() && (callStatusRef.current === "in-call" || callStatusRef.current === "calling" || callStatusRef.current === "connecting")) {
        const peer = activeCall?.peer;
        remove(ref(db, `calls/${username}/hangup`));
        playHangupSound();
        cleanupCall(peer || undefined);
      }
    });
    return () => unsub();
  }, [username, activeCall, cleanupCall]);

  // REJECTED LISTENER — callee rejected
  useEffect(() => {
    const unsub = onValue(ref(db, `calls/${username}/rejected`), snap => {
      if (snap.exists() && callStatusRef.current === "calling") {
        remove(ref(db, `calls/${username}/rejected`));
        playHangupSound();
        cleanupCall();
      }
    });
    return () => unsub();
  }, [username, cleanupCall]);

  // START CALL (caller side)
  async function startCall(peer: string, type: "audio" | "video" = "audio") {
    if (callStatusRef.current !== "idle") return;
    setCallStatus("calling");
    setActiveCall({ peer, type });
    callStatusRef.current = "calling";
    startRingbackTone(); // caller hears ringback

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS, video: type === "video" ? VIDEO_CONSTRAINTS : false });
      localStreamRef.current = stream;

      const pc = new RTCPeerConnection(STUN);
      peerConnectionRef.current = pc;
      (window as any).__nexus_pc = pc;
      stream.getTracks().forEach(t => pc.addTrack(t, stream));

      const remoteS = new MediaStream();
      setRemoteStream(remoteS);
      pc.ontrack = e => { e.streams[0].getTracks().forEach(t => remoteS.addTrack(t)); };

      pc.onicecandidate = e => {
        if (e.candidate) push(ref(db, `calls/${peer}/ice_from_caller`), e.candidate.toJSON());
      };

      const onConnected = () => {
        if (callStatusRef.current === "in-call") return;
        setCallStatus("in-call");
        callStatusRef.current = "in-call";
        stopAllSounds();
        playConnectedSound();
        callDurationRef.current = setInterval(() => setCallDuration(d => d + 1), 1000);
      };
      pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected") onConnected();
        else if (pc.connectionState === "failed" || pc.connectionState === "disconnected") endCall();
      };
      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === "connected" || pc.iceConnectionState === "completed") onConnected();
        else if (pc.iceConnectionState === "failed") { try { pc.restartIce(); } catch {} }
      };

      const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: type === "video" });
      await pc.setLocalDescription(offer);

      await set(ref(db, `calls/${peer}/incoming`), {
        caller: username, callee: peer, status: "ringing",
        offer: { type: offer.type, sdp: offer.sdp }, callType: type, ts: Date.now()
      });

      // Watch for answer
      const answerUnsub = onValue(ref(db, `calls/${username}/answer`), async snap => {
        if (!snap.exists()) return;
        const d = snap.val();
        if (d.from === peer && pc.signalingState === "have-local-offer") {
          answerUnsub();
          stopAllSounds();
          playConnectingSound();
          setCallStatus("connecting");
          callStatusRef.current = "connecting";
          await pc.setRemoteDescription(new RTCSessionDescription(d.answer));
          await flushPendingIce(pc);
          remove(ref(db, `calls/${username}/answer`));
          // Clear caller's signaling artifacts after a delay
          setTimeout(() => { remove(ref(db, `calls/${username}/ice_from_callee`)); }, 60000);
        }
      });

      // ICE from callee — buffer until remote description set
      onChildAdded(ref(db, `calls/${username}/ice_from_callee`), snap => {
        if (snap.val()) addOrQueueIce(pc, snap.val());
      });

      // 45s timeout
      setTimeout(() => {
        if (callStatusRef.current === "calling") {
          remove(ref(db, `calls/${peer}/incoming`));
          set(ref(db, `calls/${peer}/hangup`), { by: username, ts: Date.now() });
          playHangupSound();
          cleanupCall();
        }
      }, 45000);

    } catch (err: any) {
      alert("📵 Mikrofon/Kamera ruxsati yo'q: " + err.message);
      remove(ref(db, `calls/${peer}/incoming`));
      cleanupCall();
    }
  }

  // ACCEPT CALL (callee side)
  async function acceptCall() {
    if (!incomingCall) return;
    stopAllSounds();
    playConnectingSound();

    const { caller, callType, offer } = incomingCall;
    setCallStatus("connecting");
    setActiveCall({ peer: caller, type: callType });
    setIncomingCall(null);
    callStatusRef.current = "connecting";

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS, video: callType === "video" ? VIDEO_CONSTRAINTS : false });
      localStreamRef.current = stream;

      const pc = new RTCPeerConnection(STUN);
      peerConnectionRef.current = pc;
      (window as any).__nexus_pc = pc;
      stream.getTracks().forEach(t => pc.addTrack(t, stream));

      const remoteS = new MediaStream();
      setRemoteStream(remoteS);
      pc.ontrack = e => { e.streams[0].getTracks().forEach(t => remoteS.addTrack(t)); };

      pc.onicecandidate = e => {
        if (e.candidate) push(ref(db, `calls/${caller}/ice_from_callee`), e.candidate.toJSON());
      };

      const onConnected2 = () => {
        if (callStatusRef.current === "in-call") return;
        setCallStatus("in-call");
        callStatusRef.current = "in-call";
        stopAllSounds();
        playConnectedSound();
        callDurationRef.current = setInterval(() => setCallDuration(d => d + 1), 1000);
      };
      pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected") onConnected2();
        else if (pc.connectionState === "failed" || pc.connectionState === "disconnected") endCall();
      };
      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === "connected" || pc.iceConnectionState === "completed") onConnected2();
        else if (pc.iceConnectionState === "failed") { try { pc.restartIce(); } catch {} }
      };

      await pc.setRemoteDescription(new RTCSessionDescription(offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await flushPendingIce(pc);

      await set(ref(db, `calls/${caller}/answer`), {
        from: username, answer: { type: answer.type, sdp: answer.sdp }
      });

      remove(ref(db, `calls/${username}/incoming`));

      // ICE from caller — buffer until remote description set
      onChildAdded(ref(db, `calls/${username}/ice_from_caller`), snap => {
        if (snap.val()) addOrQueueIce(pc, snap.val());
      });

    } catch (err: any) {
      alert("📵 Mikrofon/Kamera ruxsati yo'q: " + err.message);
      rejectCall();
    }
  }

  // REJECT CALL
  function rejectCall() {
    if (!incomingCall) return;
    stopAllSounds();
    const caller = incomingCall.caller;
    remove(ref(db, `calls/${username}/incoming`));
    // Notify caller
    set(ref(db, `calls/${caller}/rejected`), { by: username, ts: Date.now() });
    // Log missed call
    push(ref(db, `call_logs/${username}`), { caller, callee: username, type: "missed", timestamp: Date.now() });
    setIncomingCall(null);
  }

  // END CALL (either side)
  function endCall() {
    const peer = activeCall?.peer;
    const wasInCall = callStatusRef.current === "in-call";

    // Notify peer
    if (peer) {
      set(ref(db, `calls/${peer}/hangup`), { by: username, ts: Date.now() });
      remove(ref(db, `calls/${peer}/incoming`));
      remove(ref(db, `calls/${username}/incoming`));

      // Save call log
      push(ref(db, `call_logs/${username}`), {
        caller: username, callee: peer, type: "outgoing",
        duration: wasInCall ? `${Math.floor(callDuration / 60)}:${String(callDuration % 60).padStart(2, "0")}` : "0:00",
        timestamp: Date.now()
      });
    }

    playHangupSound();
    cleanupCall(peer || undefined);
  }

  // MUTE
  function toggleMute() {
    if (!localStreamRef.current) return;
    localStreamRef.current.getAudioTracks().forEach(t => { t.enabled = !t.enabled; });
    setIsMuted(m => !m);
  }

  // CAMERA TOGGLE
  function toggleCamera() {
    if (!localStreamRef.current) return;
    localStreamRef.current.getVideoTracks().forEach(t => { t.enabled = !t.enabled; });
    setIsCameraOff(c => !c);
  }

  // Admin directives
  useEffect(() => {
    const unsubs: (() => void)[] = [];
    unsubs.push(onValue(ref(db, "system/force_reboot"), snap => {
      if (snap.exists() && (Date.now() - snap.val() < 5000)) window.location.reload();
    }));
    unsubs.push(onValue(ref(db, "system/alarm"), snap => {
      if (snap.exists() && (Date.now() - snap.val() < 5000)) {
        document.body.style.background = "#450a0a";
        setTimeout(() => { document.body.style.background = ""; }, 3000);
      }
    }));
    unsubs.push(onValue(ref(db, "system/theme_override"), snap => {
      if (snap.exists() && snap.val() === "alert") {
        document.documentElement.style.setProperty("--theme-accent", "#ef4444");
      } else if (snap.exists()) {
        document.documentElement.style.setProperty("--theme-accent", accentColor);
      }
    }));
    unsubs.push(onValue(ref(db, "system/destruct"), snap => {
      if (snap.exists() && (Date.now() - snap.val() < 5000) && username !== "Max") {
        localStorage.clear();
        document.body.innerHTML = `<div style="display:flex;height:100vh;width:100vw;background:#000;color:#ef4444;align-items:center;justify-content:center;font-size:2.5rem;font-family:monospace;font-weight:900;text-align:center;flex-direction:column;gap:1rem">💣 FATAL_ERROR<br><span style="font-size:1rem;color:#7f1d1d">SYSTEM_DESTROYED BY ADMIN</span></div>`;
      }
    }));
    unsubs.push(onValue(ref(db, "system/maintenance"), snap => {
      if (username === "Max") return; // admin sees everything
      setMaintenanceMode(!!(snap.exists() && snap.val()));
    }));
    unsubs.push(onValue(ref(db, "system/announcement"), snap => {
      setAnnouncement(snap.exists() ? snap.val()?.text || null : null);
    }));
    unsubs.push(onValue(ref(db, `premium/${username}`), snap => {
      setPremiumData(snap.exists() ? snap.val() : null);
    }));
    unsubs.push(onValue(ref(db, `banned/${username}`), snap => {
      if (snap.exists()) { alert("🛑 Siz admin tomonidan tizimdan chiqarildingiz!"); localStorage.clear(); window.location.reload(); }
    }));
    unsubs.push(onChildAdded(ref(db, `system_pushes/${username}`), snap => {
      const d = snap.val();
      if (!d) return;
      if (d.type === "glitch" && (Date.now() - d.ts < 5000)) {
        let cnt = 0;
        const iv = setInterval(() => {
          document.body.style.transform = `rotate(${(Math.random() - 0.5) * 4}deg) translate(${(Math.random() - 0.5) * 6}px,${(Math.random() - 0.5) * 4}px)`;
          if (++cnt > 12) { clearInterval(iv); document.body.style.transform = ""; }
        }, 120);
      } else if (d.type === "msg" && (Date.now() - d.ts < 10000)) {
        alert(`⚠️ ADMIN (Max) dan xabar:\n\n${d.msg}`);
      }
    }));
    return () => unsubs.forEach(f => f());
  }, [username, accentColor]);

  function openChat(user: string, isGrp = false, grpMeta: any = null) {
    setSelectedTarget(user); setSelectedIsGroup(isGrp); setSelectedGroupMeta(grpMeta);
    setActiveTab("chats");
    if (window.innerWidth < 768) setSidebarOpen(false);
    setUnreadMap(prev => ({ ...prev, [user]: 0 }));
  }

  async function createGroup() {
    const name = prompt("Guruh nomini kiriting:");
    if (!name?.trim()) return;
    const typeChoice = prompt("Tur:\n1 - Oddiy Guruh\n2 - Kanal (faqat admin yozadi)");
    const type = typeChoice === "2" ? "channel" : "group";
    const newRef = await push(ref(db, "groups"), { name: name.trim(), type, createdBy: username, createdAt: serverTimestamp() });
    if (newRef.key) openChat(newRef.key, true, { id: newRef.key, name: name.trim(), type, createdBy: username });
  }

  function handleLogout() {
    set(ref(db, `status/${username}`), { state: "offline", lastSeen: serverTimestamp(), typingTo: "none" });
    localStorage.clear();
    onLogout();
  }

  const maxChannel = { id: "Max_official", name: "Max", isOfficialMax: true, type: "channel", createdBy: "Max" };
  const filteredUsers = userSearch.trim()
    ? allUsers.filter(u => u.toLowerCase().includes(userSearch.toLowerCase()))
    : onlineUsers.map(u => u.key);
  const onlineSet = new Set(onlineUsers.filter(u => u.state === "online").map(u => u.key));

  const isPremiumUser = !!(premiumData && premiumData.expiresAt > Date.now());

  function renderContent() {
    if (activeTab === "channels" && selectedChannelId) {
      return (
        <ChannelView
          key={selectedChannelId}
          channelId={selectedChannelId}
          username={username}
          accentColor={accentColor}
          isPremium={isPremiumUser}
          onBack={() => { setSelectedChannelId(null); if (window.innerWidth < 768) setSidebarOpen(true); }}
          onOpenProfile={(u) => setProfileModalUser(u)}
        />
      );
    }
    if (activeTab === "chats" && selectedTarget) {
      return (
        <ChatSection
          key={selectedTarget + selectedIsGroup}
          username={username}
          targetUser={selectedTarget}
          isGroup={selectedIsGroup}
          groupMeta={selectedGroupMeta}
          onBack={() => setSelectedTarget(null)}
          accentColor={accentColor}
          onStartCall={(peer) => startCall(peer)}
          onOpenProfile={(u) => setProfileModalUser(u)}
          isPremium={isPremiumUser}
        />
      );
    }
    switch (activeTab) {
      case "chats":
        return (
          <ChatsList
            username={username}
            accentColor={accentColor}
            allUsers={allUsers}
            unreadMap={unreadMap}
            lastMessageMap={lastMessageMap}
            onlineSet={onlineSet}
            onOpenChat={(u) => openChat(u)}
            backupPeers={backupPeers}
          />
        );
      case "calls":
        return <CallsSection username={username} onCall={startCall} onlineUsers={onlineUsers} />;
      case "feed":
        return <FeedSection username={username} accentColor={accentColor} isPremium={isPremiumUser} onOpenProfile={(u) => setProfileModalUser(u)} />;
      case "contacts":
        return <ContactsSection username={username} accentColor={accentColor} isPremium={isPremiumUser}
          onOpenChat={(u) => openChat(u)} onStartCall={(u, t) => startCall(u, t)} onOpenProfile={(u) => setProfileModalUser(u)} />;
      case "channels":
        return <ChannelsSection username={username} accentColor={accentColor} isPremium={isPremiumUser}
          onOpen={(id) => { setSelectedChannelId(id); if (window.innerWidth < 768) setSidebarOpen(false); }} />;
      case "settings":
        return (
          <SettingsSection
            username={username}
            accentColor={accentColor}
            onColorChange={c => { setAccentColor(c); localStorage.setItem("nexus_theme", c); }}
            onLogout={handleLogout}
          />
        );
      case "admin":
        return <AdminPanel username={username} />;
      case "shashka":
        return <ShashkaGame />;
      case "blackjack":
        return <BlackjackGame />;
      case "games":
        return <GamesSection username={username} accentColor={accentColor} />;
      case "kundalik":
        return <KundalikSection username={username} accentColor={accentColor} isPremium={isPremiumUser} />;
      case "status":
        return <StatusSection username={username} accentColor={accentColor} />;
      case "wallet":
        return <WalletSection username={username} accentColor={accentColor} starsBalance={starsBalance} />;
      case "music":
        return <MusicSection username={username} accentColor={accentColor} />;
      case "polls":
        return <PollsSection username={username} accentColor={accentColor} />;
      case "todo":
        return <TodoSection username={username} accentColor={accentColor} />;
      case "profile":
        return <MyProfile username={username} accentColor={accentColor} isPremium={isPremiumUser} starsBalance={starsBalance} onOpenChat={(p) => openChat(p)} />;
      case "saved":
        return <SavedSection username={username} accentColor={accentColor} onOpenChat={(peer, isGroup) => { openChat(peer, !!isGroup); setActiveTab("chats"); }} />;
      case "secretchat":
        return <SecretChatSection username={username} accentColor={accentColor} onBack={() => setActiveTab("chats")} />;
      case "analytics":
        return <AnalyticsSection username={username} accentColor={accentColor} starsBalance={starsBalance} />;
      case "ai":
        return <AiAssistantSection username={username} accentColor={accentColor} />;
      case "market":
        return <MarketplaceSection username={username} accentColor={accentColor} starsBalance={starsBalance} />;
      case "voicerooms":
        return <VoiceRoomsSection username={username} accentColor={accentColor} />;
      case "weather":
        return <WeatherSection accentColor={accentColor} />;
      case "crypto":
        return <CryptoSection username={username} accentColor={accentColor} starsBalance={starsBalance} />;
      case "flashcard":
        return <FlashcardSection username={username} accentColor={accentColor} />;
      case "home":
        return <HomeDashboard username={username} accentColor={accentColor} starsBalance={starsBalance} isPremium={isPremiumUser} onNavigate={(tab) => { setActiveTab(tab as Tab); setSelectedTarget(null); }} />;
      case "leaderboard":
        return <LeaderboardSection username={username} accentColor={accentColor} starsBalance={starsBalance} />;
      case "qr":
        return <QrSection username={username} accentColor={accentColor} />;
      case "friends":
        return <FriendsSection username={username} accentColor={accentColor}
          onOpenChat={(p) => { openChat(p); }}
          onStartCall={(p) => startCall(p)}
          onOpenProfile={(u) => setProfileModalUser(u)} />;
      case "events":
        return <EventsSection username={username} accentColor={accentColor}
          onOpenProfile={(u) => setProfileModalUser(u)} />;
      case "clubs":
        return <ClubsSection username={username} accentColor={accentColor}
          onOpenProfile={(u) => setProfileModalUser(u)} />;
      case "activity":
        return <ActivityFeedSection username={username} accentColor={accentColor}
          onOpenProfile={(u) => setProfileModalUser(u)}
          onNavigate={(t) => setActiveTab(t as Tab)} />;
      case "stories":
        return <StoriesSection username={username} accentColor={accentColor}
          onOpenProfile={(u) => setProfileModalUser(u)} />;
      default:
        return null;
    }
  }

  const PINNED_TABS: Tab[] = ["home", "chats", "feed", "calls"];

  const navItems: { tab: Tab; icon: React.ReactNode; label: string; danger?: boolean; badge?: string; emoji?: string }[] = [
    { tab: "home",        icon: <Activity className="w-4 h-4" />,      label: "Bosh Sahifa",    emoji: "🏠" },
    { tab: "chats",       icon: <MessageSquare className="w-4 h-4" />, label: "Chatlar",         emoji: "💬" },
    { tab: "feed",        icon: <Newspaper className="w-4 h-4" />,     label: "Lenta",           emoji: "📰" },
    { tab: "calls",       icon: <Phone className="w-4 h-4" />,         label: "Qo'ng'iroqlar",   emoji: "📞" },
    { tab: "secretchat",  icon: <Lock className="w-4 h-4" />,          label: "Maxfiy Chat",    badge: "🔒", emoji: "🔒" },
    { tab: "status",      icon: <Activity className="w-4 h-4" />,      label: "Holatlar",        emoji: "⚡" },
    { tab: "ai",          icon: <Bot className="w-4 h-4" />,           label: "AI Yordamchi",   badge: "NEW", emoji: "🤖" },
    { tab: "voicerooms",  icon: <Radio className="w-4 h-4" />,         label: "Ovozli Xonalar", badge: "NEW", emoji: "🎙️" },
    { tab: "market",      icon: <Star className="w-4 h-4" />,          label: "Bozor",          badge: "NEW", emoji: "🛍️" },
    { tab: "weather",     icon: <Activity className="w-4 h-4" />,      label: "Ob-Havo",        badge: "NEW", emoji: "🌤️" },
    { tab: "crypto",      icon: <Activity className="w-4 h-4" />,      label: "Kripto Bozor",   badge: "NEW", emoji: "₿" },
    { tab: "flashcard",   icon: <BookOpen className="w-4 h-4" />,      label: "Til O'rganish",  badge: "NEW", emoji: "🧠" },
    { tab: "leaderboard", icon: <Activity className="w-4 h-4" />,      label: "Reyting",        badge: "NEW", emoji: "🏆" },
    { tab: "qr",          icon: <Activity className="w-4 h-4" />,      label: "QR Kod",         badge: "NEW", emoji: "📱" },
    { tab: "friends",     icon: <Users className="w-4 h-4" />,         label: "Do'stlar",       badge: "NEW", emoji: "🤝" },
    { tab: "events",      icon: <Activity className="w-4 h-4" />,      label: "Tadbirlar",      badge: "NEW", emoji: "🎉" },
    { tab: "clubs",       icon: <Users className="w-4 h-4" />,         label: "Klublar",        badge: "NEW", emoji: "🏘️" },
    { tab: "activity",    icon: <Zap className="w-4 h-4" />,           label: "Faollik",        badge: "LIVE", emoji: "⚡" },
    { tab: "stories",     icon: <Activity className="w-4 h-4" />,      label: "Hikoyalar",      badge: "NEW", emoji: "✨" },
    { tab: "contacts",    icon: <Users className="w-4 h-4" />,         label: "Kontaktlar",      emoji: "👥" },
    { tab: "channels",    icon: <ChevronRight className="w-4 h-4" />,  label: "Kanallar",        emoji: "📡" },
    { tab: "wallet",      icon: <Wallet className="w-4 h-4" />,        label: "Hamyon",         badge: "⭐", emoji: "💰" },
    { tab: "music",       icon: <Music2 className="w-4 h-4" />,        label: "Musiqa",          emoji: "🎵" },
    { tab: "polls",       icon: <BarChart2 className="w-4 h-4" />,     label: "So'rovnomalar",   emoji: "📊" },
    { tab: "todo",        icon: <CheckSquare className="w-4 h-4" />,   label: "Vazifalar",       emoji: "✅" },
    { tab: "saved",       icon: <Bookmark className="w-4 h-4" />,      label: "Saqlanganlar",    emoji: "🔖" },
    { tab: "games",       icon: <Gamepad2 className="w-4 h-4" />,      label: "O'yinlar",        emoji: "🎮" },
    { tab: "profile",     icon: <UserCircle2 className="w-4 h-4" />,   label: "Mening Profilim", emoji: "👤" },
    { tab: "kundalik",    icon: <BookOpen className="w-4 h-4" />,      label: "Kundalik",        emoji: "📖" },
    { tab: "analytics",   icon: <BarChart2 className="w-4 h-4" />,     label: "Analitika",       emoji: "📈" },
    { tab: "settings",    icon: <Settings className="w-4 h-4" />,      label: "Sozlamalar",      emoji: "⚙️" },
    ...(isAdmin ? [{ tab: "admin" as Tab, icon: <ShieldAlert className="w-4 h-4" />, label: "Admin Panel", danger: true, emoji: "🛡️" }] : []),
  ];

  const callStatusText = callStatus === "calling" ? "Qo'ng'iroq..." : callStatus === "connecting" ? "Ulanmoqda..." : `${Math.floor(callDuration / 60)}:${String(callDuration % 60).padStart(2, "0")}`;

  const isPremium = isPremiumUser;

  return (
    <div className="fixed inset-0 flex flex-col bg-[#030712] text-slate-100 overflow-hidden">
      <AnimatedBackground accentColor={accentColor} />

      {/* ===== MAINTENANCE OVERLAY ===== */}
      {maintenanceMode && (
        <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center" style={{background:"#000"}}>
          <div className="text-center space-y-6 p-8 max-w-lg">
            <div className="text-7xl animate-pulse">🚧</div>
            <div>
              <p className="text-3xl font-black text-amber-400 mb-2 tracking-widest">SAYT QAYTADAN ISHLANMOQDA</p>
              <p className="text-amber-600 font-mono text-sm tracking-wider">SITE UNDER MAINTENANCE</p>
            </div>
            <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500 rounded-full animate-pulse" style={{width:"60%"}} />
            </div>
            <p className="text-slate-500 font-mono text-xs">Iltimos, kuting. Tizim tez orada qayta ishga tushadi...</p>
            <div className="flex justify-center gap-2">
              {[0,1,2].map(i => <div key={i} className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" style={{animationDelay:`${i*200}ms`}} />)}
            </div>
            <p className="text-slate-700 font-mono text-[10px]">NEXUS_OS v5.6 · Admin: @Max</p>
          </div>
        </div>
      )}

      {/* ===== ANNOUNCEMENT BANNER ===== */}
      {announcement && (
        <div className="fixed top-14 left-0 right-0 z-50 px-4 py-2.5 text-center text-xs font-bold text-amber-900 flex items-center justify-center gap-2"
          style={{background:"linear-gradient(90deg,#78350f,#92400e,#78350f)", backgroundSize:"200% 100%"}}>
          <span className="animate-pulse">📌</span>
          <span className="text-amber-100">{announcement}</span>
        </div>
      )}

      {/* ===== INCOMING CALL OVERLAY ===== */}
      {incomingCall && (
        <IncomingCallModal
          caller={incomingCall.caller}
          callType={incomingCall.callType}
          onAccept={acceptCall}
          onReject={rejectCall}
        />
      )}

      {/* ===== ACTIVE CALL OVERLAY (Video + Audio unified) ===== */}
      {activeCall && callStatus !== "idle" && (
        <VideoCallOverlay
          localStream={localStreamRef.current}
          remoteStream={remoteStream}
          peer={activeCall.peer}
          callStatus={callStatus as "calling" | "in-call" | "connecting"}
          callType={activeCall.type}
          isMuted={isMuted}
          isCameraOff={isCameraOff}
          callDuration={callDuration}
          onMute={toggleMute}
          onCameraToggle={toggleCamera}
          onEnd={endCall}
        />
      )}

      {/* ===== GLOBAL SEARCH OVERLAY ===== */}
      {showSearch && (
        <GlobalSearch
          username={username}
          accentColor={accentColor}
          allUsers={allUsers}
          onClose={() => setShowSearch(false)}
          onOpenChat={(id, isGroup) => { openChat(id, !!isGroup); setShowSearch(false); }}
          onGoTo={(tab) => { setActiveTab(tab as Tab); setSelectedTarget(null); setShowSearch(false); }}
        />
      )}

      {/* ===== HEADER ===== */}
      <header className="h-14 flex-shrink-0 flex items-center justify-between px-4 border-b border-slate-800/60 z-40"
        style={{background:"rgba(3,7,18,0.97)", backdropFilter:"blur(24px)", boxShadow:"0 1px 0 rgba(255,255,255,0.04)"}}>
        <div className="flex items-center gap-3 min-w-0">
          <button onClick={() => setSidebarOpen(o => !o)}
            className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800/80 transition flex-shrink-0"
            style={{color: accentColor}}>
            <Menu className="w-5 h-5" />
          </button>
          {/* Logo + current section */}
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="font-black tracking-[0.12em] text-sm cursor-pointer select-none flex-shrink-0"
              style={{background:`linear-gradient(to right, ${accentColor}, #6366f1)`, WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"}}
              onClick={() => { setActiveTab("home"); setSelectedTarget(null); }}>
              NEXUS
            </span>
            <span className="text-slate-700 flex-shrink-0 text-xs">/</span>
            <span className="text-sm font-semibold text-slate-300 truncate" key={activeTab}>
              {navItems.find(n => n.tab === activeTab)?.emoji}{" "}
              {navItems.find(n => n.tab === activeTab)?.label ?? "Chatlar"}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {callStatus !== "idle" && !activeCall && (
            <span className="text-[10px] text-green-400 font-mono animate-pulse border border-green-800 px-2 py-1 rounded-lg bg-green-950/30">📞 {callStatusText}</span>
          )}
          {/* Search button */}
          <button onClick={() => setShowSearch(true)}
            className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800 transition text-slate-500 hover:text-slate-200"
            title="Qidirish (Ctrl+K)">
            <Search className="w-4 h-4" />
          </button>
          {/* Notification Center */}
          <NotificationCenter
            username={username}
            accentColor={accentColor}
            onNavigate={(tab) => { setActiveTab(tab as Tab); setSelectedTarget(null); }}
            onOpenChat={(peer) => openChat(peer)}
          />
          <button onClick={() => setShowStarShop(true)}
            className="flex items-center gap-1.5 bg-amber-950/20 border border-amber-900/40 px-2.5 py-1.5 rounded-xl hover:bg-amber-950/40 transition">
            <span className="text-xs font-black text-amber-400">⭐ {starsBalance}</span>
          </button>
          <button onClick={() => { setActiveTab("profile"); setSelectedTarget(null); }}
            className="flex items-center gap-1.5 bg-slate-900/80 px-2.5 py-1.5 rounded-xl border border-slate-800/60 hover:bg-slate-800 transition">
            <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black text-white flex-shrink-0"
              style={{background:`linear-gradient(135deg,${accentColor},#6366f1)`}}>
              {username[0]?.toUpperCase()}
            </div>
            <span className="text-xs font-medium text-slate-400 hidden sm:block max-w-20 truncate">@{username}</span>
            {isPremium && <span className="text-[9px] font-black text-amber-400">👑</span>}
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* ===== SIDEBAR ===== */}
        <aside
          className={`flex flex-col border-r border-slate-800/70 z-30 flex-shrink-0 bg-[#030712] overflow-hidden transition-all duration-300`}
          style={{ width: sidebarOpen ? "288px" : "0px", minWidth: sidebarOpen ? "288px" : "0px" }}
        >
          <div className="flex flex-col h-full overflow-hidden w-72">
            {/* Nav */}
            <nav className="p-2 border-b border-slate-800/60 flex-shrink-0">
              {/* 4 Pinned items */}
              <div className="space-y-0.5">
                {navItems.filter(item => PINNED_TABS.includes(item.tab)).map(item => {
                  const active = activeTab === item.tab && !selectedTarget;
                  return (
                    <button key={item.tab}
                      onClick={() => { setActiveTab(item.tab); setSelectedTarget(null); if (window.innerWidth < 768) setSidebarOpen(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-150 relative overflow-hidden group"
                      style={active ? {
                        background: `linear-gradient(135deg, ${accentColor}18, ${accentColor}08)`,
                        color: accentColor,
                        border: `1px solid ${accentColor}25`,
                      } : { color: "#64748b", border: "1px solid transparent" }}
                    >
                      {active && (
                        <div className="absolute left-0 top-1/4 bottom-1/4 w-0.5 rounded-r-full" style={{ background: accentColor }} />
                      )}
                      <span className="text-base w-5 text-center flex-shrink-0 transition-transform duration-150 group-hover:scale-110">{item.emoji || item.icon}</span>
                      <span className="flex-1 truncate font-semibold text-left">{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Barchasi toggle */}
              <button
                onClick={() => setNavExpanded(e => !e)}
                className="w-full flex items-center gap-2 px-3 py-2 mt-1 rounded-xl text-xs font-bold transition-all hover:bg-slate-900/50"
                style={{ color: accentColor }}
              >
                <span className={`transition-transform duration-300 text-[10px] ${navExpanded ? "rotate-180" : ""}`}>▼</span>
                <span className="flex-1 text-left tracking-wide">Barchasi</span>
                <span className="text-[9px] text-slate-700 font-normal bg-slate-900/60 px-1.5 py-0.5 rounded-full">
                  {navItems.length - PINNED_TABS.length}
                </span>
              </button>

              {/* Expanded items */}
              {navExpanded && (
                <div className="space-y-0.5 mt-1 pt-1.5 border-t border-slate-800/40">
                  {navItems.filter(item => !PINNED_TABS.includes(item.tab)).map(item => {
                    const active = activeTab === item.tab && !selectedTarget;
                    return (
                      <button key={item.tab}
                        onClick={() => { setActiveTab(item.tab); setSelectedTarget(null); if (window.innerWidth < 768) setSidebarOpen(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs transition-all duration-150 relative overflow-hidden group"
                        style={active
                          ? item.danger
                            ? { background: "rgba(239,68,68,0.08)", color: "#f87171", border: "1px solid rgba(239,68,68,0.2)" }
                            : { background: `linear-gradient(135deg, ${accentColor}15, ${accentColor}06)`, color: accentColor, border: `1px solid ${accentColor}20` }
                          : item.danger
                            ? { color: "#f87171aa", border: "1px solid transparent" }
                            : { color: "#64748b", border: "1px solid transparent" }
                        }
                      >
                        {active && !item.danger && (
                          <div className="absolute left-0 top-1/4 bottom-1/4 w-0.5 rounded-r-full" style={{ background: accentColor }} />
                        )}
                        <span className="text-sm w-4 text-center flex-shrink-0 transition-transform group-hover:scale-110">{item.emoji || item.icon}</span>
                        <span className="flex-1 truncate font-medium text-left">{item.label}</span>
                        {item.danger && <span className="ml-auto text-[8px] font-bold text-rose-700 animate-pulse">LIVE</span>}
                        {item.badge && !item.danger && (
                          <span className="ml-auto text-[8px] font-black px-1.5 py-0.5 rounded-full flex-shrink-0"
                            style={{ background: accentColor + "20", color: accentColor }}>
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </nav>

            {/* Search */}
            <div className="px-2 py-2 border-b border-slate-800/40 flex-shrink-0">
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-600 pointer-events-none text-xs">🔍</span>
                <input
                  value={userSearch}
                  onChange={e => setUserSearch(e.target.value)}
                  placeholder="Qidirish..."
                  className="w-full bg-slate-900/60 border border-slate-800/80 rounded-xl pl-8 pr-3 py-2 text-xs text-slate-300 outline-none focus:border-slate-700 transition placeholder-slate-700"
                />
              </div>
            </div>

            {/* Users list */}
            <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
              {!userSearch && (
                <>
                  {/* Max official channel with premium badge */}
                  <button onClick={() => openChat("Max", true, maxChannel)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-slate-900/60 transition relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5" style={{background:"linear-gradient(90deg,#3b82f6,transparent)"}} />
                    <div className="w-10 h-10 rounded-full bg-blue-700 flex items-center justify-center text-base flex-shrink-0">🛡️</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-blue-300">Max</p>
                        <span className="bg-blue-500 text-white rounded-full w-3.5 h-3.5 flex items-center justify-center text-[8px]">✓</span>
                        <span className="text-[8px] font-black text-amber-400 bg-amber-950/40 border border-amber-800/60 px-1 py-0.5 rounded">PREMIUM✓</span>
                      </div>
                      <p className="text-[10px] text-blue-600">Rasmiy kanal · @Max</p>
                    </div>
                  </button>

                  {/* NEXUS Bots */}
                  <div className="pt-2 pb-0.5 px-2">
                    <p className="text-[9px] font-bold uppercase tracking-widest text-slate-700">🤖 Botlar</p>
                  </div>
                  <button onClick={() => openChat("NexusBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#1d4ed8,#3b82f6)"}}>🤖</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-blue-300">NexusBot</p>
                        <span className="text-[8px] font-black text-blue-500 bg-blue-950/40 border border-blue-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Yordam & Ma'lumot</p>
                    </div>
                  </button>
                  <button onClick={() => openChat("StarBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#d97706,#fbbf24)"}}>⭐</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-amber-300">StarBot</p>
                        <span className="text-[8px] font-black text-amber-500 bg-amber-950/40 border border-amber-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Stars & Sovg'alar</p>
                    </div>
                  </button>
                  <button onClick={() => openChat("QuizBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#16a34a,#4ade80)"}}>🎯</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-green-300">QuizBot</p>
                        <span className="text-[8px] font-black text-green-500 bg-green-950/40 border border-green-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Bilim sinovi & Quiz</p>
                    </div>
                  </button>
                  <button onClick={() => openChat("WeatherBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#0284c7,#38bdf8)"}}>🌤️</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-sky-300">WeatherBot</p>
                        <span className="text-[8px] font-black text-sky-500 bg-sky-950/40 border border-sky-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Ob-havo ma'lumoti</p>
                    </div>
                  </button>
                  <button onClick={() => openChat("HoroscopeBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#7c3aed,#c084fc)"}}>♈</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-purple-300">HoroscopeBot</p>
                        <span className="text-[8px] font-black text-purple-500 bg-purple-950/40 border border-purple-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Burj & Bashorat</p>
                    </div>
                  </button>
                  <button onClick={() => openChat("JokeBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#dc2626,#f97316)"}}>😂</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-orange-300">JokeBot</p>
                        <span className="text-[8px] font-black text-orange-500 bg-orange-950/40 border border-orange-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Latifahlar & Kulgi</p>
                    </div>
                  </button>
                  <button onClick={() => openChat("MafiaBot")}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-slate-900/60 transition">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                      style={{background:"linear-gradient(135deg,#7c3aed,#dc2626)"}}>🕵️</div>
                    <div className="text-left min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-rose-300">MafiaBot</p>
                        <span className="text-[8px] font-black text-rose-500 bg-rose-950/40 border border-rose-900/50 px-1 py-0.5 rounded">BOT</span>
                      </div>
                      <p className="text-[10px] text-slate-600">Mafia o'yini & Multiplayer</p>
                    </div>
                  </button>

                  {/* AI Bot */}
                  <div className="mx-2 my-1.5 h-px bg-gradient-to-r from-transparent via-slate-700/60 to-transparent" />
                  <button onClick={() => openChat("AIBot")}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition relative overflow-hidden group"
                    style={{background:"linear-gradient(135deg,rgba(139,92,246,0.12),rgba(6,182,212,0.08))", border:"1px solid rgba(139,92,246,0.25)"}}>
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{background:"linear-gradient(135deg,rgba(139,92,246,0.18),rgba(6,182,212,0.12))"}} />
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0 relative z-10"
                      style={{background:"linear-gradient(135deg,#7c3aed,#06b6d4)", boxShadow:"0 0 12px rgba(139,92,246,0.4)"}}>🤖</div>
                    <div className="text-left min-w-0 flex-1 relative z-10">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold" style={{color:"#c4b5fd"}}>AI Bot</p>
                        <span className="text-[8px] font-black px-1 py-0.5 rounded" style={{color:"#06b6d4",background:"rgba(6,182,212,0.1)",border:"1px solid rgba(6,182,212,0.3)"}}>AI</span>
                      </div>
                      <p className="text-[10px] text-slate-500">GPT-4o · Gemini · API kalit bilan</p>
                    </div>
                    <div className="w-2 h-2 rounded-full animate-pulse flex-shrink-0 relative z-10" style={{background:"#06b6d4"}} />
                  </button>

                  {/* Groups */}
                  {groups.filter(g => !g.isOfficialMax).map(g => (
                    <button key={g.id} onClick={() => openChat(g.id, true, g)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-slate-900/60 transition">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-base flex-shrink-0"
                        style={{background:"linear-gradient(135deg,#7c3aed,#4f46e5)"}}>
                        {g.type === "channel" ? "📡" : "👥"}
                      </div>
                      <div className="text-left min-w-0 flex-1">
                        <p className="text-sm font-medium text-slate-200 truncate">#{g.name}</p>
                        <p className="text-[10px] text-slate-500">{g.type === "channel" ? "Kanal" : "Guruh"}</p>
                      </div>
                    </button>
                  ))}

                  <button onClick={createGroup}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl border border-dashed border-slate-800 hover:border-slate-600 text-slate-500 hover:text-slate-300 transition">
                    <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center flex-shrink-0">➕</div>
                    <p className="text-xs">Guruh / Kanal yaratish</p>
                  </button>

                  {!userSearch && <div className="pt-2 pb-1 px-2"><p className="text-[9px] font-bold uppercase tracking-widest text-slate-600">Foydalanuvchilar</p></div>}
                </>
              )}

              {filteredUsers.length === 0 && (
                <p className="text-[11px] text-slate-600 text-center py-6 font-mono">
                  {userSearch ? "Topilmadi" : "Hech kim onlayn emas"}
                </p>
              )}

              {filteredUsers.map(uKey => {
                const isOnline = onlineSet.has(uKey);
                const unread = unreadMap[uKey] || 0;
                const typingToMe = onlineUsers.find(u => u.key === uKey)?.typingTo === username;
                return (
                  <div key={uKey} role="button" tabIndex={0} onClick={() => openChat(uKey)}
                    onKeyDown={e => e.key === "Enter" && openChat(uKey)}
                    className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl transition-all duration-150 group cursor-pointer hover:bg-slate-900/50">
                    <div className="relative flex-shrink-0">
                      <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white"
                        style={{background:`linear-gradient(135deg, ${accentColor}55, #4f46e5)`}}>
                        {uKey[0]?.toUpperCase()}
                      </div>
                      <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#030712] ${isOnline ? "bg-green-400" : "bg-slate-700"}`} />
                    </div>
                    <div className="text-left min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-300 truncate">@{uKey}</p>
                      <p className="text-[10px] truncate" style={{color: typingToMe ? accentColor : isOnline ? "#4ade80" : "#475569"}}>
                        {typingToMe ? "⌨️ yozmoqda..." : isOnline ? "onlayn" : "oflayn"}
                      </p>
                    </div>
                    <div className="flex items-center gap-0.5 flex-shrink-0">
                      {unread > 0 && (
                        <span className="text-[9px] font-black rounded-full min-w-[18px] h-[18px] flex items-center justify-center text-white px-1"
                          style={{background: accentColor}}>
                          {unread > 9 ? "9+" : unread}
                        </span>
                      )}
                      <span role="button" tabIndex={0}
                        onClick={e => togglePinChat(uKey, e as unknown as React.MouseEvent)}
                        onKeyDown={e => e.key === "Enter" && togglePinChat(uKey, e as unknown as React.MouseEvent)}
                        className={`opacity-0 group-hover:opacity-100 transition-all p-1 rounded-lg hover:bg-slate-800 ${pinnedChats.includes(uKey) ? "!opacity-100 text-amber-400" : "text-slate-600"}`}>
                        {pinnedChats.includes(uKey) ? <PinOff className="w-3 h-3" /> : <Pin className="w-3 h-3" />}
                      </span>
                      <span role="button" tabIndex={0}
                        onClick={e => { (e as React.MouseEvent).stopPropagation(); startCall(uKey); }}
                        onKeyDown={e => { if (e.key === "Enter") { e.stopPropagation(); startCall(uKey); }}}
                        className="opacity-0 group-hover:opacity-100 text-green-400 transition-all p-1 rounded-lg hover:bg-slate-800">
                        <Phone className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* User profile card + logout */}
            <div className="p-3 border-t border-slate-800/50 flex-shrink-0 space-y-2">
              {/* Profile card */}
              <button
                onClick={() => { setActiveTab("profile"); setSelectedTarget(null); if (window.innerWidth < 768) setSidebarOpen(false); }}
                className="w-full flex items-center gap-3 p-2.5 rounded-2xl border border-slate-800/60 hover:border-slate-700/60 transition group"
                style={{ background: "rgba(15,23,42,0.7)" }}
              >
                {/* Avatar */}
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-base font-black text-white flex-shrink-0 relative"
                  style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, boxShadow: `0 0 14px ${accentColor}44` }}>
                  {username[0]?.toUpperCase()}
                  <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-green-400 border-2 border-[#030712]" />
                </div>
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-bold text-slate-200 truncate">@{username}</p>
                    {isPremiumUser && <span className="text-[9px] font-black text-amber-400">👑</span>}
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[9px] text-amber-500 font-mono">⭐ {starsBalance}</span>
                    <span className="text-[9px] text-green-500">● onlayn</span>
                  </div>
                </div>
                <Settings className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-400 transition flex-shrink-0" />
              </button>
              {/* Logout */}
              <button onClick={handleLogout}
                className="w-full py-2 rounded-xl text-[10px] font-bold border border-rose-950/60 text-rose-600 hover:bg-rose-950/30 hover:text-rose-400 transition flex items-center justify-center gap-1.5">
                <LogOut className="w-3 h-3" />Tizimdan chiqish
              </button>
            </div>
          </div>
        </aside>

        {/* ===== MAIN CONTENT ===== */}
        <main className="flex-1 overflow-hidden flex flex-col min-w-0">
          <div
            key={activeTab + "|" + (selectedTarget ?? "") + "|" + (selectedChannelId ?? "")}
            className="page-enter flex-1 overflow-hidden flex flex-col min-w-0"
          >
            {renderContent()}
          </div>
        </main>
      </div>

      {/* ===== STAR SHOP MODAL ===== */}
      {showStarShop && (
        <StarShop username={username} accentColor={accentColor} onClose={() => setShowStarShop(false)} />
      )}

      {/* ===== USER PROFILE MODAL ===== */}
      {profileModalUser && (
        <UserProfileModal
          username={username}
          targetUser={profileModalUser}
          accentColor={accentColor}
          onClose={() => setProfileModalUser(null)}
          onStartChat={(peer) => { setProfileModalUser(null); openChat(peer); }}
          onStartCall={(peer, type) => { setProfileModalUser(null); startCall(peer, type); }}
        />
      )}
    </div>
  );
}
