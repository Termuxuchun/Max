import { useState, useEffect } from "react";
import { Plus, CheckCircle2, Circle, Trash2, Flag, Calendar, Tag, Search, Star, MoreHorizontal, Edit3 } from "lucide-react";

type Priority = "low" | "medium" | "high" | "urgent";
type Category = "shaxsiy" | "ish" | "o'quv" | "sport" | "boshqa";

interface Todo {
  id: string;
  text: string;
  done: boolean;
  priority: Priority;
  category: Category;
  createdAt: number;
  dueDate?: string;
  starred: boolean;
  note?: string;
}

interface TodoSectionProps {
  username: string;
  accentColor: string;
}

const PRIORITY_CONFIG: Record<Priority, { label: string; color: string; icon: string }> = {
  urgent: { label: "Shoshilinch", color: "#ef4444", icon: "🔴" },
  high:   { label: "Yuqori",     color: "#f97316", icon: "🟠" },
  medium: { label: "O'rta",      color: "#eab308", icon: "🟡" },
  low:    { label: "Past",       color: "#22c55e", icon: "🟢" },
};

const CATEGORY_EMOJIS: Record<Category, string> = {
  shaxsiy: "👤", ish: "💼", "o'quv": "📚", sport: "🏋️", boshqa: "📌"
};

const STORAGE_KEY = (u: string) => `nexus_todos_${u}`;

export default function TodoSection({ username, accentColor }: TodoSectionProps) {
  const [todos, setTodos] = useState<Todo[]>(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY(username)) || "[]"); } catch { return []; }
  });
  const [input, setInput] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [category, setCategory] = useState<Category>("shaxsiy");
  const [dueDate, setDueDate] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "done" | "starred" | "urgent">("all");
  const [editId, setEditId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [note, setNote] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY(username), JSON.stringify(todos));
  }, [todos, username]);

  function addTodo() {
    if (!input.trim()) return;
    const todo: Todo = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      text: input.trim(),
      done: false,
      priority,
      category,
      createdAt: Date.now(),
      dueDate: dueDate || undefined,
      starred: false,
      note: note.trim() || undefined,
    };
    setTodos(prev => [todo, ...prev]);
    setInput(""); setDueDate(""); setNote(""); setShowForm(false);
  }

  function toggle(id: string) {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  }

  function toggleStar(id: string) {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, starred: !t.starred } : t));
  }

  function deleteTodo(id: string) {
    setTodos(prev => prev.filter(t => t.id !== id));
  }

  function saveEdit(id: string) {
    if (!editText.trim()) return;
    setTodos(prev => prev.map(t => t.id === id ? { ...t, text: editText.trim() } : t));
    setEditId(null);
  }

  function clearDone() {
    setTodos(prev => prev.filter(t => !t.done));
  }

  const filtered = todos.filter(t => {
    if (search && !t.text.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter === "active") return !t.done;
    if (filter === "done") return t.done;
    if (filter === "starred") return t.starred;
    if (filter === "urgent") return t.priority === "urgent" || t.priority === "high";
    return true;
  });

  const doneCount = todos.filter(t => t.done).length;
  const pct = todos.length > 0 ? Math.round((doneCount / todos.length) * 100) : 0;

  const isDueToday = (d?: string) => d === new Date().toISOString().slice(0, 10);
  const isDuePast = (d?: string) => d && d < new Date().toISOString().slice(0, 10);

  return (
    <div className="flex flex-col h-full bg-[#030712] text-slate-100 page-enter overflow-hidden">

      {/* ── Header ── */}
      <div className="px-4 pt-5 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-2xl font-black" style={{ color: accentColor }}>✅ Vazifalar</h1>
            <p className="text-slate-500 text-xs mt-0.5">{doneCount}/{todos.length} bajarildi</p>
          </div>
          <button onClick={() => setShowForm(s => !s)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl font-bold text-sm text-white transition active:scale-95"
            style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
            <Plus className="w-4 h-4" /> Qo'shish
          </button>
        </div>

        {/* Progress bar */}
        {todos.length > 0 && (
          <div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-700"
                style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${accentColor}, #6366f1)` }} />
            </div>
            <div className="flex justify-between text-[10px] mt-1 text-slate-600">
              <span>{doneCount} bajarildi</span>
              <span>{pct}%</span>
              <span>{todos.length - doneCount} qoldi</span>
            </div>
          </div>
        )}
      </div>

      {/* ── Add Form ── */}
      {showForm && (
        <div className="mx-4 mb-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800/60 space-y-3 drop-in flex-shrink-0">
          <input value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addTodo()}
            placeholder="Yangi vazifa yozing..."
            className="w-full bg-slate-800/60 border border-slate-700/50 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-slate-500 placeholder-slate-600 font-medium transition"
            autoFocus />

          <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Izoh (ixtiyoriy)..." rows={2}
            className="w-full bg-slate-800/40 border border-slate-700/30 rounded-xl px-4 py-2.5 text-sm text-slate-300 outline-none focus:border-slate-500 placeholder-slate-600 resize-none transition" />

          <div className="grid grid-cols-2 gap-2">
            {/* Priority */}
            <div>
              <p className="text-[9px] uppercase tracking-widest text-slate-600 mb-1">Muhimlik</p>
              <div className="flex gap-1 flex-wrap">
                {(Object.keys(PRIORITY_CONFIG) as Priority[]).map(p => (
                  <button key={p} onClick={() => setPriority(p)}
                    className="px-2 py-1 rounded-lg text-[10px] font-bold transition"
                    style={priority === p ? { background: PRIORITY_CONFIG[p].color + "33", color: PRIORITY_CONFIG[p].color, border: `1px solid ${PRIORITY_CONFIG[p].color}55` } : { background: "#1e293b", color: "#64748b", border: "1px solid #334155" }}>
                    {PRIORITY_CONFIG[p].icon}
                  </button>
                ))}
              </div>
            </div>
            {/* Category */}
            <div>
              <p className="text-[9px] uppercase tracking-widest text-slate-600 mb-1">Toifa</p>
              <div className="flex gap-1 flex-wrap">
                {(Object.keys(CATEGORY_EMOJIS) as Category[]).map(c => (
                  <button key={c} onClick={() => setCategory(c)}
                    className="px-2 py-1 rounded-lg text-[10px] font-bold transition"
                    style={category === c ? { background: accentColor + "33", color: accentColor, border: `1px solid ${accentColor}55` } : { background: "#1e293b", color: "#64748b", border: "1px solid #334155" }}>
                    {CATEGORY_EMOJIS[c]}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Due date */}
          <div>
            <p className="text-[9px] uppercase tracking-widest text-slate-600 mb-1">Muddati</p>
            <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)}
              className="bg-slate-800/60 border border-slate-700/50 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-slate-500 transition [color-scheme:dark]" />
          </div>

          <div className="flex gap-2">
            <button onClick={() => setShowForm(false)}
              className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-400 font-bold text-sm hover:bg-slate-800 transition">
              Bekor
            </button>
            <button onClick={addTodo} disabled={!input.trim()}
              className="flex-1 py-2.5 rounded-xl font-bold text-sm text-white disabled:opacity-40 transition active:scale-95"
              style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)` }}>
              Qo'shish
            </button>
          </div>
        </div>
      )}

      {/* ── Search & Filters ── */}
      <div className="px-4 pb-3 space-y-2 flex-shrink-0">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-600" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Qidirish..."
            className="w-full bg-slate-900/60 border border-slate-800/60 rounded-xl pl-8 pr-4 py-2 text-xs text-slate-300 outline-none focus:border-slate-600 placeholder-slate-600 transition" />
        </div>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {([
            { key: "all", label: "Barchasi" },
            { key: "active", label: "Faol" },
            { key: "starred", label: "⭐" },
            { key: "urgent", label: "🔴 Shoshilinch" },
            { key: "done", label: "✅ Tugadi" },
          ] as const).map(f => (
            <button key={f.key} onClick={() => setFilter(f.key)}
              className="flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition"
              style={filter === f.key ? { background: accentColor + "22", color: accentColor, border: `1px solid ${accentColor}44` } : { color: "#475569" }}>
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Todo List ── */}
      <div className="flex-1 overflow-y-auto px-4 pb-6 space-y-2">
        {todos.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
            <div className="text-6xl">✅</div>
            <p className="text-slate-400 font-bold text-lg">Hali vazifa yo'q</p>
            <p className="text-slate-600 text-sm">Yangi vazifa qo'shish uchun tugmani bosing</p>
          </div>
        )}

        {filtered.map((todo, i) => {
          const pc = PRIORITY_CONFIG[todo.priority];
          const isEditing = editId === todo.id;
          const isExpanded = expandedId === todo.id;
          const todayDue = isDueToday(todo.dueDate);
          const overdue = !todo.done && isDuePast(todo.dueDate);
          return (
            <div key={todo.id}
              className={`rounded-2xl border transition stagger-1 ${todo.done ? "opacity-60" : ""}`}
              style={{ animationDelay: `${i * 30}ms`, background: isExpanded ? "#0f172a" : "#0a0f1e55", borderColor: isExpanded ? accentColor + "44" : "#1e293b" }}>
              <div className="flex items-center gap-3 p-3">
                {/* Checkbox */}
                <button onClick={() => toggle(todo.id)} className="flex-shrink-0 transition active:scale-90">
                  {todo.done
                    ? <CheckCircle2 className="w-5 h-5" style={{ color: accentColor }} />
                    : <Circle className="w-5 h-5 text-slate-600 hover:text-slate-400 transition" />}
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0" onClick={() => setExpandedId(expandedId === todo.id ? null : todo.id)}>
                  {isEditing ? (
                    <input value={editText} onChange={e => setEditText(e.target.value)}
                      onBlur={() => saveEdit(todo.id)} onKeyDown={e => { if (e.key === "Enter") saveEdit(todo.id); }}
                      className="w-full bg-slate-800 rounded-lg px-2 py-1 text-sm text-white outline-none border border-slate-600"
                      autoFocus onClick={e => e.stopPropagation()} />
                  ) : (
                    <p className={`text-sm font-medium leading-snug ${todo.done ? "line-through text-slate-500" : "text-slate-100"}`}>
                      {todo.text}
                    </p>
                  )}
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-[10px] font-bold" style={{ color: pc.color }}>{pc.icon} {pc.label}</span>
                    <span className="text-[10px] text-slate-600">{CATEGORY_EMOJIS[todo.category]}</span>
                    {todo.dueDate && (
                      <span className={`flex items-center gap-0.5 text-[10px] font-bold ${overdue ? "text-rose-500" : todayDue ? "text-amber-400" : "text-slate-600"}`}>
                        <Calendar className="w-2.5 h-2.5" />
                        {overdue ? "Kechikdi!" : todayDue ? "Bugun!" : todo.dueDate}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => toggleStar(todo.id)}>
                    <Star className={`w-4 h-4 transition ${todo.starred ? "fill-amber-400 text-amber-400" : "text-slate-700"}`} />
                  </button>
                  <button onClick={() => { setEditId(todo.id); setEditText(todo.text); }}>
                    <Edit3 className="w-4 h-4 text-slate-700 hover:text-slate-400 transition" />
                  </button>
                  <button onClick={() => deleteTodo(todo.id)}>
                    <Trash2 className="w-4 h-4 text-slate-700 hover:text-rose-400 transition" />
                  </button>
                </div>
              </div>

              {/* Expanded note */}
              {isExpanded && todo.note && (
                <div className="px-12 pb-3 drop-in">
                  <p className="text-xs text-slate-400 bg-slate-800/50 rounded-xl p-3 leading-relaxed">{todo.note}</p>
                </div>
              )}
            </div>
          );
        })}

        {/* Clear done */}
        {doneCount > 0 && (
          <button onClick={clearDone}
            className="w-full py-2.5 rounded-xl border border-dashed border-slate-800 text-slate-600 hover:text-rose-400 hover:border-rose-900 text-xs font-bold transition mt-2">
            🗑️ {doneCount} ta bajarilganini o'chirish
          </button>
        )}
      </div>
    </div>
  );
}
