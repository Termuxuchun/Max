import { useState, useEffect, useRef } from "react";
import { ref, push, onValue, remove, serverTimestamp, get, update } from "firebase/database";
import { db } from "../firebase";
import { uploadToStorage } from "../lib/uploadMedia";
import { Plus, X, Heart, Eye, ChevronLeft, ChevronRight, Clock, Trash2, Image, Type, Sparkles } from "lucide-react";

interface Story {
  id: string;
  author: string;
  content: string;
  type: "text" | "image";
  bg: string;
  emoji?: string;
  ts: number;
  views: Record<string, boolean>;
  likes: Record<string, boolean>;
}

interface StoriesSectionProps {
  username: string;
  accentColor: string;
  onOpenProfile?: (u: string) => void;
}

const BG_PRESETS = [
  "linear-gradient(135deg,#1e1b4b,#312e81,#4c1d95)",
  "linear-gradient(135deg,#0c4a6e,#0369a1,#22d3ee)",
  "linear-gradient(135deg,#14532d,#166534,#22c55e)",
  "linear-gradient(135deg,#7f1d1d,#991b1b,#f97316)",
  "linear-gradient(135deg,#0f0c29,#302b63,#24243e)",
  "linear-gradient(135deg,#1a1a2e,#16213e,#0f3460)",
  "linear-gradient(135deg,#f97316,#ec4899,#8b5cf6)",
  "linear-gradient(135deg,#064e3b,#065f46,#10b981)",
  "linear-gradient(270deg,#22d3ee,#6366f1,#ec4899)",
  "linear-gradient(135deg,#0e7490,#6d28d9,#0e7490)",
  "linear-gradient(135deg,#030712,#0f172a,#1e293b)",
  "linear-gradient(135deg,#78350f,#92400e,#f59e0b)",
];

function timeAgo(ts: number) {
  const diff = Date.now() - ts;
  if (diff < 60000) return "hozir";
  if (diff < 3600000) return `${Math.floor(diff / 60000)}d oldin`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}s oldin`;
  return `${Math.floor(diff / 86400000)} kun oldin`;
}

function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const gradients = [
    ["#22d3ee","#3b82f6"],["#8b5cf6","#ec4899"],["#10b981","#22d3ee"],
    ["#f59e0b","#ef4444"],["#6366f1","#8b5cf6"],["#14b8a6","#3b82f6"],
  ];
  const [c1, c2] = gradients[(name.charCodeAt(0) || 0) % gradients.length];
  return (
    <div className="rounded-full flex items-center justify-center text-white font-black select-none flex-shrink-0"
      style={{ width: size, height: size, background: `linear-gradient(135deg,${c1},${c2})`, fontSize: size * 0.38 }}>
      {name[0]?.toUpperCase()}
    </div>
  );
}

function StoryViewer({
  stories, startIndex, onClose, username, accentColor
}: {
  stories: Story[];
  startIndex: number;
  onClose: () => void;
  username: string;
  accentColor: string;
}) {
  const [idx, setIdx] = useState(startIndex);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const story = stories[idx];

  useEffect(() => {
    if (!story) return;
    if (story.author !== username) {
      update(ref(db, `stories/${story.id}/views`), { [username]: true });
    }
    setProgress(0);
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(timerRef.current);
          if (idx < stories.length - 1) setIdx(i => i + 1);
          else onClose();
          return 0;
        }
        return p + 0.8;
      });
    }, 40);
    return () => clearInterval(timerRef.current);
  }, [idx, story?.id]);

  if (!story) return null;

  const viewCount = Object.keys(story.views || {}).length;
  const likeCount = Object.keys(story.likes || {}).length;
  const isLiked = !!(story.likes?.[username]);

  function toggleLike() {
    if (isLiked) remove(ref(db, `stories/${story.id}/likes/${username}`));
    else update(ref(db, `stories/${story.id}/likes`), { [username]: true });
  }

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center" style={{ background: "rgba(0,0,0,0.95)" }}>
      <div className="relative w-full max-w-sm h-full max-h-[85vh] mx-4 rounded-3xl overflow-hidden"
        style={{ background: story.bg }}>

        {/* Progress bars */}
        <div className="absolute top-3 left-3 right-3 z-20 flex gap-1">
          {stories.map((_, i) => (
            <div key={i} className="flex-1 h-0.5 rounded-full bg-white/20 overflow-hidden">
              <div className="h-full bg-white rounded-full transition-none"
                style={{ width: i < idx ? "100%" : i === idx ? `${progress}%` : "0%" }} />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-7 left-3 right-3 z-20 flex items-center gap-2.5">
          <Avatar name={story.author} size={36} />
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-bold">@{story.author}</p>
            <p className="text-white/50 text-[10px] flex items-center gap-1">
              <Clock className="w-3 h-3" />{timeAgo(story.ts)}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-black/30 flex items-center justify-center">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="w-full h-full flex items-center justify-center p-6 pt-20 pb-24">
          {story.type === "text" ? (
            <p className="text-white text-2xl font-black text-center leading-relaxed drop-shadow-lg">
              {story.emoji && <span className="text-5xl block mb-4">{story.emoji}</span>}
              {story.content}
            </p>
          ) : (
            <img src={story.content} alt="" className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl" />
          )}
        </div>

        {/* Bottom bar */}
        <div className="absolute bottom-0 left-0 right-0 z-20 flex items-center gap-4 px-5 pb-6 pt-8"
          style={{ background: "linear-gradient(to top, rgba(0,0,0,0.7), transparent)" }}>
          <div className="flex items-center gap-1 text-white/60">
            <Eye className="w-4 h-4" />
            <span className="text-xs font-mono">{viewCount}</span>
          </div>
          <button onClick={toggleLike} className="flex items-center gap-1.5 transition-transform active:scale-90">
            <Heart className={`w-5 h-5 transition-colors ${isLiked ? "text-red-400 fill-red-400" : "text-white/60"}`} />
            <span className="text-xs font-mono text-white/60">{likeCount}</span>
          </button>
          {story.author === username && (
            <button onClick={() => { remove(ref(db, `stories/${story.id}`)); onClose(); }}
              className="ml-auto flex items-center gap-1.5 text-red-400/70 hover:text-red-400 transition">
              <Trash2 className="w-4 h-4" />
              <span className="text-xs">O'chirish</span>
            </button>
          )}
        </div>

        {/* Nav areas */}
        <button className="absolute left-0 top-0 bottom-0 w-1/3 z-10" onClick={() => { if (idx > 0) setIdx(i => i - 1); else onClose(); }} />
        <button className="absolute right-0 top-0 bottom-0 w-1/3 z-10" onClick={() => { if (idx < stories.length - 1) setIdx(i => i + 1); else onClose(); }} />
      </div>

      {/* Prev/Next arrows */}
      {idx > 0 && (
        <button onClick={() => setIdx(i => i - 1)}
          className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
          <ChevronLeft className="w-5 h-5 text-white" />
        </button>
      )}
      {idx < stories.length - 1 && (
        <button onClick={() => setIdx(i => i + 1)}
          className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
          <ChevronRight className="w-5 h-5 text-white" />
        </button>
      )}
    </div>
  );
}

function CreateStoryModal({ username, accentColor, onClose }: { username: string; accentColor: string; onClose: () => void }) {
  const [tab, setTab] = useState<"text" | "image">("text");
  const [text, setText] = useState("");
  const [emoji, setEmoji] = useState("✨");
  const [bg, setBg] = useState(BG_PRESETS[0]);
  const [imgSrc, setImgSrc] = useState("");
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const EMOJIS = ["✨","🔥","💫","❤️","🌟","🚀","💎","🎯","🎉","🌈","💪","🤩","👑","🦋","🌙","⚡"];

  const [imgFile, setImgFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  async function publish() {
    if (tab === "text" && !text.trim()) return;
    if (tab === "image" && !imgFile && !imgSrc) return;
    setLoading(true);
    try {
      let contentUrl = imgSrc;
      if (tab === "image" && imgFile) {
        const storyId = Date.now().toString();
        setUploadProgress(5);
        contentUrl = await uploadToStorage(
          `stories/${username}/${storyId}/media.jpg`,
          imgFile,
          p => setUploadProgress(p)
        );
      }
      await push(ref(db, "stories"), {
        author: username,
        content: tab === "text" ? text.trim() : contentUrl,
        type: tab,
        bg,
        emoji: tab === "text" ? emoji : undefined,
        ts: Date.now(),
        views: {},
        likes: {},
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
      });
    } catch (err) {
      alert("Yuklab bo'lmadi: " + (err instanceof Error ? err.message : String(err)));
    }
    setLoading(false);
    setUploadProgress(0);
    onClose();
  }

  function handleImageFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) { alert("Rasm 20MB dan kichik bo'lishi kerak"); return; }
    setImgFile(file);
    const reader = new FileReader();
    reader.onload = ev => setImgSrc(ev.target?.result as string);
    reader.readAsDataURL(file);
  }

  return (
    <div className="fixed inset-0 z-[160] flex items-end sm:items-center justify-center"
      style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(20px)" }}>
      <div className="w-full max-w-sm bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-slate-800">
          <p className="text-base font-black text-white">Yangi Hikoya</p>
          <button onClick={onClose} className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 px-5 pt-4 pb-2">
          {[
            { id: "text" as const, icon: <Type className="w-4 h-4" />, label: "Matn" },
            { id: "image" as const, icon: <Image className="w-4 h-4" />, label: "Rasm" },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-bold transition border"
              style={tab === t.id ? { background: `${accentColor}20`, borderColor: accentColor, color: accentColor } : { borderColor: "#1e293b", color: "#64748b" }}>
              {t.icon}{t.label}
            </button>
          ))}
        </div>

        <div className="px-5 pb-5 space-y-4">
          {tab === "text" ? (
            <>
              {/* Preview */}
              <div className="relative h-36 rounded-2xl overflow-hidden flex items-center justify-center" style={{ background: bg }}>
                <div className="text-center">
                  <div className="text-4xl mb-1">{emoji}</div>
                  <p className="text-white font-black text-lg px-4 text-center drop-shadow">{text || "Matn yozing..."}</p>
                </div>
              </div>

              {/* Text input */}
              <textarea value={text} onChange={e => setText(e.target.value)} maxLength={200}
                placeholder="Fikringizni yozing..."
                className="w-full bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-600 outline-none focus:border-cyan-500/50 resize-none"
                rows={3} />

              {/* Emoji picker */}
              <div>
                <p className="text-xs text-slate-500 font-bold mb-2 uppercase tracking-wider">Emoji</p>
                <div className="flex flex-wrap gap-2">
                  {EMOJIS.map(e => (
                    <button key={e} onClick={() => setEmoji(e)}
                      className={`text-xl w-9 h-9 rounded-xl transition border ${emoji === e ? "bg-slate-700 border-slate-500 scale-110" : "bg-slate-800/50 border-transparent hover:border-slate-700"}`}>
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              {/* BG picker */}
              <div>
                <p className="text-xs text-slate-500 font-bold mb-2 uppercase tracking-wider">Fon</p>
                <div className="flex flex-wrap gap-2">
                  {BG_PRESETS.map((b, i) => (
                    <button key={i} onClick={() => setBg(b)}
                      className={`w-9 h-9 rounded-xl transition border-2 ${bg === b ? "scale-110 border-white" : "border-transparent"}`}
                      style={{ background: b }} />
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleImageFile} />
              {imgSrc ? (
                <div className="relative h-48 rounded-2xl overflow-hidden">
                  <img src={imgSrc} alt="" className="w-full h-full object-cover" />
                  <button onClick={() => setImgSrc("")}
                    className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/60 flex items-center justify-center">
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              ) : (
                <button onClick={() => fileRef.current?.click()}
                  className="w-full h-36 rounded-2xl border-2 border-dashed border-slate-700 flex flex-col items-center justify-center gap-3 hover:border-cyan-500/50 transition">
                  <Image className="w-8 h-8 text-slate-600" />
                  <p className="text-sm text-slate-500">Rasm tanlash</p>
                </button>
              )}

              {/* BG for image */}
              <div>
                <p className="text-xs text-slate-500 font-bold mb-2 uppercase tracking-wider">Freym rangi</p>
                <div className="flex flex-wrap gap-2">
                  {BG_PRESETS.map((b, i) => (
                    <button key={i} onClick={() => setBg(b)}
                      className={`w-9 h-9 rounded-xl transition border-2 ${bg === b ? "scale-110 border-white" : "border-transparent"}`}
                      style={{ background: b }} />
                  ))}
                </div>
              </div>
            </>
          )}

          <button onClick={publish} disabled={loading || (tab === "text" ? !text.trim() : !imgSrc)}
            className="w-full py-3.5 rounded-2xl font-black text-sm transition active:scale-95 disabled:opacity-40"
            style={{ background: `linear-gradient(135deg, ${accentColor}, #6366f1)`, color: "#000" }}>
            {loading ? "Yuborilmoqda..." : "✨ Hikoya qo'yish"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StoriesSection({ username, accentColor, onOpenProfile }: StoriesSectionProps) {
  const [stories, setStories] = useState<Story[]>([]);
  const [viewerData, setViewerData] = useState<{ stories: Story[]; startIdx: number } | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [myStoryCount, setMyStoryCount] = useState(0);

  useEffect(() => {
    return onValue(ref(db, "stories"), snap => {
      if (!snap.exists()) { setStories([]); return; }
      const now = Date.now();
      const all: Story[] = [];
      snap.forEach(c => {
        const d = c.val();
        if (d.expiresAt && d.expiresAt < now) {
          remove(ref(db, `stories/${c.key}`));
          return;
        }
        all.push({ ...d, id: c.key! });
      });
      all.sort((a, b) => b.ts - a.ts);
      setStories(all);
      setMyStoryCount(all.filter(s => s.author === username).length);
    });
  }, [username]);

  // Group by author for display
  const authorMap = new Map<string, Story[]>();
  stories.forEach(s => {
    if (!authorMap.has(s.author)) authorMap.set(s.author, []);
    authorMap.get(s.author)!.push(s);
  });

  // Sort: my stories first, then unseen, then seen
  const authorOrder = Array.from(authorMap.keys()).sort((a, b) => {
    if (a === username) return -1;
    if (b === username) return 1;
    const aStories = authorMap.get(a)!;
    const bStories = authorMap.get(b)!;
    const aUnseen = aStories.some(s => !s.views?.[username]);
    const bUnseen = bStories.some(s => !s.views?.[username]);
    if (aUnseen && !bUnseen) return -1;
    if (!aUnseen && bUnseen) return 1;
    return bStories[0].ts - aStories[0].ts;
  });

  function openStories(author: string) {
    const authorStories = authorMap.get(author) || [];
    if (!authorStories.length) return;
    setViewerData({ stories: authorStories, startIdx: 0 });
  }

  function openAll(startAuthorIdx: number) {
    const allOrdered: Story[] = [];
    authorOrder.slice(startAuthorIdx).forEach(a => {
      allOrdered.push(...(authorMap.get(a) || []));
    });
    setViewerData({ stories: allOrdered, startIdx: 0 });
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#030712]">
      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-black text-white tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5" style={{ color: accentColor }} />
              Hikoyalar
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{stories.length} ta hikoya · 24 soat davomida</p>
          </div>
          <button onClick={() => setShowCreate(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition active:scale-95"
            style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40`, color: accentColor }}>
            <Plus className="w-3.5 h-3.5" />Qo'shish
          </button>
        </div>

        {/* Stories row */}
        {authorOrder.length > 0 ? (
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 scrollbar-hide" style={{ scrollbarWidth: "none" }}>
            {/* Add story button */}
            <div className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer" onClick={() => setShowCreate(true)}>
              <div className="relative w-16 h-16 rounded-2xl flex items-center justify-center border-2 border-dashed border-slate-700 hover:border-cyan-500/60 transition"
                style={{ background: "#0f172a" }}>
                <Plus className="w-6 h-6 text-slate-500" />
                {myStoryCount > 0 && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black text-white"
                    style={{ background: accentColor }}>
                    {myStoryCount}
                  </div>
                )}
              </div>
              <p className="text-[10px] text-slate-500 font-medium w-16 text-center truncate">Mening</p>
            </div>

            {authorOrder.map((author, authorIdx) => {
              const authorStories = authorMap.get(author)!;
              const hasUnseen = authorStories.some(s => !s.views?.[username] && s.author !== username);
              const latestStory = authorStories[0];
              return (
                <div key={author} className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer"
                  onClick={() => openAll(authorIdx)}>
                  <div className="relative">
                    {/* Ring */}
                    <div className="absolute inset-0 rounded-2xl p-0.5"
                      style={{
                        background: hasUnseen
                          ? `linear-gradient(135deg, ${accentColor}, #6366f1)`
                          : "rgba(255,255,255,0.1)",
                        borderRadius: "18px",
                      }}>
                      <div className="w-full h-full rounded-[14px]" style={{ background: "#030712" }} />
                    </div>
                    {/* Story preview */}
                    <div className="relative w-16 h-16 rounded-2xl overflow-hidden border border-transparent"
                      style={{ background: latestStory.bg }}>
                      {latestStory.type === "image" ? (
                        <img src={latestStory.content} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <span className="text-2xl">{latestStory.emoji || "✨"}</span>
                        </div>
                      )}
                    </div>
                    {/* Count badge */}
                    {authorStories.length > 1 && (
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black text-black"
                        style={{ background: accentColor }}>
                        {authorStories.length}
                      </div>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium w-16 text-center truncate">
                    {author === username ? "Siz" : `@${author}`}
                  </p>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex gap-3">
            <div className="flex-shrink-0 flex flex-col items-center gap-1.5 cursor-pointer" onClick={() => setShowCreate(true)}>
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center border-2 border-dashed border-slate-700 hover:border-cyan-500/60 transition"
                style={{ background: "#0f172a" }}>
                <Plus className="w-6 h-6 text-slate-500" />
              </div>
              <p className="text-[10px] text-slate-500">Birinchi</p>
            </div>
          </div>
        )}
      </div>

      {/* Divider */}
      <div className="h-px bg-slate-800/60 mx-4 flex-shrink-0" />

      {/* Feed */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {stories.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="text-6xl opacity-30">🌟</div>
            <div className="text-center">
              <p className="text-sm font-semibold text-slate-500">Hali hikoyalar yo'q</p>
              <p className="text-xs text-slate-700 mt-1">Birinchi hikoyangizni qo'shing!</p>
            </div>
            <button onClick={() => setShowCreate(true)}
              className="px-5 py-2.5 rounded-xl text-sm font-bold transition active:scale-95"
              style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}40`, color: accentColor }}>
              + Hikoya qo'shish
            </button>
          </div>
        ) : (
          stories.map((story, idx) => {
            const viewCount = Object.keys(story.views || {}).length;
            const likeCount = Object.keys(story.likes || {}).length;
            const isMine = story.author === username;
            const isSeen = !isMine && !!story.views?.[username];

            return (
              <div key={story.id}
                className="rounded-2xl overflow-hidden cursor-pointer hover:opacity-95 transition active:scale-[0.98]"
                style={{ border: "1px solid rgba(255,255,255,0.06)" }}
                onClick={() => setViewerData({ stories: [story], startIdx: 0 })}>
                {/* Story card */}
                <div className="relative h-48" style={{ background: story.bg }}>
                  {story.type === "text" ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                      {story.emoji && <span className="text-5xl mb-3 drop-shadow-lg">{story.emoji}</span>}
                      <p className="text-white text-xl font-black leading-snug drop-shadow-lg line-clamp-4">{story.content}</p>
                    </div>
                  ) : (
                    <img src={story.content} alt="" className="w-full h-full object-cover" />
                  )}
                  {isSeen && (
                    <div className="absolute top-2 right-2 px-2 py-1 rounded-full bg-black/40 text-[9px] text-white/60 font-mono">
                      Ko'rildi
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="px-4 py-3 flex items-center gap-3" style={{ background: "rgba(15,23,42,0.8)" }}>
                  <Avatar name={story.author} size={32} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-200 truncate">@{story.author}</p>
                    <p className="text-[10px] text-slate-500 flex items-center gap-1">
                      <Clock className="w-3 h-3" />{timeAgo(story.ts)}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 text-slate-500">
                    <div className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-mono">{viewCount}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className={`w-3.5 h-3.5 ${likeCount > 0 ? "text-red-400" : ""}`} />
                      <span className="text-[11px] font-mono">{likeCount}</span>
                    </div>
                    {isMine && (
                      <button onClick={e => { e.stopPropagation(); remove(ref(db, `stories/${story.id}`)); }}
                        className="text-red-400/50 hover:text-red-400 transition p-1">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Viewer */}
      {viewerData && (
        <StoryViewer
          stories={viewerData.stories}
          startIndex={viewerData.startIdx}
          onClose={() => setViewerData(null)}
          username={username}
          accentColor={accentColor}
        />
      )}

      {/* Create modal */}
      {showCreate && (
        <CreateStoryModal username={username} accentColor={accentColor} onClose={() => setShowCreate(false)} />
      )}
    </div>
  );
}
