import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

interface Props { accentColor: string; }

/* ─── Constants ──────────────────────────────────────────────────────────── */
const LANE_X   = [-3.4, 0, 3.4];
const SEG_LEN  = 48;
const NUM_SEGS = 9;
const TRACK_W  = 11;
const GRAVITY  = 22;
const JUMP_VEL = 10;
const SLIDE_T  = 0.55;
const LERP_X   = 11;

type PState = "run" | "jump" | "slide" | "dead";
const ri = (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a;

/* ─── Materials (created once, reused across segments) ───────────────────── */
const mkMats = () => ({
  track:     new THREE.MeshLambertMaterial({ color: 0x0a0a18 }),
  sideTrack: new THREE.MeshLambertMaterial({ color: 0x111126 }),
  barrier:   new THREE.MeshLambertMaterial({ color: 0xee1133, emissive: 0x550011 }),
  lowBar:    new THREE.MeshLambertMaterial({ color: 0xff7700, emissive: 0x331100 }),
  coin:      new THREE.MeshBasicMaterial({ color: 0xffcc00 }),
  body:      new THREE.MeshLambertMaterial({ color: 0x22aaff, emissive: 0x002244 }),
  accent:    new THREE.MeshLambertMaterial({ color: 0xff6600, emissive: 0x331100 }),
  bld1:      new THREE.MeshLambertMaterial({ color: 0x0b0b22 }),
  bld2:      new THREE.MeshLambertMaterial({ color: 0x150b22 }),
  winOn:     new THREE.MeshBasicMaterial({ color: 0xffee88 }),
  winOff:    new THREE.MeshBasicMaterial({ color: 0x111128 }),
  rail:      new THREE.LineBasicMaterial({ color: 0x00ffcc }),
  railDim:   new THREE.LineBasicMaterial({ color: 0x005533 }),
  gridLine:  new THREE.LineBasicMaterial({ color: 0x111133 }),
  glow:      new THREE.LineBasicMaterial({ color: 0xff4466 }),
  glowO:     new THREE.LineBasicMaterial({ color: 0xff8800 }),
});
type Mats = ReturnType<typeof mkMats>;

/* ─── Obstacle data ──────────────────────────────────────────────────────── */
interface ObjData {
  mesh: THREE.Object3D;
  kind: "barrier" | "low" | "coin";
  worldZ: number;
  collected: boolean;
}

/* ─── Segment builder ────────────────────────────────────────────────────── */
function buildSegment(
  scene: THREE.Scene,
  mats: Mats,
  startZ: number,
  diff: number
): { group: THREE.Group; objects: ObjData[] } {
  const grp = new THREE.Group();
  const objects: ObjData[] = [];

  /* Ground */
  const gnd = new THREE.Mesh(new THREE.BoxGeometry(TRACK_W, 0.18, SEG_LEN), mats.track);
  gnd.position.set(0, -0.09, startZ + SEG_LEN / 2);
  grp.add(gnd);

  /* Side platforms */
  for (const sx of [-TRACK_W / 2 - 2.5, TRACK_W / 2 + 2.5]) {
    const sp = new THREE.Mesh(new THREE.BoxGeometry(5, 0.18, SEG_LEN), mats.sideTrack);
    sp.position.set(sx, -0.18, startZ + SEG_LEN / 2);
    grp.add(sp);
  }

  /* Neon rails */
  for (const rx of [-TRACK_W / 2, TRACK_W / 2]) {
    for (let z = startZ; z < startZ + SEG_LEN; z += 2.5) {
      const even = Math.round(z / 2.5) % 2 === 0;
      const pts = [new THREE.Vector3(rx, 0.35, z), new THREE.Vector3(rx, 0.35, z + 2.5)];
      grp.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), even ? mats.rail : mats.railDim));
    }
  }

  /* Lane dividers */
  for (const lx of [-3.4 / 2 - 0.8, 3.4 / 2 + 0.8]) {
    const pts = [new THREE.Vector3(lx, 0.02, startZ), new THREE.Vector3(lx, 0.02, startZ + SEG_LEN)];
    grp.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mats.gridLine));
  }

  /* Cross-grid (every 5 units) */
  for (let z = startZ; z <= startZ + SEG_LEN; z += 5) {
    const pts = [new THREE.Vector3(-TRACK_W / 2, 0.02, z), new THREE.Vector3(TRACK_W / 2, 0.02, z)];
    grp.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mats.gridLine));
  }

  /* Side buildings */
  for (const side of [-1, 1]) {
    let bz = startZ;
    while (bz < startZ + SEG_LEN) {
      const bw = ri(5, 10), bh = ri(7, 28), bd = ri(7, 14);
      const bx = side * (TRACK_W / 2 + bw / 2 + 0.8);
      const mat = side > 0 ? mats.bld1 : mats.bld2;
      const bld = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), mat);
      bld.position.set(bx, bh / 2, bz + bd / 2);
      grp.add(bld);
      /* Glowing edge */
      const glowEdge = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(bw + 0.04, bh + 0.04, bd + 0.04)),
        new THREE.LineBasicMaterial({ color: side > 0 ? 0x002244 : 0x220033 })
      );
      glowEdge.position.copy(bld.position);
      grp.add(glowEdge);
      /* Windows */
      const numW = ri(3, 8);
      for (let w = 0; w < numW; w++) {
        const wmat = Math.random() > 0.35 ? mats.winOn : mats.winOff;
        const win = new THREE.Mesh(new THREE.PlaneGeometry(0.65, 0.4), wmat);
        win.rotation.y = side > 0 ? Math.PI / 2 : -Math.PI / 2;
        win.position.set(bx - side * (bw / 2 + 0.02), ri(2, bh - 2), bz + Math.random() * bd);
        grp.add(win);
      }
      bz += bd + ri(1, 5);
    }
  }

  /* Street lights */
  for (let z = startZ + 8; z < startZ + SEG_LEN; z += 16) {
    for (const sx of [-TRACK_W / 2 - 0.5, TRACK_W / 2 + 0.5]) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 5, 6), new THREE.MeshLambertMaterial({ color: 0x445566 }));
      pole.position.set(sx, 2.5, z);
      grp.add(pole);
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffffcc }));
      lamp.position.set(sx, 5.1, z);
      grp.add(lamp);
      const pl = new THREE.PointLight(0xffee99, 0.7, 12);
      pl.position.set(sx, 5, z);
      grp.add(pl);
    }
  }

  /* ── Obstacles ── */
  if (diff > 0 && startZ > 50) {
    const pattern = ri(0, 5);

    /* Helper: make barrier mesh */
    const mkBarrier = (x: number, z: number, w = 3.2, h = 2.2, d = 0.55) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mats.barrier);
      m.position.set(x, h / 2, z);
      grp.add(m);
      const eg = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(w + 0.06, h + 0.06, d + 0.06)),
        mats.glow
      );
      eg.position.copy(m.position);
      grp.add(eg);
      return m;
    };

    const mkLow = (x: number, z: number) => {
      /* Bottom block (must slide under) */
      const bot = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.75, 0.55), mats.lowBar);
      bot.position.set(x, 0.375, z);
      grp.add(bot);
      /* Top block creating tunnel */
      const top = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.0, 0.55), mats.lowBar);
      top.position.set(x, 2.75, z);
      grp.add(top);
      /* Glow */
      [bot, top].forEach(m => {
        const eg = new THREE.LineSegments(new THREE.EdgesGeometry((m.geometry as THREE.BoxGeometry)), mats.glowO);
        eg.position.copy(m.position);
        grp.add(eg);
      });
      return bot;
    };

    if (pattern === 0) {
      /* Single lane barrier */
      const lane = ri(0, 2);
      const oz = startZ + ri(10, SEG_LEN - 10);
      const m = mkBarrier(LANE_X[lane], oz);
      objects.push({ mesh: m, kind: "barrier", worldZ: oz, collected: false });
    }

    if (pattern === 1) {
      /* Two lanes blocked */
      const free = ri(0, 2);
      [0, 1, 2].filter(l => l !== free).forEach(lane => {
        const oz = startZ + ri(10, SEG_LEN - 14);
        const m = mkBarrier(LANE_X[lane], oz);
        objects.push({ mesh: m, kind: "barrier", worldZ: oz, collected: false });
      });
    }

    if (pattern === 2) {
      /* Low obstacle */
      const lane = ri(0, 2);
      const oz = startZ + ri(10, SEG_LEN - 10);
      const m = mkLow(LANE_X[lane], oz);
      objects.push({ mesh: m, kind: "low", worldZ: oz, collected: false });
    }

    if (pattern === 3) {
      /* Train: 3 consecutive barriers, one lane */
      const lane = ri(0, 1);
      const baseOz = startZ + 8;
      for (let i = 0; i < 3; i++) {
        const oz = baseOz + i * 7;
        if (oz > startZ + SEG_LEN - 8) break;
        const m = mkBarrier(LANE_X[lane], oz, 3.2, 2.2, 5);
        objects.push({ mesh: m, kind: "barrier", worldZ: oz, collected: false });
      }
    }

    if (pattern === 4) {
      /* Mixed: low + barrier in different lanes */
      const laneB = ri(0, 1), laneL = laneB === 0 ? 2 : 0;
      const ozB = startZ + 14, ozL = startZ + 28;
      const mb = mkBarrier(LANE_X[laneB], ozB);
      const ml = mkLow(LANE_X[laneL], ozL);
      objects.push({ mesh: mb, kind: "barrier", worldZ: ozB, collected: false });
      objects.push({ mesh: ml, kind: "low", worldZ: ozL, collected: false });
    }

    if (pattern === 5 && diff > 1) {
      /* All 3 lanes blocked at same spot but staggered */
      [0, 1, 2].forEach((lane, i) => {
        const oz = startZ + 10 + i * 6;
        const m = mkBarrier(LANE_X[lane], oz);
        objects.push({ mesh: m, kind: "barrier", worldZ: oz, collected: false });
      });
    }
  }

  /* ── Coins ── */
  const coinGeo = new THREE.TorusGeometry(0.32, 0.1, 7, 14);
  const numRows = ri(2, 4);
  for (let r = 0; r < numRows; r++) {
    const coinZ = startZ + 4 + r * ((SEG_LEN - 8) / numRows);
    const lane = ri(0, 2);
    const count = ri(3, 7);
    const arc = Math.random() > 0.5; // arc pattern or straight
    for (let c = 0; c < count; c++) {
      const coin = new THREE.Mesh(coinGeo, mats.coin);
      const cz = coinZ + c * 1.6;
      const cy = arc ? 1.2 + Math.sin((c / (count - 1)) * Math.PI) * 2 : 1.2;
      coin.position.set(LANE_X[lane], cy, cz);
      coin.rotation.x = Math.PI / 2;
      grp.add(coin);
      objects.push({ mesh: coin, kind: "coin", worldZ: cz, collected: false });
    }
  }

  scene.add(grp);
  return { group: grp, objects };
}

/* ─── Player model ───────────────────────────────────────────────────────── */
function buildPlayer(mats: Mats) {
  const g = new THREE.Group();
  const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    g.add(m);
    return m;
  };
  const body  = add(new THREE.BoxGeometry(0.82, 1.1, 0.48), mats.body, 0, 1.5, 0);
  const head  = add(new THREE.BoxGeometry(0.62, 0.62, 0.62), mats.body, 0, 2.45, 0);
  const lArm  = add(new THREE.BoxGeometry(0.24, 0.88, 0.24), mats.accent, -0.58, 1.5, 0);
  const rArm  = add(new THREE.BoxGeometry(0.24, 0.88, 0.24), mats.accent, 0.58, 1.5, 0);
  const lLeg  = add(new THREE.BoxGeometry(0.3, 1.0, 0.3), mats.accent, -0.24, 0.5, 0);
  const rLeg  = add(new THREE.BoxGeometry(0.3, 1.0, 0.3), mats.accent, 0.24, 0.5, 0);
  /* Glow outline */
  const glow = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(0.86, 1.14, 0.52)),
    new THREE.LineBasicMaterial({ color: 0x00ffcc })
  );
  glow.position.set(0, 1.5, 0);
  g.add(glow);
  /* Jetpack glow */
  const jet = new THREE.PointLight(0x00ffcc, 1.0, 5);
  jet.position.set(0, 1, 0.3);
  g.add(jet);

  return { g, body, head, lArm, rArm, lLeg, rLeg, jet };
}

/* ─── Particle burst ─────────────────────────────────────────────────────── */
interface Particle { m: THREE.Mesh; v: THREE.Vector3; life: number }

function spawnBurst(
  scene: THREE.Scene,
  pos: THREE.Vector3,
  color: number,
  particles: Particle[]
) {
  const geo = new THREE.SphereGeometry(0.07, 4, 4);
  const mat = new THREE.MeshBasicMaterial({ color });
  for (let i = 0; i < 10; i++) {
    const p = new THREE.Mesh(geo, mat);
    p.position.copy(pos);
    scene.add(p);
    particles.push({
      m: p,
      v: new THREE.Vector3(
        (Math.random() - 0.5) * 5,
        Math.random() * 5 + 1,
        (Math.random() - 0.5) * 3
      ),
      life: 0.6,
    });
  }
}

/* ─── Main component ─────────────────────────────────────────────────────── */
export default function GTA3DGame({ accentColor }: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<"menu" | "play" | "dead">("menu");
  const [hud, setHud] = useState({ score: 0, coins: 0, lives: 3, speed: 12, best: 0 });
  const keysRef = useRef<Set<string>>(new Set());
  const swipeRef = useRef({ sx: 0, sy: 0 });
  const stateRef = useRef({
    pz: 5, px: 0, py: 0, pvy: 0,
    lane: 1, pstate: "run" as PState,
    slideT: 0, runAnim: 0, dist: 0,
    speed: 12, score: 0, coins: 0, lives: 3,
    nextSegZ: 0, segs: [] as { grp: THREE.Group; objs: ObjData[]; startZ: number }[],
    allObjs: [] as ObjData[], particles: [] as Particle[],
    dead: false,
  });

  useEffect(() => {
    if (phase !== "play" || !mountRef.current) return;
    const mount = mountRef.current;
    const W = mount.clientWidth, H = mount.clientHeight;

    /* Renderer */
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setSize(W, H);
    renderer.shadowMap.enabled = false; // off for perf
    mount.appendChild(renderer.domElement);

    /* Scene */
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050510);
    scene.fog = new THREE.FogExp2(0x050510, 0.02);

    /* Camera */
    const camera = new THREE.PerspectiveCamera(70, W / H, 0.1, 250);
    camera.position.set(0, 6, -8);

    /* Lights */
    scene.add(new THREE.AmbientLight(0x445577, 1.3));
    const dir = new THREE.DirectionalLight(0x8899cc, 0.9);
    dir.position.set(0, 20, -10);
    scene.add(dir);

    /* Stars */
    const sverts: number[] = [];
    for (let i = 0; i < 700; i++) sverts.push((Math.random() - 0.5) * 400, Math.random() * 60 + 6, Math.random() * 600 - 100);
    const stars = new THREE.Points(
      new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(sverts, 3)),
      new THREE.PointsMaterial({ color: 0xaabbff, size: 0.28 })
    );
    scene.add(stars);

    /* Materials */
    const mats = mkMats();

    /* Player */
    const player = buildPlayer(mats);
    scene.add(player.g);

    /* Reset state */
    const S = stateRef.current;
    Object.assign(S, {
      pz: 5, px: 0, py: 0, pvy: 0,
      lane: 1, pstate: "run", slideT: 0,
      runAnim: 0, dist: 0, speed: 12,
      score: 0, coins: 0, lives: 3,
      nextSegZ: 0, segs: [], allObjs: [],
      particles: [], dead: false,
    });

    /* Build initial segments */
    for (let i = 0; i < NUM_SEGS; i++) {
      const seg = buildSegment(scene, mats, S.nextSegZ, i < 3 ? 0 : 1);
      S.segs.push({ grp: seg.group, objs: seg.objects, startZ: S.nextSegZ });
      S.allObjs.push(...seg.objects);
      S.nextSegZ += SEG_LEN;
    }

    /* Camera lerp state */
    const camPos = new THREE.Vector3(0, 6, -8);

    /* Player bounding box */
    const pBox = new THREE.Box3();
    const oBox = new THREE.Box3();

    /* Input handlers */
    function doInput(code: string) {
      if (S.dead) return;
      if ((code === "ArrowLeft" || code === "KeyA") && S.lane > 0) S.lane--;
      else if ((code === "ArrowRight" || code === "KeyD") && S.lane < 2) S.lane++;
      else if ((code === "ArrowUp" || code === "KeyW" || code === "Space") && S.pstate === "run") {
        S.pstate = "jump"; S.pvy = JUMP_VEL;
      } else if ((code === "ArrowDown" || code === "KeyS") && S.pstate === "run") {
        S.pstate = "slide"; S.slideT = SLIDE_T;
      }
    }
    const onKD = (e: KeyboardEvent) => { keysRef.current.add(e.code); doInput(e.code); if (["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code)) e.preventDefault(); };
    const onKU = (e: KeyboardEvent) => keysRef.current.delete(e.code);

    const onTS = (e: TouchEvent) => { const t = e.touches[0]; swipeRef.current = { sx: t.clientX, sy: t.clientY }; };
    const onTE = (e: TouchEvent) => {
      const t = e.changedTouches[0];
      const dx = t.clientX - swipeRef.current.sx, dy = t.clientY - swipeRef.current.sy;
      const MIN = 22;
      if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > MIN) doInput(dx > 0 ? "ArrowRight" : "ArrowLeft");
      else if (Math.abs(dy) > MIN) doInput(dy > 0 ? "ArrowDown" : "ArrowUp");
    };
    window.addEventListener("keydown", onKD);
    window.addEventListener("keyup", onKU);
    mount.addEventListener("touchstart", onTS, { passive: true });
    mount.addEventListener("touchend", onTE, { passive: true });

    /* Resize */
    const onResize = () => {
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener("resize", onResize);

    /* ── Game Loop ── */
    let animId = 0, last = performance.now(), hudClock = 0;

    function loop(now: number) {
      animId = requestAnimationFrame(loop);
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      if (S.dead) { renderer.render(scene, camera); return; }

      /* Speed & distance */
      S.speed = 12 + S.dist * 0.009;
      S.score = Math.floor(S.dist * 3 + S.coins * 50);
      S.dist += S.speed * dt;
      S.pz   += S.speed * dt;

      /* Lane X */
      S.px += (LANE_X[S.lane] - S.px) * LERP_X * dt;

      /* Jump */
      if (S.pstate === "jump") {
        S.pvy -= GRAVITY * dt;
        S.py  += S.pvy * dt;
        if (S.py <= 0) { S.py = 0; S.pvy = 0; S.pstate = "run"; }
      }

      /* Slide */
      if (S.pstate === "slide") {
        S.slideT -= dt;
        if (S.slideT <= 0) { S.slideT = 0; S.pstate = "run"; }
      }

      /* Run animation */
      S.runAnim += dt * S.speed * 1.4;
      const swing = Math.sin(S.runAnim) * 0.55;

      /* Player mesh */
      player.g.position.set(S.px, S.py, S.pz);
      if (S.pstate === "slide") {
        player.g.scale.set(1, 0.42, 1);
        player.g.position.y = S.py - 0.25;
      } else {
        player.g.scale.set(1, 1, 1);
      }
      player.lLeg.rotation.x =  swing;
      player.rLeg.rotation.x = -swing;
      player.lArm.rotation.x = -swing * 0.6;
      player.rArm.rotation.x =  swing * 0.6;
      player.head.position.y = 2.45 + Math.abs(Math.sin(S.runAnim * 2)) * 0.03;
      player.jet.intensity = S.pstate === "jump" ? 2.0 : 0.7;

      /* Segment recycling */
      for (const seg of S.segs) {
        if (seg.startZ + SEG_LEN < S.pz - 12) {
          /* Remove old objects from allObjs */
          S.allObjs = S.allObjs.filter(o => !seg.objs.includes(o));
          scene.remove(seg.grp);
          const diff = S.dist > 250 ? 2 : 1;
          const newSeg = buildSegment(scene, mats, S.nextSegZ, diff);
          seg.grp = newSeg.group;
          seg.objs = newSeg.objects;
          seg.startZ = S.nextSegZ;
          S.nextSegZ += SEG_LEN;
          S.allObjs.push(...newSeg.objects);
        }
      }

      /* Collision */
      const pH = S.pstate === "slide" ? 0.5 : 2.2;
      const pY = S.py + pH / 2;
      pBox.setFromCenterAndSize(
        new THREE.Vector3(S.px, pY, S.pz),
        new THREE.Vector3(0.65, pH, 0.55)
      );

      for (const obj of S.allObjs) {
        if (obj.collected) continue;
        const oz = obj.worldZ;
        if (oz < S.pz - 4 || oz > S.pz + 8) continue;
        oBox.setFromObject(obj.mesh);
        if (!pBox.intersectsBox(oBox)) continue;

        if (obj.kind === "coin") {
          obj.collected = true;
          const wp = new THREE.Vector3();
          obj.mesh.getWorldPosition(wp);
          obj.mesh.visible = false;
          spawnBurst(scene, wp, 0xffcc00, S.particles);
          S.coins++;
        } else {
          obj.collected = true;
          obj.mesh.visible = false;
          S.lives--;
          spawnBurst(scene, player.g.position.clone(), 0xff2244, S.particles);
          if (S.lives <= 0) {
            S.dead = true;
            const best = Math.max(S.score, parseInt(localStorage.getItem("nxrunner_best") || "0"));
            localStorage.setItem("nxrunner_best", String(best));
            setTimeout(() => setPhase("dead"), 500);
          }
        }
      }

      /* Particles */
      for (let i = S.particles.length - 1; i >= 0; i--) {
        const p = S.particles[i];
        p.life -= dt;
        if (p.life <= 0) { scene.remove(p.m); S.particles.splice(i, 1); continue; }
        p.m.position.addScaledVector(p.v, dt);
        p.v.y -= 12 * dt;
        p.m.scale.setScalar(p.life * 1.8);
      }

      /* Coin rotation */
      for (const obj of S.allObjs) {
        if (obj.kind === "coin" && !obj.collected) (obj.mesh as THREE.Mesh).rotation.z += dt * 3;
      }

      /* Camera smooth follow */
      const tx = S.px * 0.25;
      const ty = S.py + 5.5 + Math.abs(S.pvy) * 0.08;
      const tz = S.pz - 10;
      camPos.x += (tx - camPos.x) * 7 * dt;
      camPos.y += (ty - camPos.y) * 5 * dt;
      camPos.z += (tz - camPos.z) * 9 * dt;
      camera.position.copy(camPos);
      camera.lookAt(S.px * 0.5, S.py + 1.5, S.pz + 12);

      /* Stars follow Z */
      stars.position.z = S.pz - 80;

      /* HUD throttle */
      hudClock += dt;
      if (hudClock > 0.08) {
        hudClock = 0;
        setHud({
          score: S.score, coins: S.coins, lives: S.lives,
          speed: Math.round(S.speed),
          best: parseInt(localStorage.getItem("nxrunner_best") || "0"),
        });
      }

      renderer.render(scene, camera);
    }

    animId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("keydown", onKD);
      window.removeEventListener("keyup", onKU);
      window.removeEventListener("resize", onResize);
      mount.removeEventListener("touchstart", onTS);
      mount.removeEventListener("touchend", onTE);
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, [phase]);

  /* ─── Menu ─── */
  if (phase === "menu") {
    const best = parseInt(localStorage.getItem("nxrunner_best") || "0");
    return (
      <div className="flex flex-col items-center gap-5 py-4 max-w-sm mx-auto">
        <div className="text-center space-y-1.5">
          <div className="text-5xl animate-bounce">🏃</div>
          <h2 className="text-2xl font-black text-white tracking-tight">NEXUS RUNNER</h2>
          <p className="text-sm text-slate-400">3D Endless Runner — cheksiz yugurish</p>
          {best > 0 && (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-950/40 border border-amber-700/40">
              <span className="text-sm">🏆</span>
              <span className="text-sm font-black text-amber-300">{best.toLocaleString()}</span>
            </div>
          )}
        </div>

        <div className="w-full space-y-2">
          {[
            { k: "← →", desc: "Yo'l almashtirish (chap/o'ng)", c: "#00ffcc" },
            { k: "↑ SPC", desc: "Sakrash — to'siqdan oshib o'ting", c: "#22aaff" },
            { k: "↓", desc: "Sirpanish — pastdan o'ting", c: "#ff7700" },
            { k: "📱", desc: "Telefonda swipe qiling", c: "#aa88ff" },
            { k: "🪙", desc: "Tangalar yig'ing — +50 ball", c: "#ffcc00" },
            { k: "❤️", desc: "3 ta hayot — ehtiyot bo'ling!", c: "#ff4466" },
          ].map(r => (
            <div key={r.k} className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/60">
              <span className="font-black text-sm w-10 text-center" style={{ color: r.c, fontFamily: "monospace" }}>{r.k}</span>
              <span className="text-slate-300 text-xs">{r.desc}</span>
            </div>
          ))}
        </div>

        <button
          onClick={() => setPhase("play")}
          className="w-full py-4 rounded-2xl font-black text-black text-base transition active:scale-95"
          style={{ background: "linear-gradient(135deg,#00ffcc,#00aa88)", boxShadow: "0 0 20px #00ffcc44" }}
        >
          🚀 BOSHLASH
        </button>
      </div>
    );
  }

  /* ─── Dead ─── */
  if (phase === "dead") {
    const best = parseInt(localStorage.getItem("nxrunner_best") || "0");
    const isNew = hud.score >= best && best > 0;
    return (
      <div className="flex flex-col items-center gap-5 py-6 max-w-sm mx-auto">
        <div className="text-center space-y-1">
          <div className="text-5xl">💀</div>
          <h2 className="text-xl font-black text-white">O'yin Tugadi</h2>
          {isNew && <p className="text-xs font-black text-amber-400 animate-pulse">🎉 YANGI REKORD!</p>}
        </div>

        <div className="grid grid-cols-2 gap-2.5 w-full">
          {[
            { v: hud.score.toLocaleString(), l: "Ball", i: "⭐" },
            { v: hud.coins, l: "Tangalar", i: "🪙" },
            { v: best.toLocaleString(), l: "Rekord", i: "🏆" },
            { v: `${hud.speed}u/s`, l: "Tezlik", i: "⚡" },
          ].map(s => (
            <div key={s.l} className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
              <p className="text-xl">{s.i}</p>
              <p className="text-xl font-black text-white mt-1">{s.v}</p>
              <p className="text-[10px] text-slate-500 font-mono uppercase mt-0.5">{s.l}</p>
            </div>
          ))}
        </div>

        <div className="flex gap-3 w-full">
          <button
            onClick={() => setPhase("play")}
            className="flex-1 py-4 rounded-2xl font-black text-black transition active:scale-95"
            style={{ background: "linear-gradient(135deg,#00ffcc,#006644)", boxShadow: "0 0 16px #00ffcc33" }}
          >
            🔄 Qayta
          </button>
          <button
            onClick={() => setPhase("menu")}
            className="flex-1 py-4 rounded-2xl font-bold text-slate-300 border border-slate-700 transition hover:bg-slate-800/60"
          >
            ← Menu
          </button>
        </div>
      </div>
    );
  }

  /* ─── Playing ─── */
  return (
    <div className="relative w-full select-none" style={{ height: "76vh", minHeight: 420 }}>
      {/* Viewport */}
      <div ref={mountRef} className="absolute inset-0 rounded-2xl overflow-hidden" />

      {/* HUD bar */}
      <div className="absolute top-3 left-0 right-0 flex items-start justify-between px-3 pointer-events-none">
        {/* Lives */}
        <div className="flex gap-0.5 bg-black/65 px-2.5 py-2 rounded-xl border border-slate-700/40 backdrop-blur-sm">
          {[0,1,2].map(i => (
            <span key={i} className={`text-base transition-all ${i < hud.lives ? "opacity-100" : "opacity-15 grayscale"}`}>❤️</span>
          ))}
        </div>

        {/* Score */}
        <div className="bg-black/65 px-4 py-2 rounded-xl border border-slate-700/40 backdrop-blur-sm text-center">
          <p className="text-2xl font-black text-white leading-none">{hud.score.toLocaleString()}</p>
          <p className="text-[9px] text-slate-500 font-mono tracking-widest mt-0.5">SCORE</p>
        </div>

        {/* Coins + Speed */}
        <div className="flex flex-col gap-1.5 items-end">
          <div className="bg-black/65 px-2.5 py-1.5 rounded-xl border border-amber-700/30 backdrop-blur-sm flex items-center gap-1.5">
            <span className="text-sm">🪙</span>
            <span className="text-sm font-black text-amber-400">{hud.coins}</span>
          </div>
          <div className="bg-black/65 px-2.5 py-1 rounded-xl border border-cyan-700/30 backdrop-blur-sm">
            <span className="text-[10px] font-mono text-cyan-400">{hud.speed} u/s</span>
          </div>
        </div>
      </div>

      {/* Back */}
      <button
        onClick={() => setPhase("menu")}
        className="absolute bottom-3 left-3 bg-black/70 text-slate-500 hover:text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700/50 transition pointer-events-auto backdrop-blur-sm"
      >
        ← Chiqish
      </button>

      {/* Controls hint (mobile) */}
      <div className="absolute bottom-3 right-3 bg-black/60 px-2 py-1.5 rounded-xl border border-slate-800/60 pointer-events-none backdrop-blur-sm">
        <p className="text-[9px] font-mono text-slate-600 text-center leading-relaxed">
          ← → yo'l&nbsp;&nbsp;↑ sakra<br/>↓ sirpan&nbsp;&nbsp;📱 swipe
        </p>
      </div>
    </div>
  );
}
