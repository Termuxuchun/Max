import { useState, useRef, useEffect } from "react";
import MultiplayerMafiaGame from "./MultiplayerMafiaGame";

interface Props {
  username: string;
  accentColor: string;
  onBack: () => void;
}

type Role = "godfather" | "mafia" | "detective" | "doctor" | "sheriff" | "witch" | "jester" | "bodyguard" | "vigilante" | "mayor" | "citizen";
type Phase = "modeSelect" | "setup" | "roleReveal" | "night" | "morning" | "discussion" | "vote" | "end";

interface Player {
  name: string;
  role: Role;
  alive: boolean;
  isUser: boolean;
  lastWill?: string;
  poisoned?: boolean;
  protected?: boolean;
}

interface ChatLine {
  from: string;
  text: string;
  ts: number;
}

const ROLE_INFO: Record<Role, { icon: string; color: string; bg: string; team: "mafia" | "solo" | "town"; shortDesc: string; desc: string; night: string }> = {
  godfather:  { icon: "🎩", color: "#dc2626", bg: "#7f1d1d", team: "mafia", shortDesc: "Mafia boshlig'i",  desc: "Har kechada o'ldirish buyrug'ini bering. Detektiv tekshirganda fuqaro ko'rinadi.", night: "O'ldirish uchun tanlang" },
  mafia:      { icon: "🕵️", color: "#ef4444", bg: "#450a0a", team: "mafia", shortDesc: "Mafia a'zosi",     desc: "Har kechada fuqarolardan birini yo'q qiling!", night: "O'ldirish uchun tanlang" },
  detective:  { icon: "🔍", color: "#3b82f6", bg: "#1e3a8a", team: "town",  shortDesc: "Detektiv",         desc: "Har kechada bir kishini tekshiring: mafia yoki yo'q.", night: "Tekshirish uchun tanlang" },
  doctor:     { icon: "💊", color: "#22c55e", bg: "#14532d", team: "town",  shortDesc: "Shifokor",         desc: "Har kechada bir kishini o'limdan himoya qiling!", night: "Himoya qilish uchun tanlang" },
  sheriff:    { icon: "⭐", color: "#f59e0b", bg: "#713f12", team: "town",  shortDesc: "Meriya",           desc: "Bitta imkoniyat: mafiani o'ldiring. Xato qilsangiz o'zingiz o'lasiz.", night: "Otish uchun tanlang (1 marta!)" },
  witch:      { icon: "🧙", color: "#a855f7", bg: "#3b0764", team: "town",  shortDesc: "Jodugar",          desc: "Kimnidir zaharlash yoki himoya qilish.", night: "Zaharlamoqchi yoki himoya qilmoqchimisiz?" },
  jester:     { icon: "🃏", color: "#ec4899", bg: "#500724", team: "solo",  shortDesc: "Masxaraboz",       desc: "Maqsad: ovozda chiqarilish! Chiqarilsangiz yutasiz.", night: "Uyquda kutasiz... (Masxaraboz)" },
  bodyguard:  { icon: "🛡️", color: "#0ea5e9", bg: "#0c1a2e", team: "town",  shortDesc: "Himoyachi",        desc: "Tanlagan kishini himoya qiling. Hujum bo'lsa o'zingiz o'lasiz.", night: "Himoya qilish uchun tanlang" },
  vigilante:  { icon: "⚡", color: "#eab308", bg: "#1a1200", team: "town",  shortDesc: "Qahramon",         desc: "Bir marta istalgan kishini o'ldiring. Xato bo'lsa ertasi o'lasiz.", night: "O'ldirish uchun tanlang (1 marta!)" },
  mayor:      { icon: "🏛️", color: "#06b6d4", bg: "#0a1a1a", team: "town",  shortDesc: "Mayor",            desc: "Ovozda 2 ta ovozga egasiz. Kechasi dam olasiz.", night: "Uyquda kutasiz..." },
  citizen:    { icon: "👤", color: "#94a3b8", bg: "#1e293b", team: "town",  shortDesc: "Fuqaro",           desc: "Gaplarni tahlil qiling, mafiani aniqlang!", night: "Uyquda kutasiz..." },
};

const ROLE_NAMES: Record<Role, string> = {
  godfather: "Katta Usta", mafia: "Mafia", detective: "Detektiv",
  doctor: "Shifokor", sheriff: "Meriya", witch: "Jodugar",
  jester: "Masxaraboz", bodyguard: "Himoyachi", vigilante: "Qahramon",
  mayor: "Mayor", citizen: "Fuqaro",
};

const BOT_NAMES = ["Ali","Bobur","Dildora","Farrux","Gulnora","Hamid","Iroda","Jasur","Kamola","Laziz","Malika","Nodir","Oydin","Parviz","Qodir","Rohila","Sardor","Tahminа","Ulmas","Vohid"];

const DAY_CHAT: Record<string, string[]> = {
  accuse: ["Mening fikrimcha {0} shubhali ko'rinadi", "{0} kecha juda jim edi, nima deyisiz?", "Men {0} ga ishonmayman, ovozimni shunga beraman", "{0} ning qilgan harakatlari g'alati"],
  defend: ["Men {0} ni himoya qilaman, u yaxshi odam", "{0} ga ishonish kerak, u fuqaro bo'lishi mumkin", "Nima uchun {0} ni ayblayapsiz? Isbot bormi?"],
  neutral: ["Hamma ehtiyot bo'lsin", "O'ylaylik, kimni chiqarish to'g'ri?", "Mafia bizning oramizda, ehtiyot bo'ling", "Kecha nima bo'lganini bilasizlarmi?"],
};

function randomFrom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function assignRoles(count: number): Role[] {
  const roles: Role[] = [];
  const mafiaCount = count <= 5 ? 1 : count <= 8 ? 2 : 3;
  roles.push("godfather");
  for (let i = 1; i < mafiaCount; i++) roles.push("mafia");
  roles.push("detective");
  roles.push("doctor");
  if (count >= 6)  roles.push("bodyguard");
  if (count >= 7)  roles.push("sheriff");
  if (count >= 8)  roles.push("witch");
  if (count >= 9)  roles.push("vigilante");
  if (count >= 10) roles.push("mayor");
  if (count >= 11) roles.push("jester");
  while (roles.length < count) roles.push("citizen");
  return roles.sort(() => Math.random() - 0.5);
}

export default function MafiaGame({ username, accentColor, onBack }: Props) {
  const [phase, setPhase] = useState<Phase>("modeSelect");
  const [multiplayerMode, setMultiplayerMode] = useState(false);
  const [players, setPlayers] = useState<Player[]>([]);
  const [playerCount, setPlayerCount] = useState(7);
  const [log, setLog] = useState<string[]>([]);
  const [nightTarget, setNightTarget] = useState<string | null>(null);
  const [witchAction, setWitchAction] = useState<"poison" | "protect">("poison");
  const [voteTarget, setVoteTarget] = useState<string | null>(null);
  const [dayCount, setDayCount] = useState(1);
  const [morningNews, setMorningNews] = useState<string[]>([]);
  const [sheriffUsed, setSheriffUsed] = useState(false);
  const [chatLines, setChatLines] = useState<ChatLine[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [revealStep, setRevealStep] = useState(0);
  const chatRef = useRef<HTMLDivElement>(null);
  const botTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const userPlayer = players.find(p => p.isUser);
  const alive = players.filter(p => p.alive);
  const aliveMafia = alive.filter(p => p.role === "mafia" || p.role === "godfather");
  const aliveCivil = alive.filter(p => p.role !== "mafia" && p.role !== "godfather");

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [chatLines]);

  useEffect(() => {
    if (phase === "discussion") {
      const sendBotChats = (): void => {
        const aliveBots = players.filter(p => p.alive && !p.isUser);
        if (aliveBots.length === 0) return;
        const speaker = randomFrom(aliveBots);
        const victims = alive.filter(p => p.name !== speaker.name);
        if (victims.length === 0) return;
        const victim = randomFrom(victims);
        let pool: string[];
        if (speaker.role === "mafia" || speaker.role === "godfather") {
          pool = [...DAY_CHAT.defend, ...DAY_CHAT.neutral];
        } else {
          pool = [...DAY_CHAT.accuse, ...DAY_CHAT.neutral];
        }
        const text = randomFrom(pool).replace("{0}", victim.name);
        setChatLines(prev => [...prev, { from: speaker.name, text, ts: Date.now() }]);
        botTimerRef.current = setTimeout(sendBotChats, 2500 + Math.random() * 2500);
      };
      botTimerRef.current = setTimeout(sendBotChats, 1000);
      return () => { if (botTimerRef.current) clearTimeout(botTimerRef.current); };
    }
    return undefined;
  }, [phase]);

  function startGame() {
    const bots = BOT_NAMES.sort(() => Math.random() - 0.5).slice(0, playerCount - 1);
    const names = [username, ...bots];
    const roles = assignRoles(playerCount);
    const ps: Player[] = names.map((name, i) => ({
      name, role: roles[i], alive: true, isUser: name === username,
    }));
    setPlayers(ps);
    setLog([`🎮 O'yin boshlandi! ${playerCount} ta o'yinchi.`]);
    setDayCount(1);
    setSheriffUsed(false);
    setChatLines([]);
    setMorningNews([]);
    setRevealStep(0);
    setPhase("roleReveal");
  }

  function doNight() {
    const current = [...players];
    const news: string[] = [];

    const userRole = userPlayer?.role;
    const targetPlayer = current.find(p => p.name === nightTarget);

    // Mafia kills — godfather commands
    const mafiaTeam = current.filter(p => (p.role === "mafia" || p.role === "godfather") && p.alive && !p.isUser);
    const civilTargets = alive.filter(p => p.role !== "mafia" && p.role !== "godfather");
    let mafiaKillName: string | null = null;

    if (userRole === "mafia" || userRole === "godfather") {
      mafiaKillName = nightTarget;
    } else if (mafiaTeam.length > 0) {
      mafiaKillName = civilTargets[Math.floor(Math.random() * civilTargets.length)]?.name || null;
    }

    // Doctor saves
    const botDoc = current.find(p => p.role === "doctor" && p.alive && !p.isUser);
    let doctorSave: string | null = null;
    if (botDoc) {
      const cands = alive.filter(p => p.name !== botDoc.name);
      doctorSave = cands[Math.floor(Math.random() * cands.length)]?.name || null;
    } else if (userRole === "doctor") {
      doctorSave = nightTarget;
    }

    // Detective checks
    const botDet = current.find(p => p.role === "detective" && p.alive && !p.isUser);
    if (botDet) {
      const cands = alive.filter(p => p.name !== botDet.name);
      const checked = cands[Math.floor(Math.random() * cands.length)];
      if (checked) {
        const isMaf = checked.role === "mafia" || checked.role === "godfather";
        news.push(`🔍 Detektiv ${botDet.name}: @${checked.name} — ${isMaf ? "🔴 MAFIA" : "✅ Fuqaro"}`);
      }
    }
    if (userRole === "detective" && nightTarget) {
      const t = current.find(p => p.name === nightTarget);
      const isMaf = t?.role === "mafia" || t?.role === "godfather";
      news.push(`🔍 Tekshiruv: @${nightTarget} — ${isMaf ? "🔴 MAFIA!" : "✅ Fuqaro"}`);
    }

    // Sheriff action
    if (userRole === "sheriff" && nightTarget && !sheriffUsed) {
      setSheriffUsed(true);
      const t = current.find(p => p.name === nightTarget);
      if (t && (t.role === "mafia" || t.role === "godfather")) {
        setPlayers(prev => prev.map(p => p.name === nightTarget ? { ...p, alive: false } : p));
        news.push(`⭐ Meriya @${nightTarget}ni otdi — u MAFIA edi!`);
        mafiaKillName = null;
      } else {
        setPlayers(prev => prev.map(p => p.isUser ? { ...p, alive: false } : p));
        news.push(`⭐ Meriya noto'g'ri odamni otdi — fuqaroni o'ldirdi va o'zi ham halok bo'ldi!`);
      }
    }

    // Witch action
    let witchPoisoned: string | null = null;
    const botWitch = current.find(p => p.role === "witch" && p.alive && !p.isUser);
    if (botWitch) {
      const cands = alive.filter(p => p.name !== botWitch.name);
      const pick = cands[Math.floor(Math.random() * cands.length)];
      if (pick && Math.random() > 0.5) witchPoisoned = pick.name;
    } else if (userRole === "witch" && nightTarget) {
      if (witchAction === "poison") witchPoisoned = nightTarget;
      else doctorSave = nightTarget;
    }

    // Apply mafia kill
    let killed: string | null = null;
    if (mafiaKillName && mafiaKillName !== doctorSave) {
      killed = mafiaKillName;
    }

    // Apply witch poison (kills next morning)
    let newPlayers = [...current];
    if (killed) {
      newPlayers = newPlayers.map(p => p.name === killed ? { ...p, alive: false } : p);
      news.push(`💀 Mafia @${killed}ni o'ldirdi!`);
    } else if (mafiaKillName) {
      news.push(`💊 Shifokor @${mafiaKillName}ni qutqardi!`);
    } else {
      news.push(`🌙 Bu kecha hech kim o'lmadi.`);
    }
    if (witchPoisoned) {
      newPlayers = newPlayers.map(p => p.name === witchPoisoned ? { ...p, poisoned: true } : p);
      news.push(`🧙 Kimdir zaharlanmoqda...`);
    }

    setPlayers(newPlayers);
    setMorningNews(news);
    setNightTarget(null);

    const ua = newPlayers.filter(p => p.alive);
    const um = ua.filter(p => p.role === "mafia" || p.role === "godfather");
    const uc = ua.filter(p => p.role !== "mafia" && p.role !== "godfather");

    if (um.length === 0) {
      const jester = players.find(p => p.role === "jester");
      if (jester && !jester.alive) {
        setLog(l => [...l, `\n🃏 Masxaraboz ${jester.name} yutdi! (o'limga chiqarilgan)`]);
        setPhase("end"); return;
      }
      setLog(l => [...l, "\n🏆 FUQAROLAR YUTDI!"]);
      setPhase("end"); return;
    }
    if (um.length >= uc.length) {
      setLog(l => [...l, "\n💀 MAFIA YUTDI!"]);
      setPhase("end"); return;
    }
    setLog(l => [...l, `\n🌙 ${dayCount}-kecha yakunlandi.`]);
    setPhase("morning");
  }

  function goToDiscussion() {
    // Apply witch poison deaths
    const poisoned = players.filter(p => p.poisoned && p.alive);
    if (poisoned.length > 0) {
      const news2 = poisoned.map(p => `☠️ @${p.name} zahardan o'ldi!`);
      setPlayers(prev => prev.map(p => p.poisoned ? { ...p, alive: false, poisoned: false } : p));
      setMorningNews(n => [...n, ...news2]);
    }
    setChatLines([]);
    setPhase("discussion");
  }

  function sendChat(e: React.FormEvent) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatLines(prev => [...prev, { from: username, text: chatInput.trim(), ts: Date.now() }]);
    setChatInput("");
  }

  function doVote() {
    if (!voteTarget) return;
    if (botTimerRef.current) clearTimeout(botTimerRef.current);
    const botVotes = new Map<string, number>();
    alive.filter(p => !p.isUser).forEach(p => {
      const candidates = alive.filter(c => c.name !== p.name);
      const mafiaPrefer = candidates.find(c => c.role !== "mafia" && c.role !== "godfather" && Math.random() > 0.3);
      const t = (p.role === "mafia" || p.role === "godfather") && mafiaPrefer ? mafiaPrefer.name : randomFrom(candidates).name;
      botVotes.set(t, (botVotes.get(t) || 0) + 1);
    });
    botVotes.set(voteTarget, (botVotes.get(voteTarget) || 0) + 1);

    let maxVotes = 0;
    let eliminated = "";
    botVotes.forEach((v, name) => { if (v > maxVotes) { maxVotes = v; eliminated = name; } });

    const elim = players.find(p => p.name === eliminated);
    const newLog: string[] = [`\n☀️ ${dayCount}-kun ovoz berish:`];
    newLog.push(`🗳️ @${eliminated} ${maxVotes} ovoz bilan chiqarildi! (${ROLE_NAMES[elim?.role || "citizen"]})`);

    const newPlayers = players.map(p => p.name === eliminated ? { ...p, alive: false } : p);
    setPlayers(newPlayers);
    setLog(prev => [...prev, ...newLog]);
    setVoteTarget(null);
    setChatLines([]);

    const ua = newPlayers.filter(p => p.alive);
    const um = ua.filter(p => p.role === "mafia" || p.role === "godfather");
    const uc = ua.filter(p => p.role !== "mafia" && p.role !== "godfather");

    // Jester wins if eliminated by vote
    if (elim?.role === "jester") {
      setLog(l => [...l, "\n🃏 Masxaraboz YUTDI! U chiqarilishni kutardi!"]);
      setPhase("end"); return;
    }
    if (um.length === 0) { setLog(l => [...l, "\n🏆 FUQAROLAR YUTDI!"]); setPhase("end"); return; }
    if (um.length >= uc.length) { setLog(l => [...l, "\n💀 MAFIA YUTDI!"]); setPhase("end"); return; }

    setDayCount(d => d + 1);
    setPhase("night");
    setNightTarget(null);
  }

  // ── MULTIPLAYER MODE ────────────────────────────────────────────────────
  if (multiplayerMode) {
    return <MultiplayerMafiaGame username={username} accentColor={accentColor} onBack={() => setMultiplayerMode(false)} />;
  }

  // ── MODE SELECT ──────────────────────────────────────────────────────────
  if (phase === "modeSelect") {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90" style={{ backdropFilter: "blur(12px)" }}>
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <span className="text-xl">🕵️</span>
          <div><p className="font-black text-sm text-white">MAFIA</p><p className="text-[9px] text-slate-500">O'yin rejimini tanlang</p></div>
        </header>
        <div className="flex-1 overflow-y-auto flex flex-col items-center justify-center p-6 gap-6">
          <div className="text-center space-y-2">
            <div className="text-6xl mb-1">🕵️</div>
            <h2 className="text-3xl font-black text-white tracking-tight">MAFIA</h2>
            <p className="text-sm text-slate-400">Kim mafia? Kim fuqaro? Kimga ishonish mumkin?</p>
          </div>

          <div className="w-full max-w-sm space-y-3">
            <button onClick={() => setPhase("setup")}
              className="w-full p-5 rounded-2xl border border-slate-700 hover:border-slate-500 text-left transition group active:scale-[0.98]"
              style={{ background: "linear-gradient(135deg,#1a0a0a,#0a0014)" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ background: "linear-gradient(135deg,#dc2626,#7c3aed)" }}>🤖</div>
                <div>
                  <p className="font-black text-base text-white">AI bilan o'ynash</p>
                  <p className="text-xs text-slate-400 mt-0.5">Botlarga qarshi o'ynang • 5-12 o'yinchi</p>
                  <div className="flex gap-1 mt-1.5 flex-wrap">
                    {["🎩 Katta Usta", "🔍 Detektiv", "🛡️ Himoyachi", "⚡ Qahramon"].map(r => (
                      <span key={r} className="text-[9px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400">{r}</span>
                    ))}
                  </div>
                </div>
                <span className="ml-auto text-slate-600 group-hover:text-slate-400 text-xl">›</span>
              </div>
            </button>

            <button onClick={() => setMultiplayerMode(true)}
              className="w-full p-5 rounded-2xl border border-purple-900/60 hover:border-purple-700 text-left transition group active:scale-[0.98]"
              style={{ background: "linear-gradient(135deg,#0a0014,#1a0a1a)" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ background: "linear-gradient(135deg,#7c3aed,#1d4ed8)" }}>👥</div>
                <div>
                  <p className="font-black text-base text-white">Multiplayer</p>
                  <p className="text-xs text-slate-400 mt-0.5">Do'stlaringiz bilan • Firebase real-time</p>
                  <div className="flex gap-1 mt-1.5 flex-wrap">
                    {["⏱️ 5 daqiqa timer", "🔑 Xona kodi", "4-12 o'yinchi"].map(r => (
                      <span key={r} className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-950/50 text-purple-400">{r}</span>
                    ))}
                  </div>
                </div>
                <span className="ml-auto text-purple-700 group-hover:text-purple-400 text-xl">›</span>
              </div>
            </button>
          </div>

          {/* All roles preview */}
          <div className="w-full max-w-sm p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">11 ta rol mavjud</p>
            <div className="grid grid-cols-2 gap-1.5">
              {(Object.entries(ROLE_INFO) as [Role, typeof ROLE_INFO[Role]][]).map(([, ri]) => (
                <div key={ri.shortDesc} className="flex items-center gap-2 p-1.5 rounded-lg" style={{ background: `${ri.color}10` }}>
                  <span className="text-sm">{ri.icon}</span>
                  <div>
                    <p className="text-[9px] font-black" style={{ color: ri.color }}>{ri.shortDesc}</p>
                    <p className="text-[8px] text-slate-600">{ri.team === "mafia" ? "Mafia" : ri.team === "solo" ? "Solo" : "Shahar"}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── SETUP ───────────────────────────────────────────────────────────────
  if (phase === "setup") {
    const previewRoles = assignRoles(playerCount);
    const roleCounts: Partial<Record<Role, number>> = {};
    previewRoles.forEach(r => { roleCounts[r] = (roleCounts[r] || 0) + 1; });
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90" style={{ backdropFilter: "blur(12px)" }}>
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <span className="text-xl">🕵️</span>
          <div><p className="font-black text-sm text-white">MAFIA</p><p className="text-[9px] text-slate-500">Psixologik deduktiv o'yin</p></div>
        </header>
        <div className="flex-1 overflow-y-auto flex flex-col items-center p-6 gap-6">
          <div className="text-center space-y-1">
            <div className="text-6xl mb-2">🕵️</div>
            <h2 className="text-3xl font-black text-white tracking-tight">MAFIA</h2>
            <p className="text-sm text-slate-400">Kim mafia? Kim fuqaro? Kimga ishonish mumkin?</p>
          </div>

          {/* Player count */}
          <div className="w-full max-w-sm p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">O'yinchilar soni</p>
            <div className="flex items-center gap-4">
              <button onClick={() => setPlayerCount(c => Math.max(5, c - 1))} className="w-12 h-12 rounded-xl bg-slate-800 text-white font-black text-xl hover:bg-slate-700 transition active:scale-95">−</button>
              <div className="flex-1 text-center">
                <p className="text-4xl font-black text-white">{playerCount}</p>
                <p className="text-[10px] text-slate-500">1 siz + {playerCount - 1} bot</p>
              </div>
              <button onClick={() => setPlayerCount(c => Math.min(15, c + 1))} className="w-12 h-12 rounded-xl bg-slate-800 text-white font-black text-xl hover:bg-slate-700 transition active:scale-95">+</button>
            </div>
          </div>

          {/* Role cards */}
          <div className="w-full max-w-sm space-y-2">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Rollar ({playerCount} o'yinchi)</p>
            {(Object.keys(roleCounts) as Role[]).map(r => {
              const ri = ROLE_INFO[r];
              return (
                <div key={r} className="flex items-center gap-3 p-3 rounded-xl border" style={{ background: `${ri.color}0d`, borderColor: `${ri.color}30` }}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg" style={{ background: `${ri.color}20` }}>{ri.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-bold text-white">{ROLE_NAMES[r]}</p>
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full font-black uppercase" style={{ background: ri.team === "mafia" ? "#7f1d1d" : ri.team === "solo" ? "#500724" : "#14532d", color: ri.team === "mafia" ? "#fca5a5" : ri.team === "solo" ? "#f9a8d4" : "#86efac" }}>
                        {ri.team === "mafia" ? "Mafia" : ri.team === "solo" ? "Yolg'iz" : "Shahar"}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">{ri.shortDesc}</p>
                  </div>
                  <span className="text-sm font-black" style={{ color: ri.color }}>×{roleCounts[r]}</span>
                </div>
              );
            })}
          </div>

          <button onClick={startGame} className="w-full max-w-sm py-4 rounded-2xl font-black text-base text-white shadow-xl transition active:scale-95" style={{ background: `linear-gradient(135deg, #dc2626, #7c3aed)` }}>
            🎮 O'yinni Boshlash
          </button>
        </div>
      </div>
    );
  }

  // ── ROLE REVEAL ─────────────────────────────────────────────────────────
  if (phase === "roleReveal") {
    const ur = userPlayer?.role || "citizen";
    const ri = ROLE_INFO[ur];
    const mafiaTeam = players.filter(p => (p.role === "mafia" || p.role === "godfather") && !p.isUser);
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 gap-6 text-center" style={{ background: "radial-gradient(circle at 50% 40%, #0f0019, #030712)" }}>
        <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sizning rolingiz</p>
        <div className="relative">
          <div className="w-36 h-36 rounded-3xl flex items-center justify-center text-7xl shadow-2xl border-2" style={{ background: `linear-gradient(135deg, ${ri.color}30, ${ri.color}10)`, borderColor: `${ri.color}50`, boxShadow: `0 0 60px ${ri.color}40` }}>
            {ri.icon}
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-3xl font-black text-white">{ROLE_NAMES[ur]}</p>
          <span className="inline-block text-[10px] px-2 py-0.5 rounded-full font-black uppercase" style={{ background: ri.team === "mafia" ? "#7f1d1d" : ri.team === "solo" ? "#500724" : "#14532d", color: ri.team === "mafia" ? "#fca5a5" : ri.team === "solo" ? "#f9a8d4" : "#86efac" }}>
            {ri.team === "mafia" ? "Mafia jamoasi" : ri.team === "solo" ? "Yolg'iz o'yinchi" : "Shahar jamoasi"}
          </span>
          <p className="text-sm text-slate-300 max-w-xs leading-relaxed mt-2">{ri.desc}</p>
        </div>
        {(ur === "mafia" || ur === "godfather") && mafiaTeam.length > 0 && (
          <div className="p-3 rounded-xl border border-red-900/50 bg-red-950/30 text-sm">
            <p className="text-red-400 font-bold mb-1">🕵️ Mafia hamkorlaringiz:</p>
            {mafiaTeam.map(p => <p key={p.name} className="text-red-300 text-xs">{ROLE_INFO[p.role].icon} @{p.name}</p>)}
          </div>
        )}
        <button onClick={() => setPhase("night")} className="w-full max-w-xs py-4 rounded-2xl font-black text-base text-white" style={{ background: `linear-gradient(135deg, ${ri.color}, #1e293b)` }}>
          🌙 Kechaga Kirish
        </button>
      </div>
    );
  }

  // ── END ─────────────────────────────────────────────────────────────────
  if (phase === "end") {
    const lastLog = log[log.length - 1] || "";
    const mafiaWon = lastLog.includes("MAFIA YUTDI");
    const jesterWon = lastLog.includes("Masxaraboz YUTDI");
    const userWon = userPlayer?.role === "jester" ? jesterWon
      : (userPlayer?.role === "mafia" || userPlayer?.role === "godfather") ? mafiaWon : !mafiaWon;
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90">
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <p className="font-black text-sm text-white">O'yin Yakunlandi</p>
        </header>
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="text-center space-y-3">
            <p className="text-7xl">{userWon ? "🏆" : "😔"}</p>
            <p className="text-3xl font-black" style={{ color: userWon ? "#22c55e" : "#ef4444" }}>
              {userWon ? "YUTDINGIZ!" : "YUTQAZDINGIZ!"}
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm" style={{ background: `${ROLE_INFO[userPlayer?.role || "citizen"].color}20`, color: ROLE_INFO[userPlayer?.role || "citizen"].color }}>
              <span>{ROLE_INFO[userPlayer?.role || "citizen"].icon}</span>
              <span className="font-bold">{ROLE_NAMES[userPlayer?.role || "citizen"]} edingiz</span>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Barcha rollar</p>
            {players.map(p => {
              const ri = ROLE_INFO[p.role];
              return (
                <div key={p.name} className={`flex items-center gap-3 p-3 rounded-xl border transition ${!p.alive ? "opacity-40" : ""}`} style={{ borderColor: `${ri.color}30`, background: `${ri.color}08` }}>
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm" style={{ background: `${ri.color}25` }}>{ri.icon}</div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-white">{p.isUser ? `${p.name} (Siz)` : p.name}</p>
                    <p className="text-[10px]" style={{ color: ri.color }}>{ROLE_NAMES[p.role]}{!p.alive ? " · 💀 O'ldi" : " · ✅ Omon"}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5 font-mono text-[11px] text-slate-400 max-h-40 overflow-y-auto">
            {log.map((l, i) => <p key={i}>{l}</p>)}
          </div>

          <div className="flex gap-3">
            <button onClick={() => setPhase("setup")} className="flex-1 py-3 rounded-xl font-bold text-sm border border-slate-700 text-slate-300 hover:bg-slate-800 transition">Sozlamalar</button>
            <button onClick={startGame} className="flex-1 py-3 rounded-xl font-bold text-sm text-white" style={{ background: "linear-gradient(135deg,#dc2626,#7c3aed)" }}>🔄 Qayta O'ynash</button>
          </div>
        </div>
      </div>
    );
  }

  // ── MAIN GAME PHASES ─────────────────────────────────────────────────────
  const phaseColors: Record<string, { bg: string; border: string; text: string; label: string }> = {
    night:      { bg: "#0a0014", border: "#3b1d5e", text: "#c084fc", label: "🌙 KECHA" },
    morning:    { bg: "#0a0500", border: "#713f12", text: "#fbbf24", label: "🌅 TONG" },
    discussion: { bg: "#001a0a", border: "#14532d", text: "#4ade80", label: "💬 MUHOKAMA" },
    vote:       { bg: "#1a0000", border: "#7f1d1d", text: "#f87171", label: "🗳️ OVOZ" },
  };
  const pc = phaseColors[phase] || phaseColors.night;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90" style={{ backdropFilter: "blur(12px)" }}>
        <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
        <span className="text-lg">🕵️</span>
        <div className="flex-1">
          <p className="font-black text-sm text-white">Mafia — {dayCount}-{phase === "night" ? "kecha" : "kun"}</p>
          <p className="text-[10px] text-slate-500">Tirik: {alive.length} · Mafia: {aliveMafia.length} · Shahar: {aliveCivil.length}</p>
        </div>
        <span className="px-2.5 py-1 rounded-lg text-[10px] font-black border" style={{ background: pc.bg, borderColor: pc.border, color: pc.text }}>{pc.label}</span>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* User role card */}
        {userPlayer && (
          <div className="p-3 rounded-xl border flex items-center gap-3" style={{ background: `${ROLE_INFO[userPlayer.role].color}10`, borderColor: `${ROLE_INFO[userPlayer.role].color}35` }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-2xl flex-shrink-0" style={{ background: `${ROLE_INFO[userPlayer.role].color}20` }}>
              {ROLE_INFO[userPlayer.role].icon}
            </div>
            <div className="flex-1">
              <p className="text-[10px] text-slate-500">Sizning rolingiz</p>
              <p className="text-sm font-black" style={{ color: ROLE_INFO[userPlayer.role].color }}>{ROLE_NAMES[userPlayer.role]}</p>
            </div>
            {!userPlayer.alive && <span className="text-xs text-slate-500 font-bold">💀 O'ldinggiz</span>}
            {userPlayer.role === "sheriff" && <span className="text-[9px] px-1.5 py-0.5 rounded font-black" style={{ background: sheriffUsed ? "#450a0a" : "#14532d", color: sheriffUsed ? "#fca5a5" : "#86efac" }}>{sheriffUsed ? "O'q ishlatildi" : "O'q bor"}</span>}
          </div>
        )}

        {/* NIGHT PHASE */}
        {phase === "night" && (
          <div className="space-y-3">
            <p className="text-xs font-black text-slate-400 uppercase tracking-wider">{userPlayer?.alive ? ROLE_INFO[userPlayer?.role || "citizen"].night : "💀 Vafot etgansiz — kuzating"}</p>
            {userPlayer?.alive && userPlayer.role === "witch" && (
              <div className="flex gap-2 mb-2">
                {(["poison", "protect"] as const).map(a => (
                  <button key={a} onClick={() => setWitchAction(a)} className="flex-1 py-2 rounded-xl text-xs font-bold border transition" style={{ borderColor: witchAction === a ? "#a855f7" : "#334155", background: witchAction === a ? "#3b0764" : "transparent", color: witchAction === a ? "#e9d5ff" : "#64748b" }}>
                    {a === "poison" ? "☠️ Zaharlamoq" : "🛡️ Himoya qilmoq"}
                  </button>
                ))}
              </div>
            )}
            {alive.filter(p => !p.isUser).map(p => (
              <button key={p.name} onClick={() => {
                const canAct = userPlayer?.alive && userPlayer.role !== "citizen";
                if (!canAct) return;
                if (userPlayer.role === "sheriff" && sheriffUsed) return;
                setNightTarget(nightTarget === p.name ? null : p.name);
              }}
                disabled={!userPlayer?.alive || userPlayer.role === "citizen"}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border transition ${nightTarget === p.name ? "border-purple-500 bg-purple-950/25" : "border-slate-700 bg-slate-900 hover:border-slate-500"} disabled:opacity-40 disabled:cursor-not-allowed`}>
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black" style={{ background: `${accentColor}22`, color: accentColor }}>{p.name[0]}</div>
                <p className="text-sm font-bold text-white flex-1 text-left">{p.name}</p>
                {nightTarget === p.name && <span className="text-purple-400 font-black">✓</span>}
              </button>
            ))}
            <button onClick={doNight} disabled={!userPlayer?.alive || (userPlayer.role !== "citizen" && userPlayer.role !== "jester" && !nightTarget && !(userPlayer.role === "sheriff" && sheriffUsed))}
              className="w-full py-3.5 rounded-xl font-black text-sm disabled:opacity-40 transition active:scale-95"
              style={{ background: "linear-gradient(135deg,#7c3aed,#1e1b4b)" }}>
              {userPlayer?.role === "citizen" || userPlayer?.role === "jester" ? "🌙 Kechani O'tkazish" : "✅ Harakatni Tasdiqlash"}
            </button>
          </div>
        )}

        {/* MORNING PHASE */}
        {phase === "morning" && (
          <div className="space-y-3">
            <p className="text-xs font-black text-amber-400 uppercase tracking-wider">🌅 Tong yangiliklari</p>
            <div className="space-y-2">
              {morningNews.map((n, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-200 font-mono">{n}</div>
              ))}
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <p className="text-[10px] text-slate-500 uppercase font-bold mb-2">Tirik o'yinchilar</p>
              <div className="flex flex-wrap gap-1.5">
                {alive.filter(p => !morningNews.some(n => n.includes(p.name) && n.includes("o'ldi"))).map(p => (
                  <span key={p.name} className="px-2 py-1 rounded-lg text-xs font-bold bg-slate-800 text-slate-300">{p.isUser ? `${p.name} (Siz)` : p.name}</span>
                ))}
              </div>
            </div>
            <button onClick={goToDiscussion} className="w-full py-3.5 rounded-xl font-black text-sm text-white transition active:scale-95" style={{ background: "linear-gradient(135deg,#15803d,#0f172a)" }}>
              💬 Muhokamaga O'tish
            </button>
          </div>
        )}

        {/* DISCUSSION PHASE */}
        {phase === "discussion" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black text-green-400 uppercase tracking-wider">💬 Muhokama — Kim mafia?</p>
              <button onClick={() => setPhase("vote")} className="px-3 py-1.5 rounded-lg text-xs font-black text-white" style={{ background: "#dc2626" }}>
                🗳️ Ovoz berishga o'tish
              </button>
            </div>
            <div ref={chatRef} className="h-56 overflow-y-auto space-y-2 p-3 rounded-xl bg-slate-950 border border-slate-800">
              {chatLines.length === 0 && <p className="text-xs text-slate-600 text-center py-4">Muhokama boshlanmoqda...</p>}
              {chatLines.map((c, i) => (
                <div key={i} className={`flex gap-2 ${c.from === username ? "flex-row-reverse" : ""}`}>
                  <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0" style={{ background: c.from === username ? accentColor : "#334155" }}>{c.from[0]}</div>
                  <div className={`max-w-[75%] px-2.5 py-1.5 rounded-xl text-xs ${c.from === username ? "bg-blue-950/50 text-blue-100" : "bg-slate-900 text-slate-200"}`}>
                    {c.from !== username && <span className="text-[9px] font-bold block mb-0.5" style={{ color: accentColor }}>@{c.from}</span>}
                    {c.text}
                  </div>
                </div>
              ))}
            </div>
            {userPlayer?.alive && (
              <form onSubmit={sendChat} className="flex gap-2">
                <input value={chatInput} onChange={e => setChatInput(e.target.value)} placeholder="Fikringizni ayting..." className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-600 outline-none focus:border-slate-500" />
                <button type="submit" className="px-4 py-2 rounded-xl text-sm font-black text-white" style={{ background: accentColor }}>→</button>
              </form>
            )}
          </div>
        )}

        {/* VOTE PHASE */}
        {phase === "vote" && (
          <div className="space-y-2">
            <p className="text-xs font-black text-red-400 uppercase tracking-wider">🗳️ Kim chiqarilsin?</p>
            {alive.filter(p => !p.isUser).map(p => (
              <button key={p.name} onClick={() => setVoteTarget(voteTarget === p.name ? null : p.name)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border transition ${voteTarget === p.name ? "border-rose-500 bg-rose-950/25" : "border-slate-700 bg-slate-900 hover:border-slate-500"}`}>
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black bg-red-950/30 text-red-400">{p.name[0]}</div>
                <p className="text-sm font-bold text-white flex-1 text-left">{p.name}</p>
                {voteTarget === p.name && <span className="text-rose-400 font-black">✓</span>}
              </button>
            ))}
            <button onClick={doVote} disabled={!voteTarget} className="w-full py-3.5 rounded-xl font-black text-sm text-white mt-2 disabled:opacity-40 transition active:scale-95" style={{ background: "#dc2626" }}>
              🚨 Chiqarish
            </button>
          </div>
        )}

        {/* Game log */}
        {log.length > 0 && (
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-0.5">
            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">O'yin tarixi</p>
            {log.slice(-8).map((l, i) => <p key={i} className="font-mono text-[10px] text-slate-500">{l}</p>)}
          </div>
        )}
      </div>
    </div>
  );
}
