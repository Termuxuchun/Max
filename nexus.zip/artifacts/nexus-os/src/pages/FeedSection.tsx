import { useEffect, useRef, useState } from "react";
import { ref, push, onValue, set, remove, get, update } from "firebase/database";
import { db } from "../firebase";
import { compressAndUpload, uploadToStorage } from "../lib/uploadMedia";

interface Props {
  username: string;
  accentColor: string;
  isPremium: boolean;
  onOpenProfile: (u: string) => void;
}

interface Story { id: string; author: string; mediaUrl?: string; mediaType: "image" | "video"; text?: string; ts: number; expiresAt: number; viewers?: Record<string, number>; premium?: boolean; animation?: string; mc?: Record<string, string>; mcc?: number; }
interface Post { id: string; author: string; mediaUrl?: string; mediaType?: "image" | "video"; text: string; ts: number; likes?: Record<string, boolean>; comments?: Record<string, { from: string; text: string; ts: number }>; views?: Record<string, number>; premium?: boolean; animation?: string; mc?: Record<string, string>; mcc?: number; }

const FREE_STORY_LIMIT = 3;
const PREMIUM_STORY_LIMIT = 30;
const FREE_STORY_DURATION_MS = 24 * 60 * 60 * 1000; // 24h
const PREMIUM_STORY_DURATION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const FREE_MAX_BYTES  = 2  * 1024 * 1024; // 2MB  – rasm uchun
const FREE_VIDEO_MAX  = 15 * 1024 * 1024; // 15MB – video uchun (free)
const PREM_VIDEO_MAX  = 50 * 1024 * 1024; // 50MB – video uchun (premium)
const PREMIUM_MAX_BYTES = Infinity;

export default function FeedSection({ username, accentColor, isPremium, onOpenProfile }: Props) {
  const [stories, setStories] = useState<Story[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [showStoryUpload, setShowStoryUpload] = useState(false);
  const [showPostUpload, setShowPostUpload] = useState(false);
  const [viewerGroup, setViewerGroup] = useState<{ author: string; items: Story[]; index: number } | null>(null);
  const [showViewersOf, setShowViewersOf] = useState<Story | null>(null);
  const [commentingOn, setCommentingOn] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState("");
  const [feedTab, setFeedTab] = useState<"all" | "trending" | "saved" | "friends">("all");
  const [friendsSet, setFriendsSet] = useState<Set<string>>(new Set());
  const [savedPosts, setSavedPosts] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(`nexus_saved_posts_${username}`) || "[]"); } catch { return []; }
  });

  useEffect(() => {
    return onValue(ref(db, `friends/${username}`), snap => {
      const s = new Set<string>();
      snap.forEach(c => { if (c.val()?.since) s.add(c.key!); });
      setFriendsSet(s);
    });
  }, [username]);

  function toggleSave(postId: string) {
    const next = savedPosts.includes(postId) ? savedPosts.filter(id => id !== postId) : [...savedPosts, postId];
    setSavedPosts(next);
    localStorage.setItem(`nexus_saved_posts_${username}`, JSON.stringify(next));
  }

  useEffect(() => {
    const u1 = onValue(ref(db, "stories"), s => {
      const now = Date.now();
      const list: Story[] = [];
      if (s.exists()) {
        s.forEach(authorSnap => {
          authorSnap.forEach(c => {
            const v = c.val() as Story;
            if (v.expiresAt > now) list.push({ ...v, id: c.key!, author: authorSnap.key! });
          });
        });
      }
      list.sort((a, b) => b.ts - a.ts);
      setStories(list);
    });
    const u2 = onValue(ref(db, "posts"), s => {
      const list: Post[] = [];
      if (s.exists()) s.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => b.ts - a.ts);
      setPosts(list);
    });
    return () => { u1(); u2(); };
  }, []);

  // Group stories by author
  const storyGroups = stories.reduce<Record<string, Story[]>>((acc, s) => {
    (acc[s.author] = acc[s.author] || []).push(s);
    return acc;
  }, {});
  // Put self first
  const orderedAuthors = Object.keys(storyGroups).sort((a, b) => {
    if (a === username) return -1;
    if (b === username) return 1;
    return (storyGroups[b][0]?.ts || 0) - (storyGroups[a][0]?.ts || 0);
  });

  async function uploadStory(file: File, text: string, animation: string, onProgress: (p: number) => void) {
    const mineCount = (storyGroups[username] || []).length;
    const limit = isPremium ? PREMIUM_STORY_LIMIT : FREE_STORY_LIMIT;
    if (mineCount >= limit) { alert(`Sizda ${mineCount} ta story bor. Limit: ${limit}.`); return; }

    const mediaType: "image" | "video" = file.type.startsWith("video") ? "video" : "image";
    const maxVideo = isPremium ? PREM_VIDEO_MAX : FREE_VIDEO_MAX;
    if (mediaType === "video" && file.size > maxVideo) {
      alert(`Video juda katta. Maksimum: ${isPremium ? "50MB" : "15MB"}`); return;
    }

    const now = Date.now();
    const duration = isPremium ? PREMIUM_STORY_DURATION_MS : FREE_STORY_DURATION_MS;
    try {
      const newRef = push(ref(db, `stories/${username}`));
      const storyId = newRef.key!;
      const ext = mediaType === "video" ? "mp4" : "jpg";
      const storagePath = `stories/${username}/${storyId}/media.${ext}`;

      let mediaUrl: string;
      if (mediaType === "image") {
        mediaUrl = await compressAndUpload(storagePath, file, onProgress, 1200, 0.82);
      } else {
        mediaUrl = await uploadToStorage(storagePath, file, onProgress);
      }

      await set(newRef, {
        mediaType, mediaUrl, text: text || "", ts: now,
        expiresAt: now + duration, premium: isPremium,
        animation: isPremium ? animation : "none", viewers: {},
      });
      setShowStoryUpload(false);
    } catch (err: unknown) {
      alert("Story saqlashda xato: " + (err instanceof Error ? err.message : String(err)));
    }
  }

  async function uploadPost(file: File | null, text: string, animation: string = "none", onProgress: (p: number) => void = () => {}) {
    const trimmed = text.trim();
    if (!trimmed && !file) { alert("Matn yoki media kerak"); return; }

    let mediaUrl: string | undefined;
    let mediaType: "image" | "video" | undefined;

    const postMeta: Record<string, unknown> = {
      author: username, text: trimmed || "", ts: Date.now(),
    };
    if (isPremium) postMeta.premium = true;
    if (animation && animation !== "none" && isPremium) postMeta.animation = animation;

    try {
      const newRef = push(ref(db, "posts"));
      const postId = newRef.key!;

      if (file) {
        if (file.type.startsWith("image/")) {
          mediaType = "image";
          mediaUrl = await compressAndUpload(`posts/${postId}/media.jpg`, file, onProgress, 1200, 0.82);
        } else if (file.type.startsWith("video/")) {
          const maxVideo = isPremium ? PREM_VIDEO_MAX : FREE_VIDEO_MAX;
          if (file.size > maxVideo) { alert(`Video juda katta. Maksimum: ${isPremium ? "50MB" : "15MB"}`); return; }
          mediaType = "video";
          mediaUrl = await uploadToStorage(`posts/${postId}/media.mp4`, file, onProgress);
        }
        postMeta.mediaType = mediaType;
        postMeta.mediaUrl = mediaUrl;
      }

      onProgress(95);
      await set(newRef, postMeta);
      onProgress(100);
      setShowPostUpload(false);
    } catch (err: unknown) {
      alert("Post saqlashda xato: " + (err instanceof Error ? err.message : String(err)));
    }
  }

  async function recordStoryView(story: Story) {
    if (story.author === username) return;
    await set(ref(db, `stories/${story.author}/${story.id}/viewers/${username}`), Date.now());
  }

  async function recordPostView(post: Post) {
    if (post.author === username) return;
    if (post.views?.[username]) return;
    await set(ref(db, `posts/${post.id}/views/${username}`), Date.now());
  }

  async function toggleLike(post: Post) {
    const liked = post.likes?.[username];
    await set(ref(db, `posts/${post.id}/likes/${username}`), liked ? null : true);
  }

  async function sendComment(post: Post) {
    if (!commentText.trim()) return;
    await push(ref(db, `posts/${post.id}/comments`), {
      from: username, text: commentText.trim(), ts: Date.now(),
    });
    setCommentText("");
  }

  async function deletePost(post: Post) {
    if (post.author !== username) return;
    if (!confirm("Postni o'chirasizmi?")) return;
    await remove(ref(db, `posts/${post.id}`));
  }

  async function deleteStory(s: Story) {
    if (s.author !== username) return;
    await remove(ref(db, `stories/${s.author}/${s.id}`));
    setViewerGroup(null);
  }

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* STORY BAR */}
      <div className="sticky top-0 z-10 border-b border-slate-800/40 p-3" style={{ background: "rgba(3,7,18,0.97)", backdropFilter: "blur(28px)" }}>
        <div className="flex gap-3 overflow-x-auto pb-1">
          {/* Add my story */}
          <button onClick={() => setShowStoryUpload(true)} className="flex-shrink-0 flex flex-col items-center gap-1 w-16">
            <div className="w-16 h-16 rounded-full border-2 border-dashed flex items-center justify-center text-2xl"
              style={{ borderColor: accentColor, color: accentColor }}>+</div>
            <span className="text-[10px] text-slate-400 truncate w-full text-center">Sizning</span>
          </button>
          {orderedAuthors.map(author => {
            const items = storyGroups[author];
            const first = items[0];
            const allViewed = items.every(it => it.author === username || it.viewers?.[username]);
            const isPrem = items.some(i => i.premium);
            return (
              <button key={author} onClick={() => setViewerGroup({ author, items, index: 0 })}
                className="flex-shrink-0 flex flex-col items-center gap-1 w-16">
                <div className={`w-16 h-16 rounded-full p-[2.5px] ${isPrem ? "animate-[spin_4s_linear_infinite]" : ""}`}
                  style={{
                    background: allViewed ? "#334155" :
                      isPrem ? `conic-gradient(from 0deg, #fbbf24, #ec4899, #8b5cf6, ${accentColor}, #fbbf24)` :
                      `linear-gradient(135deg, ${accentColor}, #8b5cf6)`
                  }}>
                  <div className="w-full h-full rounded-full overflow-hidden bg-slate-800 flex items-center justify-center">
                    {first.mediaType === "video" ? (
                      <video src={first.mediaUrl} className="w-full h-full object-cover" muted />
                    ) : (
                      <img src={first.mediaUrl} alt="" className="w-full h-full object-cover" />
                    )}
                  </div>
                </div>
                <span className="text-[10px] text-slate-300 truncate w-full text-center">
                  {author === username ? "Sizning" : `@${author.slice(0, 8)}`}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* CREATE POST */}
      <div className="px-3 pb-2 pt-3">
        <button onClick={() => setShowPostUpload(true)}
          className="w-full px-4 py-3 rounded-2xl text-left text-sm text-slate-500 hover:text-slate-300 transition-all group flex items-center gap-3"
          style={{ background: "rgba(15,23,42,0.7)", border: "1px solid rgba(255,255,255,0.06)" }}>
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0 text-base"
            style={{ background: `linear-gradient(135deg, ${accentColor}, #8b5cf6)`, boxShadow: `0 0 12px ${accentColor}33` }}>
            {username[0]?.toUpperCase()}
          </div>
          <span className="flex-1 group-hover:text-slate-300 transition-colors">Nima yangiliklar, @{username}?</span>
          <div className="flex items-center gap-2 opacity-60 group-hover:opacity-100 transition-opacity">
            <span className="text-lg">📸</span>
            <span className="text-lg">🎬</span>
          </div>
        </button>
      </div>

      {/* FEED TABS */}
      <div className="px-3 pb-3 flex gap-1.5 overflow-x-auto">
        {([
          { key: "all",      label: "🌐 Barchasi" },
          { key: "trending", label: "🔥 Trend" },
          { key: "friends",  label: `🤝 Do'stlar${friendsSet.size > 0 ? ` · ${friendsSet.size}` : ""}` },
          { key: "saved",    label: `🔖 Saqlangan${savedPosts.length > 0 ? ` · ${savedPosts.length}` : ""}` },
        ] as const).map(t => (
          <button key={t.key} onClick={() => setFeedTab(t.key)}
            className="px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex-shrink-0"
            style={feedTab === t.key
              ? { background: accentColor + "18", color: accentColor, border: `1px solid ${accentColor}35` }
              : { color: "#475569", border: "1px solid rgba(255,255,255,0.04)", background: "rgba(15,23,42,0.4)" }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* POSTS */}
      <div className="px-3 space-y-3">
        {(() => {
          let displayPosts = posts;
          if (feedTab === "trending") displayPosts = [...posts].sort((a, b) => Object.keys(b.likes || {}).length - Object.keys(a.likes || {}).length).slice(0, 20);
          if (feedTab === "saved") displayPosts = posts.filter(p => savedPosts.includes(p.id));
          if (feedTab === "friends") displayPosts = posts.filter(p => p.author === username || friendsSet.has(p.author));
          if (displayPosts.length === 0) return (
            <div className="text-center py-16 text-slate-600">
              <p className="text-5xl mb-3">{feedTab === "saved" ? "🔖" : feedTab === "friends" ? "🤝" : "📭"}</p>
              <p className="text-sm">{feedTab === "saved" ? "Saqlangan postlar yo'q" : feedTab === "friends" ? "Do'stlaringiz hali post qilmagan" : "Hali postlar yo'q. Birinchi bo'ling!"}</p>
            </div>
          );
          return displayPosts.map(p => (
            <PostCard key={p.id} post={p} username={username} accentColor={accentColor}
              onLike={() => toggleLike(p)}
              onComment={() => { recordPostView(p); setCommentingOn(p); }}
              onView={() => recordPostView(p)}
              onOpenProfile={onOpenProfile}
              onDelete={() => deletePost(p)}
              isSaved={savedPosts.includes(p.id)}
              onSave={() => toggleSave(p.id)} />
          ));
        })()}
      </div>

      {/* Story upload modal */}
      {showStoryUpload && (
        <UploadModal title="📸 Story qo'shish" isPremium={isPremium}
          allowVideo limitText={isPremium ? "Cheksiz · 7 kun · 30 ta" : "2MB · 24 soat · 3 ta"}
          showAnimations
          onClose={() => setShowStoryUpload(false)}
          onSubmit={(file, text, animation, onProgress) => uploadStory(file as File, text, animation, onProgress)}
          accentColor={accentColor} />
      )}

      {/* Post upload modal */}
      {showPostUpload && (
        <UploadModal title="✍️ Post yaratish" isPremium={isPremium}
          allowVideo allowEmptyMedia
          limitText={isPremium ? "Cheksiz" : "2MB"}
          showAnimations
          onClose={() => setShowPostUpload(false)}
          onSubmit={(file, text, animation, onProgress) => uploadPost(file, text, animation, onProgress)}
          accentColor={accentColor} />
      )}

      {/* Story viewer */}
      {viewerGroup && (
        <StoryViewer group={viewerGroup} username={username} accentColor={accentColor}
          onClose={() => setViewerGroup(null)}
          onNext={(next) => setViewerGroup(next)}
          onView={recordStoryView}
          onShowViewers={(s) => setShowViewersOf(s)}
          onDelete={deleteStory} />
      )}

      {/* Viewers list */}
      {showViewersOf && (
        <ViewersModal story={showViewersOf} accentColor={accentColor}
          onClose={() => setShowViewersOf(null)} onOpenProfile={onOpenProfile} />
      )}

      {/* Comments */}
      {commentingOn && (
        <CommentsModal post={commentingOn} username={username} accentColor={accentColor}
          commentText={commentText} setCommentText={setCommentText}
          onSend={() => sendComment(commentingOn)}
          onClose={() => { setCommentingOn(null); setCommentText(""); }}
          onOpenProfile={onOpenProfile} />
      )}
    </div>
  );
}

/** Media URL ni qaytaradi — eski chunked base64 ham qo'llab-quvvatlanadi */
function useAssembledUrl(mediaUrl?: string, mc?: Record<string, string>, mcc?: number): string | undefined {
  const [url, setUrl] = useState<string | undefined>(mediaUrl);
  useEffect(() => {
    if (mc && mcc && !mediaUrl) {
      let assembled = "";
      for (let i = 0; i < mcc; i++) assembled += mc[String(i)] || "";
      setUrl(assembled);
    } else {
      setUrl(mediaUrl);
    }
  }, [mediaUrl, mcc]);
  return url;
}

/* ---------------- POST CARD ---------------- */
function PostCard({ post, username, accentColor, onLike, onComment, onView, onOpenProfile, onDelete, isSaved, onSave }: {
  post: Post; username: string; accentColor: string;
  onLike: () => void; onComment: () => void; onView: () => void;
  onOpenProfile: (u: string) => void; onDelete: () => void;
  isSaved?: boolean; onSave?: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const resolvedUrl = useAssembledUrl(post.mediaUrl, post.mc, post.mcc);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { onView(); obs.disconnect(); } }, { threshold: 0.5 });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const liked = !!post.likes?.[username];
  const likeCount = Object.keys(post.likes || {}).length;
  const commentCount = Object.keys(post.comments || {}).length;
  const viewCount = Object.keys(post.views || {}).length;
  const isMine = post.author === username;

  const postAnimClass = post.animation === "pulse"
    ? "animate-[premium-pulse_2s_ease-in-out_infinite]"
    : post.animation === "glow"
    ? "shadow-[0_0_40px_rgba(251,191,36,0.5),0_0_80px_rgba(99,102,241,0.2)] animate-[premium-glow_3s_ease-in-out_infinite]"
    : post.animation === "rainbow"
    ? "animate-[rainbow-border_4s_linear_infinite]"
    : post.animation === "bounce"
    ? "animate-[premium-bounce_1.5s_ease-in-out_infinite]"
    : post.animation === "float"
    ? "animate-[premium-float_3s_ease-in-out_infinite]"
    : post.animation === "shake"
    ? "animate-[premium-shake_0.5s_ease-in-out_infinite]"
    : "";

  return (
    <div ref={ref} className={`rounded-2xl border bg-slate-900/60 overflow-hidden ${post.premium ? "border-amber-700/40 shadow-[0_0_30px_rgba(245,158,11,0.1)]" : "border-slate-800"} ${postAnimClass}`}>
      <div className="flex items-center gap-2 p-3">
        <button onClick={() => onOpenProfile(post.author)} className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
          style={{ background: `linear-gradient(135deg, ${accentColor}, #8b5cf6)` }}>
          {post.author?.[0]?.toUpperCase()}
        </button>
        <div className="flex-1 min-w-0">
          <button onClick={() => onOpenProfile(post.author)} className="text-sm font-bold text-white flex items-center gap-1">
            @{post.author}{post.premium && <span className="text-amber-400 text-xs">👑</span>}
          </button>
          <p className="text-[10px] text-slate-500">{timeAgo(post.ts)}</p>
        </div>
        {isMine && (
          <button onClick={onDelete} className="text-slate-500 hover:text-rose-400 text-sm">🗑️</button>
        )}
      </div>
      {post.text && <p className="px-3 pb-2 text-sm text-slate-200 whitespace-pre-wrap break-words">{post.text}</p>}
      {(resolvedUrl || post.mcc) && (
        <div className="bg-black">
          {!resolvedUrl ? (
            <div className="flex items-center justify-center h-32 text-slate-500 text-xs">⏳ Media yuklanmoqda...</div>
          ) : post.mediaType === "video" ? (
            <video
              src={resolvedUrl}
              controls
              playsInline
              preload="metadata"
              className="w-full max-h-[500px] object-contain"
              onError={e => { (e.target as HTMLVideoElement).style.display = "none"; }}
            />
          ) : (
            <img
              src={resolvedUrl}
              alt=""
              loading="lazy"
              className="w-full max-h-[500px] object-contain"
              onError={e => { (e.target as HTMLImageElement).style.display = "none"; }}
            />
          )}
        </div>
      )}
      <div className="flex items-center gap-3 p-3 text-sm">
        <button onClick={onLike} className={`flex items-center gap-1.5 transition ${liked ? "text-rose-500" : "text-slate-400 hover:text-rose-400"}`}>
          <span className={liked ? "scale-125 inline-block transition" : ""}>{liked ? "❤️" : "🤍"}</span>
          <span className="font-mono text-xs">{likeCount}</span>
        </button>
        <button onClick={onComment} className="flex items-center gap-1.5 text-slate-400 hover:text-cyan-400">
          💬 <span className="font-mono text-xs">{commentCount}</span>
        </button>
        <div className="flex items-center gap-1 text-slate-500 text-xs">
          👁️ <span className="font-mono">{viewCount}</span>
        </div>
        <button onClick={onSave} className={`ml-auto flex items-center gap-1 text-xs transition ${isSaved ? "text-amber-400" : "text-slate-500 hover:text-amber-400"}`}>
          {isSaved ? "🔖" : "📑"} <span className="text-[10px]">{isSaved ? "Saqlangan" : "Saqlash"}</span>
        </button>
      </div>
    </div>
  );
}

/* ---------------- UPLOAD MODAL ---------------- */
function UploadModal({ title, onClose, onSubmit, accentColor, isPremium, allowVideo, allowEmptyMedia, limitText, showAnimations }: {
  title: string; onClose: () => void;
  onSubmit: (file: File | null, text: string, animation: string, onProgress: (p: number) => void) => Promise<void> | void;
  accentColor: string; isPremium: boolean; allowVideo?: boolean; allowEmptyMedia?: boolean;
  limitText?: string; showAnimations?: boolean;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [animation, setAnimation] = useState("none");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);

  function onFile(f: File | null) {
    setFile(f);
    if (f) {
      const url = URL.createObjectURL(f);
      setPreview(url);
    } else setPreview(null);
  }

  async function submit() {
    if (!file && !allowEmptyMedia) { alert("Rasm/video tanlang"); return; }
    if (!file && !text.trim()) { alert("Matn yoki media kerak"); return; }
    setBusy(true);
    setProgress(0);
    try {
      await onSubmit(file, text, animation, (p) => setProgress(p));
    } finally {
      setBusy(false);
      setProgress(null);
    }
  }

  const animations = [
    { id: "none", label: "Yo'q" },
    { id: "pulse", label: "💗 Pulse" },
    { id: "glow", label: "✨ Glow" },
    { id: "rainbow", label: "🌈 Rainbow" },
    { id: "bounce", label: "🏀 Bounce" },
    { id: "float", label: "🎈 Float" },
    { id: "shake", label: "⚡ Shake" },
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(12px)" }} onClick={onClose}>
      <div className="w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl border border-slate-800 bg-[#0f172a] p-5 space-y-4 animate-[scale-in_0.2s]" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white">{title}</h3>
          <button onClick={onClose} className="text-slate-400">✕</button>
        </div>
        {limitText && (
          <p className="text-[10px] text-slate-500 font-mono">📦 {limitText}</p>
        )}

        <label className="block">
          <input type="file" accept={allowVideo ? "image/*,video/*" : "image/*"} className="hidden"
            onChange={e => onFile(e.target.files?.[0] || null)} />
          <div className="border-2 border-dashed border-slate-700 rounded-2xl p-6 text-center cursor-pointer hover:border-slate-500">
            {preview ? (
              file?.type.startsWith("video") ? (
                <video src={preview} className="max-h-64 mx-auto rounded-xl" controls />
              ) : (
                <img src={preview} className="max-h-64 mx-auto rounded-xl" />
              )
            ) : (
              <div className="text-slate-500">
                <p className="text-4xl mb-2">📁</p>
                <p className="text-xs">Rasm{allowVideo ? " yoki video" : ""} tanlash</p>
              </div>
            )}
          </div>
        </label>

        <textarea value={text} onChange={e => setText(e.target.value)}
          placeholder="Izoh yozing..." rows={3}
          className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-white resize-none" />

        {showAnimations && (
          <div className={`p-3 rounded-xl border ${isPremium ? "bg-amber-950/20 border-amber-700/40" : "bg-slate-900/60 border-slate-800 opacity-60"}`}>
            <p className="text-xs font-bold text-slate-300 mb-2">
              ✨ Animatsiya {!isPremium && <span className="text-amber-400">👑 Premium</span>}
            </p>
            <div className="grid grid-cols-2 gap-1.5">
              {animations.map(a => (
                <button key={a.id} disabled={!isPremium && a.id !== "none"}
                  onClick={() => setAnimation(a.id)}
                  className={`p-2 rounded-lg text-xs border ${animation === a.id ? "border-cyan-500 bg-cyan-950/30 text-cyan-300" : "border-slate-700 bg-slate-800 text-slate-300"} disabled:opacity-40`}>
                  {a.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {progress !== null && (
          <div className="w-full">
            <div className="flex justify-between text-[10px] text-slate-400 mb-1">
              <span>Yuklanmoqda...</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${accentColor}, #8b5cf6)` }}
              />
            </div>
          </div>
        )}

        <button onClick={submit} disabled={busy}
          className="w-full py-3 rounded-xl font-bold text-sm text-white disabled:opacity-60 transition"
          style={{ background: `linear-gradient(135deg, ${accentColor}, #8b5cf6)` }}>
          {busy ? `⏳ ${progress !== null ? `${Math.round(progress)}% yuklanmoqda` : "Tayyorlanmoqda..."}` : "📤 Joylash"}
        </button>
      </div>
    </div>
  );
}

/* ---------------- STORY VIEWER ---------------- */
function StoryViewer({ group, username, accentColor, onClose, onNext, onView, onShowViewers, onDelete }: {
  group: { author: string; items: Story[]; index: number };
  username: string; accentColor: string;
  onClose: () => void;
  onNext: (g: { author: string; items: Story[]; index: number }) => void;
  onView: (s: Story) => void;
  onShowViewers: (s: Story) => void;
  onDelete: (s: Story) => void;
}) {
  const current = group.items[group.index];
  useEffect(() => { if (current) onView(current); }, [current?.id]);
  useEffect(() => {
    if (!current) return;
    const dur = current.mediaType === "video" ? 15000 : 5000;
    const t = setTimeout(() => {
      if (group.index + 1 < group.items.length) onNext({ ...group, index: group.index + 1 });
      else onClose();
    }, dur);
    return () => clearTimeout(t);
  }, [current?.id]);

  const resolvedStoryUrl = useAssembledUrl(current?.mediaUrl, current?.mc, current?.mcc);
  if (!current) return null;
  const isMine = current.author === username;
  const viewerCount = Object.keys(current.viewers || {}).length;
  const animClass = current.animation === "pulse"
    ? "animate-[premium-pulse_2s_ease-in-out_infinite]"
    : current.animation === "glow"
    ? "shadow-[0_0_60px_rgba(251,191,36,0.6),0_0_120px_rgba(99,102,241,0.3)] animate-[premium-glow_3s_ease-in-out_infinite]"
    : current.animation === "rainbow"
    ? "outline outline-4 animate-[rainbow-border_4s_linear_infinite]"
    : current.animation === "bounce"
    ? "animate-[premium-bounce_1.5s_ease-in-out_infinite]"
    : current.animation === "float"
    ? "animate-[premium-float_3s_ease-in-out_infinite]"
    : current.animation === "shake"
    ? "animate-[premium-shake_0.5s_ease-in-out_infinite]"
    : "";

  return (
    <div className="fixed inset-0 z-[120] bg-black flex flex-col" onClick={onClose}>
      <div className="flex-shrink-0 p-3 flex gap-1">
        {group.items.map((_, i) => (
          <div key={i} className="flex-1 h-0.5 bg-slate-700 rounded-full overflow-hidden">
            <div className={`h-full bg-white ${i < group.index ? "w-full" : i === group.index ? "animate-[story-progress_5s_linear]" : "w-0"}`} />
          </div>
        ))}
      </div>
      <div className="flex-shrink-0 px-3 pb-2 flex items-center gap-2">
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs"
          style={{ background: `linear-gradient(135deg, ${accentColor}, #8b5cf6)` }}>
          {current.author[0]?.toUpperCase()}
        </div>
        <p className="text-white text-sm font-bold">@{current.author}</p>
        <p className="text-slate-400 text-[10px] ml-1">{timeAgo(current.ts)}</p>
        {current.premium && <span className="text-amber-400 text-xs">👑</span>}
        <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="ml-auto text-white text-xl">✕</button>
      </div>

      <div className="flex-1 flex items-center justify-center p-4" onClick={(e) => e.stopPropagation()}>
        <div className={`max-h-full max-w-full rounded-2xl overflow-hidden ${animClass}`}>
          {!resolvedStoryUrl ? (
            <div className="flex items-center justify-center w-64 h-64 text-slate-500 text-xs">⏳ Yuklanmoqda...</div>
          ) : current.mediaType === "video" ? (
            <video src={resolvedStoryUrl} autoPlay controls playsInline className="max-h-[70vh] max-w-full" />
          ) : (
            <img src={resolvedStoryUrl} alt="" className="max-h-[70vh] max-w-full" />
          )}
        </div>
      </div>

      {current.text && (
        <div className="px-4 pb-2 text-center text-white text-sm" onClick={e => e.stopPropagation()}>{current.text}</div>
      )}

      <div className="flex-shrink-0 p-3 flex items-center gap-3" onClick={e => e.stopPropagation()}>
        {isMine ? (
          <>
            <button onClick={() => onShowViewers(current)} className="flex items-center gap-1.5 text-white text-sm">
              👁️ <span className="font-mono">{viewerCount}</span> ko'rgan
            </button>
            <button onClick={() => onDelete(current)} className="ml-auto text-rose-400 text-sm">🗑️ O'chirish</button>
          </>
        ) : (
          <button onClick={onClose} className="ml-auto text-slate-400 text-xs">Tap to skip →</button>
        )}
      </div>
    </div>
  );
}

/* ---------------- VIEWERS MODAL ---------------- */
function ViewersModal({ story, accentColor, onClose, onOpenProfile }: {
  story: Story; accentColor: string; onClose: () => void; onOpenProfile: (u: string) => void;
}) {
  const viewers = Object.entries(story.viewers || {}).sort((a, b) => (b[1] as number) - (a[1] as number));
  return (
    <div className="fixed inset-0 z-[130] flex items-end md:items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.85)" }} onClick={onClose}>
      <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-[#0f172a] p-5 max-h-[70vh] flex flex-col animate-[scale-in_0.2s]" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-white">👁️ Ko'rganlar ({viewers.length})</h3>
          <button onClick={onClose} className="text-slate-400">✕</button>
        </div>
        <div className="flex-1 overflow-y-auto space-y-2">
          {viewers.length === 0 && <p className="text-slate-500 text-sm text-center py-8">Hech kim ko'rmagan</p>}
          {viewers.map(([u, t]) => (
            <button key={u} onClick={() => { onOpenProfile(u); onClose(); }}
              className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-slate-800/60 transition">
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-xs"
                style={{ background: `linear-gradient(135deg, ${accentColor}, #8b5cf6)` }}>
                {u[0]?.toUpperCase()}
              </div>
              <div className="text-left flex-1 min-w-0">
                <p className="text-sm font-bold text-white">@{u}</p>
                <p className="text-[10px] text-slate-500">{timeAgo(t as number)}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------- COMMENTS MODAL ---------------- */
function CommentsModal({ post, username, accentColor, commentText, setCommentText, onSend, onClose, onOpenProfile }: {
  post: Post; username: string; accentColor: string;
  commentText: string; setCommentText: (s: string) => void;
  onSend: () => void; onClose: () => void; onOpenProfile: (u: string) => void;
}) {
  const [live, setLive] = useState<Record<string, any>>(post.comments || {});
  useEffect(() => {
    return onValue(ref(db, `posts/${post.id}/comments`), s => setLive(s.val() || {}));
  }, [post.id]);
  const list = Object.entries(live).map(([id, c]: [string, any]) => ({ id, ...c }))
    .sort((a, b) => a.ts - b.ts);
  return (
    <div className="fixed inset-0 z-[130] flex items-end md:items-center justify-center" style={{ background: "rgba(0,0,0,0.85)" }} onClick={onClose}>
      <div className="w-full max-w-md h-[80vh] md:h-[600px] rounded-t-3xl md:rounded-3xl border border-slate-800 bg-[#0f172a] flex flex-col animate-[slide-in-right_0.2s]" onClick={e => e.stopPropagation()}>
        <div className="flex-shrink-0 flex items-center justify-between p-4 border-b border-slate-800">
          <h3 className="text-base font-bold text-white">💬 Izohlar ({list.length})</h3>
          <button onClick={onClose} className="text-slate-400">✕</button>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {list.length === 0 && <p className="text-slate-500 text-sm text-center py-8">Birinchi izoh qoldiring</p>}
          {list.map(c => (
            <div key={c.id} className="flex gap-2">
              <button onClick={() => onOpenProfile(c.from)}
                className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-white font-bold text-xs"
                style={{ background: `linear-gradient(135deg, ${accentColor}, #8b5cf6)` }}>
                {c.from[0]?.toUpperCase()}
              </button>
              <div className="flex-1 min-w-0 bg-slate-800/60 rounded-xl px-3 py-2">
                <button onClick={() => onOpenProfile(c.from)} className="text-xs font-bold" style={{ color: accentColor }}>@{c.from}</button>
                <p className="text-sm text-white whitespace-pre-wrap break-words">{c.text}</p>
                <p className="text-[9px] text-slate-500 mt-1">{timeAgo(c.ts)}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="flex-shrink-0 p-3 border-t border-slate-800 flex gap-2">
          <input value={commentText} onChange={e => setCommentText(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") onSend(); }}
            placeholder="Izoh yozing..."
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-slate-500" />
          <button onClick={onSend} disabled={!commentText.trim()}
            className="px-4 rounded-xl text-white font-bold disabled:opacity-30"
            style={{ background: accentColor }}>➤</button>
        </div>
      </div>
    </div>
  );
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "hozir";
  if (m < 60) return `${m}d oldin`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}s oldin`;
  const d = Math.floor(h / 24);
  return `${d}k oldin`;
}
