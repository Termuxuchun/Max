import { useState, useEffect, useCallback } from "react";
import { TrendingUp, TrendingDown, RefreshCw, Search, Star, ArrowUpRight, ArrowDownRight, BarChart2, Zap } from "lucide-react";

interface CoinData {
  id: string;
  symbol: string;
  name: string;
  icon: string;
  price: number;
  change24h: number;
  change7d: number;
  marketCap: number;
  volume: number;
  ath: number;
  sparkline?: number[];
}

interface Props { username: string; accentColor: string; starsBalance: number; }

const COIN_META: Record<string, { icon: string; color: string }> = {
  bitcoin:   { icon: "₿", color: "#f97316" },
  ethereum:  { icon: "Ξ", color: "#6366f1" },
  "binancecoin": { icon: "B", color: "#f59e0b" },
  solana:    { icon: "◎", color: "#22d3ee" },
  cardano:   { icon: "A", color: "#3b82f6" },
  ripple:    { icon: "✕", color: "#0ea5e9" },
  polkadot:  { icon: "●", color: "#ec4899" },
  dogecoin:  { icon: "Ð", color: "#fbbf24" },
  "matic-network": { icon: "M", color: "#8b5cf6" },
  "avalanche-2": { icon: "A", color: "#ef4444" },
  tron:      { icon: "T", color: "#ef4444" },
  litecoin:  { icon: "Ł", color: "#94a3b8" },
  ton:       { icon: "◈", color: "#22d3ee" },
  "shiba-inu": { icon: "S", color: "#f59e0b" },
  chainlink: { icon: "⬡", color: "#3b82f6" },
};

const COIN_IDS = Object.keys(COIN_META).join(",");

function MiniSparkline({ values, positive }: { values: number[]; positive: boolean }) {
  if (!values || values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const w = 64, h = 24;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - min) / range) * (h - 4) - 2;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} fill="none">
      <polyline points={pts} stroke={positive ? "#4ade80" : "#f87171"} strokeWidth="1.5" fill="none" strokeLinejoin="round" />
    </svg>
  );
}

function fmt(n: number): string {
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  return `$${n.toLocaleString()}`;
}

function fmtPrice(n: number): string {
  if (n >= 1000) return `$${n.toLocaleString("en-US", { maximumFractionDigits: 2 })}`;
  if (n >= 1) return `$${n.toFixed(2)}`;
  return `$${n.toPrecision(4)}`;
}

export default function CryptoSection({ username, accentColor, starsBalance }: Props) {
  const [coins, setCoins] = useState<CoinData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"rank" | "change" | "price" | "volume">("rank");
  const [selected, setSelected] = useState<CoinData | null>(null);
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("nexus_crypto_watch") || "[]"); } catch { return []; }
  });
  const [tab, setTab] = useState<"all" | "watch">("all");
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchCoins = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${COIN_IDS}&order=market_cap_desc&per_page=20&page=1&sparkline=true&price_change_percentage=24h,7d`;
      const res = await fetch(url, { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`API xatosi: ${res.status}`);
      const data = await res.json();
      const mapped: CoinData[] = data.map((c: any) => ({
        id: c.id, symbol: c.symbol.toUpperCase(), name: c.name,
        icon: COIN_META[c.id]?.icon || c.symbol[0].toUpperCase(),
        price: c.current_price,
        change24h: c.price_change_percentage_24h || 0,
        change7d: c.price_change_percentage_7d_in_currency || 0,
        marketCap: c.market_cap,
        volume: c.total_volume,
        ath: c.ath,
        sparkline: c.sparkline_in_7d?.price?.slice(-20),
      }));
      setCoins(mapped);
      setLastUpdated(new Date());
    } catch {
      setError("CoinGecko API dan ma'lumot yuklab bo'lmadi. Bir oz kuting va qayta urinib ko'ring.");
      // Use fallback demo data
      setCoins([
        { id: "bitcoin", symbol: "BTC", name: "Bitcoin", icon: "₿", price: 67000 + Math.random() * 5000, change24h: (Math.random() - 0.4) * 8, change7d: (Math.random() - 0.4) * 12, marketCap: 1.3e12, volume: 28e9, ath: 73794 },
        { id: "ethereum", symbol: "ETH", name: "Ethereum", icon: "Ξ", price: 3200 + Math.random() * 400, change24h: (Math.random() - 0.4) * 10, change7d: (Math.random() - 0.4) * 15, marketCap: 380e9, volume: 15e9, ath: 4878 },
        { id: "binancecoin", symbol: "BNB", name: "BNB", icon: "B", price: 580 + Math.random() * 50, change24h: (Math.random() - 0.4) * 7, change7d: (Math.random() - 0.4) * 10, marketCap: 85e9, volume: 2e9, ath: 690 },
        { id: "solana", symbol: "SOL", name: "Solana", icon: "◎", price: 170 + Math.random() * 30, change24h: (Math.random() - 0.4) * 12, change7d: (Math.random() - 0.4) * 18, marketCap: 78e9, volume: 3e9, ath: 260 },
        { id: "ripple", symbol: "XRP", name: "XRP", icon: "✕", price: 0.55 + Math.random() * 0.1, change24h: (Math.random() - 0.4) * 8, change7d: (Math.random() - 0.4) * 12, marketCap: 30e9, volume: 1.5e9, ath: 3.84 },
        { id: "dogecoin", symbol: "DOGE", name: "Dogecoin", icon: "Ð", price: 0.15 + Math.random() * 0.05, change24h: (Math.random() - 0.4) * 15, change7d: (Math.random() - 0.4) * 20, marketCap: 21e9, volume: 1e9, ath: 0.74 },
        { id: "ton", symbol: "TON", name: "Toncoin", icon: "◈", price: 5.5 + Math.random() * 1, change24h: (Math.random() - 0.4) * 10, change7d: (Math.random() - 0.4) * 14, marketCap: 19e9, volume: 0.5e9, ath: 8.24 },
        { id: "cardano", symbol: "ADA", name: "Cardano", icon: "A", price: 0.45 + Math.random() * 0.1, change24h: (Math.random() - 0.4) * 9, change7d: (Math.random() - 0.4) * 13, marketCap: 16e9, volume: 0.4e9, ath: 3.1 },
      ]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchCoins(); }, [fetchCoins]);

  function toggleWatch(id: string) {
    const next = watchlist.includes(id) ? watchlist.filter(w => w !== id) : [...watchlist, id];
    setWatchlist(next);
    localStorage.setItem("nexus_crypto_watch", JSON.stringify(next));
  }

  function getSorted(list: CoinData[]) {
    if (sortBy === "change") return [...list].sort((a, b) => Math.abs(b.change24h) - Math.abs(a.change24h));
    if (sortBy === "price") return [...list].sort((a, b) => b.price - a.price);
    if (sortBy === "volume") return [...list].sort((a, b) => b.volume - a.volume);
    return list;
  }

  const filtered = getSorted(
    (tab === "watch" ? coins.filter(c => watchlist.includes(c.id)) : coins)
      .filter(c => search ? c.name.toLowerCase().includes(search.toLowerCase()) || c.symbol.toLowerCase().includes(search.toLowerCase()) : true)
  );

  const totalChange = coins.length > 0 ? coins.reduce((s, c) => s + c.change24h, 0) / coins.length : 0;
  const gainers = coins.filter(c => c.change24h > 0).length;

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b border-slate-800/60"
        style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(12px)" }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg font-black"
            style={{ background: "linear-gradient(135deg,#f59e0b,#f97316)", color: "white" }}>₿</div>
          <div>
            <p className="text-sm font-bold text-white">Kripto Bozor</p>
            <p className="text-[10px] text-slate-500">CoinGecko · Real-vaqt narxlar</p>
          </div>
        </div>
        <button onClick={fetchCoins} disabled={loading} className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Market stats bar */}
      {coins.length > 0 && (
        <div className="flex gap-4 px-4 py-2 border-b border-slate-800/40 overflow-x-auto scrollbar-none">
          {[
            { label: "O'rtacha o'zgarish", val: `${totalChange >= 0 ? "+" : ""}${totalChange.toFixed(2)}%`, positive: totalChange >= 0 },
            { label: "Yuksaluvchilar", val: `${gainers}/${coins.length}`, positive: gainers > coins.length / 2 },
            { label: "BTC dominance", val: "~52%", positive: true },
          ].map((s, i) => (
            <div key={i} className="flex-shrink-0 flex items-center gap-1.5">
              <div className={`w-1.5 h-1.5 rounded-full ${s.positive ? "bg-green-400" : "bg-red-400"}`} />
              <span className="text-[10px] text-slate-500">{s.label}:</span>
              <span className={`text-[10px] font-bold ${s.positive ? "text-green-400" : "text-red-400"}`}>{s.val}</span>
            </div>
          ))}
        </div>
      )}

      {/* Tabs + Search + Sort */}
      <div className="flex-shrink-0 px-4 pt-3 space-y-2">
        <div className="flex gap-2">
          {[{ id: "all", label: "Hammasi" }, { id: "watch", label: `⭐ Kuzatish (${watchlist.length})` }].map(t => (
            <button key={t.id} onClick={() => setTab(t.id as any)}
              className="px-3 py-1.5 rounded-xl text-xs font-bold transition"
              style={{ background: tab === t.id ? accentColor + "22" : "rgba(30,41,59,0.4)", color: tab === t.id ? accentColor : "#64748b" }}>
              {t.label}
            </button>
          ))}
          <div className="flex-1" />
          {[
            { id: "rank", label: "Rank" },
            { id: "change", label: "O'zg." },
            { id: "volume", label: "Hajm" },
          ].map(s => (
            <button key={s.id} onClick={() => setSortBy(s.id as any)}
              className="px-2 py-1 rounded-lg text-[10px] font-medium transition"
              style={{ background: sortBy === s.id ? "#1e293b" : "transparent", color: sortBy === s.id ? "#e2e8f0" : "#475569" }}>
              {s.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-800">
          <Search className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Kripto qidiring..." className="flex-1 bg-transparent text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none" />
        </div>
      </div>

      {/* Coin list */}
      <div className="flex-1 overflow-y-auto px-3 pb-4 pt-2">
        {error && (
          <div className="mb-3 p-3 rounded-xl bg-amber-950/30 border border-amber-800/40 text-amber-400 text-xs">
            ⚠️ {error} Demo ma'lumotlar ko'rsatilmoqda.
          </div>
        )}
        {loading && coins.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <RefreshCw className="w-8 h-8 text-slate-500 animate-spin" />
            <p className="text-slate-500 text-sm">Narxlar yuklanmoqda...</p>
          </div>
        )}
        {filtered.length === 0 && !loading && (
          <div className="text-center py-12 text-slate-500 text-sm">Hech narsa topilmadi</div>
        )}
        <div className="space-y-1.5">
          {filtered.map((coin) => {
            const pos = coin.change24h >= 0;
            const meta = COIN_META[coin.id];
            const watched = watchlist.includes(coin.id);
            return (
              <button key={coin.id} onClick={() => setSelected(selected?.id === coin.id ? null : coin)}
                className="w-full flex items-center gap-3 p-3 rounded-2xl border transition hover:border-slate-700/60 text-left"
                style={{ background: selected?.id === coin.id ? "rgba(30,41,59,0.8)" : "rgba(15,23,42,0.8)", borderColor: selected?.id === coin.id ? accentColor + "44" : "rgba(51,65,85,0.5)" }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-base font-black flex-shrink-0"
                  style={{ background: (meta?.color || "#64748b") + "22", color: meta?.color || "#94a3b8", border: `1px solid ${(meta?.color || "#64748b")}33` }}>
                  {coin.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-bold text-white">{coin.symbol}</p>
                    {watched && <Star className="w-3 h-3 text-amber-400" fill="currentColor" />}
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">{coin.name}</p>
                </div>
                <div className="flex-shrink-0">
                  <MiniSparkline values={coin.sparkline || []} positive={pos} />
                </div>
                <div className="text-right flex-shrink-0 min-w-[80px]">
                  <p className="text-sm font-bold text-white">{fmtPrice(coin.price)}</p>
                  <div className="flex items-center justify-end gap-0.5">
                    {pos ? <ArrowUpRight className="w-3 h-3 text-green-400" /> : <ArrowDownRight className="w-3 h-3 text-red-400" />}
                    <span className={`text-[10px] font-bold ${pos ? "text-green-400" : "text-red-400"}`}>
                      {pos ? "+" : ""}{coin.change24h.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected coin details */}
        {selected && (
          <div className="mt-3 p-4 rounded-2xl border border-slate-700/60 space-y-3" style={{ background: "rgba(15,23,42,0.9)" }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-black"
                  style={{ background: (COIN_META[selected.id]?.color || "#64748b") + "22", color: COIN_META[selected.id]?.color || "#94a3b8" }}>
                  {selected.icon}
                </div>
                <div>
                  <p className="font-black text-white text-base">{selected.name}</p>
                  <p className="text-xs text-slate-400">{selected.symbol}</p>
                </div>
              </div>
              <button onClick={() => toggleWatch(selected.id)}
                className="p-2 rounded-xl transition"
                style={{ background: watchlist.includes(selected.id) ? "rgba(245,158,11,0.15)" : "rgba(51,65,85,0.4)" }}>
                <Star className="w-4 h-4" fill={watchlist.includes(selected.id) ? "#f59e0b" : "none"} color={watchlist.includes(selected.id) ? "#f59e0b" : "#64748b"} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Hozirgi narx", val: fmtPrice(selected.price) },
                { label: "24s o'zgarish", val: `${selected.change24h >= 0 ? "+" : ""}${selected.change24h.toFixed(2)}%`, colored: true, pos: selected.change24h >= 0 },
                { label: "7kun o'zgarish", val: `${selected.change7d >= 0 ? "+" : ""}${selected.change7d.toFixed(2)}%`, colored: true, pos: selected.change7d >= 0 },
                { label: "Bozor qiymati", val: fmt(selected.marketCap) },
                { label: "Savdo hajmi", val: fmt(selected.volume) },
                { label: "ATH", val: fmtPrice(selected.ath) },
              ].map((s: any, i) => (
                <div key={i} className="px-3 py-2.5 rounded-xl" style={{ background: "rgba(30,41,59,0.5)" }}>
                  <p className="text-[9px] text-slate-500 mb-0.5">{s.label}</p>
                  <p className={`text-xs font-bold ${s.colored ? (s.pos ? "text-green-400" : "text-red-400") : "text-white"}`}>{s.val}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {lastUpdated && <p className="text-[9px] text-slate-700 text-center mt-3">Yangilandi: {lastUpdated.toLocaleTimeString("uz-UZ")}</p>}
      </div>
    </div>
  );
}
