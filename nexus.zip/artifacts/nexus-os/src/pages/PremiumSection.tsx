import { useState, useEffect } from "react";
import { ref, push, onValue, update, get, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import { playPremiumSound } from "../sounds";

interface PremiumSectionProps {
  username: string;
  accentColor: string;
}

const PLANS = [
  { id: "1month", label: "1 Oy", months: 1, price: 3, priceUSD: "$3.00", popular: false, color: "#22d3ee", icon: "🌱" },
  { id: "3month", label: "3 Oy", months: 3, price: 7.8, priceUSD: "$7.80", popular: true, color: "#a855f7", icon: "⭐", save: "13% tejash" },
  { id: "6month", label: "6 Oy", months: 6, price: 14.7, priceUSD: "$14.70", popular: false, color: "#f59e0b", icon: "🔥", save: "18% tejash" },
  { id: "12month", label: "12 Oy", months: 12, price: 88, priceUSD: "$88.00", popular: false, color: "#ec4899", icon: "👑", save: "47% tejash" },
];

const PREMIUM_FEATURES = [
  { icon: "🎵", label: "Custom rington", desc: "O'z qo'ng'iroq ovozingizni o'rnating" },
  { icon: "✨", label: "Maxsus badge", desc: "Premium ✓ belgisi profilingizda" },
  { icon: "🎨", label: "Eksklyuziv mavzular", desc: "15+ premium rang paletlari" },
  { icon: "📊", label: "Statistika", desc: "Batafsil xabar va faollik analitikasi" },
  { icon: "📁", label: "Ko'proq media", desc: "1GB gacha fayl yuklash (oddiy: 10MB)" },
  { icon: "🔒", label: "E2E shifrlash", desc: "Haqiqiy end-to-end xabar shifrlash" },
  { icon: "👻", label: "Invisible mode", desc: "Onlayn bo'lmasdan foydalanish" },
  { icon: "⚡", label: "Tezroq javob", desc: "Priority server queue" },
  { icon: "🌐", label: "Custom profil URL", desc: "nexus.uz/@yourname" },
  { icon: "📌", label: "Ko'proq pin", desc: "Guruhda 20 ta pin xabar (oddiy: 3)" },
  { icon: "🤖", label: "Premium AI bot", desc: "ChatGPT powered assistant" },
  { icon: "📹", label: "HD video qo'ng'iroq", desc: "1080p video sifat" },
  { icon: "🎭", label: "Animatsion avatar", desc: "Harakatlanuvchi profil rasmi" },
  { icon: "🔔", label: "Premium bildirishnoma", desc: "Custom sound & vibration" },
  { icon: "💬", label: "Ko'proq reaction", desc: "100+ custom reaksiya emoji" },
  { icon: "📝", label: "Uzunroq xabar", desc: "50,000 belgigacha (oddiy: 1,000)" },
  { icon: "🗓️", label: "Kechiktirilgan xabar", desc: "Xabarni keyin yuborish" },
  { icon: "🔑", label: "Ko'proq guruh", desc: "50 ta guruh (oddiy: 10 ta)" },
  { icon: "🌟", label: "Spotlight profil", desc: "Qidiruv natijalarida birinchi" },
  { icon: "📞", label: "Ko'p chaqiruv", desc: "Guruh qo'ng'iroq (5 kishigacha)" },
  { icon: "🎪", label: "Story/Status", desc: "24 soatlik stori yuborish" },
  { icon: "🔗", label: "Maxsus havola", desc: "Qisqartirilgan premium link" },
  { icon: "💾", label: "Bulut saqlash", desc: "5GB xabar arxivi" },
  { icon: "🛡️", label: "Anti-spam shield", desc: "Premium spam himoyasi" },
  { icon: "🌙", label: "Dark Ultra mavzu", desc: "Eksklyuziv OLED qora mavzu" },
];

export default function PremiumSection({ username, accentColor }: PremiumSectionProps) {
  const [premiumData, setPremiumData] = useState<any>(null);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [paymentNote, setPaymentNote] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check premium status
    const u1 = onValue(ref(db, `premium/${username}`), snap => {
      setPremiumData(snap.exists() ? snap.val() : null);
      if (snap.exists()) playPremiumSound();
    });
    // My requests
    const u2 = onValue(ref(db, `premium_requests`), snap => {
      if (!snap.exists()) { setMyRequests([]); return; }
      const reqs: any[] = [];
      snap.forEach(c => {
        const d = c.val();
        if (d.username === username) reqs.push({ id: c.key, ...d });
      });
      setMyRequests(reqs.sort((a, b) => b.requestedAt - a.requestedAt));
    });
    return () => { u1(); u2(); };
  }, [username]);

  async function handleRequest() {
    if (!selectedPlan) return;
    const plan = PLANS.find(p => p.id === selectedPlan)!;
    setLoading(true);
    await push(ref(db, "premium_requests"), {
      username,
      plan: plan.id,
      label: plan.label,
      months: plan.months,
      price: plan.price,
      priceUSD: plan.priceUSD,
      paymentNote: paymentNote.trim() || "",
      status: "pending",
      requestedAt: Date.now(),
      adminReply: "",
    });
    setLoading(false);
    setSubmitted(true);
    setSelectedPlan(null);
    setPaymentNote("");
  }

  const isPremium = premiumData && premiumData.expiresAt > Date.now();
  const daysLeft = isPremium ? Math.ceil((premiumData.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
  const pendingReq = myRequests.find(r => r.status === "pending");

  return (
    <div className="space-y-4 p-1">

      {/* ── STATUS CARD ── */}
      {isPremium ? (
        <div className="relative p-5 rounded-2xl overflow-hidden border border-amber-700/50"
          style={{background:"linear-gradient(135deg, #1c1005, #2d1a00, #1a0a2e)"}}>
          <div className="absolute inset-0 opacity-10" style={{backgroundImage:"radial-gradient(circle at 80% 20%, #f59e0b, transparent)"}} />
          <div className="relative flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
              style={{background:"linear-gradient(135deg,#f59e0b,#ec4899)", boxShadow:"0 0 30px rgba(245,158,11,0.4)"}}>
              👑
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <p className="text-xl font-black text-amber-300">PREMIUM FAOL</p>
                <span className="text-amber-400 animate-pulse">✓</span>
              </div>
              <p className="text-sm text-amber-600 font-mono">{daysLeft} kun qoldi</p>
              <p className="text-xs text-slate-400 mt-0.5">Plan: {premiumData.label} · {new Date(premiumData.expiresAt).toLocaleDateString("uz-UZ")}</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
          <p className="text-2xl mb-2">⭐</p>
          <p className="font-bold text-slate-200">Premium obuna yo'q</p>
          <p className="text-xs text-slate-500 mt-1">Quyidan reja tanlang va admin bilan bog'laning</p>
        </div>
      )}

      {/* ── PRICING PLANS ── */}
      {!isPremium && (
        <>
          <p className="text-sm font-bold text-slate-300 mt-2">💎 Premium Reja Tanlang</p>
          <div className="grid grid-cols-2 gap-3">
            {PLANS.map(plan => (
              <button key={plan.id}
                onClick={() => setSelectedPlan(plan.id === selectedPlan ? null : plan.id)}
                className={`relative p-4 rounded-2xl border-2 text-left transition-all ${selectedPlan === plan.id ? "scale-[1.02]" : "hover:scale-[1.01]"}`}
                style={{
                  borderColor: selectedPlan === plan.id ? plan.color : "rgba(51,65,85,0.8)",
                  background: selectedPlan === plan.id ? `${plan.color}15` : "rgba(15,23,42,0.8)",
                  boxShadow: selectedPlan === plan.id ? `0 0 20px ${plan.color}30` : "none"
                }}
              >
                {plan.popular && (
                  <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-[9px] font-black px-2.5 py-0.5 rounded-full" style={{background: plan.color, color:"#000"}}>
                    MASHHUR
                  </div>
                )}
                <p className="text-xl mb-1">{plan.icon}</p>
                <p className="font-bold text-slate-200 text-sm">{plan.label}</p>
                <p className="text-lg font-black mt-1" style={{color: plan.color}}>{plan.priceUSD}</p>
                {plan.save && <p className="text-[9px] text-green-400 font-bold mt-0.5">{plan.save}</p>}
                {selectedPlan === plan.id && (
                  <div className="absolute top-2 right-2 w-4 h-4 rounded-full flex items-center justify-center text-[10px]" style={{background: plan.color}}>✓</div>
                )}
              </button>
            ))}
          </div>

          {selectedPlan && (
            <div className="space-y-3 p-4 rounded-2xl border border-slate-700 bg-slate-900/60">
              <p className="text-sm font-bold text-slate-300">📝 To'lov ma'lumoti</p>
              <p className="text-[10px] text-slate-500 font-mono">To'lov qilganingizdan so'ng tranzaksiya ID yoki izoh yozing. Admin tasdiqlaydi va premium beriladi.</p>
              <textarea
                value={paymentNote}
                onChange={e => setPaymentNote(e.target.value)}
                rows={3}
                placeholder="Tranzaksiya ID, to'lov usuli yoki xabar..."
                className="w-full bg-slate-950 border border-slate-700 p-3 rounded-xl text-sm text-white outline-none focus:border-cyan-500 transition resize-none"
              />
              <button
                onClick={handleRequest}
                disabled={loading}
                className="w-full py-3 rounded-xl font-black text-sm text-white transition hover:opacity-90 active:scale-98 disabled:opacity-50"
                style={{background: `linear-gradient(135deg, ${PLANS.find(p=>p.id===selectedPlan)?.color}, #6366f1)`}}
              >
                {loading ? "Yuborilmoqda..." : `📩 So'rov yuborish — ${PLANS.find(p=>p.id===selectedPlan)?.priceUSD}`}
              </button>
            </div>
          )}

          {submitted && (
            <div className="p-3 rounded-xl bg-green-950/30 border border-green-800/50 text-center">
              <p className="text-green-400 font-bold text-sm">✅ So'rov yuborildi!</p>
              <p className="text-xs text-slate-400 mt-1">Admin ko'rib chiqadi va javob beradi</p>
            </div>
          )}
        </>
      )}

      {/* ── MY REQUESTS ── */}
      {myRequests.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-bold text-slate-300">📋 Mening So'rovlarim</p>
          {myRequests.slice(0, 5).map(req => (
            <div key={req.id} className={`p-3 rounded-xl border ${req.status === "approved" ? "bg-green-950/20 border-green-900/40" : req.status === "denied" ? "bg-rose-950/20 border-rose-900/40" : "bg-slate-900/60 border-slate-800"}`}>
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-bold text-slate-200">{req.label} — {req.priceUSD}</p>
                <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${req.status === "approved" ? "bg-green-800 text-green-200" : req.status === "denied" ? "bg-rose-900 text-rose-300" : "bg-amber-900/40 text-amber-400"}`}>
                  {req.status === "approved" ? "✅ TASDIQLANDI" : req.status === "denied" ? "❌ RAD ETILDI" : "⏳ KUTMOQDA"}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-mono">{new Date(req.requestedAt).toLocaleString("uz-UZ")}</p>
              {req.adminReply && (
                <div className="mt-2 p-2 rounded-lg bg-slate-800/60">
                  <p className="text-[9px] text-slate-500 font-bold">ADMIN JAVOBI:</p>
                  <p className="text-xs text-slate-300 mt-0.5">{req.adminReply}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── FEATURES LIST ── */}
      <div className="space-y-2">
        <p className="text-sm font-bold text-slate-300 mt-2">✨ Premium Imtiyozlar ({PREMIUM_FEATURES.length}+)</p>
        <div className="grid grid-cols-1 gap-1.5">
          {PREMIUM_FEATURES.map(f => (
            <div key={f.label} className={`flex items-center gap-3 p-3 rounded-xl border transition ${isPremium ? "bg-amber-950/10 border-amber-900/20" : "bg-slate-900/40 border-slate-800/60"}`}>
              <span className="text-lg flex-shrink-0">{f.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-slate-200">{f.label}</p>
                <p className="text-[10px] text-slate-500">{f.desc}</p>
              </div>
              {isPremium
                ? <span className="text-green-400 text-xs flex-shrink-0">✓</span>
                : <span className="text-slate-600 text-xs flex-shrink-0">🔒</span>
              }
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
