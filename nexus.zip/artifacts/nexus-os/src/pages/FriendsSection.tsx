import { useState, useEffect, useCallback } from "react";
import { ref, onValue, set, remove, get } from "firebase/database";
import { db } from "../firebase";
import { logActivity } from "../utils/activityLog";
import { Users, UserPlus, UserCheck, UserX, MessageSquare, Phone, Search, Star, Clock, CheckCircle2, XCircle, Heart } from "lucide-react";

interface Props {
  username: string;
  accentColor: string;
  onOpenChat: (peer: string) => void;
  onStartCall: (peer: string) => void;
  onOpenProfile: (user: string) => void;
}

interface FriendEntry {
  name: string;
  online: boolean;
  premium: boolean;
  stars: number;
  since?: number;
}

interface RequestEntry {
  from: string;
  ts: number;
  online: boolean;
}

type View = "friends" | "requests" | "find";

function timeAgo(ts: number) {
  const d = Date.now() - ts;
  if (d < 3600000) return `${Math.floor(d / 60000)} daqiqa oldin`;
  if (d < 86400000) return `${Math.floor(d / 3600000)} soat oldin`;
  return `${Math.floor(d / 86400000)} kun oldin`;
}

function Avatar({ name, size = "md", online, premium, color }: { name: string; size?: "sm" | "md" | "lg"; online?: boolean; premium?: boolean; color: string }) {
  const sz = size === "sm" ? "w-8 h-8 text-sm" : size === "lg" ? "w-14 h-14 text-2xl" : "w-11 h-11 text-base";
  return (
    <div className={`relative flex-shrink-0 ${sz} rounded-full flex items-center justify-center font-black text-white`}
      style={{ background: `linear-gradient(135deg, ${color}88, #6366f1)`, boxShadow: online ? `0 0 12px ${color}50` : undefined }}>
      {name[0]?.toUpperCase()}
      {online !== undefined && (
        <div className={`absolute -bottom-0.5 -right-0.5 rounded-full border-2 border-[#030712] ${online ? "bg-green-400" : "bg-slate-700"}`}
          style={{ width: size === "lg" ? 14 : 10, height: size === "lg" ? 14 : 10 }} />
      )}
      {premium && <div className="absolute -top-1 -right-1 text-xs">👑</div>}
    </div>
  );
}

export default function FriendsSection({ username, accentColor, onOpenChat, onStartCall, onOpenProfile }: Props) {
  const [view, setView] = useState<View>("friends");
  const [friends, setFriends] = useState<FriendEntry[]>([]);
  const [incomingReqs, setIncomingReqs] = useState<RequestEntry[]>([]);
  const [outgoingReqs, setOutgoingReqs] = useState<string[]>([]);
  const [allUsers, setAllUsers] = useState<string[]>([]);
  const [onlineSet, setOnlineSet] = useState<Set<string>>(new Set());
  const [premiumSet, setPremiumSet] = useState<Set<string>>(new Set());
  const [starsMap, setStarsMap] = useState<Record<string, number>>({});
  const [friendsSet, setFriendsSet] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [animIn, setAnimIn] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);

  useEffect(() => { setTimeout(() => setAnimIn(true), 60); }, []);

  function showFlash(msg: string) {
    setFlash(msg);
    setTimeout(() => setFlash(null), 2500);
  }

  // Online status
  useEffect(() => {
    return onValue(ref(db, "status"), snap => {
      const s = new Set<string>();
      snap.forEach(c => { if (c.val()?.state === "online") s.add(c.key!); });
      setOnlineSet(s);
    });
  }, []);

  // All users
  useEffect(() => {
    return onValue(ref(db, "users"), snap => {
      const list: string[] = [];
      snap.forEach(c => { if (c.key && c.key !== username) list.push(c.key); });
      setAllUsers(list);
    });
  }, [username]);

  // Premium + stars
  useEffect(() => {
    if (!allUsers.length) return;
    allUsers.forEach(async u => {
      const [pSnap, sSnap] = await Promise.all([
        get(ref(db, `premium/${u}`)),
        get(ref(db, `stars/${u}`)),
      ]);
      if (pSnap.val()?.expiresAt > Date.now()) setPremiumSet(prev => new Set([...prev, u]));
      const bal = sSnap.val()?.balance || 0;
      if (bal > 0) setStarsMap(prev => ({ ...prev, [u]: bal }));
    });
  }, [allUsers]);

  // My friends
  useEffect(() => {
    const unsub = onValue(ref(db, `friends/${username}`), snap => {
      const set = new Set<string>();
      const list: FriendEntry[] = [];
      snap.forEach(c => {
        if (c.val()?.since) {
          set.add(c.key!);
          list.push({ name: c.key!, online: onlineSet.has(c.key!), premium: premiumSet.has(c.key!), stars: starsMap[c.key!] || 0, since: c.val().since });
        }
      });
      setFriendsSet(set);
      setFriends(list);
      setLoading(false);
    });
    return () => unsub();
  }, [username, onlineSet, premiumSet, starsMap]);

  // Incoming requests
  useEffect(() => {
    return onValue(ref(db, `friend_requests/${username}`), snap => {
      const list: RequestEntry[] = [];
      snap.forEach(c => {
        if (c.val()?.ts) list.push({ from: c.key!, ts: c.val().ts, online: onlineSet.has(c.key!) });
      });
      list.sort((a, b) => b.ts - a.ts);
      setIncomingReqs(list);
    });
  }, [username, onlineSet]);

  // Outgoing requests I sent
  useEffect(() => {
    const unsubs: (() => void)[] = [];
    allUsers.forEach(u => {
      const unsub = onValue(ref(db, `friend_requests/${u}/${username}`), snap => {
        if (snap.exists()) {
          setOutgoingReqs(prev => prev.includes(u) ? prev : [...prev, u]);
        } else {
          setOutgoingReqs(prev => prev.filter(x => x !== u));
        }
      });
      unsubs.push(unsub);
    });
    return () => unsubs.forEach(f => f());
  }, [allUsers, username]);

  async function sendRequest(to: string) {
    await set(ref(db, `friend_requests/${to}/${username}`), { ts: Date.now(), from: username });
    showFlash(`✅ Do'stlik so'rovi @${to} ga yuborildi!`);
  }

  async function cancelRequest(to: string) {
    await remove(ref(db, `friend_requests/${to}/${username}`));
    showFlash(`❌ So'rov bekor qilindi`);
  }

  async function acceptRequest(from: string) {
    const now = Date.now();
    await Promise.all([
      set(ref(db, `friends/${username}/${from}`), { since: now }),
      set(ref(db, `friends/${from}/${username}`), { since: now }),
      remove(ref(db, `friend_requests/${username}/${from}`)),
    ]);
    logActivity("friend_accept", username, { targetUser: from });
    showFlash(`🎉 @${from} do'stlar ro'yxatiga qo'shildi!`);
  }

  async function declineRequest(from: string) {
    await remove(ref(db, `friend_requests/${username}/${from}`));
    showFlash(`Do'stlik so'rovi rad etildi`);
  }

  async function removeFriend(peer: string) {
    if (!confirm(`@${peer} ni do'stlar ro'yxatidan olib tashlaysizmi?`)) return;
    await Promise.all([
      remove(ref(db, `friends/${username}/${peer}`)),
      remove(ref(db, `friends/${peer}/${username}`)),
    ]);
    showFlash(`@${peer} do'stlar ro'yxatidan olib tashlandi`);
  }

  // Filtered data
  const lc = search.toLowerCase();
  const filteredFriends = friends.filter(f => f.name.toLowerCase().includes(lc));
  const onlineFriends = filteredFriends.filter(f => onlineSet.has(f.name));
  const offlineFriends = filteredFriends.filter(f => !onlineSet.has(f.name));

  const suggestions = allUsers.filter(u =>
    !friendsSet.has(u) &&
    !outgoingReqs.includes(u) &&
    !incomingReqs.some(r => r.from === u) &&
    u.toLowerCase().includes(lc)
  ).slice(0, 20);

  const tabs: { key: View; label: string; icon: string; count?: number }[] = [
    { key: "friends",  label: "Do'stlar",      icon: "👥", count: friends.length },
    { key: "requests", label: "So'rovlar",      icon: "📨", count: incomingReqs.length },
    { key: "find",     label: "Qidirish",       icon: "🔍" },
  ];

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      <style>{`
        @keyframes fr-slide { from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);} }
        @keyframes fr-flash { from{opacity:0;transform:translateY(-8px) scale(0.96);}to{opacity:1;transform:translateY(0) scale(1);} }
        .fr-card { animation: fr-slide 0.3s ease both; }
        .fr-hover { transition:all 0.18s; }
        .fr-hover:hover { background: rgba(30,41,59,0.7); }
      `}</style>

      {/* Flash notification */}
      {flash && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl text-sm font-bold text-white shadow-2xl"
          style={{ background:"rgba(15,23,42,0.95)",border:`1px solid ${accentColor}40`,backdropFilter:"blur(20px)",animation:"fr-flash 0.3s ease" }}>
          {flash}
        </div>
      )}

      {/* ── Header ── */}
      <div className="flex-shrink-0 px-4 pt-4 pb-2 relative overflow-hidden"
        style={{ animation:animIn?"fr-slide 0.35s ease both":"none",opacity:animIn?1:0 }}>
        <div className="absolute top-0 left-0 right-0 h-px" style={{ background:`linear-gradient(90deg,transparent,${accentColor}50,transparent)` }}/>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl"
              style={{ background:`${accentColor}20`,border:`1px solid ${accentColor}35` }}>👥</div>
            <div>
              <p className="text-base font-black text-white">Do'stlar</p>
              <p className="text-[10px] text-slate-500">
                {friends.length} do'st · {onlineFriends.length} onlayn
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl"
            style={{ background:`${accentColor}10`,border:`1px solid ${accentColor}25` }}>
            <Heart className="w-3.5 h-3.5" style={{ color:accentColor }}/>
            <span className="text-xs font-black" style={{ color:accentColor }}>{friends.length}</span>
          </div>
        </div>

        {/* Search */}
        <div className="mt-3 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600"/>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Do'st qidirish..."
            className="w-full bg-slate-900/70 border border-slate-800 rounded-2xl pl-9 pr-3 py-2.5 text-sm text-slate-300 outline-none focus:border-slate-600 transition placeholder-slate-700"/>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="px-4 pb-2 flex-shrink-0"
        style={{ animation:animIn?"fr-slide 0.35s 0.05s ease both":"none",opacity:animIn?1:0 }}>
        <div className="flex gap-0.5 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60">
          {tabs.map(t => (
            <button key={t.key} onClick={() => setView(t.key)}
              className="flex-1 flex items-center justify-center gap-1 py-2 rounded-xl font-bold text-[11px] transition-all relative"
              style={view===t.key
                ? { background:`${accentColor}20`,color:accentColor }
                : { color:"#64748b" }}>
              {t.icon}
              <span className="hidden sm:inline">{t.label}</span>
              {t.count !== undefined && t.count > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[16px] h-4 rounded-full text-[9px] font-black flex items-center justify-center px-1"
                  style={{ background: t.key==="requests" ? "#ef4444" : accentColor, color:"#fff" }}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 overflow-y-auto px-4 pb-6">

        {/* ===== FRIENDS VIEW ===== */}
        {view === "friends" && (
          <div className="space-y-4 tab-slide-in">
            {loading ? (
              <div className="flex items-center justify-center py-16">
                <div className="w-7 h-7 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor:accentColor+"60",borderTopColor:accentColor }}/>
              </div>
            ) : friends.length === 0 ? (
              <div className="flex flex-col items-center gap-4 py-16 text-center">
                <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-5xl"
                  style={{ background:`${accentColor}12`,border:`1px solid ${accentColor}20` }}>🤝</div>
                <div>
                  <p className="text-white font-black text-lg">Hali do'stingiz yo'q</p>
                  <p className="text-slate-500 text-sm mt-1">"Qidirish" bo'limida yangi do'stlar toping</p>
                </div>
                <button onClick={() => setView("find")}
                  className="px-6 py-3 rounded-2xl font-bold text-sm transition active:scale-95"
                  style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                  👥 Do'st qidirish
                </button>
              </div>
            ) : (
              <>
                {/* Online friends */}
                {onlineFriends.length > 0 && (
                  <div>
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"/>
                      ONLAYN — {onlineFriends.length} ta
                    </p>
                    <div className="space-y-1">
                      {onlineFriends.map((f, i) => (
                        <FriendCard key={f.name} friend={f} idx={i} accentColor={accentColor}
                          online={true}
                          premium={premiumSet.has(f.name)}
                          stars={starsMap[f.name] || 0}
                          onChat={() => onOpenChat(f.name)}
                          onCall={() => onStartCall(f.name)}
                          onProfile={() => onOpenProfile(f.name)}
                          onRemove={() => removeFriend(f.name)}/>
                      ))}
                    </div>
                  </div>
                )}
                {/* Offline friends */}
                {offlineFriends.length > 0 && (
                  <div>
                    <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">OFLAYN — {offlineFriends.length} ta</p>
                    <div className="space-y-1">
                      {offlineFriends.map((f, i) => (
                        <FriendCard key={f.name} friend={f} idx={i + onlineFriends.length} accentColor={accentColor}
                          online={false}
                          premium={premiumSet.has(f.name)}
                          stars={starsMap[f.name] || 0}
                          onChat={() => onOpenChat(f.name)}
                          onCall={() => onStartCall(f.name)}
                          onProfile={() => onOpenProfile(f.name)}
                          onRemove={() => removeFriend(f.name)}/>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* ===== REQUESTS VIEW ===== */}
        {view === "requests" && (
          <div className="space-y-4 tab-slide-in">
            {/* Incoming */}
            <div>
              <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">
                📨 KELIB TUSHGAN SO'ROVLAR — {incomingReqs.length} ta
              </p>
              {incomingReqs.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/40 border border-slate-800/40">
                  <span className="text-2xl">📭</span>
                  <p className="text-sm text-slate-500">Hozircha yangi so'rov yo'q</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {incomingReqs.map((req, i) => (
                    <div key={req.from}
                      className="fr-card flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800"
                      style={{ animationDelay:`${i*40}ms` }}>
                      <Avatar name={req.from} color={accentColor} online={req.online}/>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="font-bold text-sm text-white">@{req.from}</p>
                          {req.online && <span className="text-[8px] text-green-400 font-bold">● LIVE</span>}
                        </div>
                        <p className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Clock className="w-2.5 h-2.5"/>
                          {timeAgo(req.ts)}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <button onClick={() => declineRequest(req.from)}
                          className="w-8 h-8 rounded-xl flex items-center justify-center bg-rose-950/30 border border-rose-900/50 hover:bg-rose-900/40 transition active:scale-90">
                          <XCircle className="w-4 h-4 text-rose-400"/>
                        </button>
                        <button onClick={() => acceptRequest(req.from)}
                          className="px-3 h-8 rounded-xl flex items-center gap-1.5 font-bold text-xs transition active:scale-90"
                          style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}40` }}>
                          <CheckCircle2 className="w-3.5 h-3.5"/>
                          Qabul
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Outgoing */}
            {outgoingReqs.length > 0 && (
              <div>
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">
                  📤 YUBORILGAN SO'ROVLAR — {outgoingReqs.length} ta
                </p>
                <div className="space-y-2">
                  {outgoingReqs.map((u, i) => (
                    <div key={u}
                      className="fr-card flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900/40 border border-slate-800/40"
                      style={{ animationDelay:`${i*40}ms` }}>
                      <Avatar name={u} color="#64748b" online={onlineSet.has(u)}/>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-sm text-slate-300">@{u}</p>
                        <p className="text-[10px] text-slate-600 mt-0.5">Kutilmoqda...</p>
                      </div>
                      <button onClick={() => cancelRequest(u)}
                        className="px-3 h-8 rounded-xl font-bold text-xs text-rose-400 border border-rose-900/50 bg-rose-950/20 hover:bg-rose-900/30 transition active:scale-90">
                        Bekor qilish
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== FIND VIEW ===== */}
        {view === "find" && (
          <div className="tab-slide-in">
            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-3">
              🔍 FOYDALANUVCHILAR — {suggestions.length} ta
            </p>
            {suggestions.length === 0 && search.length > 0 ? (
              <div className="text-center py-10">
                <p className="text-slate-500 text-sm">"{search}" topilmadi</p>
              </div>
            ) : (
              <div className="space-y-1.5">
                {suggestions.map((u, i) => {
                  const isOnline = onlineSet.has(u);
                  const isPrem = premiumSet.has(u);
                  const stars = starsMap[u] || 0;
                  const alreadyFriend = friendsSet.has(u);
                  const sent = outgoingReqs.includes(u);
                  return (
                    <div key={u}
                      className="fr-card fr-hover flex items-center gap-3 p-3 rounded-2xl border border-slate-800/40"
                      style={{ animationDelay:`${Math.min(i*25,250)}ms`,background:"rgba(15,23,42,0.6)" }}>
                      <Avatar name={u} color={accentColor} online={isOnline} premium={isPrem}/>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="font-bold text-sm text-white">@{u}</p>
                          {isPrem && <span className="text-[8px] text-amber-400">👑 Premium</span>}
                          {isOnline && <span className="text-[8px] text-green-400 font-bold">● LIVE</span>}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          {stars > 0 && <span className="text-[9px] text-amber-400">⭐ {stars}</span>}
                          <span className="text-[9px] text-slate-600">{isOnline ? "Onlayn" : "Oflayn"}</span>
                        </div>
                      </div>
                      <div className="flex-shrink-0 flex items-center gap-1.5">
                        <button onClick={() => onOpenProfile(u)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition">
                          <Users className="w-3.5 h-3.5"/>
                        </button>
                        {alreadyFriend ? (
                          <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[10px] font-bold text-green-400 bg-green-950/30 border border-green-900/40">
                            <UserCheck className="w-3 h-3"/>Do'st
                          </div>
                        ) : sent ? (
                          <button onClick={() => cancelRequest(u)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[10px] font-bold text-slate-400 bg-slate-800/50 border border-slate-700 hover:bg-slate-700 transition active:scale-90">
                            <Clock className="w-3 h-3"/>Kutilmoqda
                          </button>
                        ) : (
                          <button onClick={() => sendRequest(u)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold transition active:scale-90"
                            style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                            <UserPlus className="w-3 h-3"/>So'rov
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function FriendCard({ friend, idx, accentColor, online, premium, stars, onChat, onCall, onProfile, onRemove }: {
  friend: FriendEntry; idx: number; accentColor: string; online: boolean;
  premium: boolean; stars: number;
  onChat: () => void; onCall: () => void; onProfile: () => void; onRemove: () => void;
}) {
  const [showActions, setShowActions] = useState(false);
  return (
    <div className="fr-card group"
      style={{ animationDelay:`${Math.min(idx*30,300)}ms` }}>
      <div className={`flex items-center gap-3 p-3 rounded-2xl border transition cursor-pointer ${showActions ? "border-slate-700 bg-slate-900/60" : "border-slate-800/40 bg-slate-900/40"}`}
        onClick={() => setShowActions(v => !v)}>
        <div className="relative flex-shrink-0">
          <div className="w-11 h-11 rounded-full flex items-center justify-center text-base font-black text-white"
            style={{ background:`linear-gradient(135deg,${accentColor}66,#6366f1)`, boxShadow:online?`0 0 10px ${accentColor}40`:undefined }}>
            {friend.name[0]?.toUpperCase()}
          </div>
          <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#030712] ${online?"bg-green-400":"bg-slate-700"}`}/>
          {premium && <div className="absolute -top-1 -right-1 text-xs leading-none">👑</div>}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="font-bold text-sm text-white truncate">@{friend.name}</p>
            {online && <span className="text-[8px] text-green-400 font-bold flex-shrink-0">● LIVE</span>}
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            {stars > 0 && <span className="text-[9px] text-amber-400">⭐ {stars}</span>}
            {friend.since && <span className="text-[9px] text-slate-600">{timeAgo(friend.since)} beri do'st</span>}
          </div>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button onClick={e => { e.stopPropagation(); onChat(); }}
            className="w-8 h-8 rounded-xl flex items-center justify-center transition active:scale-90 hover:bg-slate-700"
            style={{ background:`${accentColor}15` }}>
            <MessageSquare className="w-3.5 h-3.5" style={{ color:accentColor }}/>
          </button>
          {online && (
            <button onClick={e => { e.stopPropagation(); onCall(); }}
              className="w-8 h-8 rounded-xl flex items-center justify-center bg-green-950/30 hover:bg-green-900/40 transition active:scale-90">
              <Phone className="w-3.5 h-3.5 text-green-400"/>
            </button>
          )}
        </div>
      </div>
      {showActions && (
        <div className="flex gap-1.5 px-3 pb-2 pt-1">
          <button onClick={onProfile}
            className="flex-1 py-1.5 rounded-xl text-[10px] font-bold text-slate-400 hover:text-slate-200 bg-slate-800/50 hover:bg-slate-700 border border-slate-700 transition">
            👤 Profil
          </button>
          <button onClick={onChat}
            className="flex-1 py-1.5 rounded-xl text-[10px] font-bold transition"
            style={{ background:`${accentColor}15`,color:accentColor,border:`1px solid ${accentColor}30` }}>
            💬 Chat
          </button>
          <button onClick={onRemove}
            className="flex-1 py-1.5 rounded-xl text-[10px] font-bold text-rose-400 bg-rose-950/20 hover:bg-rose-900/30 border border-rose-900/40 transition">
            🗑 O'chirish
          </button>
        </div>
      )}
    </div>
  );
}
