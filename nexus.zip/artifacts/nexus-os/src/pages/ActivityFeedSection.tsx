import { useState, useEffect, useRef } from "react";
import { ref, onValue, query, orderByChild, limitToLast } from "firebase/database";
import { db } from "../firebase";
import { ActivityEntry, ActivityType } from "../utils/activityLog";
import { Zap, Users, Calendar, Hash, MessageSquare, Heart, Flame } from "lucide-react";

interface Props { username: string; accentColor: string; onOpenProfile: (u: string) => void; onNavigate: (tab: string) => void; }

const TYPE_META: Record<ActivityType, { icon: string; color: string; label: (a: ActivityEntry) => string }> = {
  friend_accept: { icon: "🤝", color: "#4ade80",  label: a => `@${a.actor} va @${a.targetUser} do'st bo'ldi` },
  event_created: { icon: "🎉", color: "#f59e0b",  label: a => `@${a.actor} yangi tadbir yaratdi: ${a.entityName}` },
  event_rsvp:    { icon: "✅", color: "#22c55e",  label: a => `@${a.actor} "${a.entityName}" tadbiriga boradi` },
  club_created:  { icon: "🏘️", color: "#a855f7",  label: a => `@${a.actor} "${a.entityName}" klubini yaratdi` },
  club_joined:   { icon: "🚀", color: "#06b6d4",  label: a => `@${a.actor} "${a.entityName}" klubiga qo'shildi` },
  club_post:     { icon: "💬", color: "#818cf8",  label: a => `@${a.actor} "${a.entityName}" klubiga post yozdi` },
  feed_post:     { icon: "📝", color: "#f472b6",  label: a => `@${a.actor} lentaga yangi post qo'ydi` },
  went_online:   { icon: "🟢", color: "#4ade80",  label: a => `@${a.actor} onlayn` },
};

type FilterType = "all" | "friends" | "events" | "clubs" | "social";

const FILTERS: { key: FilterType; emoji: string; label: string; types: ActivityType[] }[] = [
  { key: "all",    emoji: "⚡", label: "Barchasi",  types: ["friend_accept","event_created","event_rsvp","club_created","club_joined","club_post","feed_post","went_online"] },
  { key: "social", emoji: "🤝", label: "Ijtimoiy",  types: ["friend_accept","feed_post","went_online"] },
  { key: "events", emoji: "🎉", label: "Tadbirlar", types: ["event_created","event_rsvp"] },
  { key: "clubs",  emoji: "🏘️", label: "Klublar",   types: ["club_created","club_joined","club_post"] },
];

function timeAgo(ts: number) {
  const d = Date.now() - ts;
  if (d < 60000) return "hozir";
  if (d < 3600000) return `${Math.floor(d / 60000)}d oldin`;
  if (d < 86400000) return `${Math.floor(d / 3600000)}s oldin`;
  return `${Math.floor(d / 86400000)}kun oldin`;
}

const AVATARS = ["#22d3ee","#a855f7","#f59e0b","#4ade80","#3b82f6","#f97316","#ec4899","#06b6d4","#e879f9","#ef4444"];
function avatarColor(name: string) { let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) & 0xffffff; return AVATARS[h % AVATARS.length]; }

function ActivityCard({
  entry, accentColor, onOpenProfile, isNew,
}: { entry: ActivityEntry; accentColor: string; onOpenProfile: (u: string) => void; isNew: boolean }) {
  const meta = TYPE_META[entry.type] || TYPE_META.feed_post;
  const col = meta.color;
  const label = meta.label(entry);
  const avc = avatarColor(entry.actor);

  const nav = entry.type === "event_created" || entry.type === "event_rsvp" ? "events"
    : entry.type.startsWith("club") ? "clubs"
    : entry.type === "friend_accept" ? "friends"
    : "feed";

  return (
    <div className={`relative rounded-2xl border overflow-hidden transition-all duration-300 ${isNew ? "scale-[1.01]" : ""}`}
      style={{ background: "rgba(10,15,30,0.85)", borderColor: `${col}22` }}>
      {isNew && (
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{ background: `linear-gradient(90deg,transparent,${col},transparent)`, animation: "pulse 1s ease-in-out" }} />
      )}
      <div className="px-4 py-3.5 flex items-start gap-3">
        {/* Avatar */}
        <button onClick={() => onOpenProfile(entry.actor)}
          className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-black text-white flex-shrink-0 relative"
          style={{ background: `linear-gradient(135deg,${avc},${avc}88)` }}>
          {entry.actor[0]?.toUpperCase()}
          <span className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full flex items-center justify-center text-[11px]"
            style={{ background: "rgba(10,15,30,0.95)", border: `1px solid ${col}40` }}>
            {meta.icon}
          </span>
        </button>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <p className="text-sm text-slate-200 leading-snug">
            {label.split(/@\w+/g).reduce<React.ReactNode[]>((acc, part, i, arr) => {
              acc.push(<span key={`t${i}`}>{part}</span>);
              const match = label.match(new RegExp(`@\\w+`, "g"));
              if (match && i < arr.length - 1) {
                const user = match[i].slice(1);
                acc.push(
                  <button key={`u${i}`} onClick={() => onOpenProfile(user)}
                    className="font-black hover:underline transition"
                    style={{ color: accentColor }}>
                    @{user}
                  </button>
                );
              }
              return acc;
            }, [])}
          </p>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-[9px] text-slate-600 font-mono">{timeAgo(entry.ts)}</span>
            {isNew && (
              <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full animate-pulse"
                style={{ background: `${col}20`, color: col }}>YANGI</span>
            )}
          </div>
        </div>

        {/* Type badge */}
        <div className="flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center text-base"
          style={{ background: `${col}15`, border: `1px solid ${col}25` }}>
          {meta.icon}
        </div>
      </div>
    </div>
  );
}

export default function ActivityFeedSection({ username, accentColor, onOpenProfile, onNavigate }: Props) {
  const [entries, setEntries] = useState<ActivityEntry[]>([]);
  const [filter, setFilter] = useState<FilterType>("all");
  const [animIn, setAnimIn] = useState(false);
  const [newIds, setNewIds] = useState<Set<string>>(new Set());
  const [liveCount, setLiveCount] = useState(0);
  const [onlineSet, setOnlineSet] = useState<Set<string>>(new Set());
  const prevKeys = useRef<Set<string>>(new Set());
  const isFirstLoad = useRef(true);

  useEffect(() => { setTimeout(() => setAnimIn(true), 60); }, []);

  useEffect(() => {
    return onValue(ref(db, "status"), snap => {
      const s = new Set<string>();
      snap.forEach(c => { if (c.val()?.state === "online") s.add(c.key!); });
      setOnlineSet(s);
      setLiveCount(s.size);
    });
  }, []);

  useEffect(() => {
    const q = query(ref(db, "activity_feed"), orderByChild("ts"), limitToLast(80));
    return onValue(q, snap => {
      const list: ActivityEntry[] = [];
      if (snap.exists()) snap.forEach(c => { list.push({ ...(c.val() as ActivityEntry) }); });
      list.sort((a, b) => b.ts - a.ts);

      // Detect new entries
      if (!isFirstLoad.current) {
        const incoming = new Set(list.map((_, i) => `${list[i].actor}_${list[i].ts}`));
        const fresh: string[] = [];
        incoming.forEach(k => { if (!prevKeys.current.has(k)) fresh.push(k); });
        if (fresh.length > 0) {
          setNewIds(prev => { const s = new Set(prev); fresh.forEach(k => s.add(k)); return s; });
          setTimeout(() => setNewIds(new Set()), 4000);
        }
      }
      isFirstLoad.current = false;
      prevKeys.current = new Set(list.map((_, i) => `${list[i].actor}_${list[i].ts}`));
      setEntries(list);
    });
  }, []);

  const filterMeta = FILTERS.find(f => f.key === filter)!;
  const filtered = entries.filter(e => filterMeta.types.includes(e.type));

  // Group by time: "Hozir", "Bugun", "Oldin"
  const now = Date.now();
  const grouped: { label: string; items: ActivityEntry[] }[] = [];
  const live   = filtered.filter(e => now - e.ts < 300000);        // < 5 min
  const today  = filtered.filter(e => now - e.ts >= 300000 && now - e.ts < 86400000);
  const older  = filtered.filter(e => now - e.ts >= 86400000);
  if (live.length)  grouped.push({ label: "🔴 Hoziroq", items: live });
  if (today.length) grouped.push({ label: "📅 Bugun",   items: today });
  if (older.length) grouped.push({ label: "🗓 Avvalroq",  items: older });

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      <style>{`
        @keyframes act-in { from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);} }
        .act-card { animation: act-in 0.28s ease both; }
      `}</style>

      {/* Header */}
      <div className="flex-shrink-0 px-4 pt-4 pb-2"
        style={{ animation: animIn ? "act-in 0.3s ease" : undefined }}>
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{ background: `linear-gradient(90deg,transparent,${accentColor}50,transparent)` }} />

        {/* Title row */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center relative"
              style={{ background: `${accentColor}20`, border: `1px solid ${accentColor}35` }}>
              <Zap className="w-5 h-5" style={{ color: accentColor }} />
              {liveCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black text-white bg-green-500 animate-pulse">
                  {liveCount}
                </span>
              )}
            </div>
            <div>
              <p className="text-base font-black text-white">Faollik Lentasi</p>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                <p className="text-[10px] text-green-400 font-bold">{liveCount} onlayn · jonli yangilanish</p>
              </div>
            </div>
          </div>
          <div className="text-[9px] text-slate-600 font-mono">{filtered.length} ta</div>
        </div>

        {/* Live pulse bar */}
        <div className="flex items-center gap-2 px-3 py-2 rounded-2xl mb-3"
          style={{ background: `${accentColor}08`, border: `1px solid ${accentColor}15` }}>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-[9px] font-black text-orange-400 uppercase tracking-widest">LIVE</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto flex-1">
            {Array.from(onlineSet).slice(0, 10).map(u => (
              <button key={u} onClick={() => onOpenProfile(u)}
                className="flex-shrink-0 flex items-center gap-1 px-1.5 py-0.5 rounded-lg transition"
                style={{ background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.2)" }}>
                <div className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black text-white"
                  style={{ background: avatarColor(u) }}>{u[0]?.toUpperCase()}</div>
                <span className="text-[9px] text-green-400 font-mono">{u}</span>
              </button>
            ))}
            {onlineSet.size === 0 && (
              <span className="text-[10px] text-slate-600">Hozir hech kim onlayn emas</span>
            )}
          </div>
        </div>

        {/* Quick nav */}
        <div className="grid grid-cols-3 gap-1.5 mb-3">
          {[
            { tab: "events", emoji: "🎉", label: "Tadbirlar", color: "#f59e0b" },
            { tab: "clubs",  emoji: "🏘️", label: "Klublar",   color: "#a855f7" },
            { tab: "friends",emoji: "🤝", label: "Do'stlar",  color: accentColor },
          ].map(item => (
            <button key={item.tab} onClick={() => onNavigate(item.tab)}
              className="flex items-center justify-center gap-1.5 py-2 rounded-xl text-[10px] font-bold transition active:scale-95"
              style={{ background: `${item.color}12`, color: item.color, border: `1px solid ${item.color}25` }}>
              {item.emoji} {item.label}
            </button>
          ))}
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60">
          {FILTERS.map(f => (
            <button key={f.key} onClick={() => setFilter(f.key)}
              className="flex-1 py-1.5 rounded-xl text-[10px] font-bold transition"
              style={filter === f.key
                ? { background: `${accentColor}20`, color: accentColor }
                : { color: "#64748b" }}>
              {f.emoji} {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto px-4 pb-6 space-y-1">
        {grouped.length === 0 && (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
              style={{ background: `${accentColor}12`, border: `1px solid ${accentColor}20` }}>
              ⚡
            </div>
            <div>
              <p className="text-white font-black text-lg">Hali faollik yo'q</p>
              <p className="text-slate-500 text-sm mt-1">Tadbirga boring, klub yarating yoki do'st qo'shing!</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => onNavigate("events")}
                className="px-4 py-2 rounded-xl text-xs font-bold transition active:scale-95"
                style={{ background: "#f59e0b20", color: "#f59e0b", border: "1px solid #f59e0b35" }}>
                🎉 Tadbirlar
              </button>
              <button onClick={() => onNavigate("clubs")}
                className="px-4 py-2 rounded-xl text-xs font-bold transition active:scale-95"
                style={{ background: "#a855f720", color: "#a855f7", border: "1px solid #a855f735" }}>
                🏘️ Klublar
              </button>
            </div>
          </div>
        )}

        {grouped.map(group => (
          <div key={group.label} className="mt-2">
            <div className="flex items-center gap-2 py-2 mb-1">
              <div className="h-px flex-1" style={{ background: "rgba(255,255,255,0.06)" }} />
              <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">{group.label}</span>
              <div className="h-px flex-1" style={{ background: "rgba(255,255,255,0.06)" }} />
            </div>
            <div className="space-y-2">
              {group.items.map((entry, i) => {
                const key = `${entry.actor}_${entry.ts}`;
                return (
                  <div key={key} className="act-card" style={{ animationDelay: `${Math.min(i * 30, 300)}ms` }}>
                    <ActivityCard
                      entry={entry}
                      accentColor={accentColor}
                      onOpenProfile={onOpenProfile}
                      isNew={newIds.has(key)}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
