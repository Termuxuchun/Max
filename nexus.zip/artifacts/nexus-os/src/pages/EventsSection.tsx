import { useState, useEffect, useRef } from "react";
import { ref, push, onValue, set, update, remove, get } from "firebase/database";
import { db } from "../firebase";
import { logActivity } from "../utils/activityLog";
import { Plus, Calendar, MapPin, Users, Clock, ChevronRight, Search, Globe, Wifi, Flame, Star, CheckCircle, XCircle, HelpCircle, Trash2 } from "lucide-react";

interface Props { username: string; accentColor: string; onOpenProfile: (u: string) => void; }

interface Event {
  id: string; title: string; description?: string; creator: string;
  ts: number; eventDate: number; location?: string; online: boolean;
  category: string; maxAttendees?: number; cover?: string; pinned?: boolean;
  rsvp?: Record<string, "going" | "notgoing" | "maybe">;
}

const CATEGORIES = [
  { key: "all",      emoji: "🌐", label: "Barchasi" },
  { key: "gaming",   emoji: "🎮", label: "O'yinlar" },
  { key: "music",    emoji: "🎵", label: "Musiqa" },
  { key: "sport",    emoji: "⚽", label: "Sport" },
  { key: "tech",     emoji: "💻", label: "Texnologiya" },
  { key: "food",     emoji: "🍕", label: "Oziq-ovqat" },
  { key: "art",      emoji: "🎨", label: "San'at" },
  { key: "edu",      emoji: "📚", label: "Ta'lim" },
  { key: "social",   emoji: "🤝", label: "Ijtimoiy" },
];

function pad(n: number) { return String(n).padStart(2, "0"); }

function Countdown({ target }: { target: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  const diff = target - now;
  if (diff <= 0) return <span className="text-xs font-bold text-rose-400">⏰ Boshlandi!</span>;
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (d > 0) return <span className="font-mono text-xs font-bold text-amber-400">{d}k {pad(h)}:{pad(m)}</span>;
  return <span className="font-mono text-xs font-bold text-green-400 animate-pulse">{pad(h)}:{pad(m)}:{pad(s)}</span>;
}

function timeAgo(ts: number) {
  const d = Date.now() - ts;
  if (d < 3600000) return `${Math.floor(d / 60000)} daqiqa oldin`;
  if (d < 86400000) return `${Math.floor(d / 3600000)} soat oldin`;
  return `${Math.floor(d / 86400000)} kun oldin`;
}

function formatDate(ts: number) {
  return new Date(ts).toLocaleString("uz-UZ", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function EventsSection({ username, accentColor, onOpenProfile }: Props) {
  const [events, setEvents] = useState<Event[]>([]);
  const [view, setView] = useState<"browse" | "create" | "detail">("browse");
  const [selected, setSelected] = useState<Event | null>(null);
  const [catFilter, setCatFilter] = useState("all");
  const [timeFilter, setTimeFilter] = useState<"upcoming" | "past" | "mine">("upcoming");
  const [search, setSearch] = useState("");
  const [animIn, setAnimIn] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [onlineSet, setOnlineSet] = useState<Set<string>>(new Set());
  const [allUsers, setAllUsers] = useState<string[]>([]);

  // Form
  const [form, setForm] = useState({
    title: "", description: "", eventDate: "", eventTime: "",
    location: "", online: false, category: "social", maxAttendees: ""
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { setTimeout(() => setAnimIn(true), 60); }, []);

  useEffect(() => {
    return onValue(ref(db, "status"), snap => {
      const s = new Set<string>();
      snap.forEach(c => { if (c.val()?.state === "online") s.add(c.key!); });
      setOnlineSet(s);
    });
  }, []);

  useEffect(() => {
    return onValue(ref(db, "users"), snap => {
      const list: string[] = [];
      snap.forEach(c => { if (c.key) list.push(c.key); });
      setAllUsers(list);
    });
  }, []);

  useEffect(() => {
    return onValue(ref(db, "events"), snap => {
      const list: Event[] = [];
      if (snap.exists()) snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => a.eventDate - b.eventDate);
      setEvents(list);
    });
  }, []);

  function showFlash(msg: string) { setFlash(msg); setTimeout(() => setFlash(null), 2500); }

  async function createEvent() {
    if (!form.title.trim() || !form.eventDate || !form.eventTime) return;
    setSubmitting(true);
    const dateMs = new Date(`${form.eventDate}T${form.eventTime}`).getTime();
    if (isNaN(dateMs)) { setSubmitting(false); return; }
    await push(ref(db, "events"), {
      title: form.title.trim(), description: form.description.trim() || null,
      creator: username, ts: Date.now(), eventDate: dateMs,
      location: form.location.trim() || null, online: form.online,
      category: form.category,
      maxAttendees: form.maxAttendees ? parseInt(form.maxAttendees) : null,
    });
    logActivity("event_created", username, { entityName: form.title.trim() });
    setForm({ title: "", description: "", eventDate: "", eventTime: "", location: "", online: false, category: "social", maxAttendees: "" });
    setView("browse");
    setSubmitting(false);
    showFlash("🎉 Tadbir yaratildi!");
  }

  async function rsvp(event: Event, status: "going" | "notgoing" | "maybe") {
    await set(ref(db, `events/${event.id}/rsvp/${username}`), status);
    if (status === "going") logActivity("event_rsvp", username, { entityName: event.title, entityId: event.id });
    showFlash(status === "going" ? "✅ Borasiz!" : status === "notgoing" ? "❌ Bormasligingiz saqlandi" : "🤔 Ehtimol saqlandi");
  }

  async function deleteEvent(event: Event) {
    if (event.creator !== username) return;
    if (!confirm("Bu tadbirni o'chirasizmi?")) return;
    await remove(ref(db, `events/${event.id}`));
    setSelected(null); setView("browse");
    showFlash("🗑 Tadbir o'chirildi");
  }

  const now = Date.now();
  let filtered = events;
  if (timeFilter === "upcoming") filtered = events.filter(e => e.eventDate > now);
  if (timeFilter === "past") filtered = events.filter(e => e.eventDate <= now);
  if (timeFilter === "mine") filtered = events.filter(e => e.creator === username || e.rsvp?.[username] === "going");
  if (catFilter !== "all") filtered = filtered.filter(e => e.category === catFilter);
  if (search.trim()) filtered = filtered.filter(e => e.title.toLowerCase().includes(search.toLowerCase()) || e.description?.toLowerCase().includes(search.toLowerCase()));

  const myStatus = selected?.rsvp?.[username];
  const goingCount = selected ? Object.values(selected.rsvp || {}).filter(v => v === "going").length : 0;
  const goingUsers = selected ? Object.entries(selected.rsvp || {}).filter(([, v]) => v === "going").map(([k]) => k) : [];

  const catInfo = CATEGORIES.find(c => c.key === selected?.category);

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      <style>{`
        @keyframes ev-in { from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);} }
        .ev-card { animation: ev-in 0.3s ease both; }
        .ev-hover:hover { background: rgba(30,41,59,0.7); }
      `}</style>

      {flash && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl text-sm font-bold text-white shadow-2xl"
          style={{ background:"rgba(15,23,42,0.95)",border:`1px solid ${accentColor}40`,backdropFilter:"blur(20px)" }}>
          {flash}
        </div>
      )}

      {/* ── DETAIL VIEW ── */}
      {view === "detail" && selected && (
        <div className="flex flex-col h-full overflow-y-auto"
          style={{ animation:animIn?"ev-in 0.3s ease":undefined }}>
          {/* Cover / Header */}
          <div className="relative flex-shrink-0 h-48 overflow-hidden"
            style={{ background:`linear-gradient(135deg,${accentColor}22,#6366f122)` }}>
            <div className="absolute inset-0 flex items-center justify-center text-8xl opacity-20">
              {CATEGORIES.find(c => c.key === selected.category)?.emoji || "🎉"}
            </div>
            <div className="absolute inset-0 p-4 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <button onClick={() => { setView("browse"); setSelected(null); }}
                  className="flex items-center gap-1.5 text-white/80 hover:text-white text-sm font-bold bg-black/30 px-3 py-1.5 rounded-xl backdrop-blur-md">
                  ← Orqaga
                </button>
                <div className="flex items-center gap-2">
                  {selected.creator === username && (
                    <button onClick={() => deleteEvent(selected)}
                      className="w-8 h-8 rounded-xl flex items-center justify-center bg-rose-950/60 border border-rose-900/60 text-rose-400 hover:bg-rose-900/60 transition active:scale-90 backdrop-blur-md">
                      <Trash2 className="w-4 h-4"/>
                    </button>
                  )}
                  <div className="px-2.5 py-1 rounded-xl text-xs font-bold bg-black/40 backdrop-blur-md"
                    style={{ color:accentColor }}>
                    {catInfo?.emoji} {catInfo?.label}
                  </div>
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-black text-white drop-shadow-lg">{selected.title}</h1>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs text-white/70">yaratdi: @{selected.creator}</span>
                  <span className="text-white/40">·</span>
                  <span className="text-xs text-white/70">{timeAgo(selected.ts)}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 px-4 py-4 space-y-4">
            {/* Countdown + date */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">⏱ Vaqt</p>
                <Countdown target={selected.eventDate} />
                <p className="text-[10px] text-slate-500">{formatDate(selected.eventDate)}</p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">
                  {selected.online ? "🌐 Online" : "📍 Joylashuv"}
                </p>
                <p className="text-sm font-bold text-white">{selected.online ? "Internet orqali" : (selected.location || "Ko'rsatilmagan")}</p>
              </div>
            </div>

            {/* Going count */}
            <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">👥 Qatnashchilar — {goingCount} ta boradi</p>
                {selected.maxAttendees && (
                  <span className="text-[9px] text-slate-600">Max: {selected.maxAttendees}</span>
                )}
              </div>
              {goingCount > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {goingUsers.slice(0, 12).map(u => (
                    <button key={u} onClick={() => onOpenProfile(u)}
                      className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-slate-800/60 hover:bg-slate-700 transition text-xs">
                      <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black text-white"
                        style={{ background:`linear-gradient(135deg,${accentColor}88,#6366f1)` }}>
                        {u[0]?.toUpperCase()}
                      </div>
                      <span className="text-slate-300">@{u}</span>
                      {onlineSet.has(u) && <span className="w-1.5 h-1.5 rounded-full bg-green-400 flex-shrink-0"/>}
                    </button>
                  ))}
                  {goingUsers.length > 12 && (
                    <span className="px-2 py-1 rounded-xl text-xs text-slate-500 bg-slate-800/40">+{goingUsers.length - 12}</span>
                  )}
                </div>
              ) : (
                <p className="text-xs text-slate-600">Hali hech kim ro'yxatdan o'tmagan. Birinchi bo'ling!</p>
              )}
            </div>

            {/* Description */}
            {selected.description && (
              <div className="p-3.5 rounded-2xl bg-slate-900/40 border border-slate-800/50">
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-2">📝 Tavsif</p>
                <p className="text-sm text-slate-300 leading-relaxed">{selected.description}</p>
              </div>
            )}

            {/* RSVP */}
            {selected.eventDate > now && (
              <div>
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-2">Siz borasizmi?</p>
                <div className="grid grid-cols-3 gap-2">
                  {([
                    { key: "going",    emoji: "✅", label: "Boraman",  color: "#4ade80", bg: "rgba(20,83,45,0.4)", border: "rgba(74,222,128,0.3)" },
                    { key: "maybe",    emoji: "🤔", label: "Ehtimol",  color: "#fbbf24", bg: "rgba(78,52,6,0.4)",  border: "rgba(251,191,36,0.3)" },
                    { key: "notgoing", emoji: "❌", label: "Bormayman",color: "#f87171", bg: "rgba(69,10,10,0.4)", border: "rgba(248,113,113,0.3)" },
                  ] as const).map(opt => (
                    <button key={opt.key} onClick={() => rsvp(selected, opt.key)}
                      className="flex flex-col items-center gap-1.5 py-3 rounded-2xl font-bold text-xs transition active:scale-95"
                      style={myStatus === opt.key
                        ? { background: opt.bg, color: opt.color, border: `1px solid ${opt.border}`, boxShadow: `0 0 12px ${opt.color}30` }
                        : { background: "rgba(15,23,42,0.7)", color: "#64748b", border: "1px solid rgba(255,255,255,0.05)" }}>
                      <span className="text-lg">{opt.emoji}</span>
                      <span>{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── CREATE VIEW ── */}
      {view === "create" && (
        <div className="flex flex-col h-full overflow-y-auto">
          <div className="flex items-center gap-3 p-4 border-b border-slate-800/50 flex-shrink-0">
            <button onClick={() => setView("browse")}
              className="w-9 h-9 rounded-xl flex items-center justify-center bg-slate-900/60 border border-slate-800 text-slate-400 hover:text-white transition">
              ←
            </button>
            <div>
              <p className="font-black text-white">Tadbir yaratish</p>
              <p className="text-[10px] text-slate-500">Yangi event e'lon qiling</p>
            </div>
          </div>
          <div className="flex-1 p-4 space-y-3 overflow-y-auto">
            <input value={form.title} onChange={e => setForm(f=>({...f,title:e.target.value}))}
              placeholder="Tadbir nomi *"
              className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-700 transition"/>
            <textarea value={form.description} onChange={e => setForm(f=>({...f,description:e.target.value}))}
              placeholder="Tavsif (ixtiyoriy)"
              rows={3}
              className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-700 transition resize-none"/>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1">Sana *</p>
                <input type="date" value={form.eventDate} onChange={e => setForm(f=>({...f,eventDate:e.target.value}))}
                  className="w-full bg-slate-900/60 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-slate-600 transition"/>
              </div>
              <div>
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1">Vaqt *</p>
                <input type="time" value={form.eventTime} onChange={e => setForm(f=>({...f,eventTime:e.target.value}))}
                  className="w-full bg-slate-900/60 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white outline-none focus:border-slate-600 transition"/>
              </div>
            </div>
            {/* Online toggle */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/50 border border-slate-800">
              <div>
                <p className="text-sm font-bold text-white">🌐 Online tadbir</p>
                <p className="text-[10px] text-slate-500">Internet orqali o'tkaziladi</p>
              </div>
              <button onClick={() => setForm(f=>({...f,online:!f.online}))}
                className={`w-12 h-6 rounded-full transition-all relative ${form.online ? "" : "bg-slate-700"}`}
                style={form.online ? { background:accentColor } : {}}>
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${form.online ? "left-6" : "left-0.5"}`}/>
              </button>
            </div>
            {!form.online && (
              <input value={form.location} onChange={e => setForm(f=>({...f,location:e.target.value}))}
                placeholder="📍 Manzil (ixtiyoriy)"
                className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-700 transition"/>
            )}
            <div>
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-2">Kategoriya</p>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.filter(c => c.key !== "all").map(c => (
                  <button key={c.key} onClick={() => setForm(f=>({...f,category:c.key}))}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold transition"
                    style={form.category === c.key
                      ? { background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }
                      : { color:"#64748b",border:"1px solid rgba(255,255,255,0.06)" }}>
                    {c.emoji} {c.label}
                  </button>
                ))}
              </div>
            </div>
            <input value={form.maxAttendees} onChange={e => setForm(f=>({...f,maxAttendees:e.target.value}))}
              placeholder="👥 Maks ishtirokchilar soni (ixtiyoriy)"
              type="number" min="1"
              className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-700 transition"/>
            <button onClick={createEvent} disabled={submitting || !form.title.trim() || !form.eventDate || !form.eventTime}
              className="w-full py-3.5 rounded-2xl font-black text-sm text-white disabled:opacity-40 transition active:scale-95"
              style={{ background:`linear-gradient(135deg,${accentColor},#6366f1)` }}>
              {submitting ? "⏳ Saqlanmoqda..." : "🎉 Tadbir yaratish"}
            </button>
          </div>
        </div>
      )}

      {/* ── BROWSE VIEW ── */}
      {view === "browse" && (
        <>
          {/* Header */}
          <div className="flex-shrink-0 px-4 pt-4 pb-2"
            style={{ animation:animIn?"ev-in 0.3s ease":undefined }}>
            <div className="absolute top-0 left-0 right-0 h-px" style={{ background:`linear-gradient(90deg,transparent,${accentColor}50,transparent)` }}/>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl"
                  style={{ background:`${accentColor}20`,border:`1px solid ${accentColor}35` }}>🎉</div>
                <div>
                  <p className="text-base font-black text-white">Tadbirlar</p>
                  <p className="text-[10px] text-slate-500">{filtered.length} ta tadbir</p>
                </div>
              </div>
              <button onClick={() => setView("create")}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold text-xs transition active:scale-95"
                style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                <Plus className="w-3.5 h-3.5"/> Yaratish
              </button>
            </div>
            {/* Search */}
            <div className="relative mb-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600"/>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Tadbir qidirish..."
                className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl pl-9 pr-3 py-2.5 text-sm text-slate-300 outline-none focus:border-slate-600 transition placeholder-slate-700"/>
            </div>
            {/* Time filter */}
            <div className="flex gap-1 mb-3 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60">
              {([
                { key:"upcoming", label:"🔜 Kelayotgan" },
                { key:"past",     label:"📜 O'tgan" },
                { key:"mine",     label:"⭐ Mening" },
              ] as const).map(t => (
                <button key={t.key} onClick={() => setTimeFilter(t.key)}
                  className="flex-1 py-1.5 rounded-xl text-[10px] font-bold transition"
                  style={timeFilter===t.key ? {background:`${accentColor}20`,color:accentColor} : {color:"#64748b"}}>
                  {t.label}
                </button>
              ))}
            </div>
            {/* Category chips */}
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {CATEGORIES.map(c => (
                <button key={c.key} onClick={() => setCatFilter(c.key)}
                  className="flex-shrink-0 px-2.5 py-1.5 rounded-xl text-[10px] font-bold transition"
                  style={catFilter===c.key
                    ? {background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35`}
                    : {color:"#475569",border:"1px solid rgba(255,255,255,0.04)"}}>
                  {c.emoji} {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Events list */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            {filtered.length === 0 && (
              <div className="flex flex-col items-center gap-4 py-16 text-center">
                <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-5xl"
                  style={{ background:`${accentColor}12`,border:`1px solid ${accentColor}20` }}>📅</div>
                <div>
                  <p className="text-white font-black text-lg">Tadbir topilmadi</p>
                  <p className="text-slate-500 text-sm mt-1">Yangi tadbir yarating!</p>
                </div>
                <button onClick={() => setView("create")}
                  className="px-6 py-3 rounded-2xl font-bold text-sm transition active:scale-95"
                  style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                  🎉 Tadbir yaratish
                </button>
              </div>
            )}
            {filtered.map((ev, i) => {
              const going = Object.values(ev.rsvp || {}).filter(v => v === "going").length;
              const myRsvp = ev.rsvp?.[username];
              const isPast = ev.eventDate <= now;
              const cat = CATEGORIES.find(c => c.key === ev.category);
              return (
                <div key={ev.id}
                  className="ev-card rounded-2xl border border-slate-800/60 overflow-hidden cursor-pointer transition-all hover:border-slate-700 active:scale-[0.99]"
                  style={{ animationDelay:`${Math.min(i*40,320)}ms`,background:"rgba(10,15,30,0.8)" }}
                  onClick={() => { setSelected(ev); setView("detail"); }}>
                  {/* Color bar */}
                  <div className="h-1" style={{ background:`linear-gradient(90deg,${accentColor},#6366f1,transparent)` }}/>
                  <div className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                        style={{ background:`${accentColor}15`,border:`1px solid ${accentColor}25` }}>
                        {cat?.emoji || "🎉"}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className={`font-black text-sm leading-snug ${isPast ? "text-slate-500" : "text-white"}`}>{ev.title}</p>
                          {myRsvp === "going" && <span className="text-[9px] text-green-400 font-bold flex-shrink-0 bg-green-950/40 border border-green-900/40 px-1.5 py-0.5 rounded-lg">✅ Boraman</span>}
                          {myRsvp === "maybe" && <span className="text-[9px] text-amber-400 font-bold flex-shrink-0 bg-amber-950/40 border border-amber-900/40 px-1.5 py-0.5 rounded-lg">🤔 Ehtimol</span>}
                        </div>
                        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                          <span className="text-[10px] text-slate-500 flex items-center gap-1">
                            <Calendar className="w-2.5 h-2.5"/> {formatDate(ev.eventDate)}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-1.5">
                          {ev.online ? (
                            <span className="text-[9px] text-blue-400 font-bold flex items-center gap-1"><Wifi className="w-2.5 h-2.5"/> Online</span>
                          ) : ev.location ? (
                            <span className="text-[9px] text-slate-500 flex items-center gap-1"><MapPin className="w-2.5 h-2.5"/> {ev.location}</span>
                          ) : null}
                          <span className="text-[9px] text-slate-500 flex items-center gap-1">
                            <Users className="w-2.5 h-2.5"/> {going} boradi
                          </span>
                          {!isPast && (
                            <span className="ml-auto">
                              <Countdown target={ev.eventDate} />
                            </span>
                          )}
                          {isPast && <span className="text-[9px] text-slate-700 font-bold ml-auto">O'TDI</span>}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
