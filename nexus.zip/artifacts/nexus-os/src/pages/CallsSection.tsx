import { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { db } from "../firebase";
import {
  Phone, Video, PhoneIncoming, PhoneOutgoing, PhoneMissed,
  Star, StarOff, Search, Clock, Users, Trash2
} from "lucide-react";

interface CallLog {
  id: string;
  caller: string;
  callee: string;
  type: "outgoing" | "incoming" | "missed";
  callType?: "audio" | "video";
  duration?: string;
  timestamp: number;
}
interface OnlineUser { key: string; state: string; }

interface CallsSectionProps {
  username: string;
  onCall: (peer: string, type?: "audio" | "video") => void;
  onlineUsers: OnlineUser[];
}

function getAvatarGradient(name: string) {
  const gs = [
    ["#22d3ee", "#3b82f6"], ["#8b5cf6", "#ec4899"],
    ["#10b981", "#22d3ee"], ["#f59e0b", "#ef4444"],
    ["#6366f1", "#8b5cf6"], ["#14b8a6", "#3b82f6"],
  ];
  return gs[(name.charCodeAt(0) || 0) % gs.length];
}

function Avatar({ name, size = 44, online }: { name: string; size?: number; online?: boolean }) {
  const [c1, c2] = getAvatarGradient(name);
  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <div
        className="w-full h-full rounded-full flex items-center justify-center font-bold text-white select-none"
        style={{ background: `linear-gradient(135deg, ${c1}, ${c2})`, fontSize: size * 0.35 }}
      >
        {name.slice(0, 2).toUpperCase()}
      </div>
      {online !== undefined && (
        <div
          className="absolute -bottom-0.5 -right-0.5 rounded-full border-2"
          style={{ width: size * 0.28, height: size * 0.28, borderColor: "#030712", background: online ? "#4ade80" : "#475569" }}
        />
      )}
    </div>
  );
}

function timeAgo(ts: number) {
  const diff = Date.now() - ts;
  if (diff < 60000) return "hozir";
  if (diff < 3600000) return `${Math.floor(diff / 60000)} daq oldin`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} soat oldin`;
  return new Date(ts).toLocaleDateString([], { month: "short", day: "numeric" });
}

type Tab = "recent" | "contacts" | "favorites";

export default function CallsSection({ username, onCall, onlineUsers }: CallsSectionProps) {
  const [tab, setTab] = useState<Tab>("recent");
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("nexus_favorites") || "[]"); } catch { return []; }
  });

  useEffect(() => {
    return onValue(ref(db, `call_logs/${username}`), snap => {
      if (!snap.exists()) { setCallLogs([]); return; }
      const logs: CallLog[] = [];
      snap.forEach(c => { logs.push({ id: c.key!, ...c.val() }); });
      logs.sort((a, b) => b.timestamp - a.timestamp);
      setCallLogs(logs.slice(0, 80));
    });
  }, [username]);

  function toggleFavorite(user: string) {
    setFavorites(prev => {
      const next = prev.includes(user) ? prev.filter(u => u !== user) : [user, ...prev];
      localStorage.setItem("nexus_favorites", JSON.stringify(next));
      return next;
    });
  }

  const onlineSet = new Set(onlineUsers.filter(u => u.state === "online").map(u => u.key));

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "recent", label: "So'nggi", icon: <Clock className="w-3.5 h-3.5" /> },
    { id: "contacts", label: "Kontaktlar", icon: <Users className="w-3.5 h-3.5" /> },
    { id: "favorites", label: "Sevimlilar", icon: <Star className="w-3.5 h-3.5" /> },
  ];

  const filteredUsers = onlineUsers.filter(u =>
    !search || u.key.toLowerCase().includes(search.toLowerCase())
  );
  const filteredFavs = favorites.filter(f =>
    !search || f.toLowerCase().includes(search.toLowerCase())
  );
  const filteredLogs = callLogs.filter(l => {
    if (!search) return true;
    const peer = l.caller === username ? l.callee : l.caller;
    return peer.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#030712]">
      {/* Header */}
      <div className="px-4 pt-4 pb-2 flex-shrink-0">
        <h2 className="text-lg font-black text-white mb-3 tracking-tight">Qo'ng'iroqlar</h2>
        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Qidirish..."
            className="w-full bg-slate-900/80 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-600 outline-none focus:border-cyan-500/50 transition"
          />
        </div>

        {/* Tabs */}
        <div className="flex rounded-xl overflow-hidden bg-slate-900/60 border border-slate-800 p-1 gap-1">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all duration-200 ${
                tab === t.id
                  ? "bg-cyan-500/15 text-cyan-400 shadow"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-2 pt-2">

        {/* ── RECENT LOGS ── */}
        {tab === "recent" && (
          <>
            {filteredLogs.length === 0 ? (
              <Empty
                icon={<PhoneMissed className="w-10 h-10 text-slate-700" />}
                title="Tarix yo'q"
                sub="Kontaktlar bo'limidan qo'ng'iroq qiling"
              />
            ) : (
              filteredLogs.map((log, i) => {
                const peer = log.caller === username ? log.callee : log.caller;
                const isOut = log.caller === username;
                const isMissed = log.type === "missed";
                const [c1, c2] = getAvatarGradient(peer);
                return (
                  <div
                    key={log.id}
                    className="flex items-center gap-3 px-3 py-3 rounded-2xl transition-all duration-200 group"
                    style={{
                      background: "rgba(15,23,42,0.6)",
                      border: "1px solid rgba(255,255,255,0.05)",
                      animationDelay: `${i * 30}ms`,
                    }}
                  >
                    <Avatar name={peer} size={44} online={onlineSet.has(peer)} />

                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-100 truncate">@{peer}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {isMissed ? (
                          <PhoneMissed className="w-3 h-3 text-red-400 flex-shrink-0" />
                        ) : isOut ? (
                          <PhoneOutgoing className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                        ) : (
                          <PhoneIncoming className="w-3 h-3 text-green-400 flex-shrink-0" />
                        )}
                        <span className={`text-[11px] font-medium ${isMissed ? "text-red-400" : isOut ? "text-cyan-400" : "text-green-400"}`}>
                          {isMissed ? "O'tkazib yuborildi" : isOut ? "Chiquvchi" : "Kiruvchi"}
                        </span>
                        {log.duration && (
                          <span className="text-[10px] text-slate-600">· {log.duration}</span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <span className="text-[10px] text-slate-600 font-mono">{timeAgo(log.timestamp)}</span>
                      <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <CallBtn onClick={() => onCall(peer)} audio />
                        <CallBtn onClick={() => onCall(peer, "video")} />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </>
        )}

        {/* ── CONTACTS ── */}
        {tab === "contacts" && (
          <>
            {/* Online section */}
            {filteredUsers.filter(u => u.state === "online").length > 0 && (
              <SectionLabel label="Onlayn" count={filteredUsers.filter(u => u.state === "online").length} color="#4ade80" />
            )}
            {filteredUsers.filter(u => u.state === "online").map((u, i) => (
              <ContactRow
                key={u.key}
                user={u}
                isFav={favorites.includes(u.key)}
                onToggleFav={() => toggleFavorite(u.key)}
                onCall={t => onCall(u.key, t)}
                index={i}
              />
            ))}

            {filteredUsers.filter(u => u.state !== "online").length > 0 && (
              <SectionLabel label="Oflayn" count={filteredUsers.filter(u => u.state !== "online").length} color="#64748b" />
            )}
            {filteredUsers.filter(u => u.state !== "online").map((u, i) => (
              <ContactRow
                key={u.key}
                user={u}
                isFav={favorites.includes(u.key)}
                onToggleFav={() => toggleFavorite(u.key)}
                onCall={t => onCall(u.key, t)}
                index={i}
              />
            ))}

            {filteredUsers.length === 0 && (
              <Empty
                icon={<Users className="w-10 h-10 text-slate-700" />}
                title="Hech kim onlayn emas"
                sub="Foydalanuvchilar onlayn bo'lganda ko'rinadi"
              />
            )}
          </>
        )}

        {/* ── FAVORITES ── */}
        {tab === "favorites" && (
          <>
            {filteredFavs.length === 0 ? (
              <Empty
                icon={<Star className="w-10 h-10 text-slate-700" />}
                title="Sevimlilar yo'q"
                sub="Kontaktlar bo'limida yulduzcha tugmasini bosing"
              />
            ) : (
              filteredFavs.map((uKey, i) => (
                <div
                  key={uKey}
                  className="flex items-center gap-3 px-3 py-3 rounded-2xl group transition-all"
                  style={{ background: "rgba(245,158,11,0.05)", border: "1px solid rgba(245,158,11,0.12)", animationDelay: `${i * 30}ms` }}
                >
                  <Avatar name={uKey} size={44} online={onlineSet.has(uKey)} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-100 truncate">@{uKey}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400 flex-shrink-0" />
                      <span className="text-[11px] text-amber-500/80">Sevimli</span>
                      {onlineSet.has(uKey) && (
                        <span className="text-[10px] text-green-400 ml-1">· onlayn</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <CallBtn onClick={() => onCall(uKey)} audio disabled={!onlineSet.has(uKey)} />
                      <CallBtn onClick={() => onCall(uKey, "video")} disabled={!onlineSet.has(uKey)} />
                    </div>
                    <button
                      onClick={() => toggleFavorite(uKey)}
                      className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-950/30 transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </>
        )}
      </div>
    </div>
  );
}

function ContactRow({
  user, isFav, onToggleFav, onCall, index
}: {
  user: OnlineUser;
  isFav: boolean;
  onToggleFav: () => void;
  onCall: (type?: "audio" | "video") => void;
  index: number;
}) {
  const isOnline = user.state === "online";
  return (
    <div
      className="flex items-center gap-3 px-3 py-3 rounded-2xl group transition-all duration-200"
      style={{
        background: "rgba(15,23,42,0.6)",
        border: `1px solid ${isOnline ? "rgba(34,211,238,0.08)" : "rgba(255,255,255,0.04)"}`,
        animationDelay: `${index * 25}ms`,
      }}
    >
      <Avatar name={user.key} size={44} online={isOnline} />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-slate-100 truncate">@{user.key}</p>
        <p className={`text-[11px] font-medium mt-0.5 ${isOnline ? "text-green-400" : "text-slate-600"}`}>
          {isOnline ? "Onlayn" : "Oflayn"}
        </p>
      </div>
      <div className="flex items-center gap-1.5">
        <div className={`flex gap-1.5 transition-opacity ${isOnline ? "opacity-100" : "opacity-0 group-hover:opacity-40"}`}>
          <CallBtn onClick={() => onCall()} audio disabled={!isOnline} />
          <CallBtn onClick={() => onCall("video")} disabled={!isOnline} />
        </div>
        <button
          onClick={onToggleFav}
          className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
            isFav
              ? "text-amber-400 bg-amber-500/10"
              : "text-slate-600 hover:text-amber-400 hover:bg-amber-500/10 opacity-0 group-hover:opacity-100"
          }`}
        >
          {isFav ? <Star className="w-3.5 h-3.5 fill-amber-400" /> : <Star className="w-3.5 h-3.5" />}
        </button>
      </div>
    </div>
  );
}

function CallBtn({ onClick, audio, disabled }: { onClick: () => void; audio?: boolean; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-90 ${
        disabled
          ? "opacity-20 cursor-not-allowed bg-slate-900"
          : audio
            ? "bg-green-500/15 border border-green-500/25 text-green-400 hover:bg-green-500/25"
            : "bg-blue-500/15 border border-blue-500/25 text-blue-400 hover:bg-blue-500/25"
      }`}
    >
      {audio ? <Phone className="w-3.5 h-3.5" /> : <Video className="w-3.5 h-3.5" />}
    </button>
  );
}

function SectionLabel({ label, count, color }: { label: string; count: number; color: string }) {
  return (
    <div className="flex items-center gap-2 px-1 py-1 mb-1">
      <div className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
      <span className="text-[11px] font-bold uppercase tracking-widest" style={{ color }}>
        {label}
      </span>
      <span className="text-[10px] text-slate-600 font-mono">{count}</span>
    </div>
  );
}

function Empty({ icon, title, sub }: { icon: React.ReactNode; title: string; sub: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <div className="opacity-40">{icon}</div>
      <div className="text-center">
        <p className="text-sm font-semibold text-slate-500">{title}</p>
        <p className="text-xs text-slate-700 mt-1">{sub}</p>
      </div>
    </div>
  );
}

// Expose OnlineUser type for external use
export type { OnlineUser };
