import { useState, useEffect, useRef } from "react";
import { ref, set, push, update, remove, onValue, get } from "firebase/database";
import { db } from "../firebase";

interface Props {
  username: string;
  accentColor: string;
  onBack: () => void;
  initialRoomId?: string;
}

type Role = "godfather" | "mafia" | "detective" | "doctor" | "sheriff" | "witch" | "jester" | "bodyguard" | "vigilante" | "mayor" | "spy" | "citizen";
type Phase = "lobby" | "roleReveal" | "night" | "morning" | "discussion" | "vote" | "end";

interface RoomPlayer {
  name: string;
  alive: boolean;
  role: Role | null;
  ready: boolean;
  joinedAt: number;
}

interface GameRoom {
  host: string;
  status: "waiting" | "playing" | "ended";
  createdAt: number;
  startAt: number;
  phase: Phase;
  day: number;
  players: Record<string, RoomPlayer>;
  nightActions: Record<string, string>;
  voteActions: Record<string, string>;
  morningNews: string[];
  winner: string | null;
  chatLines: Record<string, { from: string; text: string; ts: number }>;
}

const ROLE_INFO: Record<Role, { icon: string; color: string; team: "mafia" | "solo" | "town"; name: string; desc: string; nightDesc: string }> = {
  godfather:  { icon: "🎩", color: "#dc2626", team: "mafia", name: "Katta Usta",   desc: "Mafia boshlig'i. Detektiv tekshirganda fuqaro ko'rinadi.", nightDesc: "O'ldirish uchun tanlang" },
  mafia:      { icon: "🕵️", color: "#ef4444", team: "mafia", name: "Mafia",         desc: "Kecha fuqarolarni o'ldiring.",                                nightDesc: "O'ldirish uchun tanlang" },
  detective:  { icon: "🔍", color: "#3b82f6", team: "town",  name: "Detektiv",      desc: "Har kechada bir kishini tekshiring.",                         nightDesc: "Tekshirish uchun tanlang" },
  doctor:     { icon: "💊", color: "#22c55e", team: "town",  name: "Shifokor",      desc: "Har kechada bir kishini himoya qiling.",                      nightDesc: "Himoya qilish uchun tanlang" },
  sheriff:    { icon: "⭐", color: "#f59e0b", team: "town",  name: "Meriya",        desc: "Bir marta: mafiani o'ldiring. Xato — o'zingiz o'lasiz.",      nightDesc: "Otish uchun tanlang (1 marta!)" },
  witch:      { icon: "🧙", color: "#a855f7", team: "town",  name: "Jodugar",       desc: "Kimnidir zaharlaing yoki himoya qiling.",                     nightDesc: "Zaharlamoq yoki himoya?" },
  jester:     { icon: "🃏", color: "#ec4899", team: "solo",  name: "Masxaraboz",    desc: "Ovozda chiqarilsangiz yutasiz!",                             nightDesc: "Uyquda kutasiz..." },
  bodyguard:  { icon: "🛡️", color: "#0ea5e9", team: "town",  name: "Himoyachi",     desc: "Tanlagan kishini himoya qiling. Hujum bo'lsa o'zingiz o'lasiz.", nightDesc: "Himoya qilish uchun tanlang" },
  vigilante:  { icon: "⚡", color: "#eab308", team: "town",  name: "Qahramon",      desc: "Bir marta: istalgan kishini o'ldiring. Xato — keyingi kun o'lasiz.", nightDesc: "O'ldirish uchun tanlang (1 marta!)" },
  mayor:      { icon: "🏛️", color: "#06b6d4", team: "town",  name: "Mayor",         desc: "Ovozda 2 ta ovozga egasiz.",                                 nightDesc: "Uyquda kutasiz..." },
  spy:        { icon: "👁️", color: "#8b5cf6", team: "town",  name: "Josus",         desc: "O'yin boshida mafia kimligini bilasiz. O'ldirilmasligingiz uchun ehtiyot bo'ling.", nightDesc: "Uyquda kutasiz..." },
  citizen:    { icon: "👤", color: "#94a3b8", team: "town",  name: "Fuqaro",        desc: "Gaplarni tahlil qiling, mafiani aniqlang!",                  nightDesc: "Uyquda kutasiz..." },
};

function generateRoomId(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

function assignRoles(count: number): Role[] {
  const roles: Role[] = [];
  const mafiaCount = count <= 5 ? 1 : count <= 8 ? 2 : 3;
  roles.push("godfather");
  for (let i = 1; i < mafiaCount; i++) roles.push("mafia");
  roles.push("detective");
  roles.push("doctor");
  if (count >= 6)  roles.push("bodyguard");
  if (count >= 7)  roles.push("sheriff");
  if (count >= 8)  roles.push("witch");
  if (count >= 9)  roles.push("vigilante");
  if (count >= 10) roles.push("mayor");
  if (count >= 11) roles.push("spy");
  if (count >= 12) roles.push("jester");
  while (roles.length < count) roles.push("citizen");
  return roles.sort(() => Math.random() - 0.5);
}

export default function MultiplayerMafiaGame({ username, accentColor, onBack, initialRoomId }: Props) {
  const [screen, setScreen] = useState<"home" | "waiting" | "game" | "end">(initialRoomId ? "waiting" : "home");
  const [roomIdInput, setRoomIdInput] = useState(initialRoomId || "");
  const [roomId, setRoomId] = useState(initialRoomId || "");
  const [room, setRoom] = useState<GameRoom | null>(null);
  const [error, setError] = useState("");
  const [timeLeft, setTimeLeft] = useState(300);
  const [chatInput, setChatInput] = useState("");
  const [myRole, setMyRole] = useState<Role | null>(null);
  const [nightTarget, setNightTarget] = useState<string | null>(null);
  const [witchMode, setWitchMode] = useState<"poison" | "protect">("poison");
  const [voteTarget, setVoteTarget] = useState<string | null>(null);
  const [sheriffUsed, setSheriffUsed] = useState(false);
  const [vigilanteUsed, setVigilanteUsed] = useState(false);
  const [showRoleCard, setShowRoleCard] = useState(true);
  const chatRef = useRef<HTMLDivElement>(null);

  // Join room and listen to changes
  useEffect(() => {
    if (!roomId) return;
    const unsub = onValue(ref(db, `mafia_rooms/${roomId}`), snap => {
      if (!snap.exists()) { setError("Xona topilmadi"); return; }
      const data = snap.val() as GameRoom;
      setRoom(data);
      if (data.players?.[username]?.role) {
        setMyRole(data.players[username].role as Role);
      }
      if (data.status === "playing" && screen === "waiting") setScreen("game");
      if (data.status === "ended") setScreen("end");
    });
    return () => unsub();
  }, [roomId, username]);

  // Countdown timer
  useEffect(() => {
    if (!room || screen !== "waiting") return;
    const startAt = room.startAt;
    const update = () => {
      const left = Math.max(0, Math.ceil((startAt - Date.now()) / 1000));
      setTimeLeft(left);
      if (left === 0 && room.host === username) {
        startGame();
      }
    };
    update();
    const iv = setInterval(update, 1000);
    return () => clearInterval(iv);
  }, [room, screen]);

  // Scroll chat
  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [room?.chatLines]);

  async function createRoom() {
    const id = generateRoomId();
    const now = Date.now();
    const roomData: GameRoom = {
      host: username,
      status: "waiting",
      createdAt: now,
      startAt: now + 300000, // 5 minutes
      phase: "lobby",
      day: 0,
      players: {
        [username]: { name: username, alive: true, role: null, ready: true, joinedAt: now }
      },
      nightActions: {},
      voteActions: {},
      morningNews: [],
      winner: null,
      chatLines: {},
    };
    await set(ref(db, `mafia_rooms/${id}`), roomData);
    setRoomId(id);
    setScreen("waiting");
    // Save to user's active rooms
    await set(ref(db, `users/${username}/activeMafiaRoom`), id);
  }

  async function joinRoom() {
    const id = roomIdInput.trim().toUpperCase();
    if (!id) return;
    const snap = await get(ref(db, `mafia_rooms/${id}`));
    if (!snap.exists()) { setError("Xona topilmadi. Kodni tekshiring."); return; }
    const data = snap.val() as GameRoom;
    if (data.status !== "waiting") { setError("O'yin allaqachon boshlangan."); return; }
    const playerCount = Object.keys(data.players || {}).length;
    if (playerCount >= 12) { setError("Xona to'liq (max 12 o'yinchi)."); return; }

    await update(ref(db, `mafia_rooms/${id}/players/${username}`), {
      name: username, alive: true, role: null, ready: true, joinedAt: Date.now()
    });
    await set(ref(db, `users/${username}/activeMafiaRoom`), id);
    setRoomId(id);
    setScreen("waiting");
  }

  async function startGame() {
    if (!room) return;
    const players = Object.keys(room.players);
    if (players.length < 4) { setError("Kamida 4 o'yinchi kerak!"); return; }

    const roles = assignRoles(players.length);
    const updates: Record<string, any> = {};
    players.forEach((p, i) => {
      updates[`players/${p}/role`] = roles[i];
      updates[`players/${p}/alive`] = true;
    });
    updates["status"] = "playing";
    updates["phase"] = "night";
    updates["day"] = 1;
    updates["morningNews"] = [];
    updates["nightActions"] = {};
    updates["voteActions"] = {};

    // Notify spy of mafia
    const spyIdx = players.findIndex((_, i) => roles[i] === "spy");
    if (spyIdx >= 0) {
      const mafiaList = players.filter((_, i) => roles[i] === "mafia" || roles[i] === "godfather");
      await push(ref(db, `mafia_rooms/${roomId}/chatLines`), {
        from: "🎮 O'YIN",
        text: `👁️ Josus @${players[spyIdx]}: Mafia: ${mafiaList.map(m => "@" + m).join(", ")}`,
        ts: Date.now(),
        secret: players[spyIdx],
      });
    }

    await update(ref(db, `mafia_rooms/${roomId}`), updates);
  }

  async function submitNightAction() {
    if (!myRole || !nightTarget) return;
    await update(ref(db, `mafia_rooms/${roomId}/nightActions`), {
      [username]: `${myRole}:${nightTarget}${myRole === "witch" ? `:${witchMode}` : ""}${myRole === "sheriff" || myRole === "vigilante" ? `:shoot` : ""}`,
    });
    setNightTarget(null);

    // Check if all active-role players have submitted
    const snap = await get(ref(db, `mafia_rooms/${roomId}`));
    const r = snap.val() as GameRoom;
    const activePlayers = Object.entries(r.players)
      .filter(([, p]) => p.alive && p.role && !["citizen", "jester", "mayor"].includes(p.role as string));
    const submitted = Object.keys(r.nightActions || {});
    if (activePlayers.every(([name]) => submitted.includes(name))) {
      if (r.host === username) await resolveNight(r);
    }
  }

  async function resolveNight(r: GameRoom) {
    const actions = r.nightActions || {};
    const players = r.players;
    const news: string[] = [];
    const newPlayers = { ...players };
    let mafiaTarget: string | null = null;
    let doctorSave: string | null = null;
    let bodyguardTarget: string | null = null;
    let witchPoison: string | null = null;

    // Parse actions
    Object.entries(actions).forEach(([actor, action]) => {
      const parts = action.split(":");
      const role = parts[0] as Role;
      const target = parts[1];
      const extra = parts[2];

      if (role === "godfather" || role === "mafia") mafiaTarget = target;
      else if (role === "doctor") doctorSave = target;
      else if (role === "bodyguard") bodyguardTarget = target;
      else if (role === "detective") {
        const t = players[target];
        const isMaf = t?.role === "mafia" || t?.role === "godfather";
        const actualRole = t?.role === "godfather" ? "Fuqaro" : (isMaf ? "🔴 MAFIA" : "✅ Fuqaro");
        news.push(`🔍 @${actor} (Detektiv): @${target} — ${actualRole}`);
      } else if (role === "witch") {
        if (extra === "poison") witchPoison = target;
        else doctorSave = target;
      } else if ((role === "sheriff" || role === "vigilante") && extra === "shoot") {
        const t = players[target];
        const isMaf = t?.role === "mafia" || t?.role === "godfather";
        if (isMaf) {
          newPlayers[target] = { ...newPlayers[target], alive: false };
          news.push(`${role === "sheriff" ? "⭐ Meriya" : "⚡ Qahramon"} @${target}ni otdi — u MAFIA edi!`);
          if (role === "sheriff") setSheriffUsed(true);
          if (role === "vigilante") {
            setVigilanteUsed(true);
            mafiaTarget = null;
          }
        } else {
          newPlayers[actor] = { ...newPlayers[actor], alive: false };
          news.push(`${role === "sheriff" ? "⭐ Meriya" : "⚡ Qahramon"} xato odamni otdi va o'zi halok bo'ldi!`);
        }
      }
    });

    // Apply mafia kill
    if (mafiaTarget) {
      if (mafiaTarget === bodyguardTarget) {
        const bg = Object.entries(players).find(([, p]) => p.role === "bodyguard" && p.alive);
        if (bg) {
          newPlayers[bg[0]] = { ...newPlayers[bg[0]], alive: false };
          news.push(`🛡️ Himoyachi @${bg[0]} o'z jonini fido qildi! @${mafiaTarget} omon qoldi!`);
        }
      } else if (mafiaTarget !== doctorSave) {
        newPlayers[mafiaTarget] = { ...newPlayers[mafiaTarget], alive: false };
        news.push(`💀 Mafia @${mafiaTarget}ni o'ldirdi!`);
      } else {
        news.push(`💊 Shifokor @${mafiaTarget}ni qutqardi!`);
      }
    } else if (!Object.values(actions).length) {
      news.push("🌙 Bu kecha hech kim o'lmadi.");
    }

    if (witchPoison) {
      newPlayers[witchPoison] = { ...newPlayers[witchPoison], alive: false };
      news.push(`🧙 @${witchPoison} zahardan o'ldi!`);
    }

    if (news.length === 0) news.push("🌙 Bu kecha hech kim o'lmadi.");

    // Check win
    const aliveArr = Object.entries(newPlayers).filter(([, p]) => p.alive);
    const aliveMafia = aliveArr.filter(([, p]) => p.role === "mafia" || p.role === "godfather");
    const aliveTown = aliveArr.filter(([, p]) => p.role !== "mafia" && p.role !== "godfather");

    let winner: string | null = null;
    if (aliveMafia.length === 0) winner = "town";
    else if (aliveMafia.length >= aliveTown.length) winner = "mafia";

    await update(ref(db, `mafia_rooms/${roomId}`), {
      players: newPlayers,
      morningNews: news,
      nightActions: {},
      phase: winner ? "end" : "morning",
      status: winner ? "ended" : "playing",
      winner,
    });
  }

  async function sendChat(e: React.FormEvent) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    await push(ref(db, `mafia_rooms/${roomId}/chatLines`), {
      from: username,
      text: chatInput.trim(),
      ts: Date.now(),
    });
    setChatInput("");
  }

  async function submitVote() {
    if (!voteTarget) return;
    await update(ref(db, `mafia_rooms/${roomId}/voteActions`), { [username]: voteTarget });

    const snap = await get(ref(db, `mafia_rooms/${roomId}`));
    const r = snap.val() as GameRoom;
    const alivePlayers = Object.entries(r.players).filter(([, p]) => p.alive);
    const votes = Object.keys(r.voteActions || {});
    if (votes.length >= alivePlayers.length && r.host === username) {
      await resolveVote(r);
    }
    setVoteTarget(null);
  }

  async function resolveVote(r: GameRoom) {
    const votes = r.voteActions || {};
    const tally: Record<string, number> = {};
    Object.values(votes).forEach(v => { tally[v] = (tally[v] || 0) + 1; });

    // Mayor gets double vote
    Object.entries(votes).forEach(([voter, target]) => {
      if (r.players[voter]?.role === "mayor") tally[target] = (tally[target] || 0) + 1;
    });

    let maxVotes = 0;
    let eliminated = "";
    Object.entries(tally).forEach(([name, v]) => { if (v > maxVotes) { maxVotes = v; eliminated = name; } });

    const elimPlayer = r.players[eliminated];
    const newPlayers = { ...r.players };
    newPlayers[eliminated] = { ...newPlayers[eliminated], alive: false };

    const news = [`🗳️ @${eliminated} ${maxVotes} ovoz bilan chiqarildi! (${ROLE_INFO[elimPlayer?.role as Role]?.name || "Fuqaro"})`];
    if (elimPlayer?.role === "jester") news.push("🃏 Masxaraboz yutdi! U chiqarilishni kutardi!");

    const aliveArr = Object.entries(newPlayers).filter(([, p]) => p.alive);
    const aliveMafia = aliveArr.filter(([, p]) => p.role === "mafia" || p.role === "godfather");
    const aliveTown = aliveArr.filter(([, p]) => p.role !== "mafia" && p.role !== "godfather");

    let winner: string | null = null;
    if (elimPlayer?.role === "jester") winner = "jester";
    else if (aliveMafia.length === 0) winner = "town";
    else if (aliveMafia.length >= aliveTown.length) winner = "mafia";

    await update(ref(db, `mafia_rooms/${roomId}`), {
      players: newPlayers,
      morningNews: news,
      voteActions: {},
      phase: winner ? "end" : "night",
      status: winner ? "ended" : "playing",
      day: winner ? r.day : r.day + 1,
      winner,
    });
  }

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const players = room ? Object.values(room.players) : [];
  const alivePlayers = players.filter(p => p.alive);
  const myPlayer = room?.players[username];
  const isHost = room?.host === username;
  const phase = room?.phase;

  // ── HOME ──
  if (screen === "home") {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90">
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <span className="text-xl">🕵️</span>
          <div><p className="font-black text-sm text-white">MAFIA — Multiplayer</p><p className="text-[9px] text-slate-500">Do'stlaringiz bilan o'ynang</p></div>
        </header>
        <div className="flex-1 overflow-y-auto flex flex-col items-center p-6 gap-5">
          <div className="text-center">
            <div className="text-5xl mb-3">🕵️</div>
            <p className="text-2xl font-black text-white">Multiplayer Mafia</p>
            <p className="text-xs text-slate-400 mt-1">4–12 o'yinchi • Firebase real-time</p>
          </div>

          <div className="w-full max-w-sm space-y-3">
            <button onClick={createRoom}
              className="w-full py-4 rounded-2xl font-black text-white text-base transition active:scale-95"
              style={{ background: "linear-gradient(135deg,#dc2626,#7c3aed)" }}>
              🎮 Yangi o'yin yaratish
            </button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"/></div>
              <div className="relative flex justify-center"><span className="bg-[#030712] px-3 text-xs text-slate-600">yoki</span></div>
            </div>

            <div className="space-y-2">
              <input
                value={roomIdInput}
                onChange={e => { setRoomIdInput(e.target.value.toUpperCase()); setError(""); }}
                placeholder="Xona kodi (masalan: AB3X7K)"
                maxLength={6}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-slate-500 uppercase tracking-widest text-center font-bold placeholder:normal-case placeholder:tracking-normal placeholder:font-normal"
              />
              <button onClick={joinRoom}
                className="w-full py-3.5 rounded-xl font-black text-sm border border-slate-600 text-slate-300 hover:bg-slate-800 transition">
                🚪 Xonaga qo'shilish
              </button>
            </div>

            {error && <p className="text-rose-400 text-xs text-center font-bold bg-rose-950/30 rounded-xl py-2 px-3">{error}</p>}
          </div>

          {/* Role preview */}
          <div className="w-full max-w-sm p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Mavjud rollar</p>
            <div className="grid grid-cols-3 gap-1.5">
              {(Object.entries(ROLE_INFO) as [Role, typeof ROLE_INFO[Role]][]).map(([, ri]) => (
                <div key={ri.name} className="flex items-center gap-1.5 p-1.5 rounded-lg" style={{ background: `${ri.color}12` }}>
                  <span className="text-sm">{ri.icon}</span>
                  <span className="text-[9px] font-bold" style={{ color: ri.color }}>{ri.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── WAITING LOBBY ──
  if (screen === "waiting" && room) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90">
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <span className="text-xl">⏳</span>
          <div className="flex-1">
            <p className="font-black text-sm text-white">Xona: {roomId}</p>
            <p className="text-[9px] text-slate-500">{players.length} o'yinchi • Kamida 4 kerak</p>
          </div>
          <div className="text-center">
            <div className="text-lg font-black" style={{ color: timeLeft < 30 ? "#ef4444" : accentColor }}>{formatTime(timeLeft)}</div>
            <p className="text-[8px] text-slate-600">avto-boshlanish</p>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Share code */}
          <div className="p-4 rounded-2xl border border-dashed border-slate-700 text-center space-y-2">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Do'stlaringizga yuboring</p>
            <p className="text-3xl font-black tracking-[0.3em] text-white">{roomId}</p>
            <p className="text-[10px] text-slate-600">Ushbu kodni kiriting → "Xonaga qo'shilish"</p>
          </div>

          {/* Players */}
          <div className="space-y-2">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">O'yinchilar ({players.length}/12)</p>
            {players.map(p => (
              <div key={p.name} className="flex items-center gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div className="w-9 h-9 rounded-full flex items-center justify-center font-black text-sm"
                  style={{ background: `${accentColor}22`, color: accentColor }}>
                  {p.name[0].toUpperCase()}
                </div>
                <p className="text-sm font-bold text-white flex-1">@{p.name}</p>
                {room.host === p.name && <span className="text-[9px] px-2 py-0.5 rounded font-black bg-amber-950/40 text-amber-400 border border-amber-900/50">HOST</span>}
                {p.name === username && <span className="text-[9px] px-2 py-0.5 rounded font-black bg-blue-950/40 text-blue-400 border border-blue-900/50">SIZ</span>}
                <span className="text-green-400 text-xs">✓</span>
              </div>
            ))}
          </div>

          {isHost && (
            <button
              onClick={startGame}
              disabled={players.length < 4}
              className="w-full py-4 rounded-2xl font-black text-white text-base disabled:opacity-40 transition active:scale-95"
              style={{ background: players.length >= 4 ? "linear-gradient(135deg,#16a34a,#0f172a)" : "#1e293b" }}>
              {players.length < 4 ? `⏳ Kamida 4 o'yinchi kerak (${players.length}/4)` : "🚀 O'yinni Boshlash"}
            </button>
          )}
          {!isHost && (
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center text-sm text-slate-400">
              ⏳ Host o'yinni boshlaishini kuting yoki {formatTime(timeLeft)} da avto-boshlanadi
            </div>
          )}
          {error && <p className="text-rose-400 text-xs text-center">{error}</p>}
        </div>
      </div>
    );
  }

  // ── GAME ──
  if (screen === "game" && room && myPlayer) {
    const ri = myPlayer.role ? ROLE_INFO[myPlayer.role as Role] : null;
    const chatLines = room.chatLines ? Object.values(room.chatLines).sort((a, b) => a.ts - b.ts) : [];
    const hasSubmittedNight = room.nightActions?.[username] !== undefined;
    const hasVoted = room.voteActions?.[username] !== undefined;

    const phaseColors: Record<string, { bg: string; border: string; text: string; label: string }> = {
      night:      { bg: "#0a0014", border: "#3b1d5e", text: "#c084fc", label: "🌙 KECHA" },
      morning:    { bg: "#0a0500", border: "#713f12", text: "#fbbf24", label: "🌅 TONG" },
      discussion: { bg: "#001a0a", border: "#14532d", text: "#4ade80", label: "💬 MUHOKAMA" },
      vote:       { bg: "#1a0000", border: "#7f1d1d", text: "#f87171", label: "🗳️ OVOZ" },
    };
    const pc = phaseColors[phase || "night"] || phaseColors.night;
    const aliveMafia = alivePlayers.filter(p => p.role === "mafia" || p.role === "godfather");
    const aliveTown = alivePlayers.filter(p => p.role !== "mafia" && p.role !== "godfather");

    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90">
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <span>🕵️</span>
          <div className="flex-1">
            <p className="font-black text-sm text-white">Mafia — {room.day}-{phase === "night" ? "kecha" : "kun"}</p>
            <p className="text-[9px] text-slate-500">Tirik: {alivePlayers.length} · Mafia: {aliveMafia.length} · Shahar: {aliveTown.length}</p>
          </div>
          <span className="px-2.5 py-1 rounded-lg text-[10px] font-black border"
            style={{ background: pc.bg, borderColor: pc.border, color: pc.text }}>{pc.label}</span>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Role card */}
          {ri && showRoleCard && (
            <div className="p-3 rounded-xl border flex items-center gap-3 cursor-pointer" onClick={() => setShowRoleCard(false)}
              style={{ background: `${ri.color}10`, borderColor: `${ri.color}35` }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                style={{ background: `${ri.color}20` }}>{ri.icon}</div>
              <div className="flex-1">
                <p className="text-[10px] text-slate-500">Sizning rolingiz</p>
                <p className="text-sm font-black" style={{ color: ri.color }}>{ri.name}</p>
                <p className="text-[10px] text-slate-400">{ri.desc}</p>
              </div>
              {!myPlayer.alive && <span className="text-xs text-slate-500 font-bold">💀 O'ldinggiz</span>}
            </div>
          )}

          {/* MORNING PHASE */}
          {phase === "morning" && (
            <div className="space-y-3">
              <p className="text-xs font-black text-amber-400 uppercase tracking-wider">🌅 Tong yangiliklari</p>
              {(room.morningNews || []).map((n, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-200 font-mono">{n}</div>
              ))}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <p className="text-[10px] text-slate-500 uppercase font-bold mb-2">Tirik o'yinchilar</p>
                <div className="flex flex-wrap gap-1.5">
                  {alivePlayers.map(p => (
                    <span key={p.name} className="px-2 py-1 rounded-lg text-xs font-bold bg-slate-800 text-slate-300">
                      {p.name === username ? `${p.name} (Siz)` : p.name}
                    </span>
                  ))}
                </div>
              </div>
              {isHost && (
                <button onClick={() => update(ref(db, `mafia_rooms/${roomId}`), { phase: "discussion" })}
                  className="w-full py-3.5 rounded-xl font-black text-sm text-white"
                  style={{ background: "linear-gradient(135deg,#15803d,#0f172a)" }}>
                  💬 Muhokamaga O'tish
                </button>
              )}
            </div>
          )}

          {/* DISCUSSION PHASE */}
          {phase === "discussion" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-black text-green-400 uppercase tracking-wider">💬 Muhokama</p>
                {isHost && (
                  <button onClick={() => update(ref(db, `mafia_rooms/${roomId}`), { phase: "vote", voteActions: {} })}
                    className="px-3 py-1.5 rounded-lg text-xs font-black text-white" style={{ background: "#dc2626" }}>
                    🗳️ Ovozga o'tish
                  </button>
                )}
              </div>
              <div ref={chatRef} className="h-56 overflow-y-auto space-y-2 p-3 rounded-xl bg-slate-950 border border-slate-800">
                {chatLines.length === 0 && <p className="text-xs text-slate-600 text-center py-4">Muhokama boshlanmoqda...</p>}
                {chatLines.map((c, i) => (
                  <div key={i} className={`flex gap-2 ${c.from === username ? "flex-row-reverse" : ""}`}>
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0"
                      style={{ background: c.from === username ? accentColor : "#334155" }}>
                      {c.from[0]}
                    </div>
                    <div className={`max-w-[75%] px-2.5 py-1.5 rounded-xl text-xs ${c.from === username ? "bg-blue-950/50 text-blue-100" : "bg-slate-900 text-slate-200"}`}>
                      {c.from !== username && <span className="text-[9px] font-bold block mb-0.5" style={{ color: accentColor }}>@{c.from}</span>}
                      {c.text}
                    </div>
                  </div>
                ))}
              </div>
              {myPlayer.alive && (
                <form onSubmit={sendChat} className="flex gap-2">
                  <input value={chatInput} onChange={e => setChatInput(e.target.value)}
                    placeholder="Fikringizni yozing..."
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-600 outline-none focus:border-slate-500" />
                  <button type="submit" className="px-4 py-2 rounded-xl text-sm font-black text-white" style={{ background: accentColor }}>→</button>
                </form>
              )}
            </div>
          )}

          {/* VOTE PHASE */}
          {phase === "vote" && (
            <div className="space-y-2">
              <p className="text-xs font-black text-red-400 uppercase tracking-wider">🗳️ Kim chiqarilsin?</p>
              {hasVoted ? (
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center text-sm text-slate-400">
                  ✅ Ovozingiz qabul qilindi. Boshqalarni kuting...
                  <p className="text-[10px] mt-1 text-slate-600">({Object.keys(room.voteActions || {}).length}/{alivePlayers.length} ovoz berdi)</p>
                </div>
              ) : (
                <>
                  {alivePlayers.filter(p => p.name !== username).map(p => (
                    <button key={p.name} onClick={() => setVoteTarget(voteTarget === p.name ? null : p.name)}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border transition ${voteTarget === p.name ? "border-rose-500 bg-rose-950/25" : "border-slate-700 bg-slate-900 hover:border-slate-500"}`}>
                      <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black bg-red-950/30 text-red-400">
                        {p.name[0].toUpperCase()}
                      </div>
                      <p className="text-sm font-bold text-white flex-1 text-left">@{p.name}</p>
                      {voteTarget === p.name && <span className="text-rose-400 font-black">✓</span>}
                    </button>
                  ))}
                  <button onClick={submitVote} disabled={!voteTarget || !myPlayer.alive}
                    className="w-full py-3.5 rounded-xl font-black text-sm text-white mt-2 disabled:opacity-40"
                    style={{ background: "#dc2626" }}>
                    🚨 Ovoz berish
                  </button>
                </>
              )}
            </div>
          )}

          {/* NIGHT PHASE */}
          {phase === "night" && (
            <div className="space-y-3">
              <p className="text-xs font-black text-purple-400 uppercase tracking-wider">
                {myPlayer.alive && ri && !["citizen", "jester", "mayor"].includes(myPlayer.role as string)
                  ? ri.nightDesc
                  : "💀 Kechani kuzating..."}
              </p>

              {myPlayer.alive && myPlayer.role === "witch" && (
                <div className="flex gap-2 mb-2">
                  {(["poison", "protect"] as const).map(a => (
                    <button key={a} onClick={() => setWitchMode(a)}
                      className="flex-1 py-2 rounded-xl text-xs font-bold border transition"
                      style={{ borderColor: witchMode === a ? "#a855f7" : "#334155", background: witchMode === a ? "#3b0764" : "transparent", color: witchMode === a ? "#e9d5ff" : "#64748b" }}>
                      {a === "poison" ? "☠️ Zaharlamoq" : "🛡️ Himoya"}
                    </button>
                  ))}
                </div>
              )}

              {myPlayer.alive && ri && !["citizen", "jester", "mayor"].includes(myPlayer.role as string) && !hasSubmittedNight &&
                alivePlayers.filter(p => p.name !== username).map(p => (
                  <button key={p.name} onClick={() => setNightTarget(nightTarget === p.name ? null : p.name)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border transition ${nightTarget === p.name ? "border-purple-500 bg-purple-950/25" : "border-slate-700 bg-slate-900 hover:border-slate-500"}`}>
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black"
                      style={{ background: `${accentColor}22`, color: accentColor }}>
                      {p.name[0].toUpperCase()}
                    </div>
                    <p className="text-sm font-bold text-white flex-1 text-left">@{p.name}</p>
                    {nightTarget === p.name && <span className="text-purple-400 font-black">✓</span>}
                  </button>
                ))
              }

              {myPlayer.alive && !hasSubmittedNight && (
                <button onClick={submitNightAction}
                  disabled={(ri?.nightDesc !== "Uyquda kutasiz..." && ri?.nightDesc !== "Uyquda kutasiz... (Masxaraboz)" && !nightTarget) ||
                    ((myPlayer.role === "sheriff" && sheriffUsed) || (myPlayer.role === "vigilante" && vigilanteUsed))}
                  className="w-full py-3.5 rounded-xl font-black text-sm disabled:opacity-40 transition active:scale-95"
                  style={{ background: "linear-gradient(135deg,#7c3aed,#1e1b4b)" }}>
                  {["citizen", "jester", "mayor"].includes(myPlayer.role as string) ? "🌙 Kechani O'tkazish" : "✅ Harakatni Tasdiqlash"}
                </button>
              )}

              {hasSubmittedNight && (
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center text-sm text-slate-400">
                  ✅ Harakat yuborildi. Boshqalarni kuting...
                  <p className="text-[10px] mt-1 text-slate-600">
                    ({Object.keys(room.nightActions || {}).length} ta harakat)
                  </p>
                </div>
              )}

              {isHost && Object.keys(room.nightActions || {}).length > 0 && (
                <button onClick={async () => {
                  const snap = await get(ref(db, `mafia_rooms/${roomId}`));
                  await resolveNight(snap.val() as GameRoom);
                }}
                  className="w-full py-2.5 rounded-xl font-bold text-xs border border-amber-700 text-amber-400 hover:bg-amber-950/30 transition">
                  🌅 Kechani Yakunlash (Host)
                </button>
              )}
            </div>
          )}

          {/* Players list */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">O'yinchilar</p>
            <div className="flex flex-wrap gap-2">
              {players.map(p => (
                <div key={p.name} className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs font-bold transition ${!p.alive ? "opacity-40 line-through" : ""}`}
                  style={{ background: p.name === username ? `${accentColor}20` : "#1e293b", color: p.name === username ? accentColor : "#94a3b8" }}>
                  {p.alive ? "✓" : "💀"} {p.name}
                  {p.name === username && " (Siz)"}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── END ──
  if (screen === "end" && room) {
    const winner = room.winner;
    const myWon = (winner === "town" && myPlayer?.role && !["mafia", "godfather"].includes(myPlayer.role as string)) ||
      (winner === "mafia" && (myPlayer?.role === "mafia" || myPlayer?.role === "godfather")) ||
      (winner === "jester" && myPlayer?.role === "jester");

    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex-shrink-0 px-4 py-3 border-b border-slate-800/70 flex items-center gap-3 bg-[#030712]/90">
          <button onClick={onBack} className="text-slate-400 hover:text-white p-1.5 text-xl">←</button>
          <p className="font-black text-sm text-white">O'yin Yakunlandi</p>
        </header>
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="text-center space-y-3">
            <p className="text-7xl">{myWon ? "🏆" : "😔"}</p>
            <p className="text-3xl font-black" style={{ color: myWon ? "#22c55e" : "#ef4444" }}>
              {myWon ? "YUTDINGIZ!" : "YUTQAZDINGIZ!"}
            </p>
            <p className="text-sm text-slate-400">
              {winner === "town" ? "🏆 Fuqarolar yutdi!" : winner === "mafia" ? "💀 Mafia yutdi!" : "🃏 Masxaraboz yutdi!"}
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Barcha rollar</p>
            {players.map(p => {
              const ri = p.role ? ROLE_INFO[p.role as Role] : null;
              return (
                <div key={p.name} className={`flex items-center gap-3 p-3 rounded-xl border ${!p.alive ? "opacity-50" : ""}`}
                  style={{ borderColor: `${ri?.color || "#334155"}30`, background: `${ri?.color || "#334155"}08` }}>
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm"
                    style={{ background: `${ri?.color || "#334155"}25` }}>{ri?.icon || "👤"}</div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-white">{p.name === username ? `${p.name} (Siz)` : p.name}</p>
                    <p className="text-[10px]" style={{ color: ri?.color || "#94a3b8" }}>
                      {ri?.name || "Fuqaro"}{!p.alive ? " · 💀 O'ldi" : " · ✅ Omon"}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex gap-3">
            <button onClick={onBack} className="flex-1 py-3 rounded-xl font-bold text-sm border border-slate-700 text-slate-300 hover:bg-slate-800 transition">Chiqish</button>
            <button onClick={() => { setScreen("home"); setRoomId(""); setRoom(null); }}
              className="flex-1 py-3 rounded-xl font-bold text-sm text-white"
              style={{ background: "linear-gradient(135deg,#dc2626,#7c3aed)" }}>🔄 Qayta O'ynash</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex items-center justify-center">
      <div className="text-center space-y-3">
        <div className="animate-spin text-4xl">⏳</div>
        <p className="text-sm text-slate-400">Yuklanmoqda...</p>
      </div>
    </div>
  );
}
