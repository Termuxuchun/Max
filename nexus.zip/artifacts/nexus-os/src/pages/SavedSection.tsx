import { useEffect, useState } from "react";
import { ref, onValue, remove } from "firebase/database";
import { db } from "../firebase";
import { Bookmark, Trash2, MessageSquare, Image, Mic, MapPin, Search } from "lucide-react";

interface SavedMsg {
  id: string;
  text: string;
  sender: string;
  type: "text" | "image" | "voice" | "location";
  timestamp: number;
  savedAt: number;
  chatWith: string;
  isGroup: boolean;
}

interface Props {
  username: string;
  accentColor: string;
  onOpenChat: (peer: string, isGroup?: boolean) => void;
}

export default function SavedSection({ username, accentColor, onOpenChat }: Props) {
  const [saved, setSaved] = useState<SavedMsg[]>([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const unsub = onValue(ref(db, `saved_messages/${username}`), snap => {
      const list: SavedMsg[] = [];
      if (snap.exists()) {
        snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      }
      list.sort((a, b) => b.savedAt - a.savedAt);
      setSaved(list);
    });
    return unsub;
  }, [username]);

  async function deleteSaved(id: string) {
    await remove(ref(db, `saved_messages/${username}/${id}`));
  }

  const filtered = query.trim()
    ? saved.filter(m => m.text?.toLowerCase().includes(query.toLowerCase()) || m.sender?.toLowerCase().includes(query.toLowerCase()))
    : saved;

  function typeIcon(type: string) {
    if (type === "image") return <Image className="w-3.5 h-3.5 text-blue-400" />;
    if (type === "voice") return <Mic className="w-3.5 h-3.5 text-green-400" />;
    if (type === "location") return <MapPin className="w-3.5 h-3.5 text-red-400" />;
    return <MessageSquare className="w-3.5 h-3.5 text-slate-400" />;
  }

  function typeLabel(type: string) {
    if (type === "image") return "📷 Rasm";
    if (type === "voice") return "🎤 Ovozli xabar";
    if (type === "location") return "📍 Joylashuv";
    return "";
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 border-b border-slate-800/60 flex-shrink-0">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${accentColor}30, #4f46e580)` }}>
            <Bookmark className="w-4.5 h-4.5" style={{ color: accentColor }} />
          </div>
          <div>
            <h2 className="font-bold text-slate-100 text-base">Saqlanganlar</h2>
            <p className="text-[11px] text-slate-500">{saved.length} ta xabar saqlangan</p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Xabarlarda qidirish..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-sm text-slate-200 outline-none focus:border-slate-600 transition placeholder-slate-600"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-slate-700 py-20">
            <Bookmark className="w-10 h-10 opacity-30" />
            <p className="text-sm font-mono">
              {query ? "Topilmadi" : "Hali saqlangan xabar yo'q"}
            </p>
            <p className="text-[11px] text-slate-600 text-center max-w-48">
              Chat ichida xabar ustiga bosib «Saqlash» tugmasini tanlang
            </p>
          </div>
        )}

        {filtered.map(msg => (
          <div key={msg.id}
            className="group bg-slate-900/70 border border-slate-800/60 rounded-2xl p-3.5 hover:border-slate-700/60 transition-all">
            {/* Top row */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                  style={{ background: `linear-gradient(135deg, ${accentColor}40, #4f46e5)` }}>
                  {msg.sender[0]?.toUpperCase()}
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-200">@{msg.sender}</p>
                  <p className="text-[9px] text-slate-500">
                    {msg.isGroup ? `#${msg.chatWith} guruhi` : `@${msg.chatWith} bilan suhbat`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-[9px] text-slate-600 font-mono">
                  {new Date(msg.savedAt).toLocaleDateString([], { month: "short", day: "numeric" })}
                </span>
                <button
                  onClick={() => onOpenChat(msg.chatWith, msg.isGroup)}
                  className="opacity-0 group-hover:opacity-100 transition p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200"
                  title="Chatga o'tish">
                  <MessageSquare className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => deleteSaved(msg.id)}
                  className="opacity-0 group-hover:opacity-100 transition p-1.5 rounded-lg hover:bg-rose-950/40 text-slate-500 hover:text-rose-400"
                  title="O'chirish">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="pl-9">
              {msg.type === "text" && msg.text ? (
                <p className="text-sm text-slate-300 leading-relaxed line-clamp-3 whitespace-pre-wrap">
                  {msg.text}
                </p>
              ) : (
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  {typeIcon(msg.type)}
                  <span>{typeLabel(msg.type)}</span>
                </div>
              )}
            </div>

            {/* Bottom */}
            <div className="pl-9 mt-1.5 flex items-center gap-2">
              <span className="text-[9px] text-slate-600 font-mono">
                {new Date(msg.timestamp).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
