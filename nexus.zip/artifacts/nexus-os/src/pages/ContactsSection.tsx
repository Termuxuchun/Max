import { useEffect, useState, useMemo } from "react";
import { ref, onValue, get, set, remove, serverTimestamp } from "firebase/database";
import { db } from "../firebase";
import ShareModal from "../components/ShareModal";
import QRScannerModal from "../components/QRScannerModal";
import NearbyModal from "../components/NearbyModal";
import {
  Search, X, Users, ScanLine, QrCode, Globe, Phone, Video,
  MessageCircle, Star, Trash2, Edit3, StickyNote, ChevronDown,
  Plus, UserPlus, Crown
} from "lucide-react";

interface Props {
  username: string;
  accentColor: string;
  onOpenChat: (peer: string) => void;
  onStartCall: (peer: string, type: "audio" | "video") => void;
  onOpenProfile: (peer: string) => void;
  isPremium: boolean;
}

interface Contact {
  username: string;
  name: string;
  addedAt: number;
  note?: string;
}

type FilterTab = "all" | "online" | "favorites";

const GRAD_PAIRS: [string,string][] = [
  ["#22d3ee","#6366f1"],["#a855f7","#ec4899"],["#22c55e","#14b8a6"],
  ["#f59e0b","#ef4444"],["#38bdf8","#818cf8"],["#84cc16","#22c55e"],
  ["#f97316","#f43f5e"],["#8b5cf6","#6366f1"],["#10b981","#0891b2"],
];

function contactGrad(name: string): [string,string] {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffffffff;
  return GRAD_PAIRS[Math.abs(h) % GRAD_PAIRS.length];
}

export default function ContactsSection({
  username, accentColor, onOpenChat, onStartCall, onOpenProfile, isPremium,
}: Props) {
  const [contacts,     setContacts]     = useState<Contact[]>([]);
  const [search,       setSearch]       = useState("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [allUsers,     setAllUsers]     = useState<string[]>([]);
  const [statusMap,    setStatusMap]    = useState<Record<string, string>>({});
  const [showMyQR,     setShowMyQR]     = useState(false);
  const [showScanner,  setShowScanner]  = useState(false);
  const [showNearby,   setShowNearby]   = useState(false);
  const [filter,       setFilter]       = useState<FilterTab>("all");
  const [favorites,    setFavorites]    = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(`nexus_fav_contacts_${username}`) || "[]"); }
    catch { return []; }
  });
  const [expandedContact, setExpandedContact] = useState<string | null>(null);
  const [editingNote,  setEditingNote]  = useState<string | null>(null);
  const [noteText,     setNoteText]     = useState("");
  const [addingContact, setAddingContact] = useState<string | null>(null);
  const [newContactName, setNewContactName] = useState("");

  useEffect(() => {
    const u1 = onValue(ref(db, `contacts/${username}`), s => {
      if (!s.exists()) { setContacts([]); return; }
      const list: Contact[] = [];
      s.forEach(c => {
        const d = c.val();
        list.push({ username: c.key!, name: d.name, addedAt: d.addedAt || 0, note: d.note });
      });
      list.sort((a, b) => a.name.localeCompare(b.name));
      setContacts(list);
    });
    const u2 = onValue(ref(db, "users"), s => {
      const list: string[] = [];
      s.forEach(c => { if (c.key !== username) list.push(c.key!); });
      setAllUsers(list);
    });
    const u3 = onValue(ref(db, "status"), s => {
      const m: Record<string, string> = {};
      s.forEach(c => { m[c.key!] = c.val()?.state || "offline"; });
      setStatusMap(m);
    });
    return () => { u1(); u2(); u3(); };
  }, [username]);

  useEffect(() => {
    if (!search.trim()) { setSearchResults([]); return; }
    const q = search.toLowerCase().replace(/^@/, "");
    setSearchResults(allUsers.filter(u => u.toLowerCase().includes(q)).slice(0, 8));
  }, [search, allUsers]);

  async function addContact(uname: string, name: string) {
    if (!isPremium && contacts.length >= 20) {
      alert("🔒 Tekin limit (20 kontakt) tugadi.\n👑 Premium — cheksiz kontaktlar!");
      return;
    }
    if (contacts.find(c => c.username === uname)) { alert("Bu kontakt allaqachon mavjud!"); return; }
    await set(ref(db, `contacts/${username}/${uname}`), {
      name: name.trim() || uname,
      addedAt: serverTimestamp(),
    });
    setSearch(""); setAddingContact(null); setNewContactName("");
  }

  function handleScanResult(text: string) {
    setShowScanner(false);
    if (text.startsWith("nexus://user/")) onOpenProfile(text.replace("nexus://user/", ""));
    else if (text.startsWith("nexus://join/")) alert(`Kanal: ${text.replace("nexus://join/", "@")}`);
    else alert(`QR kod: ${text}`);
  }

  function toggleFavorite(uname: string) {
    const next = favorites.includes(uname)
      ? favorites.filter(f => f !== uname)
      : [...favorites, uname];
    setFavorites(next);
    localStorage.setItem(`nexus_fav_contacts_${username}`, JSON.stringify(next));
  }

  async function deleteContact(uname: string) {
    if (!confirm(`@${uname} o'chirilsinmi?`)) return;
    await remove(ref(db, `contacts/${username}/${uname}`));
    if (expandedContact === uname) setExpandedContact(null);
  }

  async function saveNote(uname: string) {
    await set(ref(db, `contacts/${username}/${uname}/note`), noteText.trim());
    setEditingNote(null);
  }

  const filtered = useMemo(() => {
    let list = contacts;
    if (search.trim() && searchResults.length === 0) {
      const q = search.toLowerCase().replace(/^@/, "");
      list = list.filter(c => c.username.toLowerCase().includes(q) || c.name.toLowerCase().includes(q));
    }
    if (filter === "online")    list = list.filter(c => statusMap[c.username] === "online");
    if (filter === "favorites") list = list.filter(c => favorites.includes(c.username));
    return list;
  }, [contacts, search, searchResults, filter, statusMap, favorites]);

  const onlineCount    = contacts.filter(c => statusMap[c.username] === "online").length;
  const favoritesCount = contacts.filter(c => favorites.includes(c.username)).length;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* ===== header ===== */}
      <div className="flex-shrink-0 px-4 pt-4 pb-3 space-y-3">
        {/* title row */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-mono">Kontaktlar</p>
            <div className="flex items-center gap-2 mt-0.5">
              <p className="text-lg font-black text-white">Contacts</p>
              {contacts.length > 0 && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                  {contacts.length}{!isPremium ? "/20" : ""}
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button onClick={() => setShowNearby(true)}
              title="Yaqin atrofidagilar"
              className="w-8 h-8 rounded-xl flex items-center justify-center transition hover:scale-105 active:scale-95 text-green-400"
              style={{ background:"rgba(34,197,94,0.12)", border:"1px solid rgba(34,197,94,0.25)" }}>
              <Globe className="w-4 h-4" />
            </button>
            <button onClick={() => setShowScanner(true)}
              title="QR Scan"
              className="w-8 h-8 rounded-xl flex items-center justify-center transition hover:scale-105 active:scale-95 text-cyan-400"
              style={{ background:"rgba(14,116,144,0.15)", border:"1px solid rgba(14,116,144,0.3)" }}>
              <ScanLine className="w-4 h-4" />
            </button>
            <button onClick={() => setShowMyQR(true)}
              title="Mening QR"
              className="w-8 h-8 rounded-xl flex items-center justify-center transition hover:scale-105 active:scale-95 text-indigo-400"
              style={{ background:"rgba(99,102,241,0.15)", border:"1px solid rgba(99,102,241,0.3)" }}>
              <QrCode className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Kontakt yoki @username..."
            className="w-full pl-9 pr-9 py-2.5 rounded-xl text-sm text-white outline-none transition-all duration-200"
            style={{
              background:"rgba(15,23,42,0.7)",
              border:`1px solid ${search ? accentColor + "44" : "rgba(255,255,255,0.07)"}`,
              boxShadow: search ? `0 0 0 2px ${accentColor}12` : "none",
            }}
          />
          {search && (
            <button onClick={() => setSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* filter tabs */}
        <div className="flex gap-1">
          {([
            { key:"all",       label:"Hammasi",  count: contacts.length },
            { key:"online",    label:"Online",   count: onlineCount },
            { key:"favorites", label:"⭐ Sevimli", count: favoritesCount },
          ] as { key: FilterTab; label: string; count: number }[]).map(tab => (
            <button key={tab.key} onClick={() => setFilter(tab.key)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all duration-200 flex-shrink-0"
              style={filter === tab.key
                ? { background:`${accentColor}20`, color: accentColor, border:`1px solid ${accentColor}35` }
                : { background:"transparent", color:"#64748b", border:"1px solid transparent" }
              }>
              {tab.label}
              {tab.count > 0 && (
                <span className="min-w-[16px] h-4 flex items-center justify-center rounded-full text-[9px] font-black px-1"
                  style={filter === tab.key
                    ? { background: accentColor, color:"white" }
                    : { background:"#1e293b", color:"#64748b" }}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ===== body ===== */}
      <div className="flex-1 overflow-y-auto px-4 space-y-2 pb-4">
        {/* search results for new contacts */}
        {search.trim() && searchResults.length > 0 && (
          <div className="space-y-1.5 mb-3">
            <p className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">Tizimda topildi</p>
            {searchResults.map(u => {
              const already = contacts.find(c => c.username === u);
              const isOnline = statusMap[u] === "online";
              const [g1, g2] = contactGrad(u);
              return (
                <div key={u}
                  className="flex items-center gap-3 p-3 rounded-2xl border border-slate-800 bg-slate-900/50 transition hover:border-slate-700">
                  <div className="relative flex-shrink-0">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm text-white"
                      style={{ background:`linear-gradient(135deg,${g1},${g2})` }}>
                      {u[0].toUpperCase()}
                    </div>
                    {isOnline && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-400 border-2 border-[#030712]" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-200 truncate">@{u}</p>
                    <p className="text-[10px] font-mono" style={{ color: isOnline ? "#4ade80" : "#475569" }}>
                      {isOnline ? "● Online" : "○ Offline"}
                    </p>
                  </div>
                  {already ? (
                    <button onClick={() => onOpenChat(u)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 bg-slate-800 border border-slate-700 hover:bg-slate-700 transition">
                      <MessageCircle className="w-3 h-3" /> Chat
                    </button>
                  ) : addingContact === u ? (
                    <div className="flex gap-1.5">
                      <input
                        value={newContactName}
                        onChange={e => setNewContactName(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") addContact(u, newContactName || u); if (e.key === "Escape") setAddingContact(null); }}
                        placeholder="Ism"
                        autoFocus
                        className="w-20 bg-slate-950 border border-slate-600 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-cyan-500 transition"
                      />
                      <button onClick={() => addContact(u, newContactName || u)}
                        className="px-2 py-1 rounded-lg text-xs font-bold text-white transition"
                        style={{ background: accentColor }}>
                        ✓
                      </button>
                      <button onClick={() => { setAddingContact(null); setNewContactName(""); }}
                        className="px-2 py-1 rounded-lg text-xs text-slate-500 bg-slate-800 transition">
                        ✕
                      </button>
                    </div>
                  ) : (
                    <button onClick={() => { setAddingContact(u); setNewContactName(u); }}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition hover:scale-105 active:scale-95"
                      style={{ background:`${accentColor}20`, color: accentColor, border:`1px solid ${accentColor}30` }}>
                      <UserPlus className="w-3 h-3" /> Qo'shish
                    </button>
                  )}
                </div>
              );
            })}
            <div className="border-b border-slate-800/50 pt-1" />
          </div>
        )}

        {/* empty state */}
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
            <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl"
              style={{ background:`${accentColor}10`, border:`1px solid ${accentColor}20` }}>
              {filter === "favorites" ? "⭐" : filter === "online" ? "🟢" : "👥"}
            </div>
            <div>
              <p className="text-slate-300 font-bold">
                {filter === "favorites" ? "Sevimlilar yo'q" : filter === "online" ? "Hech kim online emas" : "Kontaktlar yo'q"}
              </p>
              <p className="text-xs text-slate-600 mt-1">
                {filter !== "all" ? "Filtrni o'zgartiring" : "Yuqoridagi qidiruvdan foydalanuvchi qo'shing"}
              </p>
            </div>
          </div>
        )}

        {/* contact cards */}
        {filtered.map(contact => {
          const isOnline  = statusMap[contact.username] === "online";
          const isFav     = favorites.includes(contact.username);
          const isExpanded = expandedContact === contact.username;
          const [g1, g2]  = contactGrad(contact.username);

          return (
            <div key={contact.username}
              className="rounded-2xl border overflow-hidden transition-all duration-200"
              style={{
                borderColor: isExpanded ? `${accentColor}30` : "rgba(255,255,255,0.07)",
                background: isExpanded ? `${accentColor}06` : "rgba(15,23,42,0.6)",
              }}>
              {/* main row */}
              <div className="flex items-center gap-3 p-3">
                {/* avatar */}
                <button onClick={() => onOpenProfile(contact.username)} className="relative flex-shrink-0">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-base text-white shadow-md"
                    style={{ background:`linear-gradient(135deg,${g1},${g2})`, boxShadow:`0 4px 14px ${g1}25` }}>
                    {contact.name[0]?.toUpperCase()}
                  </div>
                  {isOnline && (
                    <div className="absolute -bottom-0.5 -right-0.5">
                      <div className="w-3.5 h-3.5 rounded-full bg-green-400 border-2 border-[#030712]" />
                      <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-30" />
                    </div>
                  )}
                </button>

                {/* info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-bold text-slate-100 truncate">{contact.name}</p>
                    {isFav && <Star className="w-3 h-3 text-amber-400 flex-shrink-0" fill="#f59e0b" />}
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-[11px] text-slate-500 font-mono truncate">@{contact.username}</p>
                    <span className="text-[10px] font-mono" style={{ color: isOnline ? "#4ade80" : "#475569" }}>
                      {isOnline ? "● Online" : ""}
                    </span>
                  </div>
                  {contact.note && (
                    <p className="text-[10px] text-slate-600 truncate mt-0.5 italic">📝 {contact.note}</p>
                  )}
                </div>

                {/* quick actions */}
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => onOpenChat(contact.username)}
                    className="w-9 h-9 rounded-xl flex items-center justify-center transition hover:scale-110 active:scale-90"
                    style={{ background:`${accentColor}15`, color: accentColor, border:`1px solid ${accentColor}25` }}>
                    <MessageCircle className="w-4 h-4" />
                  </button>
                  <button onClick={() => onStartCall(contact.username, "audio")}
                    className="w-9 h-9 rounded-xl flex items-center justify-center text-green-400 transition hover:scale-110 active:scale-90"
                    style={{ background:"rgba(34,197,94,0.12)", border:"1px solid rgba(34,197,94,0.2)" }}>
                    <Phone className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setExpandedContact(isExpanded ? null : contact.username)}
                    className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-500 hover:text-slate-300 transition hover:bg-slate-800"
                  >
                    <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`} />
                  </button>
                </div>
              </div>

              {/* expanded row */}
              {isExpanded && (
                <div className="border-t px-3 py-3 space-y-3"
                  style={{ borderColor:`${accentColor}18`, background:`${accentColor}04` }}>
                  {/* action buttons row */}
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { icon: <Video className="w-4 h-4" />,       label:"Video",    action: () => onStartCall(contact.username, "video"), color:"#6366f1" },
                      { icon: <Star className="w-4 h-4" />,        label: isFav ? "Olib tashlash" : "Sevimli", action: () => toggleFavorite(contact.username), color:"#f59e0b", active: isFav },
                      { icon: <StickyNote className="w-4 h-4" />,  label:"Eslatma",  action: () => { setEditingNote(contact.username); setNoteText(contact.note || ""); }, color:"#22c55e" },
                      { icon: <Trash2 className="w-4 h-4" />,      label:"O'chirish", action: () => deleteContact(contact.username), color:"#ef4444" },
                    ].map((btn, i) => (
                      <button key={i} onClick={btn.action}
                        className="flex flex-col items-center gap-1 py-2.5 rounded-xl text-[10px] font-bold transition hover:opacity-80 active:scale-95"
                        style={{
                          background:`${btn.color}10`,
                          border:`1px solid ${btn.color}20`,
                          color: btn.active ? btn.color : btn.color,
                        }}>
                        <span style={{ color: btn.color }}>{btn.icon}</span>
                        {btn.label}
                      </button>
                    ))}
                  </div>

                  {/* note editor */}
                  {editingNote === contact.username && (
                    <div className="flex gap-2">
                      <input
                        value={noteText}
                        onChange={e => setNoteText(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") saveNote(contact.username); if (e.key === "Escape") setEditingNote(null); }}
                        placeholder="Eslatma yozing..."
                        autoFocus
                        className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-500 transition"
                      />
                      <button onClick={() => saveNote(contact.username)}
                        className="px-3 py-2 rounded-xl text-xs font-bold text-white transition"
                        style={{ background: accentColor }}>
                        ✓
                      </button>
                      <button onClick={() => setEditingNote(null)}
                        className="px-3 py-2 rounded-xl text-xs text-slate-500 bg-slate-800 hover:bg-slate-700 transition">
                        ✕
                      </button>
                    </div>
                  )}

                  {/* meta */}
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-700 font-mono">
                      Qo'shilgan: {contact.addedAt ? new Date(contact.addedAt).toLocaleDateString("uz-UZ") : "—"}
                    </span>
                    <button onClick={() => onOpenProfile(contact.username)}
                      className="text-[10px] font-bold transition hover:opacity-80"
                      style={{ color: accentColor }}>
                      Profilni ko'rish →
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* premium limit warning */}
        {!isPremium && contacts.length >= 15 && (
          <div className="flex items-center gap-3 p-3.5 rounded-2xl border border-amber-800/40 bg-amber-950/10">
            <Crown className="w-5 h-5 text-amber-400 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-xs font-bold text-amber-300">{contacts.length}/20 kontakt ishlatildi</p>
              <p className="text-[10px] text-amber-700">Premium bilan cheksiz kontakt!</p>
            </div>
          </div>
        )}

        <div className="h-4" />
      </div>

      {/* ===== modals ===== */}
      {showMyQR && (
        <ShareModal
          title={`@${username}`}
          subtitle="Mening profil QR kodi"
          link={`nexus://user/${username}`}
          displayLink={`nexus://user/${username}`}
          onClose={() => setShowMyQR(false)}
        />
      )}
      {showScanner  && <QRScannerModal onResult={handleScanResult} onClose={() => setShowScanner(false)} />}
      {showNearby   && <NearbyModal username={username} accentColor={accentColor} onOpenChat={onOpenChat} onOpenProfile={onOpenProfile} onClose={() => setShowNearby(false)} />}
    </div>
  );
}
