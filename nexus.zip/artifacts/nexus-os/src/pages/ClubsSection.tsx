import { useState, useEffect } from "react";
import { ref, push, onValue, set, remove, get, update } from "firebase/database";
import { db } from "../firebase";
import { logActivity } from "../utils/activityLog";
import { Plus, Users, Search, Flame, Hash, Crown, ArrowLeft, Send, Heart, MessageCircle } from "lucide-react";

interface Props { username: string; accentColor: string; onOpenProfile: (u: string) => void; }

interface Club {
  id: string; name: string; description?: string; topic: string;
  creator: string; createdAt: number; icon: string; color: string;
  members?: Record<string, number>; pinned?: boolean;
}

interface ClubPost {
  id: string; text: string; author: string; ts: number;
  likes?: Record<string, boolean>; image?: string;
}

const TOPICS = [
  { key: "all",      emoji: "🌐", label: "Barchasi",    color: "#22d3ee" },
  { key: "gaming",   emoji: "🎮", label: "Gaming",      color: "#a855f7" },
  { key: "music",    emoji: "🎵", label: "Musiqa",       color: "#f59e0b" },
  { key: "sport",    emoji: "⚽", label: "Sport",        color: "#4ade80" },
  { key: "tech",     emoji: "💻", label: "Tech",         color: "#3b82f6" },
  { key: "food",     emoji: "🍕", label: "Ovqat",        color: "#f97316" },
  { key: "art",      emoji: "🎨", label: "San'at",       color: "#ec4899" },
  { key: "travel",   emoji: "✈️", label: "Sayohat",      color: "#06b6d4" },
  { key: "anime",    emoji: "🍥", label: "Anime",        color: "#e879f9" },
  { key: "cinema",   emoji: "🎬", label: "Kino",         color: "#ef4444" },
  { key: "crypto",   emoji: "₿",  label: "Kripto",       color: "#f59e0b" },
  { key: "study",    emoji: "📚", label: "O'qish",       color: "#22c55e" },
];

function timeAgo(ts: number) {
  const d = Date.now() - ts;
  if (d < 60000) return "hozir";
  if (d < 3600000) return `${Math.floor(d / 60000)}d`;
  if (d < 86400000) return `${Math.floor(d / 3600000)}s`;
  return `${Math.floor(d / 86400000)}kun`;
}

const PRESET_ICONS = ["🎮","🎵","⚽","💻","🍕","🎨","✈️","🍥","🎬","₿","📚","🌍","🔥","💎","🚀","🎯","🦋","🌸","⚡","🎭"];
const PRESET_COLORS = ["#22d3ee","#a855f7","#f59e0b","#4ade80","#3b82f6","#f97316","#ec4899","#06b6d4","#e879f9","#ef4444"];

export default function ClubsSection({ username, accentColor, onOpenProfile }: Props) {
  const [clubs, setClubs] = useState<Club[]>([]);
  const [view, setView] = useState<"browse" | "create" | "club">("browse");
  const [selectedClub, setSelectedClub] = useState<Club | null>(null);
  const [clubPosts, setClubPosts] = useState<ClubPost[]>([]);
  const [topicFilter, setTopicFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"discover" | "joined">("discover");
  const [animIn, setAnimIn] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [onlineSet, setOnlineSet] = useState<Set<string>>(new Set());
  const [postText, setPostText] = useState("");
  const [posting, setPosting] = useState(false);

  // Form
  const [form, setForm] = useState({
    name: "", description: "", topic: "gaming", icon: "🎮", color: "#22d3ee"
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { setTimeout(() => setAnimIn(true), 60); }, []);

  useEffect(() => {
    return onValue(ref(db, "status"), snap => {
      const s = new Set<string>();
      snap.forEach(c => { if (c.val()?.state === "online") s.add(c.key!); });
      setOnlineSet(s);
    });
  }, []);

  useEffect(() => {
    return onValue(ref(db, "clubs"), snap => {
      const list: Club[] = [];
      if (snap.exists()) snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => Object.keys(b.members || {}).length - Object.keys(a.members || {}).length);
      setClubs(list);
    });
  }, []);

  useEffect(() => {
    if (!selectedClub) return;
    return onValue(ref(db, `club_posts/${selectedClub.id}`), snap => {
      const list: ClubPost[] = [];
      if (snap.exists()) snap.forEach(c => { list.push({ id: c.key!, ...c.val() }); });
      list.sort((a, b) => b.ts - a.ts);
      setClubPosts(list);
    });
  }, [selectedClub?.id]);

  function showFlash(msg: string) { setFlash(msg); setTimeout(() => setFlash(null), 2500); }

  async function createClub() {
    if (!form.name.trim()) return;
    setSubmitting(true);
    const clubRef = await push(ref(db, "clubs"), {
      name: form.name.trim(), description: form.description.trim() || null,
      topic: form.topic, creator: username, createdAt: Date.now(),
      icon: form.icon, color: form.color,
      members: { [username]: Date.now() },
    });
    logActivity("club_created", username, { entityName: form.name.trim() });
    setForm({ name: "", description: "", topic: "gaming", icon: "🎮", color: "#22d3ee" });
    setView("browse");
    setSubmitting(false);
    showFlash(`🎉 "${form.name}" klubi yaratildi!`);
  }

  async function joinClub(club: Club) {
    await set(ref(db, `clubs/${club.id}/members/${username}`), Date.now());
    logActivity("club_joined", username, { entityName: club.name, entityId: club.id });
    showFlash(`✅ "${club.name}" klubiga qo'shildingiz!`);
  }

  async function leaveClub(club: Club) {
    if (club.creator === username) { showFlash("⚠️ Siz klub yaratuvchisisiz, tark eta olmaysiz"); return; }
    await remove(ref(db, `clubs/${club.id}/members/${username}`));
    showFlash(`Siz "${club.name}" klubini tark etdingiz`);
  }

  async function sendPost() {
    if (!postText.trim() || !selectedClub) return;
    setPosting(true);
    await push(ref(db, `club_posts/${selectedClub.id}`), {
      text: postText.trim(), author: username, ts: Date.now()
    });
    logActivity("club_post", username, { entityName: selectedClub.name, entityId: selectedClub.id });
    setPostText("");
    setPosting(false);
  }

  async function toggleLike(post: ClubPost) {
    if (!selectedClub) return;
    const path = `club_posts/${selectedClub.id}/${post.id}/likes/${username}`;
    if (post.likes?.[username]) await remove(ref(db, path));
    else await set(ref(db, path), true);
  }

  async function deletePost(post: ClubPost) {
    if (!selectedClub || post.author !== username) return;
    await remove(ref(db, `club_posts/${selectedClub.id}/${post.id}`));
  }

  const joined = clubs.filter(c => c.members?.[username]);
  const notJoined = clubs.filter(c => !c.members?.[username]);

  let browseClubs = activeTab === "joined" ? joined : notJoined;
  if (topicFilter !== "all") browseClubs = browseClubs.filter(c => c.topic === topicFilter);
  if (search.trim()) browseClubs = browseClubs.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  const topicInfo = TOPICS.find(t => t.key === selectedClub?.topic);
  const memberCount = Object.keys(selectedClub?.members || {}).length;
  const onlineMembers = Object.keys(selectedClub?.members || {}).filter(u => onlineSet.has(u)).length;
  const isMember = selectedClub ? !!selectedClub.members?.[username] : false;

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      <style>{`
        @keyframes cl-in { from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);} }
        .cl-card { animation: cl-in 0.3s ease both; }
      `}</style>

      {flash && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl text-sm font-bold text-white shadow-2xl"
          style={{ background:"rgba(15,23,42,0.95)",border:`1px solid ${accentColor}40`,backdropFilter:"blur(20px)" }}>
          {flash}
        </div>
      )}

      {/* ── CLUB DETAIL VIEW ── */}
      {view === "club" && selectedClub && (
        <div className="flex flex-col h-full">
          {/* Club Header */}
          <div className="flex-shrink-0 relative overflow-hidden"
            style={{ background:`linear-gradient(135deg,${selectedClub.color}18,#03071288)`,borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
            <div className="absolute inset-0" style={{ background:`radial-gradient(circle at top right,${selectedClub.color}15,transparent 60%)` }}/>
            <div className="relative px-4 pt-4 pb-3">
              <div className="flex items-center gap-3 mb-3">
                <button onClick={() => { setView("browse"); setSelectedClub(null); setClubPosts([]); }}
                  className="w-8 h-8 rounded-xl flex items-center justify-center bg-black/30 backdrop-blur-md text-white/70 hover:text-white transition flex-shrink-0">
                  <ArrowLeft className="w-4 h-4"/>
                </button>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0"
                  style={{ background:`${selectedClub.color}25`,border:`1px solid ${selectedClub.color}40` }}>
                  {selectedClub.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-black text-white text-base truncate">{selectedClub.name}</p>
                    {selectedClub.creator === username && <Crown className="w-3.5 h-3.5 text-amber-400 flex-shrink-0"/>}
                  </div>
                  <div className="flex items-center gap-3 mt-0.5">
                    <span className="text-[9px] text-slate-400">👥 {memberCount} a'zo</span>
                    <span className="text-[9px] text-green-400">● {onlineMembers} onlayn</span>
                    <span className="text-[9px]" style={{ color: topicInfo?.color || accentColor }}>
                      {topicInfo?.emoji} {topicInfo?.label}
                    </span>
                  </div>
                </div>
                <button onClick={() => isMember ? leaveClub(selectedClub) : joinClub(selectedClub)}
                  className="px-3 py-1.5 rounded-xl text-[10px] font-black transition active:scale-90 flex-shrink-0"
                  style={isMember
                    ? { background:"rgba(239,68,68,0.12)",color:"#f87171",border:"1px solid rgba(239,68,68,0.25)" }
                    : { background:`${selectedClub.color}20`,color:selectedClub.color,border:`1px solid ${selectedClub.color}40` }}>
                  {isMember ? "Tark et" : "Qo'shil"}
                </button>
              </div>
              {selectedClub.description && (
                <p className="text-[11px] text-slate-400 pl-11">{selectedClub.description}</p>
              )}
            </div>
          </div>

          {/* Posts feed */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            {clubPosts.length === 0 && (
              <div className="flex flex-col items-center gap-3 py-12 text-center">
                <span className="text-5xl">{selectedClub.icon}</span>
                <p className="text-white font-black text-lg">{selectedClub.name}</p>
                <p className="text-slate-500 text-sm">Hali post yo'q. Birinchi bo'ling!</p>
              </div>
            )}
            {clubPosts.map((post, i) => {
              const likeCount = Object.keys(post.likes || {}).length;
              const liked = !!post.likes?.[username];
              const isMe = post.author === username;
              return (
                <div key={post.id} className="cl-card rounded-2xl bg-slate-900/50 border border-slate-800/40 p-4"
                  style={{ animationDelay:`${Math.min(i*30,240)}ms` }}>
                  <div className="flex items-start gap-3">
                    <button onClick={() => onOpenProfile(post.author)}
                      className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black text-white flex-shrink-0"
                      style={{ background:`linear-gradient(135deg,${selectedClub.color}88,#6366f1)` }}>
                      {post.author[0]?.toUpperCase()}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <button onClick={() => onOpenProfile(post.author)}
                          className="font-bold text-sm text-white hover:text-slate-300 transition">
                          @{post.author}
                          {onlineSet.has(post.author) && <span className="text-[8px] text-green-400 font-bold ml-1.5">● LIVE</span>}
                        </button>
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] text-slate-600">{timeAgo(post.ts)}</span>
                          {isMe && (
                            <button onClick={() => deletePost(post)}
                              className="text-[9px] text-rose-600 hover:text-rose-400 transition">🗑</button>
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-slate-300 mt-1.5 leading-relaxed">{post.text}</p>
                      <div className="flex items-center gap-3 mt-2.5">
                        <button onClick={() => toggleLike(post)}
                          className="flex items-center gap-1 text-xs font-bold transition active:scale-90"
                          style={{ color: liked ? "#f43f5e" : "#64748b" }}>
                          <Heart className={`w-3.5 h-3.5 ${liked ? "fill-current" : ""}`}/>
                          {likeCount > 0 && <span>{likeCount}</span>}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Post input */}
          {isMember && (
            <div className="flex-shrink-0 px-4 py-3 border-t border-slate-800/50 flex items-end gap-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black text-white flex-shrink-0"
                style={{ background:`linear-gradient(135deg,${accentColor}88,#6366f1)` }}>
                {username[0]?.toUpperCase()}
              </div>
              <div className="flex-1 relative">
                <textarea value={postText} onChange={e => setPostText(e.target.value)}
                  placeholder="Nimadir yozing..."
                  rows={1}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendPost(); }}}
                  className="w-full bg-slate-900/70 border border-slate-800 rounded-2xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-slate-600 resize-none placeholder-slate-700 transition"/>
              </div>
              <button onClick={sendPost} disabled={posting || !postText.trim()}
                className="w-9 h-9 rounded-xl flex items-center justify-center transition active:scale-90 disabled:opacity-40 flex-shrink-0"
                style={{ background:`${accentColor}20`,border:`1px solid ${accentColor}35` }}>
                <Send className="w-4 h-4" style={{ color:accentColor }}/>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ── CREATE CLUB VIEW ── */}
      {view === "create" && (
        <div className="flex flex-col h-full overflow-y-auto">
          <div className="flex items-center gap-3 p-4 border-b border-slate-800/50 flex-shrink-0">
            <button onClick={() => setView("browse")}
              className="w-9 h-9 rounded-xl flex items-center justify-center bg-slate-900/60 border border-slate-800 text-slate-400 hover:text-white transition">
              <ArrowLeft className="w-4 h-4"/>
            </button>
            <div>
              <p className="font-black text-white">Klub yaratish</p>
              <p className="text-[10px] text-slate-500">Yangi jamoa boshlang</p>
            </div>
          </div>
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            {/* Icon + color preview */}
            <div className="flex items-center gap-4 p-4 rounded-2xl border border-slate-800"
              style={{ background:`${form.color}10` }}>
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl flex-shrink-0"
                style={{ background:`${form.color}25`,border:`2px solid ${form.color}50` }}>
                {form.icon}
              </div>
              <div className="flex-1">
                <p className="font-black text-white text-lg">{form.name || "Klub nomi"}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">{form.description || "Tavsif..."}</p>
              </div>
            </div>

            <input value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))}
              placeholder="Klub nomi *"
              className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-700 transition"/>
            <textarea value={form.description} onChange={e => setForm(f=>({...f,description:e.target.value}))}
              placeholder="Tavsif (ixtiyoriy)"
              rows={2}
              className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3 text-sm text-white outline-none focus:border-slate-600 placeholder-slate-700 transition resize-none"/>

            {/* Topic */}
            <div>
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-2">Mavzu</p>
              <div className="flex flex-wrap gap-1.5">
                {TOPICS.filter(t => t.key !== "all").map(t => (
                  <button key={t.key} onClick={() => setForm(f=>({...f,topic:t.key,color:t.color}))}
                    className="px-2.5 py-1.5 rounded-xl text-[10px] font-bold transition"
                    style={form.topic === t.key
                      ? { background:`${t.color}20`,color:t.color,border:`1px solid ${t.color}35` }
                      : { color:"#64748b",border:"1px solid rgba(255,255,255,0.06)" }}>
                    {t.emoji} {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Icons */}
            <div>
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-2">Ikonka</p>
              <div className="flex flex-wrap gap-2">
                {PRESET_ICONS.map(ic => (
                  <button key={ic} onClick={() => setForm(f=>({...f,icon:ic}))}
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-xl transition active:scale-90"
                    style={form.icon === ic
                      ? { background:`${form.color}25`,border:`2px solid ${form.color}60` }
                      : { background:"rgba(15,23,42,0.7)",border:"1px solid rgba(255,255,255,0.06)" }}>
                    {ic}
                  </button>
                ))}
              </div>
            </div>

            {/* Colors */}
            <div>
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-2">Rang</p>
              <div className="flex gap-2 flex-wrap">
                {PRESET_COLORS.map(col => (
                  <button key={col} onClick={() => setForm(f=>({...f,color:col}))}
                    className="w-8 h-8 rounded-xl transition active:scale-90"
                    style={{ background:col, boxShadow: form.color === col ? `0 0 0 3px ${col}60` : undefined }}/>
                ))}
              </div>
            </div>

            <button onClick={createClub} disabled={submitting || !form.name.trim()}
              className="w-full py-3.5 rounded-2xl font-black text-sm text-white disabled:opacity-40 transition active:scale-95"
              style={{ background:`linear-gradient(135deg,${form.color},${accentColor})` }}>
              {submitting ? "⏳ Saqlanmoqda..." : "🏘️ Klub yaratish"}
            </button>
          </div>
        </div>
      )}

      {/* ── BROWSE VIEW ── */}
      {view === "browse" && (
        <>
          {/* Header */}
          <div className="flex-shrink-0 px-4 pt-4 pb-2"
            style={{ animation:animIn?"cl-in 0.3s ease":undefined }}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl"
                  style={{ background:`${accentColor}20`,border:`1px solid ${accentColor}35` }}>🏘️</div>
                <div>
                  <p className="text-base font-black text-white">Klublar</p>
                  <p className="text-[10px] text-slate-500">{joined.length} ta klub a'zosi</p>
                </div>
              </div>
              <button onClick={() => setView("create")}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold text-xs transition active:scale-95"
                style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                <Plus className="w-3.5 h-3.5"/> Yaratish
              </button>
            </div>

            {/* Search */}
            <div className="relative mb-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600"/>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Klub qidirish..."
                className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl pl-9 pr-3 py-2.5 text-sm text-slate-300 outline-none focus:border-slate-600 transition placeholder-slate-700"/>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 bg-slate-900/60 p-1 rounded-2xl border border-slate-800/60 mb-3">
              {([
                { key:"discover", label:"🌐 Kashf et" },
                { key:"joined",   label:`⭐ Mening (${joined.length})` },
              ] as const).map(t => (
                <button key={t.key} onClick={() => setActiveTab(t.key)}
                  className="flex-1 py-1.5 rounded-xl text-[10px] font-bold transition"
                  style={activeTab===t.key ? {background:`${accentColor}20`,color:accentColor} : {color:"#64748b"}}>
                  {t.label}
                </button>
              ))}
            </div>

            {/* Topic filter */}
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {TOPICS.map(t => (
                <button key={t.key} onClick={() => setTopicFilter(t.key)}
                  className="flex-shrink-0 px-2.5 py-1.5 rounded-xl text-[10px] font-bold transition"
                  style={topicFilter===t.key
                    ? { background:`${t.color}20`,color:t.color,border:`1px solid ${t.color}35` }
                    : { color:"#475569",border:"1px solid rgba(255,255,255,0.04)" }}>
                  {t.emoji} {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Clubs list */}
          <div className="flex-1 overflow-y-auto px-4 pb-6">
            {browseClubs.length === 0 && (
              <div className="flex flex-col items-center gap-4 py-16 text-center">
                <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-5xl"
                  style={{ background:`${accentColor}12`,border:`1px solid ${accentColor}20` }}>
                  {activeTab === "joined" ? "🤷" : "🏘️"}
                </div>
                <div>
                  <p className="text-white font-black text-lg">
                    {activeTab === "joined" ? "Hali klub yo'q" : "Bu mavzuda klub yo'q"}
                  </p>
                  <p className="text-slate-500 text-sm mt-1">
                    {activeTab === "joined" ? "Qiziqarli klublarga qo'shiling!" : "Yangi klub yarating!"}
                  </p>
                </div>
                <button onClick={() => setView("create")}
                  className="px-6 py-3 rounded-2xl font-bold text-sm transition active:scale-95"
                  style={{ background:`${accentColor}20`,color:accentColor,border:`1px solid ${accentColor}35` }}>
                  🏘️ Klub yaratish
                </button>
              </div>
            )}
            <div className="space-y-2.5 mt-2">
              {browseClubs.map((club, i) => {
                const memberCount = Object.keys(club.members || {}).length;
                const onlineCount = Object.keys(club.members || {}).filter(u => onlineSet.has(u)).length;
                const isMem = !!club.members?.[username];
                const topInfo = TOPICS.find(t => t.key === club.topic);
                return (
                  <div key={club.id} className="cl-card rounded-2xl border overflow-hidden cursor-pointer"
                    style={{ animationDelay:`${Math.min(i*35,280)}ms`,background:"rgba(10,15,30,0.85)",borderColor:"rgba(255,255,255,0.06)" }}
                    onClick={() => { setSelectedClub(club); setView("club"); }}>
                    <div className="h-0.5" style={{ background:`linear-gradient(90deg,${club.color},${club.color}33,transparent)` }}/>
                    <div className="p-4 flex items-center gap-3">
                      <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0 relative"
                        style={{ background:`${club.color}20`,border:`1px solid ${club.color}40` }}>
                        {club.icon}
                        {onlineCount > 0 && (
                          <div className="absolute -bottom-1 -right-1 min-w-[16px] h-4 rounded-full flex items-center justify-center text-[8px] font-black text-white px-1"
                            style={{ background:"#16a34a" }}>{onlineCount}</div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-black text-sm text-white truncate">{club.name}</p>
                          {club.creator === username && <Crown className="w-3 h-3 text-amber-400 flex-shrink-0"/>}
                        </div>
                        {club.description && (
                          <p className="text-[10px] text-slate-500 truncate mt-0.5">{club.description}</p>
                        )}
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[9px] text-slate-500">👥 {memberCount}</span>
                          <span className="text-[9px]" style={{ color: topInfo?.color || "#64748b" }}>{topInfo?.emoji} {topInfo?.label}</span>
                        </div>
                      </div>
                      <button
                        onClick={e => { e.stopPropagation(); isMem ? leaveClub(club) : joinClub(club); }}
                        className="flex-shrink-0 px-3 py-1.5 rounded-xl text-[10px] font-black transition active:scale-90"
                        style={isMem
                          ? { background:"rgba(74,222,128,0.12)",color:"#4ade80",border:"1px solid rgba(74,222,128,0.25)" }
                          : { background:`${club.color}15`,color:club.color,border:`1px solid ${club.color}30` }}>
                        {isMem ? "✅ A'zo" : "+ Qo'shil"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
