// Sound Engine — cinnamon_girl.mp3 ringtone + Web Audio API fallback

let ctx: AudioContext | null = null;
let ringAudio: HTMLAudioElement | null = null;
let ringbackInterval: ReturnType<typeof setInterval> | null = null;
let ringInterval: ReturnType<typeof setInterval> | null = null;
let sirenAudio: HTMLAudioElement | null = null;
let sirenInterval: ReturnType<typeof setInterval> | null = null;
let connectingTimeout: ReturnType<typeof setTimeout> | null = null;

export function getCtx(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function osc(freq1: number, freq2: number, duration: number, vol = 0.3, delay = 0) {
  const c = getCtx();
  const g = c.createGain();
  g.gain.setValueAtTime(vol, c.currentTime + delay);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + delay + duration);
  g.connect(c.destination);
  [freq1, freq2].forEach(f => {
    const o = c.createOscillator();
    o.frequency.value = f;
    o.type = "sine";
    o.connect(g);
    o.start(c.currentTime + delay);
    o.stop(c.currentTime + delay + duration);
  });
}

// ── RING TONE — cinnamon_girl.mp3 ──────────────────────────────────
export function startRingTone() {
  stopAllSounds();
  const audio = new Audio("/sounds/cinnamon_girl.mp3");
  audio.loop = true;
  audio.volume = 0.9;
  ringAudio = audio;
  audio.play().catch(() => {
    // Web Audio API fallback if autoplay blocked
    ringAudio = null;
    const doRing = () => {
      osc(480, 520, 0.5, 0.4);
      osc(480, 520, 0.5, 0.4, 0.65);
    };
    doRing();
    ringInterval = setInterval(doRing, 3500);
  });
}

// ── RINGBACK TONE (caller hears while waiting) ──────────────────────
export function startRingbackTone() {
  stopAllSounds();
  const doBeep = () => osc(440, 440, 0.9, 0.12);
  doBeep();
  ringbackInterval = setInterval(doBeep, 3000);
}

// ── CONNECTING ─────────────────────────────────────────────────────
export function playConnectingSound() {
  let i = 0;
  const beep = () => {
    osc(300 + i * 90, 320 + i * 90, 0.14, 0.22);
    i++;
    if (i < 5) connectingTimeout = setTimeout(beep, 190);
  };
  beep();
}

// ── HANGUP / GUDOK ─────────────────────────────────────────────────
export function playHangupSound() {
  osc(480, 480, 0.28, 0.45);
  setTimeout(() => osc(380, 380, 0.35, 0.3), 320);
  setTimeout(() => osc(260, 260, 0.5, 0.18), 700);
}

// ── CONNECTED CHIME ────────────────────────────────────────────────
export function playConnectedSound() {
  osc(520, 520, 0.14, 0.32);
  setTimeout(() => osc(660, 660, 0.18, 0.3), 155);
  setTimeout(() => osc(800, 800, 0.28, 0.28), 320);
}

// ── SIREN (admin alarm) ────────────────────────────────────────────
export function startSiren() {
  stopSiren();
  const c = getCtx();
  function chirp() {
    const g = c.createGain();
    g.gain.setValueAtTime(0.6, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.9);
    g.connect(c.destination);
    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(700, c.currentTime);
    o.frequency.linearRampToValueAtTime(1400, c.currentTime + 0.45);
    o.frequency.linearRampToValueAtTime(700, c.currentTime + 0.9);
    o.connect(g);
    o.start(c.currentTime);
    o.stop(c.currentTime + 0.95);
  }
  chirp();
  sirenInterval = setInterval(chirp, 950);
}

export function stopSiren() {
  if (sirenInterval) { clearInterval(sirenInterval); sirenInterval = null; }
  if (sirenAudio) { sirenAudio.pause(); sirenAudio = null; }
}

// ── MESSAGE PING ───────────────────────────────────────────────────
export function playMessageSound() {
  const c = getCtx();
  const g = c.createGain();
  g.gain.setValueAtTime(0.18, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.3);
  g.connect(c.destination);
  const o = c.createOscillator();
  o.frequency.setValueAtTime(900, c.currentTime);
  o.frequency.exponentialRampToValueAtTime(660, c.currentTime + 0.3);
  o.type = "sine";
  o.connect(g);
  o.start(c.currentTime);
  o.stop(c.currentTime + 0.35);
}

// ── PREMIUM SUCCESS SOUND ──────────────────────────────────────────
export function playPremiumSound() {
  [0, 150, 300, 500].forEach((d, i) => {
    setTimeout(() => osc(440 + i * 110, 440 + i * 110, 0.25, 0.35 - i * 0.05), d);
  });
}

export function stopAllSounds() {
  if (ringAudio) { ringAudio.pause(); ringAudio.currentTime = 0; ringAudio = null; }
  if (ringInterval) { clearInterval(ringInterval); ringInterval = null; }
  if (ringbackInterval) { clearInterval(ringbackInterval); ringbackInterval = null; }
  if (connectingTimeout) { clearTimeout(connectingTimeout); connectingTimeout = null; }
  stopSiren();
}
