import { useEffect, useState } from "react";
import { SessionManager } from "./session";
import AuthPage from "./pages/AuthPage";
import MainApp from "./pages/MainApp";
import { LangProvider } from "./lib/LangContext";

function NexusBoot() {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState(0);

  const phases = [
    "Tizim yadrosiinit...",
    "Firebase ulanmoqda...",
    "Moduli yuklanmoqda...",
    "Interfeys qurilmoqda...",
    "Tayyor!",
  ];

  useEffect(() => {
    const intervals: ReturnType<typeof setTimeout>[] = [];
    const targets = [20, 45, 68, 88, 100];
    const delays  = [0, 300, 600, 900, 1150];
    targets.forEach((t, i) => {
      intervals.push(setTimeout(() => {
        setProgress(t);
        setPhase(i);
      }, delays[i]));
    });
    return () => intervals.forEach(clearTimeout);
  }, []);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#030712] overflow-hidden">
      <style>{`
        @keyframes boot-ring-spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes boot-ring-spin-rev {
          from { transform: rotate(0deg); }
          to   { transform: rotate(-360deg); }
        }
        @keyframes boot-pulse-scale {
          0%,100% { transform: scale(1); opacity: 0.7; }
          50%      { transform: scale(1.12); opacity: 1; }
        }
        @keyframes boot-bar-shine {
          0%   { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        @keyframes boot-dot-bounce {
          0%,100% { transform: translateY(0); opacity: 0.3; }
          50%      { transform: translateY(-6px); opacity: 1; }
        }
        @keyframes boot-fade-in {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes boot-orb {
          0%,100% { transform: translate(0,0) scale(1); }
          33%      { transform: translate(20px,-14px) scale(1.05); }
          66%      { transform: translate(-14px,10px) scale(0.97); }
        }
        .boot-ring-1 { animation: boot-ring-spin 3s linear infinite; }
        .boot-ring-2 { animation: boot-ring-spin-rev 2s linear infinite; }
        .boot-ring-3 { animation: boot-ring-spin 5s linear infinite; }
        .boot-logo   { animation: boot-pulse-scale 2s ease-in-out infinite; }
        .boot-bar-shine {
          background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.18) 50%, transparent 100%);
          background-size: 200% auto;
          animation: boot-bar-shine 1.4s linear infinite;
        }
        .boot-orb { animation: boot-orb 6s ease-in-out infinite; }
        .boot-fade { animation: boot-fade-in 0.5s ease forwards; }
      `}</style>

      {/* Background orbs */}
      <div className="absolute w-80 h-80 rounded-full boot-orb pointer-events-none"
        style={{ top: "10%", left: "5%", background: "radial-gradient(circle, #22d3ee18, transparent 70%)", filter: "blur(40px)" }} />
      <div className="absolute w-64 h-64 rounded-full pointer-events-none"
        style={{ bottom: "15%", right: "8%", background: "radial-gradient(circle, #6366f118, transparent 70%)", filter: "blur(40px)", animation: "boot-orb 8s ease-in-out infinite 2s" }} />

      {/* Grid */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.025]"
        style={{ backgroundImage: "linear-gradient(#22d3ee 1px,transparent 1px),linear-gradient(90deg,#22d3ee 1px,transparent 1px)", backgroundSize: "40px 40px" }} />

      <div className="flex flex-col items-center gap-8 boot-fade">
        {/* Rings + Logo */}
        <div className="relative w-32 h-32 flex items-center justify-center">
          {/* Outer ring */}
          <svg className="absolute inset-0 boot-ring-1" viewBox="0 0 128 128" fill="none">
            <circle cx="64" cy="64" r="60" stroke="#22d3ee22" strokeWidth="1.5" />
            <circle cx="64" cy="64" r="60" stroke="url(#rg1)" strokeWidth="1.5"
              strokeDasharray="60 320" strokeLinecap="round" />
            <defs>
              <linearGradient id="rg1" x1="0" y1="0" x2="128" y2="128" gradientUnits="userSpaceOnUse">
                <stop stopColor="#22d3ee" />
                <stop offset="1" stopColor="#6366f1" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
          {/* Mid ring */}
          <svg className="absolute boot-ring-2" style={{ inset: "10px" }} viewBox="0 0 108 108" fill="none">
            <circle cx="54" cy="54" r="50" stroke="#6366f122" strokeWidth="1" />
            <circle cx="54" cy="54" r="50" stroke="url(#rg2)" strokeWidth="1.5"
              strokeDasharray="40 274" strokeLinecap="round" />
            <defs>
              <linearGradient id="rg2" x1="0" y1="0" x2="108" y2="108" gradientUnits="userSpaceOnUse">
                <stop stopColor="#a855f7" />
                <stop offset="1" stopColor="#22d3ee" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
          {/* Inner ring */}
          <svg className="absolute boot-ring-3" style={{ inset: "22px" }} viewBox="0 0 84 84" fill="none">
            <circle cx="42" cy="42" r="38" stroke="#a855f715" strokeWidth="1" />
            <circle cx="42" cy="42" r="38" stroke="#a855f7" strokeWidth="1"
              strokeDasharray="20 220" strokeLinecap="round" />
          </svg>
          {/* Icon */}
          <div className="boot-logo relative z-10 w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#22d3ee,#6366f1)", boxShadow: "0 0 40px #22d3ee44, 0 0 80px #6366f122" }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="white" />
            </svg>
          </div>
        </div>

        {/* Title */}
        <div className="text-center space-y-1">
          <p className="text-2xl font-black tracking-[0.2em]"
            style={{ background: "linear-gradient(90deg,#22d3ee,#6366f1,#a855f7)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            NEXUS_OS
          </p>
          <p className="text-[10px] text-slate-600 font-mono tracking-widest">CONNECTUZ TIZIMI · v5.6</p>
        </div>

        {/* Progress bar */}
        <div className="w-56 space-y-2">
          <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden relative">
            <div className="h-full rounded-full transition-all duration-500 relative overflow-hidden"
              style={{ width: `${progress}%`, background: "linear-gradient(90deg,#22d3ee,#6366f1)" }}>
              <div className="absolute inset-0 boot-bar-shine rounded-full" />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-mono text-slate-600 transition-all duration-300">{phases[phase]}</p>
            <p className="text-[10px] font-mono text-slate-700">{progress}%</p>
          </div>
        </div>

        {/* Dots */}
        <div className="flex gap-2">
          {[0, 1, 2].map(i => (
            <div key={i} className="w-1.5 h-1.5 rounded-full"
              style={{
                background: "#22d3ee",
                animation: `boot-dot-bounce 1.2s ease-in-out infinite ${i * 200}ms`,
              }} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [username, setUsername] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (SessionManager.isLoggedIn()) {
      setUsername(SessionManager.get());
    }
    const t = setTimeout(() => setLoading(false), 1400);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <NexusBoot />;

  if (!username) {
    return <AuthPage onLogin={(uname) => setUsername(uname)} />;
  }

  return (
    <LangProvider>
      <MainApp username={username} onLogout={() => { SessionManager.clear(); setUsername(null); }} />
    </LangProvider>
  );
}
