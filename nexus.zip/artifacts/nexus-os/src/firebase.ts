import { initializeApp, getApps, getApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyB-HS-QUOwGuzffhqNUwSUG1J62IzMhSaQ",
  authDomain: "nexusosuz-38925.firebaseapp.com",
  databaseURL: "https://nexusosuz-38925-default-rtdb.firebaseio.com",
  projectId: "nexusosuz-38925",
  storageBucket: "nexusosuz-38925.firebasestorage.app",
  messagingSenderId: "64933640003",
  appId: "1:64933640003:web:5e39c76862569d3e9f61f6",
  measurementId: "G-DY24E8HS9Q"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db = getDatabase(app);
export const storage = getStorage(app);
