export const SessionManager = {
  save(username: string) {
    localStorage.setItem("nexus_session", username);
  },
  get(): string | null {
    return localStorage.getItem("nexus_session");
  },
  clear() {
    localStorage.removeItem("nexus_session");
  },
  isLoggedIn(): boolean {
    return !!localStorage.getItem("nexus_session");
  }
};
