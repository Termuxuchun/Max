import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { type Lang, t, type Strings } from "./i18n";

interface LangContextType {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: keyof Strings) => string;
}

const LangContext = createContext<LangContextType>({
  lang: "uz",
  setLang: () => {},
  t: (key) => key as string,
});

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const stored = localStorage.getItem("nexus_lang") as Lang | null;
    return stored && ["uz", "ru", "en", "kk"].includes(stored) ? stored : "uz";
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-lang", lang);
  }, [lang]);

  function setLang(l: Lang) {
    setLangState(l);
    localStorage.setItem("nexus_lang", l);
    document.documentElement.setAttribute("data-lang", l);
  }

  const translate = (key: keyof Strings) => t(lang, key);

  return (
    <LangContext.Provider value={{ lang, setLang, t: translate }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  return useContext(LangContext);
}
