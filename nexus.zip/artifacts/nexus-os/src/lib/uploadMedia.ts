import { ref as storageRef, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { storage } from "../firebase";

/**
 * Faylni Firebase Storage ga yuklaydi va download URL qaytaradi.
 * @param path  Storage dagi yo'l, masalan "avatars/username"
 * @param file  File yoki Blob
 * @param onProgress  0-100 orasida progress callback (ixtiyoriy)
 */
export function uploadToStorage(
  path: string,
  file: File | Blob,
  onProgress?: (pct: number) => void
): Promise<string> {
  return new Promise((resolve, reject) => {
    const fileRef = storageRef(storage, path);
    const task = uploadBytesResumable(fileRef, file);

    task.on(
      "state_changed",
      snap => {
        if (onProgress && snap.totalBytes > 0) {
          onProgress(Math.round((snap.bytesTransferred / snap.totalBytes) * 95));
        }
      },
      err => reject(err),
      async () => {
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          onProgress?.(100);
          resolve(url);
        } catch (e) {
          reject(e);
        }
      }
    );
  });
}

/**
 * Rasmni canvas orqali JPEG ga siqib Storage ga yuklaydi.
 */
export function compressAndUpload(
  path: string,
  file: File,
  onProgress?: (pct: number) => void,
  maxPx = 1200,
  quality = 0.82
): Promise<string> {
  return new Promise((resolve, reject) => {
    onProgress?.(5);
    const img = new Image();
    const blobUrl = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(blobUrl);
      onProgress?.(20);
      const ratio = Math.min(1, maxPx / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
      const canvas = document.createElement("canvas");
      canvas.width  = Math.max(1, Math.round(img.naturalWidth  * ratio));
      canvas.height = Math.max(1, Math.round(img.naturalHeight * ratio));
      const ctx = canvas.getContext("2d");
      if (!ctx) { reject(new Error("Canvas yo'q")); return; }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      onProgress?.(35);
      canvas.toBlob(
        blob => {
          if (!blob) { reject(new Error("Blob hosil bo'lmadi")); return; }
          onProgress?.(40);
          uploadToStorage(path, blob, p => onProgress?.(40 + Math.round(p * 0.6)))
            .then(resolve)
            .catch(reject);
        },
        "image/jpeg",
        quality
      );
    };
    img.onerror = () => { URL.revokeObjectURL(blobUrl); reject(new Error("Rasm o'qilmadi")); };
    img.src = blobUrl;
  });
}
