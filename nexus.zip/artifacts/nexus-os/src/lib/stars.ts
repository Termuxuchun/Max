export interface StarPackage {
  id: string;
  amount: number;
  label: string;
  icon: string;
  price: string;
  popular?: boolean;
  gradient: string;
}

export const STAR_PACKAGES: StarPackage[] = [
  { id: "stars_100",  amount: 100,  label: "100 Stars",  icon: "⭐",  price: "0.99$",  gradient: "linear-gradient(135deg,#d97706,#fbbf24)" },
  { id: "stars_250",  amount: 250,  label: "250 Stars",  icon: "⭐⭐", price: "1.99$", popular: true, gradient: "linear-gradient(135deg,#c2410c,#fb923c)" },
  { id: "stars_500",  amount: 500,  label: "500 Stars",  icon: "🌟",  price: "3.99$",  gradient: "linear-gradient(135deg,#b45309,#fbbf24)" },
  { id: "stars_1000", amount: 1000, label: "1000 Stars", icon: "💫",  price: "6.99$",  gradient: "linear-gradient(135deg,#7c3aed,#fbbf24)" },
  { id: "stars_2500", amount: 2500, label: "2500 Stars", icon: "✨",  price: "14.99$", gradient: "linear-gradient(135deg,#be185d,#fbbf24)" },
  { id: "stars_5000", amount: 5000, label: "5000 Stars", icon: "🎆",  price: "24.99$", gradient: "linear-gradient(135deg,#1d4ed8,#fbbf24)" },
];

export const CHAT_ANIMATIONS = [
  { id: "none",    label: "Oddiy",   icon: "—" },
  { id: "pulse",   label: "Pulse",   icon: "💗" },
  { id: "glow",    label: "Glow",    icon: "✨" },
  { id: "rainbow", label: "Rainbow", icon: "🌈" },
  { id: "bounce",  label: "Bounce",  icon: "🏀" },
  { id: "float",   label: "Float",   icon: "🎈" },
  { id: "shake",   label: "Shake",   icon: "⚡" },
];

export function animClassForMsg(animation?: string): string {
  switch (animation) {
    case "pulse":   return "animate-[premium-pulse_2s_ease-in-out_infinite]";
    case "glow":    return "shadow-[0_0_20px_rgba(251,191,36,0.5),0_0_40px_rgba(99,102,241,0.2)] animate-[premium-glow_3s_ease-in-out_infinite]";
    case "rainbow": return "outline outline-2 animate-[rainbow-border_4s_linear_infinite]";
    case "bounce":  return "animate-[premium-bounce_1.5s_ease-in-out_infinite]";
    case "float":   return "animate-[premium-float_3s_ease-in-out_infinite]";
    case "shake":   return "animate-[premium-shake_0.5s_ease-in-out_infinite]";
    default:        return "";
  }
}
