export interface DeviceInfo {
  id: string;
  device: string;
  browser: string;
  os: string;
  addedAt?: number;
}

export function getDeviceId(): string {
  let id = localStorage.getItem("nx_device_id");
  if (!id) {
    id = typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID()
      : Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem("nx_device_id", id);
  }
  return id;
}

export function getDeviceInfo(): DeviceInfo {
  const ua = navigator.userAgent;
  return {
    id: getDeviceId(),
    device: /Mobi|Android/i.test(ua) ? "📱 Mobil" : "🖥️ Desktop",
    browser: ua.includes("Chrome") && !ua.includes("Edg")
      ? "Chrome"
      : ua.includes("Firefox")
      ? "Firefox"
      : ua.includes("Safari") && !ua.includes("Chrome")
      ? "Safari"
      : ua.includes("Edg")
      ? "Edge"
      : "Browser",
    os: ua.includes("Windows")
      ? "Windows"
      : ua.includes("Mac")
      ? "macOS"
      : ua.includes("Android")
      ? "Android"
      : /iPad|iPhone|iPod/.test(ua)
      ? "iOS"
      : ua.includes("Linux")
      ? "Linux"
      : "Unknown",
  };
}
