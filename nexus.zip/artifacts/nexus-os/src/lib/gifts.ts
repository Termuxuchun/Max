export interface GiftDef {
  id: string;
  name: string;
  icon: string;
  price: number;
  gradient: string;
  rarity: "common" | "rare" | "epic" | "legendary" | "mythic";
}

export const GIFTS: GiftDef[] = [
  { id: "rose",        name: "Atirgul",       icon: "🌹", price: 5,    gradient: "linear-gradient(135deg,#f43f5e,#ec4899)",              rarity: "common" },
  { id: "tulip",       name: "Lola",           icon: "🌷", price: 5,    gradient: "linear-gradient(135deg,#fb7185,#f43f5e)",              rarity: "common" },
  { id: "sunflower",   name: "Quyoshgul",      icon: "🌻", price: 7,    gradient: "linear-gradient(135deg,#fbbf24,#f59e0b)",              rarity: "common" },
  { id: "balloon",     name: "Shar",           icon: "🎈", price: 8,    gradient: "linear-gradient(135deg,#ef4444,#3b82f6)",              rarity: "common" },
  { id: "cake",        name: "Tort",           icon: "🎂", price: 10,   gradient: "linear-gradient(135deg,#fbbf24,#ec4899)",              rarity: "common" },
  { id: "candy",       name: "Konfet",         icon: "🍬", price: 6,    gradient: "linear-gradient(135deg,#e879f9,#f43f5e)",              rarity: "common" },
  { id: "coffee",      name: "Qahva",          icon: "☕", price: 8,    gradient: "linear-gradient(135deg,#92400e,#d97706)",              rarity: "common" },
  { id: "pizza",       name: "Pizza",          icon: "🍕", price: 10,   gradient: "linear-gradient(135deg,#dc2626,#fbbf24)",              rarity: "common" },
  { id: "icecream",    name: "Muzqaymoq",      icon: "🍦", price: 7,    gradient: "linear-gradient(135deg,#f9a8d4,#c084fc)",              rarity: "common" },
  { id: "bow",         name: "Kamoncha",       icon: "🎀", price: 9,    gradient: "linear-gradient(135deg,#ec4899,#f43f5e)",              rarity: "common" },
  { id: "popcorn",     name: "Popkorn",        icon: "🍿", price: 6,    gradient: "linear-gradient(135deg,#fbbf24,#ef4444)",              rarity: "common" },
  { id: "lollipop",    name: "Lolipop",        icon: "🍭", price: 5,    gradient: "linear-gradient(135deg,#fb923c,#ec4899)",              rarity: "common" },
  { id: "teddy",       name: "Ayiqcha",        icon: "🧸", price: 25,   gradient: "linear-gradient(135deg,#a16207,#fde68a)",              rarity: "rare" },
  { id: "champagne",   name: "Shampan",        icon: "🍾", price: 50,   gradient: "linear-gradient(135deg,#fde047,#84cc16)",              rarity: "rare" },
  { id: "guitar",      name: "Gitara",         icon: "🎸", price: 40,   gradient: "linear-gradient(135deg,#8b5cf6,#3b82f6)",              rarity: "rare" },
  { id: "moon_l",      name: "Oy Chirog'i",    icon: "🌙", price: 35,   gradient: "linear-gradient(135deg,#1e1b4b,#818cf8)",              rarity: "rare" },
  { id: "fire_g",      name: "Olov",           icon: "🔥", price: 30,   gradient: "linear-gradient(135deg,#dc2626,#f97316)",              rarity: "rare" },
  { id: "heart_g",     name: "Qizil Yurak",    icon: "❤️", price: 30,   gradient: "linear-gradient(135deg,#f43f5e,#ec4899)",              rarity: "rare" },
  { id: "money_bag",   name: "Pul Xaltasi",    icon: "💰", price: 50,   gradient: "linear-gradient(135deg,#15803d,#22c55e)",              rarity: "rare" },
  { id: "gem_r",       name: "Binafsha Tosh",  icon: "💜", price: 45,   gradient: "linear-gradient(135deg,#7c3aed,#c026d3)",              rarity: "rare" },
  { id: "butterfly",   name: "Kapalak",        icon: "🦋", price: 35,   gradient: "linear-gradient(135deg,#06b6d4,#8b5cf6)",              rarity: "rare" },
  { id: "mushroom",    name: "Sehr Qo'ziqorin",icon: "🍄", price: 40,   gradient: "linear-gradient(135deg,#ef4444,#fbbf24)",              rarity: "rare" },
  { id: "ring",        name: "Uzuk",           icon: "💍", price: 100,  gradient: "linear-gradient(135deg,#e0e7ff,#a5b4fc,#6366f1)",      rarity: "epic" },
  { id: "diamond_g",   name: "Olmos",          icon: "💎", price: 250,  gradient: "linear-gradient(135deg,#22d3ee,#3b82f6,#6366f1)",      rarity: "epic" },
  { id: "trophy_g",    name: "Kubok",          icon: "🏆", price: 150,  gradient: "linear-gradient(135deg,#fbbf24,#a16207)",              rarity: "epic" },
  { id: "crystal",     name: "Sehrli Kristal", icon: "🔮", price: 180,  gradient: "linear-gradient(135deg,#a855f7,#6366f1,#22d3ee)",      rarity: "epic" },
  { id: "lightning_g", name: "Chaqmoq",        icon: "⚡", price: 120,  gradient: "linear-gradient(135deg,#fde047,#f59e0b,#ef4444)",      rarity: "epic" },
  { id: "robot_g",     name: "AI Robot",       icon: "🤖", price: 200,  gradient: "linear-gradient(135deg,#0ea5e9,#6366f1,#7c3aed)",      rarity: "epic" },
  { id: "star_g",      name: "Zarhal Yulduz",  icon: "⭐", price: 130,  gradient: "linear-gradient(135deg,#fbbf24,#f59e0b,#dc2626)",      rarity: "epic" },
  { id: "skull_g",     name: "Oltin Bosh",     icon: "💀", price: 160,  gradient: "linear-gradient(135deg,#475569,#7c3aed,#0f172a)",      rarity: "epic" },
  { id: "crown_g",     name: "Oltin Toj",      icon: "👑", price: 500,  gradient: "linear-gradient(135deg,#f59e0b,#ec4899,#8b5cf6)",      rarity: "legendary" },
  { id: "rocket_g",    name: "Kosmik Raketa",  icon: "🚀", price: 300,  gradient: "linear-gradient(135deg,#8b5cf6,#ec4899,#f43f5e)",      rarity: "legendary" },
  { id: "unicorn_g",   name: "Yagona Shox",    icon: "🦄", price: 750,  gradient: "linear-gradient(135deg,#f472b6,#a78bfa,#38bdf8)",      rarity: "legendary" },
  { id: "dragon_g",    name: "Ajdaho",         icon: "🐉", price: 1000, gradient: "linear-gradient(135deg,#15803d,#22d3ee,#6366f1)",      rarity: "legendary" },
  { id: "planet",      name: "Saturn Sayyorasi",icon: "🪐", price: 800,  gradient: "linear-gradient(135deg,#7c3aed,#1e40af,#0ea5e9)",     rarity: "legendary" },
  { id: "phoenix_g",   name: "Feniks",         icon: "🦅", price: 900,  gradient: "linear-gradient(135deg,#dc2626,#f59e0b,#fde047)",      rarity: "legendary" },
  { id: "galaxy_g",    name: "Galaktika",      icon: "🌌", price: 1200, gradient: "linear-gradient(135deg,#1e1b4b,#4f46e5,#ec4899)",      rarity: "legendary" },
  { id: "nexus_orb",   name: "NEXUS Orb",      icon: "🔵", price: 2000, gradient: "linear-gradient(135deg,#22d3ee,#3b82f6,#8b5cf6,#ec4899)", rarity: "mythic" },
  { id: "black_hole",  name: "Qora Tuynuk",    icon: "🌑", price: 5000, gradient: "linear-gradient(135deg,#000000,#1e1b4b,#7c3aed)",      rarity: "mythic" },
  { id: "infinity",    name: "Cheksizlik",     icon: "♾️", price: 9999, gradient: "linear-gradient(270deg,#f59e0b,#22d3ee,#ec4899,#22c55e,#f59e0b)", rarity: "mythic" },
];

export function getGift(id?: string | null): GiftDef {
  return GIFTS.find(g => g.id === id) || GIFTS[0];
}

export const RARITY_STYLES: Record<GiftDef["rarity"], string> = {
  common:    "bg-slate-700/50 text-slate-300 border border-slate-600/40",
  rare:      "bg-blue-500/20 text-blue-300 border border-blue-500/40",
  epic:      "bg-purple-500/20 text-purple-200 border border-purple-500/50",
  legendary: "bg-gradient-to-r from-amber-500/25 to-rose-500/25 text-amber-200 border border-amber-400/50",
  mythic:    "bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 text-cyan-100 border border-cyan-400/60 holo-border",
};
