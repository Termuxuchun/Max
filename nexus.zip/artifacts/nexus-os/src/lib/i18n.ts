export type Lang = "uz" | "ru" | "en" | "kk";

export const LANG_NAMES: Record<Lang, string> = {
  uz: "O'zbek",
  ru: "Русский",
  en: "English",
  kk: "Qaraqalpaq",
};

export const LANG_FLAGS: Record<Lang, string> = {
  uz: "🇺🇿",
  ru: "🇷🇺",
  en: "🇬🇧",
  kk: "🏳️",
};

type Strings = {
  // Nav
  chats: string;
  feed: string;
  calls: string;
  contacts: string;
  channels: string;
  settings: string;
  games: string;
  diary: string;
  admin: string;
  logout: string;

  // Settings sections
  profile: string;
  appearance: string;
  animation: string;
  notifications: string;
  privacy: string;
  security: string;
  premium: string;
  about: string;
  language: string;
  chatSettings: string;
  keyboard: string;
  storage: string;

  // Profile
  profilePhoto: string;
  uploadPhoto: string;
  deletePhoto: string;
  bio: string;
  customStatus: string;
  displayName: string;
  save: string;
  saving: string;

  // Appearance
  theme: string;
  fontSize: string;
  wallpaper: string;
  compactMode: string;
  blurEffect: string;
  animations: string;
  small: string;
  medium: string;
  large: string;

  // Notifications
  sound: string;
  desktop: string;
  msgPreview: string;
  typingIndicator: string;
  autoPlayMedia: string;

  // Privacy
  onlineStatus: string;
  readReceipts: string;
  lastSeen: string;
  whoCanMessage: string;
  everyone: string;
  contactsOnly: string;
  nobody: string;
  blockedUsers: string;
  block: string;
  unblock: string;

  // Security
  changePassword: string;
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
  showPassword: string;
  twoFA: string;
  activeSessions: string;
  dangerZone: string;
  deleteAccount: string;

  // General
  on: string;
  off: string;
  enabled: string;
  disabled: string;
  saved: string;
  cancel: string;
  confirm: string;
  loading: string;
  online: string;
  offline: string;
  premiumOnly: string;
  search: string;

  // Chat
  enterSend: string;
  linkPreview: string;
  forwardHistory: string;
  msgFontSize: string;
  bubbleStyle: string;
  timeFormat: string;

  // Keyboard
  keyboardHeight: string;
  autocorrect: string;
  suggestions: string;
  hapticFeedback: string;
  soundFeedback: string;
  swipeToReply: string;

  // Storage
  cacheSize: string;
  clearCache: string;
  mediaStorage: string;
  autoDownload: string;
  downloadWifi: string;
  downloadMobile: string;

  // Language
  appLanguage: string;
  selectLanguage: string;
  languageChanged: string;

  // About
  version: string;
  buildDate: string;

  // Animations
  badge: string;
  badges: string;
  selectBadge: string;
  badgeRemoved: string;
  badgeSelected: string;
  premiumBadge: string;
};

const uz: Strings = {
  chats: "Chatlar",
  feed: "Lenta",
  calls: "Qo'ng'iroqlar",
  contacts: "Kontaktlar",
  channels: "Kanallar",
  settings: "Sozlamalar",
  games: "O'yinlar",
  diary: "Kundalik",
  admin: "Admin",
  logout: "Tizimdan chiqish",

  profile: "Profil",
  appearance: "Ko'rinish",
  animation: "Animatsiya",
  notifications: "Bildirishnomalar",
  privacy: "Maxfiylik",
  security: "Xavfsizlik",
  premium: "Premium",
  about: "Tizim",
  language: "Til",
  chatSettings: "Chat",
  keyboard: "Klaviatura",
  storage: "Saqlash",

  profilePhoto: "Profil rasmi",
  uploadPhoto: "📷 Rasm yuklash",
  deletePhoto: "🗑️ O'chirish",
  bio: "Bio / Tavsif",
  customStatus: "Maxsus status",
  displayName: "Ko'rsatish ismi",
  save: "Saqlash",
  saving: "⏳ Saqlanmoqda...",

  theme: "Mavzu rangi",
  fontSize: "Matn o'lchami",
  wallpaper: "Fon rangi",
  compactMode: "Ixcham rejim",
  blurEffect: "Blur effekti",
  animations: "Animatsiyalar",
  small: "Kichik",
  medium: "O'rta",
  large: "Katta",

  sound: "Ovozli signal",
  desktop: "Desktop bildirishnomalar",
  msgPreview: "Xabar ko'rinishi",
  typingIndicator: "Yozish indikatori",
  autoPlayMedia: "Media avtoyuklash",

  onlineStatus: "Online holat ko'rsatish",
  readReceipts: "O'qildi tasdiqlash (✔✔)",
  lastSeen: "Oxirgi kirish vaqti",
  whoCanMessage: "Kim menga yoza oladi",
  everyone: "Hammasi",
  contactsOnly: "Faqat kontaktlar",
  nobody: "Hech kim",
  blockedUsers: "Bloklangan foydalanuvchilar",
  block: "Blok",
  unblock: "Olib tashla",

  changePassword: "Parolni o'zgartirish",
  currentPassword: "Joriy parol",
  newPassword: "Yangi parol (min 4 belgi)",
  confirmPassword: "Yangi parolni tasdiqlang",
  showPassword: "Parolni ko'rsatish",
  twoFA: "Ikki bosqichli tekshiruv (2FA)",
  activeSessions: "Faol sessiyalar",
  dangerZone: "⚠️ Xavfli zona",
  deleteAccount: "🗑️ Hisobni butunlay o'chirish",

  on: "Yoqildi",
  off: "O'chirildi",
  enabled: "✅ Yoqildi",
  disabled: "🔕 O'chirildi",
  saved: "✅ Saqlandi",
  cancel: "Bekor",
  confirm: "Tasdiqlash",
  loading: "Yuklanmoqda...",
  online: "🟢 Onlayn",
  offline: "⚫ Oflayn",
  premiumOnly: "👑 Premium",
  search: "Qidirish...",

  enterSend: "Enter bilan yuborish",
  linkPreview: "Link ko'rinishi",
  forwardHistory: "Yo'naltirish tarixi",
  msgFontSize: "Xabar shrift o'lchami",
  bubbleStyle: "Xabar ko'rinishi",
  timeFormat: "Vaqt formati",

  keyboardHeight: "Klaviatura balandligi",
  autocorrect: "Avtomatik to'g'irlash",
  suggestions: "So'z tavsiyalari",
  hapticFeedback: "Tebranish (haptic)",
  soundFeedback: "Bosish tovushi",
  swipeToReply: "Swipe bilan javob berish",

  cacheSize: "Kesh hajmi",
  clearCache: "🧹 Keshni tozalash",
  mediaStorage: "Media saqlash",
  autoDownload: "Avtomatik yuklash",
  downloadWifi: "Wi-Fi da yuklab olish",
  downloadMobile: "Mobil internette yuklab olish",

  appLanguage: "Ilova tili",
  selectLanguage: "Tilni tanlang",
  languageChanged: "✅ Til o'zgartirildi",

  version: "Versiya",
  buildDate: "Qurilgan sana",

  badge: "Nishon",
  badges: "Nishonlar",
  selectBadge: "Nishon tanlang",
  badgeRemoved: "✅ Nishon olib tashlandi",
  badgeSelected: "✅ Nishon tanlandi",
  premiumBadge: "🔒 Nishon — faqat Premium uchun!",
};

const ru: Strings = {
  chats: "Чаты",
  feed: "Лента",
  calls: "Звонки",
  contacts: "Контакты",
  channels: "Каналы",
  settings: "Настройки",
  games: "Игры",
  diary: "Дневник",
  admin: "Админ",
  logout: "Выйти",

  profile: "Профиль",
  appearance: "Внешний вид",
  animation: "Анимации",
  notifications: "Уведомления",
  privacy: "Приватность",
  security: "Безопасность",
  premium: "Премиум",
  about: "О системе",
  language: "Язык",
  chatSettings: "Чат",
  keyboard: "Клавиатура",
  storage: "Хранилище",

  profilePhoto: "Фото профиля",
  uploadPhoto: "📷 Загрузить фото",
  deletePhoto: "🗑️ Удалить",
  bio: "Био / Описание",
  customStatus: "Статус",
  displayName: "Отображаемое имя",
  save: "Сохранить",
  saving: "⏳ Сохранение...",

  theme: "Цвет темы",
  fontSize: "Размер текста",
  wallpaper: "Цвет фона",
  compactMode: "Компактный режим",
  blurEffect: "Эффект размытия",
  animations: "Анимации",
  small: "Маленький",
  medium: "Средний",
  large: "Большой",

  sound: "Звуковой сигнал",
  desktop: "Desktop уведомления",
  msgPreview: "Просмотр сообщений",
  typingIndicator: "Индикатор набора",
  autoPlayMedia: "Автозагрузка медиа",

  onlineStatus: "Показывать статус онлайн",
  readReceipts: "Подтверждение прочтения (✔✔)",
  lastSeen: "Последнее появление",
  whoCanMessage: "Кто может писать мне",
  everyone: "Все",
  contactsOnly: "Только контакты",
  nobody: "Никто",
  blockedUsers: "Заблокированные пользователи",
  block: "Заблокировать",
  unblock: "Разблокировать",

  changePassword: "Изменить пароль",
  currentPassword: "Текущий пароль",
  newPassword: "Новый пароль (мин. 4 символа)",
  confirmPassword: "Подтвердите пароль",
  showPassword: "Показать пароль",
  twoFA: "Двухфакторная аутентификация",
  activeSessions: "Активные сессии",
  dangerZone: "⚠️ Опасная зона",
  deleteAccount: "🗑️ Удалить аккаунт навсегда",

  on: "Включено",
  off: "Выключено",
  enabled: "✅ Включено",
  disabled: "🔕 Выключено",
  saved: "✅ Сохранено",
  cancel: "Отмена",
  confirm: "Подтвердить",
  loading: "Загрузка...",
  online: "🟢 Онлайн",
  offline: "⚫ Офлайн",
  premiumOnly: "👑 Премиум",
  search: "Поиск...",

  enterSend: "Отправка по Enter",
  linkPreview: "Предпросмотр ссылок",
  forwardHistory: "История пересылки",
  msgFontSize: "Размер шрифта сообщений",
  bubbleStyle: "Стиль сообщений",
  timeFormat: "Формат времени",

  keyboardHeight: "Высота клавиатуры",
  autocorrect: "Автокоррекция",
  suggestions: "Предложения слов",
  hapticFeedback: "Тактильный отклик",
  soundFeedback: "Звук нажатий",
  swipeToReply: "Свайп для ответа",

  cacheSize: "Размер кэша",
  clearCache: "🧹 Очистить кэш",
  mediaStorage: "Хранилище медиа",
  autoDownload: "Автозагрузка",
  downloadWifi: "Скачивать по Wi-Fi",
  downloadMobile: "Скачивать по мобильному",

  appLanguage: "Язык приложения",
  selectLanguage: "Выберите язык",
  languageChanged: "✅ Язык изменён",

  version: "Версия",
  buildDate: "Дата сборки",

  badge: "Значок",
  badges: "Значки",
  selectBadge: "Выберите значок",
  badgeRemoved: "✅ Значок снят",
  badgeSelected: "✅ Значок выбран",
  premiumBadge: "🔒 Значки — только для Премиум!",
};

const en: Strings = {
  chats: "Chats",
  feed: "Feed",
  calls: "Calls",
  contacts: "Contacts",
  channels: "Channels",
  settings: "Settings",
  games: "Games",
  diary: "Diary",
  admin: "Admin",
  logout: "Log out",

  profile: "Profile",
  appearance: "Appearance",
  animation: "Animations",
  notifications: "Notifications",
  privacy: "Privacy",
  security: "Security",
  premium: "Premium",
  about: "About",
  language: "Language",
  chatSettings: "Chat",
  keyboard: "Keyboard",
  storage: "Storage",

  profilePhoto: "Profile photo",
  uploadPhoto: "📷 Upload photo",
  deletePhoto: "🗑️ Delete",
  bio: "Bio / Description",
  customStatus: "Custom status",
  displayName: "Display name",
  save: "Save",
  saving: "⏳ Saving...",

  theme: "Theme color",
  fontSize: "Font size",
  wallpaper: "Background color",
  compactMode: "Compact mode",
  blurEffect: "Blur effect",
  animations: "Animations",
  small: "Small",
  medium: "Medium",
  large: "Large",

  sound: "Sound",
  desktop: "Desktop notifications",
  msgPreview: "Message preview",
  typingIndicator: "Typing indicator",
  autoPlayMedia: "Auto-play media",

  onlineStatus: "Show online status",
  readReceipts: "Read receipts (✔✔)",
  lastSeen: "Last seen",
  whoCanMessage: "Who can message me",
  everyone: "Everyone",
  contactsOnly: "Contacts only",
  nobody: "Nobody",
  blockedUsers: "Blocked users",
  block: "Block",
  unblock: "Unblock",

  changePassword: "Change password",
  currentPassword: "Current password",
  newPassword: "New password (min 4 chars)",
  confirmPassword: "Confirm new password",
  showPassword: "Show password",
  twoFA: "Two-factor authentication",
  activeSessions: "Active sessions",
  dangerZone: "⚠️ Danger zone",
  deleteAccount: "🗑️ Delete account permanently",

  on: "Enabled",
  off: "Disabled",
  enabled: "✅ Enabled",
  disabled: "🔕 Disabled",
  saved: "✅ Saved",
  cancel: "Cancel",
  confirm: "Confirm",
  loading: "Loading...",
  online: "🟢 Online",
  offline: "⚫ Offline",
  premiumOnly: "👑 Premium",
  search: "Search...",

  enterSend: "Send with Enter",
  linkPreview: "Link preview",
  forwardHistory: "Forward history",
  msgFontSize: "Message font size",
  bubbleStyle: "Bubble style",
  timeFormat: "Time format",

  keyboardHeight: "Keyboard height",
  autocorrect: "Autocorrect",
  suggestions: "Word suggestions",
  hapticFeedback: "Haptic feedback",
  soundFeedback: "Key sound",
  swipeToReply: "Swipe to reply",

  cacheSize: "Cache size",
  clearCache: "🧹 Clear cache",
  mediaStorage: "Media storage",
  autoDownload: "Auto download",
  downloadWifi: "Download on Wi-Fi",
  downloadMobile: "Download on mobile data",

  appLanguage: "App language",
  selectLanguage: "Select language",
  languageChanged: "✅ Language changed",

  version: "Version",
  buildDate: "Build date",

  badge: "Badge",
  badges: "Badges",
  selectBadge: "Select badge",
  badgeRemoved: "✅ Badge removed",
  badgeSelected: "✅ Badge selected",
  premiumBadge: "🔒 Badges are Premium only!",
};

const kk: Strings = {
  chats: "Chatlar",
  feed: "Lenta",
  calls: "Qon'ırıwlar",
  contacts: "Kontaktlar",
  channels: "Kanallar",
  settings: "Parametrler",
  games: "Oyınlar",
  diary: "Kúndelik",
  admin: "Admin",
  logout: "Shıǵıw",

  profile: "Profil",
  appearance: "Kórinisi",
  animation: "Animaciya",
  notifications: "Xabarlar",
  privacy: "Maxpiylik",
  security: "Qáwipsizlik",
  premium: "Premium",
  about: "Sistema",
  language: "Til",
  chatSettings: "Chat",
  keyboard: "Klaviatura",
  storage: "Saqlawsh",

  profilePhoto: "Profil suwreti",
  uploadPhoto: "📷 Suwret júklew",
  deletePhoto: "🗑️ Óshiriw",
  bio: "Bio / Taswir",
  customStatus: "Maxsus status",
  displayName: "Kórsatiletugın at",
  save: "Saqlash",
  saving: "⏳ Saqlanıwda...",

  theme: "Tema rengi",
  fontSize: "Matn ólshemi",
  wallpaper: "Fon rengi",
  compactMode: "Ixsham rejim",
  blurEffect: "Blur effekti",
  animations: "Animaciyalar",
  small: "Kishi",
  medium: "Orta",
  large: "Úlken",

  sound: "Ses signal",
  desktop: "Desktop bildiriwler",
  msgPreview: "Xabar kórinisi",
  typingIndicator: "Jazıw indikatori",
  autoPlayMedia: "Media auto-júklen",

  onlineStatus: "Online statusın kórsetiw",
  readReceipts: "Oqıldı tastıyıqlawı (✔✔)",
  lastSeen: "Son kirgen waqtı",
  whoCanMessage: "Kim jazıwı múmkin",
  everyone: "Hámme",
  contactsOnly: "Tek kontaktlar",
  nobody: "Heshkim",
  blockedUsers: "Bloklangan paydalanıwshılar",
  block: "Bloklaw",
  unblock: "Bloktan shıǵarıw",

  changePassword: "Paroldi ózgertiw",
  currentPassword: "Házirgi parol",
  newPassword: "Jańa parol (min 4 simvol)",
  confirmPassword: "Jańa paroldi tastıyıqlaw",
  showPassword: "Paroldi kórsetiw",
  twoFA: "Eki basqıshlı tekseriw",
  activeSessions: "Aktiv sessiyalar",
  dangerZone: "⚠️ Qáwipli zona",
  deleteAccount: "🗑️ Esapti óshiriw",

  on: "Qosıldı",
  off: "Óshirildi",
  enabled: "✅ Qosıldı",
  disabled: "🔕 Óshirildi",
  saved: "✅ Saqlandı",
  cancel: "Biykar",
  confirm: "Tastıyıqlaw",
  loading: "Júkleniwde...",
  online: "🟢 Online",
  offline: "⚫ Offline",
  premiumOnly: "👑 Premium",
  search: "Izlew...",

  enterSend: "Enter menen jiberiw",
  linkPreview: "Link kórinisi",
  forwardHistory: "Jiberiw tarixi",
  msgFontSize: "Xabar shrift ólshemi",
  bubbleStyle: "Xabar kórinisi",
  timeFormat: "Waqıt formatı",

  keyboardHeight: "Klaviatura biyikligi",
  autocorrect: "Avtomatik túzetiw",
  suggestions: "Sóz usınısları",
  hapticFeedback: "Titerewish",
  soundFeedback: "Basıw awazı",
  swipeToReply: "Swipe menen jawap",

  cacheSize: "Kesh ólshemi",
  clearCache: "🧹 Keshti tazalaw",
  mediaStorage: "Media saqlawsh",
  autoDownload: "Avtomatik júklew",
  downloadWifi: "Wi-Fi da júklew",
  downloadMobile: "Mobil internette júklew",

  appLanguage: "Ilovа tili",
  selectLanguage: "Tildi tańlań",
  languageChanged: "✅ Til ózgertirildi",

  version: "Versiya",
  buildDate: "Qurılǵan sáne",

  badge: "Nıshan",
  badges: "Nıshanlar",
  selectBadge: "Nıshan tańlań",
  badgeRemoved: "✅ Nıshan alındı",
  badgeSelected: "✅ Nıshan tańlandı",
  premiumBadge: "🔒 Nıshanlar — tek Premium ushın!",
};

const translations: Record<Lang, Strings> = { uz, ru, en, kk };

export function t(lang: Lang, key: keyof Strings): string {
  return translations[lang]?.[key] ?? translations.uz[key] ?? key;
}

export { type Strings };
