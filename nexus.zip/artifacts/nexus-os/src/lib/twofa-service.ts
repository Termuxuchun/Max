import { ref, get, set, remove, update } from "firebase/database";
import { db } from "../firebase";
import { getDeviceId, getDeviceInfo } from "./device";

export function generateCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function isTwoFAEnabled(username: string): Promise<boolean> {
  const snap = await get(ref(db, `users/${username}/security/twoFA/enabled`));
  return snap.exists() && snap.val() === true;
}

export async function getMaxId(username: string): Promise<string | null> {
  const snap = await get(ref(db, `users/${username}/security/twoFA`));
  if (!snap.exists()) return null;
  const val = snap.val() as Record<string, unknown>;
  const id = val.telegramChatId ?? val.maxId;
  return id ? String(id) : null;
}

export async function isDeviceTrusted(username: string): Promise<boolean> {
  const deviceId = getDeviceId();
  const snap = await get(
    ref(db, `users/${username}/security/trustedDevices/${deviceId}`)
  );
  return snap.exists();
}

export async function storePendingCode(
  username: string,
  code: string
): Promise<void> {
  await set(ref(db, `twofa/${username}`), {
    code,
    expiresAt: Date.now() + 5 * 60 * 1000,
    attempts: 0,
    createdAt: Date.now(),
  });
}

export async function verifyCode(
  username: string,
  inputCode: string
): Promise<"ok" | "wrong" | "expired" | "max_attempts"> {
  const snap = await get(ref(db, `twofa/${username}`));
  if (!snap.exists()) return "expired";

  const data = snap.val() as {
    code: string;
    expiresAt: number;
    attempts: number;
  };

  if (Date.now() > data.expiresAt) {
    await remove(ref(db, `twofa/${username}`));
    return "expired";
  }

  if ((data.attempts || 0) >= 5) {
    return "max_attempts";
  }

  if (String(data.code) !== String(inputCode).trim()) {
    await update(ref(db, `twofa/${username}`), {
      attempts: (data.attempts || 0) + 1,
    });
    return "wrong";
  }

  await remove(ref(db, `twofa/${username}`));
  return "ok";
}

export async function trustCurrentDevice(username: string): Promise<void> {
  const info = getDeviceInfo();
  await set(
    ref(db, `users/${username}/security/trustedDevices/${info.id}`),
    {
      ...info,
      addedAt: Date.now(),
    }
  );
}

export async function sendCodeViaMax(
  username: string,
  telegramChatId: string,
  code: string
): Promise<boolean> {
  try {
    const res = await fetch("/api/2fa/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, maxId: telegramChatId, code }),
    });
    const data = (await res.json()) as { ok: boolean };
    return data.ok === true;
  } catch {
    return false;
  }
}
