import { push, ref } from "firebase/database";
import { db } from "../firebase";

export type ActivityType =
  | "friend_accept"
  | "event_created" | "event_rsvp"
  | "club_created"  | "club_joined" | "club_post"
  | "feed_post"     | "went_online";

export interface ActivityEntry {
  type: ActivityType;
  actor: string;
  targetUser?: string;
  entityName?: string;
  entityId?: string;
  ts: number;
}

export function logActivity(
  type: ActivityType,
  actor: string,
  meta?: { targetUser?: string; entityName?: string; entityId?: string }
): void {
  push(ref(db, "activity_feed"), { type, actor, ts: Date.now(), ...meta }).catch(() => {});
}
